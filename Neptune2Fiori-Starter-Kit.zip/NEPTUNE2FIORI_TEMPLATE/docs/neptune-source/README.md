# Neptune sources — ZDCI_NAD_PROJECT_REQ_LIST

Put here:
- `Backend Class/<name>.txt` — the Neptune backend class of the list app (SE24 → source-based view → copy all).
  This file is the only source of the class; the class in SAP is never read or referenced by the new solution.
- Optional: AJAX specs, DDIC printouts (`DB Model/`), Init/Global/Utility JavaScript, UI specs — if they exist.

Source order when files disagree: XML export / live capture > ABAP source > SE11 > JS > specs (playbook §Source of truth).
