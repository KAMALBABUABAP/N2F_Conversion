# Neptune export — ZDCI_NAD_PROJECT_REQ_LIST

Put here:
- `zdci_nad_project_req_list.xml` — the Neptune designer XML export of the app (the source of truth for every
  control id, attribute, binding, event script, AJAX object and script function).
- `app.css` and any shared JS library the app loads (e.g. `discoveryFiori.js`), if different from the copies in
  `../../../NEPTUNE2FIORI_PROJREQ/docs/neptune-export/`.
- Template files (`.xlsx`) the app offers for download, if any.

Never read the XML by hand: session S1 parses it with `docs/capture/parse_export.py`.
