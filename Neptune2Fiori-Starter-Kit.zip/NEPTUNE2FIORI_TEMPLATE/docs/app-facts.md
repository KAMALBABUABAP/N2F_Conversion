# App facts — Neptune `<NEPTUNE_APP>` → SEGW OData V2 + freestyle SAPUI5

Facts and owner decisions known **before** the kit is built. Fill §1–§3 before K0. K0 reads this file first,
confirms each row marked *to confirm*, adds §4–§6 from the export, and moves confirmed rows into `CLAUDE.md` and
the naming registry.

## 1. Owner decisions

| Topic | Decision | Status |
|---|---|---|
| Neptune app | `<NEPTUNE_APP>` — <one line: what the app does> | |
| Method | apple-to-apple, same names, behaviour incl. bugs (`PARITY P-xx`), SEGW OData V2 envelope, freestyle SAPUI5, licence removal (`NEPTUNE`), one-line comments with the transport number, macOS zsh | |
| New object names rule | e.g. Neptune "NAD" → "UI" for the new ABAP/SEGW objects | |
| Related apps | parent/child apps it opens or is opened by (Neptune `discoveryFiori.ParentComponent` / `ChildComponent`); embed or launchpad navigation? | |
| System / client | `<SYSTEM>` / `<CLIENT>` (DEV) | |
| Package | `<PACKAGE>` | |
| Workbench transport | `<TR_WB>` | |
| Customizing transport | `<TR_CU>` (service registration, launchpad) | |

## 2. Proposed names (confirmed in K0 — nothing is created before the owner's "yes")

| Object | Proposed name | Rule / check |
|---|---|---|
| UI5 app id / component namespace | `<neptune_app in lower case>` | exact Neptune app name, lower case |
| Logic class | `ZCL_UI_<…>` | from the Neptune class name; ≤ 30 chars |
| SEGW project | `<…>` | ≤ 30 chars |
| OData service / model | `<project>_SRV` / `<project>_MDL`, version 1 | SEGW default |
| MPC / DPC classes | SEGW default `ZCL_<first 18 chars of project>_MPC…` | **check the default does not already exist** (another app with the same 18-char prefix) — else override in the generate dialog |
| BSP application | `<…>` | ≤ 15 chars |

## 3. Inputs

| What | Where | Present? |
|---|---|---|
| Neptune backend class source | `docs/neptune-source/Backend Class/` | |
| Neptune XML export | `docs/neptune-export/` | |
| MIME files (`app.css`, shared JS, templates) | `docs/neptune-export/` | |
| Screenshots (window width in the file name) | `docs/capture/layout/neptune/` | |
| HAR **report** (never the `.har`) | `docs/capture/` | optional |

## 4. What the screenshots show (K0 — ASSUMPTION until checked against the export)

## 5. Contracts with other apps (K0)

## 6. Open questions for K0

---
Created using Anthropic Claude — internal working document; keep it on internal versions until a human has reviewed and verified the content.
