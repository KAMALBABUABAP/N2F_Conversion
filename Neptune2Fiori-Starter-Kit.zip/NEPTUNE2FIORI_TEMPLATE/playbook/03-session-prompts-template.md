# Session prompts — template for any Neptune → Fiori conversion

K0 copies this file to `docs/claude-code-session-prompts.md` of the project and replaces every `<PLACEHOLDER>`
(table below). One prompt = one new Claude Code chat. Shape of every prompt (owner standard): rules → skill →
read first → **Actions (Create / Update / Delete)** → Scope → Out of scope → Replacement log → When done.

**Start a chat:** terminal in the project folder → the "Start with" command. VS Code panel instead: new chat, `/model <model>`,
first line *Read `.claude/agents/<agent>.md` and follow it as your rules for this whole session.* SAP-writing sessions
belong in a terminal started with `--agent` (a subagent cannot ask for your "yes"). End: commit, `/exit`.

## Placeholders

| Placeholder | Meaning | Example (first project) |
|---|---|---|
| `<PROJECT>` | project folder | `NEPTUNE2FIORI_PROJREQ` |
| `<NEPTUNE_APP>` | Neptune app id | `ZDCI_NAD_PROJECT_REQUEST` |
| `<APP_ID>` | UI5 app id = folder in `src/ui5/` | `zdci_nad_project_request` |
| `<EXPORT_FILE>` | XML export in `docs/neptune-export/` | `zdci_nad_project_request.xml` |
| `<CLASS_TXT>` | Neptune class source in `docs/neptune-source/Backend Class/` | `ProjectRequest App.txt` |
| `<UI_CLASS>` | new logic class | `ZCL_UI_PROJECT_CODE_REQUEST` |
| `<SEGW>` / `<SRV>` | SEGW project / service | `ZDCI_UI_PROJECT_REQUEST` / `…_SRV` |
| `<MPC>` `<MPC_EXT>` `<DPC>` `<DPC_EXT>` | generated classes (registry 01) | `ZCL_ZDCI_UI_PROJECT_RE_MPC` … |
| `<BSP>` | BSP application | `ZUI_PROJREQCODE` |
| `<REG>` | registry skill name | `nad-project-request-registry` |
| `<SYS>` `<CLIENT>` `<PACKAGE>` | target | `S4M` `100` `ZMDG` |
| `<TR_WB>` `<TR_CU>` | workbench / customizing transport | `S4MK927514` / `S4MK927516` |
| `<INIT_AJAX_ID>` | the AJAX call the app makes on start (spike) | `GET_DATA` |
| `<IGNORE>` | volatile fields for `parity_diff.py` | `FORM_GUID STEP_GUID START_TIME LATEST_STARTTIME` |

## Standard blocks (prompts refer to them by name; the agent reads them from this file)

**[SAP]** Target (you cannot read `.env`): system `<SYS>`, client `<CLIENT>`, package `<PACKAGE>`, workbench `<TR_WB>`,
customizing `<TR_CU>`. Call `ListSapSystems` first; pass `system` and `client` on every SAP tool call (the server default is
another system; never production). Before the first write: a "Confirm target" block (system, client, user, package,
transport, objects, repo files) and wait for my "yes"; apply my modifiers literally. DEV only; never release transports;
never delete objects. If a source write fails with HTTP 413: create the shell via MCP, tell me to run
`pbcopy < src/abap/<file>` and paste in SE24/ADT (save, do not activate), then verify by counts and syntax check.
Show every activation result. What MCP cannot do (SEGW, `/IWFND/MAINT_SERVICE`, cache cleanup, Gateway Client, error
log, launchpad) → exact click path, then wait for my result. Save every successful response I paste under `docs/capture/`.

**[LIC-READ]** Licence log: list every name you read that starts with or contains NEPTUNE (namespace /NEPTUNE/, data
element, structure, class, interface, variable, MIME/ICF path, literal, description) and every Neptune runtime API without
the word (`getOnline*`, `SERVER->API_*`, `sap.n.*`, `ModelData`). Replace nothing. Propose the standard SAP object of the same
type and length. Write `docs/replacements/<SESSION>-replacements.txt` in the register format ("RESULT: none found" if none)
and add proposed rows to `docs/replacements/framework-replacement-register.md`.

**[LIC-BUILD]** Licence rule: nothing you create or change may start with or contain NEPTUNE or use /NEPTUNE/ — code,
comments (also yours), texts, CSS, yaml, manifest, descriptions. Replace with a standard SAP data element/structure of the
same type and length or a local type from standard data elements; never a new DDIC object without my approval. Write
`docs/replacements/<SESSION>-replacements.txt` ("RESULT: none found" if none) and add rows to the register.

**[ALSO]** Also allowed when the change requires it — list each in your summary: `verify_kit.py` exception lines (one
comment naming the P-xx, nothing else), `smoke.js` expectations / known-error filter (`// PARITY P-xx`), unit-test
fixtures, registry rows that mention the changed ids, the rule docs (`binding-rules.md`, `js-port-rules.md`,
`spec-gaps.md`). Any other file outside the lists: stop and ask.

**[DONE]** Run `python3 .claude/scripts/verify_kit.py` and, in `src/ui5/<APP_ID>`, `npm run test:unit` (+ the smoke test if
the webapp changed: `npm run start-smoke` on port 8081, `npm run test:smoke`); show the real last lines; report a skipped
check as skipped. List every file touched outside the lists. Commit on `main`, only this session's files (never `.env`,
`*.har`, `.DS_Store`), with the message given; never push. Documents end with "Created using Anthropic Claude" + review note.

## Contents

| # | Session | Start with | Model | CRUD |
|---|---|---|---|---|
| K0, K1 | Kickoff + backend assets (before S0) | see the project's `KICKOFF-PROMPT.md` | Opus 5.5 | R · C · U (project folder) |
| 1 | S0 Setup check | `claude --model sonnet` | Sonnet 5.5 | R · C (log) |
| 2 | S1 Export audit | `claude --agent neptune-parity-reviewer` | Opus 5.5 | R · C (report, parser) |
| 3 | S2a AJAX layer from the export | `claude --agent neptune-ui5-converter` | Opus 5.5 | R · C · U |
| 4 | S2b Client library shim | `claude --agent neptune-ui5-converter` | Opus 5.5 | R · C · U |
| 5 | S2c Events, functions, formatters | `claude --agent neptune-ui5-converter` | Opus 5.5 | R · C · U |
| 6 | S2d View: ids, attributes, bindings, texts, CSS, dialogs | `claude --agent neptune-ui5-converter` | Opus 5.5 | R · U |
| 7 | S2L Layout check offline | `claude --agent neptune-ui5-converter` | Opus 5.5 | R · C · U (after OK) |
| 8 | R1 Review of S2 | `claude --agent neptune-parity-reviewer` | Opus 5.5 | R · C (report) |
| 9 | R1-fix | `claude --agent neptune-ui5-converter` | Opus 5.5 | R · U |
| 10 | B0 DDIC, dependencies, licence scan | `claude --agent neptune-abap-converter` | Opus 5.5 | R · U (registry) |
| 11 | B1 Logic class | `claude --agent neptune-abap-converter` | Opus 5.5 | R · C · U |
| 12 | B2 SEGW project (guided) | `claude --agent neptune-abap-converter` | Sonnet 5.5 | R · U (registry) |
| 13 | B3 MPC_EXT / DPC_EXT + spike | `claude --agent neptune-abap-converter` | Opus 5.5 | R · U |
| 14 | B3b Import model into SEGW | `claude --agent neptune-abap-converter` | Opus 5.5 | R · U |
| 15 | B4 Every AJAX ID | `claude --agent neptune-abap-converter` | Opus 5.5 | R · C (results) |
| 16 | B5–B7 Backend parity, stream, hand-off | `claude --agent neptune-abap-converter` | Opus 5.5 | R · U |
| 17 | F0/F1 Offline checks | `claude --agent neptune-ui5-converter`, then `/model sonnet` | Sonnet 5.5 | R · C (local) |
| 18 | F3 Against DEV | `claude --agent neptune-ui5-converter` | Opus 5.5 | R · U |
| 19 | S5 Parity test | `claude` | Opus 5.5 | R · C · U |
| 20–23 | LIC-1 find · LIC-2 check · LIC-3 write repo · LIC-4 SAP (only if LIC-2 hit) | reviewer · reviewer · ui5-converter · abap-converter | Opus 5.5 | R / R / U / U |
| 24 | R2 Review before sign-off | `claude --agent neptune-parity-reviewer` | Opus 5.5 | R · C (log) |
| 25 | S6 Deploy BSP + launchpad | `claude --agent neptune-ui5-converter`, then `/model sonnet` | Sonnet 5.5 | R · C · U |
| 26 | Q&A | `claude --agent neptune-parity-reviewer`, then `/model sonnet` | Sonnet 5.5 | R |
| 27 | Rollback / decommission plan | `claude` | Opus 5.5 | R · C (plan) |

Backend 10–14 can run in parallel with 3–9. 18 needs 13 passed. 19 needs 16 and 18.

---

## 1 · S0 Setup check

```text
Run session S0 (setup check) for <PROJECT>. Read CLAUDE.md and README.md first. Use the skill n2f-s0-setup-check.
Actions: Read only. Run verify_kit.py; in src/ui5/<APP_ID> run npm install (if node_modules is missing), npx playwright install chromium (ask first), npm run test:unit. Call ListSapSystems and one read-only tool (GetClass CL_ABAP_CHAR_UTILITIES) with system <SYS> client <CLIENT>; read CVERS for SAP_BASIS, SAP_UI, SAP_GWFND, S4CORE. Create only docs/replacements/S0-replacements.txt. Update: nothing (list the .env keys I must fill; you cannot read .env). Delete: nothing.
Scope: kit check, unit test, skills/agents/MCP servers seen, SAP ADT MCP tools grouped read/write/activate/test/transport/other, nested duplicate folders, missing input files (export, class, MIME files).
Out of scope: any SAP write, any file change.
[LIC-READ] with SESSION=S0.
When done: last lines of each check, the tool table, release table, missing inputs, next session.
```

## 2 · S1 Export audit (read-only)

```text
Run session S1 (export audit) for <NEPTUNE_APP>. Read CLAUDE.md, the skill <REG> (references 03, 04, 08, 09) and playbook/01-method.md §5 first. You run as neptune-parity-reviewer. Use the skill n2f-s1-coverage-audit with docs/neptune-export/<EXPORT_FILE>.
Actions: Read the export (only through docs/capture/parse_export.py), docs/neptune-source/, src/ui5/<APP_ID>/webapp/. Create/Update only docs/capture/parse_export.py (taken from the reference project, extend the type map only), docs/capture/export-extract/*.json, docs/coverage-report.md, docs/replacements/S1-replacements.txt. Delete: nothing.
Scope: 1) --structure, show it, wait for my OK. 2) --summary: every FIELD_TYPE with count; any type not in the map → show its attributes and children and propose the mapping (control / aggregation node / data-only / none); wait for my OK. 3) --extract: controls (DISABLED flag), attributes by GROUPING, bindings, events, AJAX objects with [model, ABAP attr, send, receive] via IT_MODEL+IT_BINDING, scripts, formatters, texts, CSS, header (UI5 version, theme). 4) The class: every WHEN branch of the AJAX dispatcher, branches that call api_message_create; AJAX objects without caller/branch (dead). 5) Coverage tables vs the kit + "Answers to open items".
Out of scope: fixing anything, registries, SAP.
[LIC-READ] with SESSION=S1.
When done: counts per status, unknown node types and the agreed mapping, top 10 blockers, which S2 prompt first. Commit: "S1 export audit".
```

## 3 · S2a AJAX layer from the export

```text
Build/close the AJAX layer of <APP_ID> from the export. Read docs/coverage-report.md (AJAX area), docs/capture/export-extract/ajax.json, registry 04 and references/ajax-client.md first. Follow neptune-ui5-converter; skill n2f-s2-close-gaps.
Actions: Update only webapp/util/AjaxConfig.js, webapp/util/ModelRegistry.js, registry 03 and 04, and the getOnline<Name> stubs in the controller. Create: nothing else. Delete: pairs that are not in the export (the only removal allowed), dead AJAX objects (one P-xx).
Scope: per AJAX ID: fn = export FIELD_NAME, send/receive pairs exactly as IT_MODEL resolved via IT_BINDING, evidence "CAP" with the export FIELD_ID; sysMessage receive only for branches that call api_message_create. Show the table before editing.
[ALSO] [LIC-BUILD] with SESSION=S2a. [DONE] commit "S2a AJAX layer from export".
```

## 4 · S2b Client library shim

```text
Port the client libraries the app loads (docs/neptune-export/discoveryFiori.js and any other MIME JS) into webapp/util/ as sap.ui.define modules. Read the originals and references/spec-gaps.md §C first. Follow neptune-ui5-converter.
Actions: Update only webapp/util/discoveryFiori.js (and other util shims), spec-gaps.md, registry 05. Create: a util module only for a library the export loads. Delete: SHIM-RECONSTRUCTED markers you replaced.
Scope: same object structure and method names, bodies verbatim except the mechanical replacements; Neptune-only runtime (module paths /neptune/…, shell APIs) → runtime replacement + P-xx; window-event contracts between parent and child apps kept 1:1. Method table before editing.
[ALSO] [LIC-BUILD] with SESSION=S2b. [DONE] commit "S2b client library ported".
```

## 5 · S2c Events, functions, formatters

```text
Port every event script, script function and formatter of the export into webapp/controller/. Read docs/coverage-report.md (events, functions), export-extract events/scripts, references/js-port-rules.md first. Follow neptune-ui5-converter.
Actions: Update only the controller(s), the event attributes and formatter wiring in view/fragments XML (wiring only), registry 05, spec-gaps.md. Create: methods named <controlId>_<event>, <id>_<property> formatters, Neptune function names, <AJAX_ID>_ajaxSuccess/_ajaxError. Delete: TODO markers you replaced.
Scope: bodies verbatim (even a missing semicolon), local aliases at the top, only the mechanical replacements; calls to things that never existed → guarded + P-xx; crash-midway scripts → lines before the crash as code, rest commented (P-xx). Plan per group before editing.
[ALSO] [LIC-BUILD] with SESSION=S2c. [DONE] commit "S2c events and functions from export".
```

## 6 · S2d View: ids, attributes, bindings, texts, CSS, dialogs

```text
Build/close the view of <APP_ID> from the export. Read docs/coverage-report.md (ids, attributes, texts), references/binding-rules.md and playbook/01-method.md §5 first. Follow neptune-ui5-converter.
Actions: Update only webapp/view/**, i18n/i18n.properties, css/app.css (byte copy of the MIME file), registries 03 and 08. Create: fragments for dialogs only. Delete: controls with DISABLED=X (one P-xx), properties not in the export.
Scope: section by section (show the plan per section, wait for my OK): copy only properties the export has, bindings via binding-rules ({ATTR-FIELD} → {X>/FIELD}); aggregation nodes → aggregations, never wrapper controls; dialog buttons via associations; Translate folder → i18n; texts verbatim (typos kept).
[ALSO] [LIC-BUILD] with SESSION=S2d. [DONE] counts before/after; commit "S2d view from export".
```

## 7 · S2L Layout check offline

```text
Layout check of <APP_ID> against the Neptune screenshots in docs/capture/layout/neptune/ (window width in the file name). Read playbook/01-method.md §6 first. Follow neptune-ui5-converter.
Actions: Read the export extract, the view, the screenshots. Create docs/layout-parity.md, screenshots docs/capture/layout/localhost/pw_<section>_<width>.png, a throwaway Playwright script in the scratchpad. Update view XML only after my decision per row. Delete: nothing.
Scope: container level first, then header/toolbar/theme, then fields/columns; classes A/C/D/V; headless Chromium on port 8081 with the smoke mock, viewports = Neptune width and one wider; geometry from the DOM. Grep before moving any id.
[ALSO] [LIC-BUILD] with SESSION=S2L. [DONE] commit "S2L layout parity".
```

## 8 · R1 Review of S2 · 9 · R1-fix

```text
R1: Review the S2 batch of <APP_ID>. You are neptune-parity-reviewer (read-only). Read CLAUDE.md, registries 01/05/08 first. Strict diffs: apply the allowed mechanical replacements to both sides, then line/token diff; comments separately. Create only docs/review-S2.md and docs/replacements/review-S2-replacements.txt. Output: severity | finding | evidence | suggested action | owner agent; then checks passed. [LIC-READ] with SESSION=review-S2.
```
```text
R1-fix: Fix exactly these review findings: <R-1 … R-n with the decided action>. Follow neptune-ui5-converter. Update only the files named per finding. [ALSO] [LIC-BUILD] with SESSION=S2-fix. [DONE] commit "S2 review fixes R-1..R-n".
```

## 10 · B0 DDIC, dependencies, licence scan

```text
Run backend step B0 for <NEPTUNE_APP>. Read CLAUDE.md, the skill neptune-to-segw-backend (B0), registry 09 first. Follow neptune-abap-converter (read-only part of abap-adt-workflow). [SAP]
Actions: Read via ADT MCP the DDIC of every structure/table/table type the class uses, TFDIR for every FM it calls, every Z class it calls. Update only registry 09 (and 07 for new boolean/date fields). Create docs/replacements/B0-replacements.txt. Delete: nothing.
Scope: live DDIC vs docs/neptune-source/DB Model/ (if present); FMs/classes that do not exist (dynamic calls!); licence scan of shared objects (components, domains, row types of all Z* DDIC; SearchSource in shared classes; type groups → tell me to check SE11) — a hit in another team's object is a go-live blocker: name it.
[LIC-READ] with SESSION=B0. When done: table object | field | printout | live | consequence; blockers. Commit "B0 DDIC confirmed".
```

## 11 · B1 Logic class

```text
Run backend step B1: create <UI_CLASS> in DEV. Read the skill (B1), references/class-conversion-changes.md first. Follow neptune-abap-converter and abap-adt-workflow. [SAP]
Actions: Run assets/convert_class.py "docs/neptune-source/Backend Class/<CLASS_TXT>" with <TR_WB> as 4th argument; diff with src/abap/<UI_CLASS>.clas.abap (only <TR> may differ); save. Create the class <UI_CLASS> only (package <PACKAGE>, transport <TR_WB>). Update its source (expect HTTP 413 for a large class → [SAP] fallback), syntax check, activate. Update transports/transport-log.md. Delete: nothing.
Scope: the counted change groups only; a TYPE-POOLS line if activation needs it ("<TR_WB> activation"). Verify: method list = Neptune − 6 interface methods + HANDLE_ON_AJAX/HANDLE_ON_REQUEST; <TR> comment count; 0 "neptune"; no inactive parts.
Out of scope: logic changes, refactoring, test classes, SEGW.
[LIC-BUILD] with SESSION=B1. When done: verification table + standard ABAP response block. Commit "B1 <UI_CLASS> activated" only after activation was seen.
```

## 12 · B2 SEGW project (guided)

```text
Run backend step B2: guide me through SEGW project <SEGW>. Read the skill (B2), references/segw-steps.md, registry 01 first. Follow neptune-abap-converter.
Actions: Give the click path (description without "Neptune", empty Data Model, package <PACKAGE>, transport <TR_WB>). In the Generate Runtime Objects dialog the class names MUST be <MPC>, <MPC_EXT>, <DPC>, <DPC_EXT> from registry 01 — check first via MCP that none of them exists. After my report read the generated classes via MCP. Update only registry 01 and transports/transport-log.md. Create/Delete: nothing yourself.
[LIC-BUILD] with SESSION=B2. When done: standard ABAP response block with the 4 names + transport object list. Commit "B2 SEGW project <SEGW> generated".
```

## 13 · B3 MPC_EXT / DPC_EXT + spike

```text
Run backend step B3. Read the skill (B3), references/gateway-api-checklist.md, troubleshooting.md, registry 02 first. Follow neptune-abap-converter. [SAP]
Actions: Check gc_self and class names in src/abap/<MPC_EXT>/<DPC_EXT>; replace <TR>; set lc_gen_date_time later than the generated MPC timestamp. Write + check + activate MPC_EXT first, then DPC_EXT. D/T properties: set_internal_type( typekind_char ) (date trap). Update transports/transport-log.md. Delete: nothing.
Scope: click paths for /IWFND/MAINT_SERVICE (alias LOCAL; tell me which transports it asks for: <TR_CU>), both cache cleanups; check_metadata.py on the $metadata I save as docs/capture/metadata-B3.xml; spike POST /sap/opu/odata/sap/<SRV>/AJAXSet with assets/gateway-client/00_spike_<INIT_AJAX_ID>.json; pass criteria from the skill. Save the successful response as docs/capture/spike-B3.json.
Out of scope: changing <UI_CLASS>, COMMIT WORK in DPC_EXT, renaming OData names, B4 before the spike passes.
[LIC-BUILD] with SESSION=B3. When done: pass/fail per criterion + ABAP response block. Commit "B3 spike passed" only after all criteria pass.
```

## 14 · B3b Import model into SEGW

```text
Run backend step B3b. Read the skill (B3b) and docs/capture/metadata-B3.xml, spike-B3.json first. Follow neptune-abap-converter. [SAP]
Actions: Reduce src/abap/<MPC_EXT> (keep super->define, deep type, TS_* types, bind_structure, the D/T char fix), bump lc_gen_date_time, do not activate until I imported. Click path: Data Model → Import → Data Model from File → Custom Import → all; Media on ATTACHMENT (if any); Generate (same names). Then activate MPC_EXT/DPC_EXT, cache cleanups. Update transport log.
Scope: new $metadata saved as metadata-B3b.xml must equal B3 (names, keys, Edm types, facets, associations); spike again → parity_diff.py with spike-B3.json → no difference, dates still yyyyMMdd. Any difference: STOP, restore MPC_EXT from git, report.
[LIC-BUILD] with SESSION=B3b. Commit "B3b model imported into SEGW".
```

## 15 · B4 Every AJAX ID

```text
Run backend step B4 for <SRV>. Read registry 04 and assets/gateway-client/ first. Follow neptune-abap-converter.
Actions: For each AJAX ID give me the body (asset or derived from the last <INIT_AJAX_ID> response), expected result and DB effect. I save request, response AND status line in docs/capture/b4/. Run queries/*.sql read-only. Create only docs/backend-ajax-results.md. Update registry 04 only with evidence.
Scope: tell me before any state-changing call (test record); parity behaviour counts as pass; send every GT_* as [] (deferred navigation otherwise).
[LIC-READ] with SESSION=B4. When done: AJAX ID | HTTP | key fields | DB effect | pass/fail. Commit "B4 AJAX IDs tested".
```

## 16 · B5–B7 Backend parity, stream, hand-off

```text
Run backend steps B5–B7. Read registry 05, 06 and the skill (B5–B7) first. Follow neptune-abap-converter. [SAP]
Actions: parity_diff.py --ignore <IGNORE> on Neptune vs OData pairs in docs/capture/; fixes only in MPC_EXT/DPC_EXT or registries, else new P-xx; B6 media stream (if the app has attachments); B7 hand-off section in docs/backend-ajax-results.md (service URL, generated names, model state, open items for F3). Update transport log.
[LIC-BUILD] with SESSION=B5-B7. Commit "B5-B7 backend parity and hand-off".
```

## 17 · F0/F1 Offline checks

```text
Run F0 and F1 for <APP_ID>. Read the skill neptune-to-ui5-frontend (F0, F1), references/test-plan.md §1 first. Follow neptune-ui5-converter; skill n2f-s4-frontend F0-F1.
Actions: npm install, npm run test:unit, smoke (server on 8081), npm run lint against the target UI5 version; explain each lint finding (expected vs real). Update webapp only for a mechanical fix, after asking.
[LIC-BUILD] with SESSION=F0F1. [DONE] commit only if a file changed: "F1 offline checks".
```

## 18 · F3 Against DEV

```text
Run F3: <APP_ID> against <SRV> on DEV. Read references/ajax-client.md, test-plan.md §2, the B7 hand-off first. Follow neptune-ui5-converter.
Actions: Update ui5.yaml (host, client <CLIENT>, UI5 version = the system's from sap-ui-version.json), webapp files only for defects proven against Neptune behaviour, registries for confirmed facts. Credentials only via FIORI_TOOLS_USER / read -s FIORI_TOOLS_PASSWORD.
Scope: npm start; test-plan §2 start rows; read the ported Init before writing test URLs (parameter case); every failure via ajax-client.md §Troubleshooting; backend issues → list for the ABAP agent.
[LIC-BUILD] with SESSION=F3. [DONE] commit "F3 frontend on DEV".
```

## 19 · S5 Parity test

```text
Run S5: Neptune vs UI5 side by side for <NEPTUNE_APP>. Read test-plan.md §2–3 and registry 05 first. Use n2f-s5-parity-test, one row at a time.
Actions: Read the bodies I save in docs/capture/ and the DB via queries/*.sql (read-only). Create docs/parity-results.md. Update webapp only for proven UI differences (verbatim rules), registry 05 for new P-xx.
Scope: every row, every role; parity_diff.py --ignore <IGNORE>; visibility/enabled/required per step; confirm the open V/C items (theme: Neptune console getTheme(); width bands).
[LIC-BUILD] with SESSION=S5. [DONE] commit "S5 parity results".
```

## 20–23 · Licence sweep

```text
LIC-1 (neptune-parity-reviewer, read-only): find every NEPTUNE name and every Neptune runtime API without the word in the export (parse_export.py, never by hand; ignore designer container tags), the original class and the JS copies. Map each getOnline*/SERVER->API_*/sap.n.*/ModelData use to its kit replacement or MISSING. Create docs/replacements/LIC-1-replacements.txt + proposed register rows.
LIC-2 (neptune-parity-reviewer, read-only, [SAP] read only): check the converted repo code and SAP DEV objects (ours + shared dependencies) against LIC-1; re-verify every register row marked done. Create docs/replacements/LIC-2-replacements.txt.
LIC-3 (neptune-ui5-converter): apply repo-only fixes from LIC-2, add verify_kit checks (with a negative test), complete the register. [LIC-BUILD] [DONE].
LIC-4 (neptune-abap-converter, main session, only if LIC-2 found SAP hits): fix our SAP objects. [SAP] [LIC-BUILD] [DONE].
```

## 24 · R2 Review before sign-off

```text
Review <PROJECT> before sign-off. You are neptune-parity-reviewer (read-only). Re-run convert_class.py and diff with src/abap/; verify_kit.py; unit test; read SAP objects read-only. Check names, ported bodies (strict diff), backend change groups, DPC_EXT without logic/COMMIT, registry consistency, open INF/TODO markers, overrides respected. Create only docs/replacements/review-replacements.txt. [LIC-READ] with SESSION=review. Output: severity | finding | evidence | action | owner agent.
```

## 25 · S6 Deploy

```text
Run S6: deploy <APP_ID> to BSP <BSP> on DEV and repoint the existing launchpad tile. Read references/deployment.md, common/standards/transport-management.md, docs/parity-results.md first. Follow neptune-ui5-converter; skill n2f-s6-deploy. [SAP]
Actions: npm run build (show dist/), npm run deploy after my "yes" (transport <TR_WB>; BSP description without "Neptune"); update ui5-deploy.yaml and the transport log. I change the target mapping (customizing <TR_CU>).
Out of scope: new tiles, QA/PRD, releasing transports, removing the Neptune app.
[LIC-BUILD] with SESSION=S6. When done: deploy log summary, post-deploy checks (SE80, SICF, /UI5/APP_INDEX_CALCULATE, open tile). Commit "S6 deployed to <BSP> (DEV)".
```

## 26 · Q&A · 27 · Rollback / decommission plan

```text
Q&A: Answer my question about <NEPTUNE_APP> or its conversion from the registries, CLAUDE.md, docs/. Cite file:line; if not in the files say so (ASSUMPTION). Read only, no SAP beyond read. Question: <question>
```
```text
Rollback/decommission plan for <NEPTUNE_APP>: read the transport log, deployment.md §5, docs/decommission-and-ecc.md. Create only docs/rollback-decommission-plan.md: hypercare rollback (repoint target mapping), decommission candidates with dependencies (parent/child apps, shared library, other users of the Neptune class — where-used first), the transport and approval per step. Nothing is executed. [LIC-READ] with SESSION=rollback.
```

---
Created using Anthropic Claude — internal working document; keep it on internal versions until a human has reviewed and verified the content.
