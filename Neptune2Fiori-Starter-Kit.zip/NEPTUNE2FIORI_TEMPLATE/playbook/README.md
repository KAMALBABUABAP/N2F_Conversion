# Neptune → Fiori playbook (generic)

Shareable method for converting any Neptune DXP app into a SEGW OData V2 service + freestyle SAPUI5 app with Claude
Code, consolidated from the first conversion (NEPTUNE2FIORI_PROJREQ) on 2026-10-27. Nothing here is specific to one
app except the examples, which are marked.

| File | Use it for |
|---|---|
| `01-method.md` | Principles (copy into each project's `CLAUDE.md`), architecture, session sequence with gates, how the owner works, export map, layout method, model per session |
| `02-lessons-learned.md` | Pre-flight checklist and every lesson of the first conversion, with evidence |
| `03-session-prompts-template.md` | All session prompts with `<PLACEHOLDERS>` and the standard blocks [SAP], [LIC-READ], [LIC-BUILD], [ALSO], [DONE] |
| `04-reuse-map.md` | Which file of a finished project to copy as is, adapt, or rebuild |

**New conversion:** create `projects/NEPTUNE2FIORI_<NAME>/` with this skeleton (copy the folder structure and
`docs/app-facts.md` pattern of NEPTUNE2FIORI_PROJLIST), drop the inputs, run a K0 kickoff prompt adapted from
`../KICKOFF-PROMPT.md` (replace the app-specific lines).

**Moving to `common/` later (owner's decision, not done yet):** move this folder to `common/playbooks/neptune2fiori/`,
change the relative paths in `../KICKOFF-PROMPT.md` and in each project's `CLAUDE.md`, and keep the reference project
pointer (`projects/NEPTUNE2FIORI_PROJREQ`) or replace it with the generic scripts once they are extracted
(`04-reuse-map.md` marks them AS IS). After each conversion, add its lessons to `02-lessons-learned.md`.

---
Created using Anthropic Claude — internal working document; keep it on internal versions until a human has reviewed and verified the content.
