# Lessons learned — first conversion (NEPTUNE2FIORI_PROJREQ, 2026-10-16 … 2026-10-27)

Generic lessons from the 20 Claude Code chats of the first conversion (Neptune `ZDCI_NAD_PROJECT_REQUEST`) and its
repo (registries, transport log, `docs/`). Evidence = chat date/time (the reference project's chat history) or a
reference-project file. App-specific facts appear only where they illustrate a rule.

## 0. Pre-flight checklist for the next app (do these before building anything)

- [ ] Neptune XML export **and** the MIME files the app loads (`discoveryFiori.js`, `app.css`, templates) are in `docs/neptune-export/`.
- [ ] The Neptune class source is in `docs/neptune-source/Backend Class/`; source paths are fixed and every check **fails** (not skips) when a path is missing.
- [ ] All new object names are decided **before** SEGW, including the four generated MPC/DPC class names (collision check against existing classes).
- [ ] Neptune screenshots with the window width; one HAR **report** of the Neptune app if possible (confirms booleans/dates).
- [ ] `.env` filled by the owner (Claude cannot read it); system/client/package/transports also written in every SAP prompt.
- [ ] `npm install` + `npx playwright install chromium` done in S0.
- [ ] Shared dependencies of the class (FMs, `ZCL_ND_*`, type groups) scanned for `/NEPTUNE/` in B0 — a hit in another team's object is a go-live blocker to raise early.

## 1. Inputs and the XML export

- **Build from the export, not from specs.** The first kit (from specs/PDF/OCR) matched the export in only 1,073 of 1,751 compared rows (182 different, 356 missing, 140 extra): invented handlers, wrong bound fields, placeholder texts, AJAX handlers copied from the wrong call, DISABLED controls shown, swapped `rows`/`cols`. Four rework sessions (S2a–S2d) followed. (10-18 03:07)
- **Parse with a script, agree the structure first**: `--structure` → owner OK → `--summary` → `--extract` to JSON in `docs/capture/export-extract/` → `--compare`. The root has an XML namespace (match local names); `ET.tostring` escapes `>` (read attribute values directly). (10-18 03:07)
- **Send/receive contract** = `IT_MODEL` rows resolved through `IT_BINDING`. Rows whose control has no Model Source sent nothing — do not invent payloads. AJAX objects with no caller and no active `WHEN` branch are dead → not ported, one P-xx. (10-18 03:37)
- **`DISABLED=X` = not rendered.** Remove the control and subtree from the view, keep its handlers, one P-xx listing all. (10-18 12:12)
- **Aggregation nodes are not controls** (`UM5_OPSUBC`, `UM5_BARCON`, `UM5_OPCONT`, `UM5_RESFOL`); see `01-method.md` §5. The kit rule "wrap in a VBox with the same id" broke the ObjectPage two-column layout and was found only in layout parity. (10-20 16:20)
- The export can be **newer** than text copies of the scripts (`Utility.txt` lacked a URL parameter); export spelling of ids wins over control-tree docs. (10-18 03:07, 12:12)
- Every `/NEPTUNE/` in export container tags is harmless, but every `VALUE` and script line must be scanned because it is ported. The export had ~7,800 tag hits and 5 real `/neptune/` paths. (10-18 03:07, 10-20 18:53)

## 2. Frontend (SAPUI5)

- **Order of the UI build:** AJAX layer → client library shim (`discoveryFiori`, `ModelData`) → events/functions/formatters → view. Porting the shim after the handlers left six buttons throwing errors for a session. (10-18 11:28)
- Adding a handler is useless without the **event attribute in the XML** — allow wiring edits across view and controller in the same session. (10-18 11:28)
- Copy only properties the export has; remove invented ones (`forceSelection`, `layout`, `labelSpan*`, `width`, `class`, expression bindings). Respect `editable` vs `enabled`. Copy wrong-looking values verbatim (invalid colour `Green`, `class="false"`); skip only properties that do not exist in the target UI5 version and log them. (10-18 12:12, 15:42)
- Bindings to an attribute that no ancestor owns (copied from another app) → unbound, all in one provisional P-xx with a switch rule after a production check. (10-18 12:12)
- `displayFormat="date:SAPUserDefault"` → unset (UI5 default follows the FLP user format), P-xx. (10-18 12:12)
- JS port: method = Neptune function name; events `<id>_<event>`; AJAX `<AJAX_ID>_ajaxSuccess/_ajaxError`; `getOnline<Name>` = export AJAX `FIELD_NAME`; bodies verbatim incl. a missing semicolon; ids passed to UI5 APIs go through `getControlName(id)` (`this.createId`). Calls to functions that never existed → keep, guard with `typeof … === "function"`, P-xx. A script that crashed midway in Neptune → port the lines before the crash, comment the rest (P-48). (10-18 03:37, 11:28)
- Runtime replacements the owner accepted: `goBack` fallback to `CrossApplicationNavigation.backToPreviousApp()` when no parent; `sap.ushell.Container.setDirtyFlag` in `setDirty`. (10-18 11:54)
- Texts: i18n key = control name, value verbatim (typos kept); hidden Translate-folder texts are i18n keys too; a missing key shows the key name. CSS = byte copy of the MIME `app.css`, loaded once via manifest. (10-18 12:12)
- Original library bugs produce console errors in tests — reproduce minimally before blaming the port; add known parity errors to the smoke filter with `// PARITY P-xx`. (10-18 11:54, 12:12)
- Lint against the **target** UI5 version (warnings for 1.119+ APIs are noise on 1.108). (10-18 12:12)
- Rendered `UI5_TABLE` / tree tables must stay `sap.ui.table.*`; never-rendered model holders may stay as they are in `<dependents>`. (10-18 12:12)

## 3. Backend (ABAP, SEGW, Gateway)

- **B0 — live DDIC differs from printouts** (new fields, lengths, CHAR→STRING, new keys). Check TFDIR for every FM the class calls: a missing FM called dynamically does not stop activation but dumps at runtime. (10-18 16:07)
- **Licence scan must include shared objects.** `ZCL_ND_CA_UTILITIES` used `/NEPTUNE/LOCK_*`; once the add-on is removed the whole shared class stops compiling. Pattern: where-used (class level only via MCP; SearchSource covers main sources only — state the limits) → in our copy comment out the calls as a counted group → P-xx + R-xx naming the other team. Scan components/domains/row types of all `Z*` DDIC for "NEPTUNE", then filter. Type-group source cannot be read via MCP → manual SE11. (10-18 16:07, 16:32)
- **Converter with counted change groups**; each group aborts on a different match count; diff output vs working copy: only `<TR>` and the new group may differ. Verify after writing by counts (41/41 `<TR>` lines, 8/8 markers, 0 "neptune", method count, no inactive objects), not by line numbers — SE24 re-sorts methods. (10-18 16:32)
- **HTTP 413 on large writes** through the BTP ADT MCP (216 KB class): create the shell via MCP → owner `pbcopy < src/abap/<class>.clas.abap` and pastes in SE24/ADT, saves inactive → Claude verifies and checks. EU 510 "currently editing" = the owner's own editor holds the lock (leave change mode/close the tab, SM12). Small classes (MPC_EXT/DPC_EXT) wrote fine. (10-18 16:32, 19:17)
- **SEGW** generates with an empty Data Model; do not hand-model anything MPC_EXT creates (duplicate error). SEGW truncates the project name in class names (`ZDCI_UI_PROJECT_REQUEST` → `ZCL_ZDCI_UI_PROJECT_RE_MPC…`) — decide names before B2; renaming the project mid-B2 touched 26 kit files. Transport afterwards holds IWPR, 4 classes, IWMO, IWSV, SUSH. Descriptions without "Neptune". (10-18 17:17)
- **Write MPC_EXT, activate, then DPC_EXT** (DPC_EXT uses `MPC_EXT=>TS_AJAX_DEEP`). `lc_gen_date_time` must be **later** than the generated MPC's timestamp and bumped on every change (`<TR> Bump timestamp on every change`). `/IWBEP/CX_MGW_BUSI_EXCEPTION` `MESSAGE` is `BAPI_MSG` → `CONV #( … )`. (10-18 19:17)
- **Date trap (most important):** Gateway writes ABAP `D` as ISO `yyyy-mm-dd` even for `Edm.String MaxLength=8` → HTTP 500 `invalid value '0000-00-00'` while writing the response. Fix in MPC_EXT: for D/T properties `set_internal_type( cl_abap_typedescr=>typekind_char )` before binding → wire `yyyyMMdd`/`HHmmss`, `$metadata` unchanged. Must survive B3b (unproven in the first project). (10-18 19:17)
- Empty dates differ per structure (`''` vs `00000000`) — compare with Neptune. STRING flags arrive as `"true"/"false"`: convert only in the client registry, never `Edm.Boolean`. (10-19 12:41)
- **Deep insert returns inline only the navigation properties that were sent**; the client sends every `GT_*` as `[]` on every call. Entity key = `AJAX_ID` only. (B4 results)
- Service registration: `/IWFND/MAINT_SERVICE`, alias LOCAL, standard ICF mode; note which transports it asked for. After every MPC/DPC change: `/IWFND/CACHE_CLEANUP` + `/IWBEP/CACHE_CLEANUP` + hard reload. Errors: `/IWFND/ERROR_LOG` → newest → Error Context. (10-18 19:17)
- **Save every successful SAP response** under the exact name later steps expect (the successful spike was never saved; B3b needs it). Save HTTP status lines in B4; run the DB queries. (10-19 12:41, B4)

## 4. Local run against DEV

- `ui5.yaml` `fiori-tools-proxy`: backend `/sap` → `http://<host>:8000`, `client`, UI5 version = the **system's** (`sap-ui-version.json`). Credentials only via `FIORI_TOOLS_USER` / `read -s FIORI_TOOLS_PASSWORD`, unset afterwards. (repo `local-test-quickref.md`)
- `AjaxRuntime` = plain `fetch` POST with its own CSRF (fetch token, retry once on 403 `required`); no ODataModel, no `$batch`.
- URL parameters are read case-sensitively by the ported Init (`form_guid`, `mode` lower case) — read the code before writing test URLs. (10-20 18:59)

## 5. Layout

- Root cause of "one column instead of two": the aggregation-node wrappers (§1). Rule: one block per form in `moreBlocks`. UI5 1.108 ObjectPage: block grid uses container width (75 % − 2rem with `TitleOnLeft`); M = 2 columns, L = 1, XL = 3; one block = full width. (10-20 16:20)
- Measure in a headless browser at the Neptune width; the 1440 px estimate was wrong. Width-band behaviour and theme are V/C parity items (P-65, P-64), confirmed in S5 on the real Neptune app. (10-20 16:20)
- Many apparent layout differences are data (enabled/required flags, value-help icons on disabled fields, different user/form). Test with mock data that enables fields before changing the view. (10-20 16:20)
- Screenshots in `.docx`: unzip `word/media/*`, keep order, note pixel size (Retina 2×). (10-20 16:20)

## 6. Tooling, MCP, permissions

- VS Code panel: `/mcp` can say "connected" while tools are not loaded → Developer: Reload Window, `/mcp`, sign in. (10-16)
- `ListSapSystems` also lists production — the guard is discipline; never call PRD, even read-only, without a go-ahead. Read-only proof: `GetClass CL_ABAP_CHAR_UTILITIES`; release: `CVERS` via SQL. (10-16, 10-18 02:58)
- Permission rules deny reading `.env` and compound commands containing `rm -rf`; do not work around — run commands one by one, print what the owner must set. (10-16, 10-18)
- MCP SQL preview: long IN-lists break the parser; columns shift after NULL (rows are right). (10-18 16:07)
- Session skills with `disable-model-invocation` are read as files when a prompt names them. (10-18 02:58)
- Port 8080 is the owner's `npm start`; tests/screens on 8081. Python on the Mac is 3.9 (no backslash in f-string expressions). abaplint not installed → SAP syntax check is the ABAP gate. (10-18, 10-20)

## 7. Process and kit quality

- Most rework came from the **pre-built kit** (spec-based webapp, wrong rule docs, MPC_EXT timestamp, fallback entity, `MESSAGE` type, date bug, "Neptune" in descriptions). Validate every asset against the export and a real system before trusting it. (10-18 14:36 review)
- A compare tool that calls ≥ 85 % similar "same" hid real differences; use strict token/line diffs after applying the allowed mechanical replacements; check comments separately. (10-18 14:36, 15:42)
- New `verify_kit.py` checks need a negative test (must print KIT NOT OK on the old bad value); checks must **fail** when their input is missing (check 8 silently skipped after a folder move and still printed KIT OK). (10-18 15:42, 10-20 16:20)
- Pristine kit assets drift from the working app; decide per fix whether the assets change too. (10-18 15:42)
- Run the read-only reviewer in its own chat between batches; then one fix session with an exact list (R-1 … R-n). (10-18 14:36 → 15:42)
- Layout was checked only after real data ran on localhost; do an offline screenshot comparison right after the view is built. (10-20 16:20)
- Licence sweep as 3+1 prompts (find → check → write repo → SAP only if needed), covering runtime APIs without the word. (10-20 18:53)
- Git: stay on `main` when told; check `git status` before checkout; stage only listed files. (10-18 03:37)

## 8. Still open in the first project (affects the list app)

- B3b (SEGW import) not done; whether the D/T fix survives the reduced MPC_EXT is unproven → the list app should reuse whatever B3b of the request app proves.
- Request app BSP `ZUI_PROJREQCODE` not deployed yet (S6) → needed before the list app opens it on DEV.
- `ZCL_ND_CA_UTILITIES` lock methods (other team) block go-live of both apps if the list class uses that class too.
- P-64 (theme) and P-65 (width bands) to confirm on the real Neptune app; the list app inherits the same questions.

---
Created using Anthropic Claude — internal working document; keep it on internal versions until a human has reviewed and verified the content.
