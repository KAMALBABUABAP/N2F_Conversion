# Neptune → Fiori conversion method (generic)

How to convert one Neptune DXP app into a **SEGW OData V2 service + freestyle SAPUI5 app**, apple-to-apple,
with Claude Code and the SAP ADT MCP server. Written from the first conversion (NEPTUNE2FIORI_PROJREQ,
2026-10-12 … 2026-10-27); every rule below was either agreed with the owner or learned the hard way
(`02-lessons-learned.md`). App-specific values are `<placeholders>`.

## 1. Fixed principles (copy into every project's `CLAUDE.md`)

| # | Principle | Detail |
|---|---|---|
| 1 | **No name changes** | Every Neptune name is reused byte-for-byte: ABAP class members, AJAX IDs, DDIC, control ids, model names, JS function names, i18n keys, texts (typos included). New objects only from the project's naming registry `01`. Anything else new → stop and ask |
| 2 | **Parity including bugs** | Behaviour that looks wrong is copied and logged as the next `P-xx` in the parity log, marked `PARITY P-xx` in code. Never a silent fix. Runtime replacements are allowed **only** where the Neptune runtime/shell itself is gone (launchpad back, dirty flag, module paths) — each one is a `P-xx` "runtime replacement for …" |
| 3 | **Evidence before code** | Source order: Neptune XML export / live capture > Neptune ABAP source > live SE11 > Neptune JS text copies > specs/PDFs. Never "Fiori migration" snippets from specs (they rename). Guesses are marked `TODO(SPEC-MISSING)` / `ASSUMPTION` |
| 4 | **Architecture** | SEGW OData V2 "AJAX-mirror envelope": one deep-insert `POST AJAXSet` per Neptune AJAX call; every OData name = ABAP name; no RAP, CAP, Fiori elements; no `$batch` (the copied class commits) |
| 5 | **Logic class** | Neptune-free 1:1 copy `ZCL_UI_<…>` of the Neptune class (`ZCL_NAD_<…>`) produced by a converter script with **counted change groups**; no refactoring, no Clean ABAP, no test class. The original class is never read from SAP or referenced; its `.txt` copy in the repo is the source |
| 6 | **Licence removal** | No SAP object, type, data element, structure, variable, MIME/ICF path, literal, description or comment used by the new solution may start with or contain `NEPTUNE` or use `/NEPTUNE/` — including Claude's own comments and SEGW/BSP/transport descriptions. Replace with standard SAP objects of the same type/length; log every case in `docs/replacements/` (register R-xx + one `<session>-replacements.txt` per chat, "RESULT: none found" if none). The only accepted reason to change an original name |
| 7 | **Comments** | Keep every original comment. Every new conversion comment is **one short line**: `<TR> few words` (e.g. `" S4MK900123 Interface removed`), a parity id at the end if any (`(P-63)`); no words that hint at the removed product ("framework", "Neptune") |
| 8 | **SAP access** | ADT MCP, DEV only, `system` + `client` on **every** call (server default is another system), `ListSapSystems` first; "Confirm target" block + owner "yes" before the first write of a session; never QA/PRD, never release transports, never delete unasked. SAP writes only in a main session started **as** the agent (`claude --agent …`), never a subagent |
| 9 | **Evidence of results** | Never claim activation, test, deploy or "works" without having seen the tool output or the owner's paste. A commit message that claims success waits for that success |
| 10 | **macOS zsh only** | No PowerShell; one command per call when the permission rules deny compound commands; avoid `echo "==="` (zsh) |
| 11 | **Files are the memory** | Sessions share nothing; hand-over through registries, `docs/`, `transports/`. Update the registry in the same change that confirms/corrects a fact |

## 2. Architecture

```
<Main>.view.xml (+ fragments)            every id = Neptune control name; designer aggregation nodes are NOT controls
   │ bindings {X>/FIELD}                  X = nearest control that owns the Model Source
<Main>.controller.js                     every Neptune function, same name, body verbatim (js-port-rules)
   │ getOnline<Name>(value)               the Neptune AJAX object FIELD_NAME
util/AjaxRuntime.js ──POST AJAXSet──▶ <SRV> (DPC_EXT) ──▶ ZCL_UI_<…>->handle_on_ajax( ajax_id, ajax_value )
   │ Send/Receive per util/AjaxConfig.js (from export IT_MODEL + IT_BINDING), ABAP⇄JS per JsonConversionRegistry
   └─ <AJAX_ID>_ajaxSuccess / _ajaxError  (export ajaxSuccess/ajaxError code)
util/ModelData.js, util/discoveryFiori.js  ports of the Neptune client APIs the code calls
MPC_EXT: model built from ABAP types by RTTI (B3), later imported into the SEGW Data Model (B3b)
```

Parent ↔ child apps (Neptune `discoveryFiori.ParentComponent` / `ChildComponent`): the parent loads the child in a
`ComponentContainer` with `componentData: { child: true }` and talks through window CustomEvents
(`data-from-parent`, `<cName>child-loaded`, `<cName>-data-from-child`, `go-back`). Keep the contract 1:1 on both sides;
the module path `/neptune/<app>` becomes the child's BSP path (licence replacement).

## 3. Session sequence (one Claude Code chat per row; prompts in `03-session-prompts-template.md`)

Improved order — the first project built the UI from specs and needed four rework sessions plus a late layout fix.

| Phase | Session | Goal | Gate to pass before the next phase |
|---|---|---|---|
| 0 | **K0 Kickoff** | Inventory inputs, ask the owner, build the project kit (CLAUDE.md, agents, skills, registries skeleton, scripts, prompts, app scaffold) from the reference project + playbook | owner "yes" on names; `verify_kit.py` → KIT OK |
| 0 | **K1 Backend assets (offline)** | Class converter rebuilt for the new class (counted groups, dry-run table), MPC_EXT/DPC_EXT with the new names and types, Gateway Client bodies, spike criteria, SQL | 0 "neptune" in the generated class; method list as expected |
| 0 | **S0 Setup check** | kit check, `npm install`, `npx playwright install chromium`, unit test, MCP tool list, `ListSapSystems`, read-only proof, release from `CVERS`, empty `.env` keys (owner fills) | S0 log written |
| 1 | **S1 Export audit** | Parse the XML export with `parse_export.py` (`--structure` → owner OK → `--summary` → `--extract` JSON); inventory controls, attributes, events, AJAX (with send/receive), scripts, CSS, texts, unknown node types; read the Neptune class dispatcher (AJAX IDs) | owner OK on the node-type map; registries 03/04/08 filled from the export |
| 2 | **S2 Build UI from the export**, in this order: **a** AJAX layer (AjaxConfig, models) → **b** client library shim (`discoveryFiori`, `ModelData`) → **c** events + script functions + formatters (incl. XML event attributes) → **d** view: ids, attributes, bindings, texts, CSS, dialogs | Each area: plan table → owner OK → edit → `verify_kit.py` + unit test + smoke | compare counts: 0 "missing", every remaining "different" explained |
| 2 | **S2L Layout check (offline)** | Headless browser at the Neptune screenshot width, mock data; container level first, then header/theme, then fields | every row decided (fixed / P-xx) |
| 2 | **R1 Review** | `neptune-parity-reviewer` (read-only, separate chat) → findings → one fix session with an exact list | — |
| 3 | **B0** DDIC + dependencies + licence scan of shared objects | live DDIC vs printouts; every called FM/class exists (TFDIR); `/NEPTUNE/` use inside shared objects | registry 09 updated; blockers listed |
| 3 | **B1** logic class | converter (counted groups, `<TR>` → real TR) → create shell via MCP → large source: owner pastes in SE24 (HTTP 413) → verify via MCP by counts → activate | method list = Neptune − 6 interface methods + `HANDLE_ON_AJAX`/`HANDLE_ON_REQUEST`; 0 "neptune" |
| 3 | **B2** SEGW project (owner in SAP GUI) | empty Data Model; **override generated class names if they collide** | names in registry 01 |
| 3 | **B3** MPC_EXT/DPC_EXT + spike | write MPC_EXT, activate, then DPC_EXT; bump `lc_gen_date_time` above generation time; register service; both cache cleanups; `$metadata` check; spike in Gateway Client | all spike criteria; save `$metadata` **and the successful response** |
| 3 | **B3b** import model into SEGW | Data Model → Import → Data Model from File; regenerate; reduce MPC_EXT; **D/T-as-CHAR fix must survive** | `$metadata` equal to B3; spike identical |
| 3 | **B4** every AJAX ID | saved request/response bodies **with status line**; DB checks with `queries/*.sql`; state-changing calls on a test form | results table |
| 4 | **F0/F1** offline checks, **F3** against DEV | `ui5.yaml` proxy (system UI5 version), CSRF, all `GT_*` sent, conversions | test-plan rows |
| 5 | **S5 Parity** Neptune vs UI5 | side by side, same user/form, `parity_diff.py`, DB state, visibility/enabled/required per role; confirm theme/width items | `docs/parity-results.md` |
| 5 | **LIC-1…4 Licence sweep** | find (export + class + JS, incl. runtime APIs without the word: `getOnline*`, `SERVER->API_*`, `sap.n.*`, `ModelData`) → check (repo + SAP read-only) → write repo fixes + checks → SAP fixes (only if LIC-2 finds a hit) | register complete, 0 open rows for our objects |
| 6 | **R2 Review before sign-off** → **S6 Deploy** (BSP, target mapping) → **Rollback/decommission plan** | — | — |

Backend B0–B3 may run in parallel with S2 (different agents, different files). F3 needs B3 passed.

## 4. How the owner works (follow it without being asked)

- **Prompt shape:** agent rules → session skill → "Read … first" → **Actions** (Create / Update / Delete lists) → **Scope** → **Out of scope** → **Replacement log** → **When done** (checks, tables, commit message). Anything not listed needs a separate "yes"; flag every out-of-scope touch in the summary.
- **Edit lists must include the files a change necessarily touches:** `verify_kit.py` exception lines, `smoke.js` expectations/known errors, unit-test fixtures, registries that mention the changed ids, the rule docs (binding-rules etc.). The template prompts list them; ask if one is missing.
- **Plan first:** structure/plan table → owner OK → edit; big areas section by section. Decisions numbered, each with a recommended option ("Decision 1: recommended …").
- **Exact counts:** a change that should hit *n* places aborts if the real count differs; show the count and ask ("yes, count 8"). Re-count from the source; never trust a count from an earlier session.
- **Confirm target** before SAP writes: system, client, user, package, transport, objects, repo changes. Apply owner modifiers literally ("yes + bump", "no re-indent").
- **Terse or cut-off messages / unfilled placeholders:** state the interpretation, ask when a bare "yes" could mean several options.
- **Commits:** on `main`, only the session's files, message as given; never push; never `.DS_Store`, `.env`, `*.har`, stray xlsx.
- **Output:** "Written for: …" line, tables, real check output (a skipped check is reported as skipped), "Next step", and on documents "Created using Anthropic Claude" + internal-review note.
- **`.env` is owner-maintained** (Claude cannot read it): every SAP prompt carries system, client, package and transports inline.

## 5. Neptune XML export — what is where (parse, never read by hand)

| Export table | Content | Use |
|---|---|---|
| `IT_CONTENT` | controls: `FIELD_ID`, `FIELD_NAME` (= id), `FIELD_TYPE` (`UM5_*`/`UI5_*`), `FIELD_PARENT`, `FIELD_POS`, `DISABLED`, `EVENT_ID` (AJAX ID) | view tree; `DISABLED=X` → not rendered: remove from view, keep handlers, one P-xx |
| `IT_ATTRIBUTES` | `ATTRIBUTE`, `VALUE`, `GROUPING` = Properties / Events / Associations / Model / Parent / Formatter | bindings are inside `VALUE` as `{ATTR-FIELD}`; formatters → `<id>_<property>` methods |
| `IT_BINDING` | Model Source per control (`BINDING` = ABAP attribute) | named JSONModel per owning control |
| `IT_MODEL` | AJAX parameter rows (`MODEL` control, `SEND`, `RECEIVE`) | resolved via `IT_BINDING` → `[model, ABAP attr, send, receive]` = `AjaxConfig.js` |
| `IT_EVENT_SCRIPT` | event code per line (`FIELD_ID`+`EVENT`, by `SEQNR`), incl. ajaxSuccess/ajaxError | controller methods `<id>_<event>` |
| `IT_SCRIPT` | script controls (Init, Utility, …) and page scripts | controller functions |
| `IT_TABLE_FIELDS` | column metadata | table/tree columns |
| `IT_CSS_DESKTOP`, `IT_PLUGIN`, header | CSS, theme plugin, UI5 version, app version, last transport | `css/app.css` byte copy; P-64-type theme item |

**Not controls** (designer nodes → aggregations or nothing): `UM5_OPSUBC` (`position=MoreBlock` → children go
straight into `<uxap:moreBlocks>`), `UM5_BARCON` (Bar `contentLeft/Middle/Right`), `UM5_OPCONT` (`headerContent`),
`UM5_RESFOL` (Translate folder → i18n), `SCRIPT`, `RESOURCES`, `HTML5 DOC`, `UM5_AJAX`; data-only: `UM5_DBARR`,
`UM5_MESSAG`. Never wrap an aggregation node in a `VBox` with its id (breaks ObjectPage block layout). Any new
`UM5_*`/`UI5_*` type in a new app: stop, show its attributes and children, agree the mapping with the owner.

Dialog buttons attach via associations (`beginButton`/`endButton`, `leftButton`/`rightButton`); a button without one is
content of the never-shown dialogs page. Export the **MIME files** too (`discoveryFiori.js`, `app.css`, templates) — the
XML does not contain them.

## 6. Layout parity method

1. Inputs: Neptune screenshots with the **window width** known (Retina images are 2×); same user, same data, same
   start context (standalone vs child) on both sides.
2. Container level first: per section, the outer controls and their layout attributes from the export vs the view;
   automatic both-direction check of every layout property over all controls (view + fragments).
3. Classify each difference: **A** attribute/structure (fix view), **C** CSS/theme, **D** data/start context,
   **V** UI5 runtime (new P-xx). Table: section | id | what differs | export value + ref | kit file:line | class | action | decision.
4. Measure, don't estimate: headless Chromium, smoke server on **8081** (8080 is the owner's), mock data that enables
   the fields, viewport = Neptune width (+ one wider), DOM geometry (rects, grid span classes); screenshots
   `pw_after_<section>_<width>.png`.
5. Judge visual details on the real SAPUI5 runtime (proxy), not the OpenUI5 smoke runtime. Theme: confirm in the
   Neptune app console `sap.ui.getCore().getConfiguration().getTheme()`.
6. Before removing/moving an id: grep webapp, tests, smoke; ids used in code stay. Fix the rule docs in the same change.

## 7. Model choice per session (Claude Code)

| Work | Model | Why |
|---|---|---|
| K0 kickoff/kit build, S1 export audit, S2 builds, S2L layout, B1–B3b, LIC-1/2, reviews R1/R2 | **Opus 5.5** (`claude --model opus`, or `model: opus` in the agent file) | long sources, judgement, parity reasoning |
| S5 parity, F3, B4 analysis, LIC-3 | **Opus 5.5** (Sonnet 5.5 acceptable) | mixed analysis + edits |
| S0 setup, F0/F1 offline checks, S6 deploy, B2 guidance, Q&A | **Sonnet 5.5** (`claude --model sonnet`) | procedural |
| Quick file lookups | Haiku 5.5 | — |

Agents: `neptune-abap-converter` and `neptune-parity-reviewer` → `model: opus`; `neptune-ui5-converter` → `model: opus`
(switch with `/model sonnet` for F0/F1/S6). In the VS Code panel pick the model with `/model`.

---
Created using Anthropic Claude — internal working document; keep it on internal versions until a human has reviewed and verified the content.
