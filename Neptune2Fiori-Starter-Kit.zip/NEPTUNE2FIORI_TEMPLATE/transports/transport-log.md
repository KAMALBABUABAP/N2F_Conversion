# Transport log — NEPTUNE2FIORI_<SHORTNAME>

Rules: `reference-kit/common/standards/transport-management.md`. One row per object; update when created, released, imported.

| Transport | Type | Object(s) | Created (date/who) | Released | QA import | PRD import | Notes |
|---|---|---|---|---|---|---|---|
| <TR_WB> | Workbench | logic class, SEGW project, MPC/DPC(_EXT), BSP — pending | | | | | package <PACKAGE> |
| <TR_CU> | Customizing | service registration, launchpad target mapping — pending | | | | | |
