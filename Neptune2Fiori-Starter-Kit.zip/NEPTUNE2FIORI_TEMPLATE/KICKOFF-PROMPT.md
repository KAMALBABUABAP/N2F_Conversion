# Kickoff prompts — NEPTUNE2FIORI_<SHORTNAME> (Neptune `<NEPTUNE_APP>`)

Two sessions build the project kit before the normal sessions (S0 …) start. Both run **without SAP access**.
Replace every `<…>` below before pasting (or tell K0 the values in your first message).

## Before you start

1. Inputs dropped and `docs/app-facts.md` §1–§3 filled (see `START-HERE.md`).
2. Terminal (zsh): `cd` into this folder, then `claude --model opus`.
   VS Code panel instead: open this folder, new chat, type `/model opus`.
3. Paste K0. Answer its questions. After K0 is committed: `/exit`, start `claude --agent neptune-abap-converter`, paste K1.
4. After K1: follow `docs/claude-code-session-prompts.md` (built by K0), starting with S0.

---

## K0 · Kickoff — inventory, questions, kit core · Model: Opus 5.5 · CRUD: R · C · U (this folder only)

```text
Run session K0 (kickoff) for project NEPTUNE2FIORI_<SHORTNAME>: convert the Neptune app <NEPTUNE_APP> into a SEGW OData V2 service + freestyle SAPUI5 app, apple-to-apple, with exactly the method of the first conversion.

Read first, in this order: CLAUDE.md, START-HERE.md, docs/app-facts.md, playbook/01-method.md, playbook/02-lessons-learned.md, playbook/04-reuse-map.md, playbook/03-session-prompts-template.md, and the screenshots in docs/capture/layout/neptune/.
Reference kit (READ-ONLY — never modify): reference-kit/ = the first project's kit. Wherever the playbook says projects/NEPTUNE2FIORI_PROJREQ/, read reference-kit/. Workspace standards: reference-kit/common/ (use ../../common/ instead if this folder sits in a workspace that has it).

Rules: CLAUDE.md of this folder. No SAP tool calls in this session. macOS zsh, one command per call. Temporary files go to your scratchpad. Work in the steps below; stop after each step and wait for my OK.

Step 1 — Inventory (read only).
- List what is in docs/neptune-source/, docs/neptune-export/, docs/capture/. If the class source or the XML export is missing, stop and tell me.
- Copy reference-kit/docs/capture/parse_export.py to docs/capture/ unchanged and run it with --structure, then --summary on the export. Never read the XML by hand.
- Report: export header (app version, UI5 version, theme plugin, last transport); count per FIELD_TYPE; every type the parser does not know, with its attributes and children and a proposed mapping (control / aggregation node / data-only / none); DISABLED controls; AJAX objects (FIELD_NAME, EVENT_ID); script controls; every MIME file or path the scripts load (loadCSS, getScript, /neptune/…); parent/child app calls (ParentComponent.loadSubComponent, ChildComponent).
- From the class source: class name, interface methods, the AJAX dispatcher WHEN branches, branches calling api_message_create, every shared Z object / FM it calls, line count, every "neptune" line (count by kind).
- Write docs/app-facts.md §4 (what the screenshots show vs the export) and §5 (contracts with other apps).

Step 2 — Questions. One numbered block: everything Step 1 raised plus the names of docs/app-facts.md §2 (check that the SEGW default class names do not collide with existing ones — list the 18-char prefix), each with a recommended option and the reason. Wait for my answers. Then update docs/app-facts.md (decisions with date).

Step 3 — Kit plan. Table: file | category (AS IS / PARAM / REBUILD from playbook/04-reuse-map.md) | source in reference-kit/ | what changes. Must cover:
- CLAUDE.md (full version, built from reference-kit/CLAUDE.md + docs/app-facts.md; keep every rule row) and README.md;
- .claude/settings.json (generic allow/deny/ask only), .mcp.json.example, .env.example (I fill .env myself), .gitignore;
- .claude/agents/neptune-abap-converter.md, neptune-ui5-converter.md, neptune-parity-reviewer.md with `model: opus` and this app's names; the abap agent's step table includes B3b;
- .claude/skills/: the registry skill (name agreed in Step 2) with references 01–09 + json-conversion-registry.json — 01 with the agreed names, 03/04/08 filled from the export extract, 05 parity log empty, 09 source-of-truth order; neptune-to-segw-backend and neptune-to-ui5-frontend (SKILL.md + references, with the lessons of playbook/02 merged in: date trap, 413 fallback, MPC/DPC name check, aggregation nodes, all GT_* sent); the n2f-s0…s6 + n2f-qa session skills; abap-adt-workflow (copy from reference-kit/.claude/skills/);
- .claude/scripts/verify_kit.py adapted (checks FAIL when an input path is missing; licence scan incl. ui5*.yaml/manifest; master-tree ids; registry JSON = JS; every PARITY P-xx in the log);
- docs/claude-code-session-prompts.md from playbook/03 with every placeholder filled (keep the standard blocks);
- docs/replacements/framework-replacement-register.md (format of the reference; R-01 … for this app);
- UI5 scaffold src/ui5/<app_id>/: package.json, ui5.yaml (proxy), ui5-smoke.yaml, ui5-deploy.yaml (BSP description without "Neptune"), webapp/Component.js, manifest.json, index.html, util/AjaxRuntime.js and ModelData.js (AS IS), util/discoveryFiori.js header/structure only (ported in S2b, marked TODO(S2b)), empty view/controller shells. No view content and no controller logic: that comes from the S2 sessions built from the export.
Wait for my OK on the plan.

Step 4 — Build exactly the approved plan. Every new document ends with "Created using Anthropic Claude" + the internal-review note. Nothing you write may contain "neptune" in shipped files (src/, webapp, yaml, manifest); the word is allowed in docs/ and .claude/ where it names the source.

Step 5 — Checks: python3 .claude/scripts/verify_kit.py (must print KIT OK; show a negative test for each new check), node --check on every JS, XML/JSON parse, grep -ri neptune src/ (must be 0). Show the folder tree.

[LIC-READ] from playbook/03-session-prompts-template.md with SESSION=K0.

When done: what was built, results of the checks, decisions taken, open questions, next session (K1). Commit on the branch I name (default main) only the files of this folder (never .env, *.har, .DS_Store), message "K0 kit for <NEPTUNE_APP>"; never push.
```

---

## K1 · Backend assets (offline) · Model: Opus 5.5 · CRUD: R · C · U (this folder only)

Start: `claude --agent neptune-abap-converter` (the agent exists after K0). No SAP calls in this session.

```text
Run session K1 (backend assets, offline) for <NEPTUNE_APP>. Read CLAUDE.md, docs/app-facts.md, the registry skill (01, 02, 04, 05, 09), the skill neptune-to-segw-backend and playbook/02-lessons-learned.md §3 first.
Reference (READ-ONLY): reference-kit/.claude/skills/neptune-to-segw-backend/ (assets/convert_class.py, assets/abap/*_MPC_EXT/*_DPC_EXT, assets/gateway-client/, references/class-conversion-changes.md, scripts/check_metadata.py).

Rules: no SAP tool calls; never modify reference-kit/. Show the plan, wait for my OK, then build.

Actions:
- Create .claude/skills/neptune-to-segw-backend/assets/convert_class.py for this class: keep the generic change groups (interface removal, HANDLE_ON_AJAX / HANDLE_ON_REQUEST, local message type, licence guard, <TR> one-line comments without "framework"/"neptune"), rebuild every app-specific match pattern against "docs/neptune-source/Backend Class/<file>". Every group has an expected count and aborts if the count differs. Show a dry-run table: group | pattern | expected | found.
- Generate assets/abap/<UI_CLASS>.clas.abap (with <TR>) and references/class-conversion-changes.md; copy to src/abap/.
- Create assets/abap/<MPC_EXT>.clas.abap and <DPC_EXT>.clas.abap from the reference with this app's names (registry 01), the root/deep types from this class's attributes (registry 02), the D/T set_internal_type( typekind_char ) fix, lc_gen_date_time placeholder comment "set above the generation time in B3", the media entity only if the app streams files; copy to src/abap/.
- Create assets/gateway-client/00_spike_<init AJAX ID>.json and one body per AJAX ID (every GT_* as []), the spike pass criteria in SKILL.md B3 (values the init call sets independent of customizing), check_metadata.py expectations, queries/*.sql for the tables the AJAX calls change.
- Update registries 01, 02, 04, 07 with what the class proves.

Scope: offline only. Exact counts; if a count differs from what the class shows, stop and ask.
Out of scope: SAP access, logic changes, refactoring, the frontend.
[LIC-BUILD] from playbook/03-session-prompts-template.md with SESSION=K1.
When done: dry-run table, method list (Neptune − interface methods + HANDLE_ON_AJAX/HANDLE_ON_REQUEST), "neptune" count in the generated class (must be 0), verify_kit output, next session (S0). Commit only this session's files: "K1 backend assets for <NEPTUNE_APP>"; never push.
```

---
Created using Anthropic Claude — internal working document; keep it on internal versions until a human has reviewed and verified the content.
