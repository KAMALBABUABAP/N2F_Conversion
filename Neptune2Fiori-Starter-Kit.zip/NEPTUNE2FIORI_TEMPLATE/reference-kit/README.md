# NEPTUNE2FIORI_PROJREQ — Neptune `ZDCI_NAD_PROJECT_REQUEST` → SEGW OData V2 + freestyle SAPUI5

Project folder for the apple-to-apple conversion. Rules: `CLAUDE.md`. Tool: Claude Code (terminal
or the VS Code extension) with the SAP ADT MCP server.

## What is here

| Path | What |
|---|---|
| `CLAUDE.md` | Project rules (+ overrides of `common/standards`) |
| `.claude/agents/` | Agents: `neptune-abap-converter`, `neptune-ui5-converter`, `neptune-parity-reviewer` |
| `.claude/settings.json`, `.mcp.json.example` | Permissions; SAP ADT MCP server config (copy to `.mcp.json`) |
| `.claude/skills/nad-project-request-registry` | Names, AJAX inventory, models, controls, parity log (38 items), JSON conversions, capture guide |
| `.claude/skills/neptune-to-segw-backend` | Backend steps B0–B7, pristine ABAP + Gateway test assets, `$metadata` checker |
| `.claude/skills/neptune-to-ui5-frontend` | Frontend steps F0–F6, pristine webapp, tests, deployment guide |
| `.claude/skills/n2f-s0…s6, n2f-qa` | Session skills — type `/n2f-…` in chat |
| `.claude/skills/abap-adt-workflow` (link to `common/skills/`) | How every SAP write is done + the standard ABAP response format |
| `.claude/scripts/verify_kit.py` | Consistency check — must print `KIT OK` |
| `docs/neptune-source/` | The Neptune repo (class source, AJAX specs, JS, UI specs, DDIC printouts) |
| `docs/neptune-export/` | Put the Neptune XML export, `discoveryFiori.js`, `app.css`, templates here |
| `src/abap/`, `src/ui5/zdci_nad_project_request/` | Working copies (ABAP classes, UI5 app) |
| `queries/`, `transports/` | Parity SQL, transport log |

## Session plan (one Claude Code session per row — prompts in `docs/claude-code-session-prompts.md`)

| Session | Start with (zsh, in this folder) | Then type |
|---|---|---|
| S0 setup check | `claude` | `/n2f-s0-setup-check` |
| S1 coverage audit vs XML export | `claude --agent neptune-parity-reviewer` | `/n2f-s1-coverage-audit <export file>` |
| S3 backend B0–B7 | `claude --agent neptune-abap-converter` | `/n2f-s3-backend B0` |
| S4 frontend F0–F1, later F3 | `claude --agent neptune-ui5-converter` | `/n2f-s4-frontend F0-F1` |
| S2 close gaps | `claude --agent neptune-ui5-converter` | `/n2f-s2-close-gaps` |
| S5 parity test | `claude` | `/n2f-s5-parity-test` |
| S6 deploy | `claude --agent neptune-ui5-converter` | `/n2f-s6-deploy` |
| Q&A (keep open) | `claude --agent neptune-parity-reviewer` | `/n2f-qa <question>` |

Commit after every session; sessions share state only through files. In the VS Code extension, start a new
conversation per session and type the same prompt (the agent is picked with `@agent-<name>` only for read-only
work; SAP-writing sessions belong in a terminal started with `--agent`).

## Verified offline

ABAP passes the abaplint parser; JS `node --check`; XML parses; conversion unit test 9/9; headless smoke test
on OpenUI5 1.108 with a mocked service passes; `verify_kit.py` → `KIT OK`. Not yet run against SAP.
