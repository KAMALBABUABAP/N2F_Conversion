#!/usr/bin/env python3
"""
verify_kit.py - consistency checks for the Neptune -> SEGW + SAPUI5 kit of ZDCI_NAD_PROJECT_REQUEST.

Run from the project folder (projects/NEPTUNE2FIORI_PROJREQ, which contains .claude/):
    python3 .claude/scripts/verify_kit.py [--app <webapp>] [--source docs/neptune-source]
Defaults: app = src/ui5/zdci_nad_project_request/webapp, source = docs/neptune-source.

Checks
  1. registry JSON (json-conversion-registry.json) == util/JsonConversionRegistry.js
  2. every view/fragment event handler exists in Main.controller.js
  3. every this.byId("x") in the controller exists in the views (known exceptions listed)
  4. every model used in views/controller is declared in util/ModelRegistry.js; every config model too
  5. every AjaxConfig "fn" is a controller method; every AJAX ID of the ABAP dispatcher is in the config
  6. every PARITY P-xx used in code exists in 05-parity-log.md
  7. every file referenced in SKILL.md "Assets" tables exists
  8. control ids of Master_Control_Tree.md exist in the views (known exceptions listed)
  9. licence: no "neptune" in ABAP, webapp files, ui5*.yaml and manifest.json (deployed to SAP)
Exit code 0 = KIT OK.
"""
import argparse
import glob
import json
import os
import re
import sys

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))          # .claude/
SK = os.path.join(KIT, "skills")
REG = os.path.join(SK, "nad-project-request-registry", "references")
FE = os.path.join(SK, "neptune-to-ui5-frontend")

# ids referenced by the Neptune code / tree that intentionally have no control (documented)
BYID_EXCEPTIONS = {"BtnProjectCode", "BtnProjectCodeClear", "diaMessages"}
BYID_EXCEPTIONS |= {"inpAuthBy", "inpProjCode", "diaSearchPrevProj"}  # S2a: DISABLED in the original, not rendered (P-56)
TREE_EXCEPTIONS = {"oShell", "oBusyIndicator", "oPageDialogs", "oSelectMultiCCCode",
                   "cFormEmployeeInfo", "colItemDTableApprovers_",
                   "Neptune", "red"}  # last two: words from tree comments
TREE_EXCEPTIONS |= {"hcAttributes"}  # S2a: headerContent aggregation node, no runtime control (registry 08)
TREE_EXCEPTIONS |= {"RequesterBlock", "ProjDetailBlock", "ProjMultiCCode", "oObjectPageSubSectionFPA", "oObjectPageSubSectionRTR", "oObjectPageSubSectionBPC", "attachBlock1", "approvalBlock1", "CommentsBlock"}  # layout parity 2026-10-20: moreBlocks aggregation nodes, no runtime control (registry 08)
TREE_EXCEPTIONS |= {"oSelectUSState"}  # S2a: DISABLED in the original, not rendered (P-56)
TREE_EXCEPTIONS |= {"oSelectInit_Group", "oLblProjCode", "inpProjCode", "oLblInternalOrder", "inpOnInternalNo"}  # S2a: DISABLED, not rendered (P-56)
TREE_EXCEPTIONS |= {"diaSearchPrevProj", "listPrev_ProjCode"}  # S2a: DISABLED dialog and its item, not rendered (P-56)
TREE_EXCEPTIONS |= {"colDTableApproversSTEPS", "colDTableApproversSTATUS_ICON", "coloDTableApproversSTEP_STATUS"}  # S2a: old spelling in Master_Control_Tree.md; export spelling wins (registry 09)

problems = []


def err(msg):
    problems.append(msg)
    print("FAIL  " + msg)


def ok(msg):
    print("ok    " + msg)


def read(p):
    with open(p, encoding="utf-8", errors="replace") as f:
        return f.read()


def js_object_literal(src):
    """Extract the object returned by sap.ui.define(... return {...}) and parse it as JSON-ish."""
    m = re.search(r"return\s*(\{.*\});\s*\}\);\s*$", src, re.S)
    if not m:
        return None
    txt = m.group(1)
    return json.loads(txt)


def main():
    ap = argparse.ArgumentParser()
    proj = os.path.dirname(KIT)                                   # project folder (contains .claude/)
    work_app = os.path.join(proj, "src", "ui5", "zdci_nad_project_request", "webapp")
    ap.add_argument("--app", default=work_app if os.path.isdir(work_app) else os.path.join(FE, "assets", "webapp"))
    src = os.path.join(proj, "docs", "neptune-source")
    ap.add_argument("--source", default=src if os.path.isdir(src) else proj)
    a = ap.parse_args()
    app = a.app

    # 1 registry sync
    reg = json.load(open(os.path.join(REG, "json-conversion-registry.json")))
    reg.pop("_comment", None)
    try:
        js = js_object_literal(read(os.path.join(app, "util", "JsonConversionRegistry.js")))
        if js == reg:
            ok("JsonConversionRegistry.js == json-conversion-registry.json")
        else:
            err("JsonConversionRegistry.js differs from json-conversion-registry.json")
    except Exception as e:  # noqa
        err("cannot parse JsonConversionRegistry.js: %s" % e)

    ctrl = read(os.path.join(app, "controller", "Main.controller.js"))
    xml_files = [os.path.join(app, "view", "Main.view.xml")] + glob.glob(os.path.join(app, "view", "fragments", "*.xml"))
    xml = "".join(read(f) for f in xml_files)
    xml_nocomment = re.sub(r"<!--.*?-->", "", xml, flags=re.S)
    ids = set(re.findall(r'\bid="([^"]+)"', xml_nocomment))
    methods = set(re.findall(r"^\s{8}([A-Za-z_0-9]+): function", ctrl, re.M))

    # 2 handlers
    handlers = set(re.findall(r'="\.([A-Za-z_0-9]+)"', xml_nocomment))
    miss = handlers - methods
    err("handlers missing in controller: %s" % sorted(miss)) if miss else ok("%d view handlers exist in controller" % len(handlers))

    # 3 byId
    used = set(re.findall(r'this\.byId\("([^"<]+)"\)', ctrl)) - BYID_EXCEPTIONS
    miss = used - ids
    err("byId ids not in views: %s" % sorted(miss)) if miss else ok("%d byId ids exist in views" % len(used))

    # 4 models
    models_src = read(os.path.join(app, "util", "ModelRegistry.js"))
    models = set(re.findall(r'\["([A-Za-z_0-9]+)", "(?:GT|GS|WA)_', models_src))
    used_m = set(re.findall(r'this\.model\("([A-Za-z_0-9]+)"\)', ctrl))
    used_m |= set(re.findall(r"\{([A-Za-z_0-9]+)>", xml_nocomment))
    used_m |= set(re.findall(r"path: '([A-Za-z_0-9]+)>", xml_nocomment))
    used_m |= set(re.findall(r"\$\{([A-Za-z_0-9]+)>", xml_nocomment))
    cfg_src = read(os.path.join(app, "util", "AjaxConfig.js"))
    cfg_models = set(re.findall(r'\["([A-Za-z_0-9]+)", "(?:GT|GS|WA)_', cfg_src))
    miss = (used_m | cfg_models) - models
    err("models used but not declared: %s" % sorted(miss)) if miss else ok("%d models declared, all used ones present" % len(models))

    # registry 03 models
    reg03 = read(os.path.join(REG, "03-neptune-model-registry.md"))
    reg03_models = set(re.findall(r"^\| `([A-Za-z_0-9]+)` \| [^|]+\| `(?:GT|GS|WA)_", reg03, re.M))
    miss = reg03_models - models
    err("registry 03 models missing in ModelRegistry.js: %s" % sorted(miss)) if miss else ok("all %d registry-03 models created" % len(reg03_models))

    # attributes in config are in the envelope
    attrs = set(re.findall(r'"((?:GT|GS|WA)_[A-Z_0-9]+)"', cfg_src))
    env = set(reg["TABLES"]) | set(reg["STRUCTURES"])
    miss = attrs - env
    err("config attributes not in envelope: %s" % sorted(miss)) if miss else ok("config attributes all in envelope (%d)" % len(attrs))

    # 5 fn + dispatcher
    fns = set(re.findall(r'fn: "([^"]+)"', cfg_src))
    miss = fns - methods
    err("config fn not in controller: %s" % sorted(miss)) if miss else ok("%d getOnline functions exist" % len(fns))
    cfg_ids = set(re.findall(r"^\s{8}([A-Z_]+): \{", cfg_src, re.M))
    abap = os.path.join(a.source, "Backend Class", "ProjectRequest App.txt")
    if os.path.exists(abap):
        src = read(abap)
        m = re.search(r"method /NEPTUNE/IF_NAD_SERVER~HANDLE_ON_AJAX\.(.*?)endmethod\.", src, re.S | re.I)
        body = m.group(1) if m else ""
        live = [l for l in body.splitlines() if not l.lstrip().startswith("*")]
        whens = set(re.findall(r"WHEN\s+'([A-Z_]+)'", "\n".join(live), re.I))
        whens = {w.upper() for w in whens}
        miss = whens - cfg_ids
        err("dispatcher AJAX IDs missing in config: %s" % sorted(miss)) if miss else ok("all %d dispatcher AJAX IDs in config" % len(whens))
    else:
        print("skip  dispatcher check (Neptune source not found at %s)" % abap)

    # 6 parity ids
    plog = read(os.path.join(REG, "05-parity-log.md"))
    logged = set(re.findall(r"^\| (P-\d+) \|", plog, re.M))
    code = ctrl + xml + "".join(read(f) for f in glob.glob(os.path.join(app, "util", "*.js")))
    for f in glob.glob(os.path.join(SK, "neptune-to-segw-backend", "assets", "abap", "*.abap")):
        code += read(f)
    used_p = set(re.findall(r"PARITY (P-\d+)", code))
    miss = used_p - logged
    err("parity ids in code but not logged: %s" % sorted(miss)) if miss else ok("%d parity ids in code, all logged (%d logged)" % (len(used_p), len(logged)))

    # 7 assets in SKILL.md
    for sk in glob.glob(os.path.join(SK, "*", "SKILL.md")):
        base = os.path.dirname(sk)
        for ref in re.findall(r"`((?:assets|scripts|references)/[^`*<> ]+)`", read(sk)):
            for part in ref.split(", "):
                p = os.path.join(base, part.strip().rstrip("/"))
                if "{" in p or "*" in p:
                    continue
                if not os.path.exists(p):
                    err("%s references missing %s" % (os.path.relpath(sk, KIT), part))
    ok("SKILL.md asset references checked")

    # 8 master tree ids
    tree = os.path.join(a.source, "Master_Control_Tree.md")
    if os.path.exists(tree):
        t = read(tree)
        block = "\n".join(re.findall(r"```\n(.*?)```", t, re.S))
        tids = set(re.findall(r"(?:[├└│─\s])([a-zA-Z][A-Za-z_0-9]{2,})\s+\(", block))
        tids = {i for i in tids if not i.startswith(("sap", "Left", "Right", "Middle", "Columns", "Data", "Init", "Utility", "Form", "Resources"))}
        tids -= TREE_EXCEPTIONS
        tids -= {"cntr_formdetails", "cntr_stepdetails", "UrlParameters", "ProgramState", "CompanyCodes",
                 "AttachmentCategories", "AttachmentsRequired"}
        miss = sorted(i for i in tids if i not in ids)
        err("master-tree ids missing in views: %s" % miss) if miss else ok("all %d master-tree ids present" % len(tids))
    else:
        print("skip  master tree check (not found)")

    # 9 licence removal: no NEPTUNE names/paths in what is deployed to SAP
    proj = os.path.dirname(KIT)
    abap_files = glob.glob(os.path.join(proj, "src", "abap", "*.abap")) + \
        glob.glob(os.path.join(SK, "neptune-to-segw-backend", "assets", "abap", "*.abap"))
    hits = [f for f in abap_files if re.search(r"neptune", read(f), re.I)]
    err("ABAP contains 'neptune': %s" % [os.path.relpath(f, proj) for f in hits]) if hits else ok("%d ABAP files free of 'neptune'" % len(abap_files))
    bad_names, bad_paths, bad_words = [], [], []
    for root, _, files in os.walk(app):
        for fn in files:
            fp = os.path.join(root, fn)
            if re.search(r"neptune", fn, re.I):
                bad_names.append(os.path.relpath(fp, app))
            if fn.endswith((".js", ".xml", ".json", ".html", ".properties", ".css", ".md")):
                if re.search(r"neptune", read(fp), re.I):
                    bad_words.append(os.path.relpath(fp, app))
                code = re.sub(r"/\*.*?\*/|<!--.*?-->", "", read(fp), flags=re.S)
                code = re.sub(r"(?m)^\s*(//|#).*$", "", code)
                code = re.sub(r"//[^\n\"']*$", "", code, flags=re.M)
                if re.search(r"/neptune/", code, re.I):
                    bad_paths.append(os.path.relpath(fp, app))
    err("webapp file names contain 'neptune': %s" % bad_names) if bad_names else ok("webapp file names free of 'neptune'")
    err("webapp code uses /neptune/ paths: %s" % bad_paths) if bad_paths else ok("webapp code uses no /neptune/ paths")
    err("webapp text/comments contain 'neptune': %s" % bad_words) if bad_words else ok("webapp free of 'neptune' (code, comments, texts)")
    # review S2 R-3: deploy descriptors (fiori deploy writes the BSP description from ui5-deploy.yaml)
    deploy_files = sorted(glob.glob(os.path.join(os.path.dirname(app), "ui5*.yaml"))) + [os.path.join(app, "manifest.json")]
    deploy_files = [f for f in deploy_files if os.path.exists(f)]
    bad_deploy = [os.path.relpath(f, proj) for f in deploy_files if re.search(r"neptune", read(f), re.I)]
    err("ui5*.yaml / manifest.json contain 'neptune': %s" % bad_deploy) if bad_deploy else ok("%d ui5*.yaml / manifest.json files free of 'neptune'" % len(deploy_files))
    reg = os.path.join(proj, "docs", "replacements", "framework-replacement-register.md")
    ok("replacement register present") if os.path.exists(reg) else err("missing docs/replacements/framework-replacement-register.md")
    print("app    = %s" % app)
    print("source = %s" % a.source)
    print()
    if problems:
        print("KIT NOT OK - %d problem(s)" % len(problems))
        sys.exit(1)
    print("KIT OK")


if __name__ == "__main__":
    main()
