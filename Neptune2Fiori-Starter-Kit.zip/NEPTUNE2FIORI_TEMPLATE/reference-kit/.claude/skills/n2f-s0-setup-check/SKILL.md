---
name: n2f-s0-setup-check
description: S0 — check the kit, the tools and the SAP connection before any work
disable-model-invocation: true
---

Session S0 (setup check). Do not change any file except `.env` (release values only) and the replacement log.
1. Run `python3 .claude/scripts/verify_kit.py` and, in `src/ui5/zdci_nad_project_request`, `npm run test:unit` (run `npm install` first if `node_modules` is missing). Show the last lines of each.
2. List the skills you can see (`.claude/skills`) and the agents (`.claude/agents`) and the MCP servers (`/mcp` status) and say in one line each what they are for.
3. List the SAP ADT MCP tools available in this session, grouped as read / write / activate / test / transport. Then call `ListSapSystems` (confirm `SAP_SYSTEM_ID` from `.env` is listed) and one read-only tool with `system` and `client` from `.env` (read the standard class `CL_ABAP_CHAR_UTILITIES` — the original class `ZCL_NAD_PROJECT_CODE_REQUEST` may be deleted) to prove the connection, and tell me the system ID and client you are connected to, plus SAP_BASIS, SAP_UI (SAPUI5 version), SAP_GWFND/IW_BEP and whether it is S/4HANA or ECC. If the tool list differs from `../../common/mcp/README.md`, show me the difference.
4. Check `.env` exists and which values are still empty (do not print secrets).
5. Summarise the order of work from `CLAUDE.md` and tell me the next session to run.

**Replacement log (licence removal):** names that start with or contain `NEPTUNE` (or use `/NEPTUNE/`) must not appear in anything the new solution uses in SAP. Log every one you find in `docs/replacements/S0-replacements.txt` (format and rules: `docs/replacements/framework-replacement-register.md`; write `RESULT: none found` if none) and add rows to the register. Read-only session: propose replacements, do not apply them.
