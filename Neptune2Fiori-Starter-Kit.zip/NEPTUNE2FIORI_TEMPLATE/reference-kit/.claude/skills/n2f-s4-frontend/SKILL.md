---
name: n2f-s4-frontend
description: S4 — frontend F0/F1 offline checks, then F3 against the real backend
argument-hint: F0-F1 (offline) or F3 (backend)
disable-model-invocation: true
---

Work as the custom agent `neptune-ui5-converter` (`.claude/agents/neptune-ui5-converter.md`; best: start this session with `claude --agent neptune-ui5-converter`): follow its rules.

Session S4 (frontend), scope: <scope — default F0-F1, taken from the text after the command>. Use the skill `neptune-to-ui5-frontend`; the app is in `src/ui5/zdci_nad_project_request`.
- F0/F1: npm install, unit test, smoke test (start `npm run start-smoke` in a separate terminal, then `npm run test:smoke`), lint. Show real output; explain lint findings using `.claude/skills/neptune-to-ui5-frontend/references/test-plan.md` §Lint.
- F3 (only after backend B3 passed): fill `ui5.yaml` from `.env`, `npm start`, run the checks of F3 and test-plan §2 rows 1–6 with me. For any failure use `.claude/skills/neptune-to-ui5-frontend/references/ajax-client.md` §Troubleshooting.

**Replacement log (licence removal):** names that start with or contain `NEPTUNE` (or use `/NEPTUNE/`) must not appear in anything the new solution uses in SAP. Log every one you find in `docs/replacements/S4-replacements.txt` (format and rules: `docs/replacements/framework-replacement-register.md`; write `RESULT: none found` if none) and add rows to the register. Replace with standard SAP data elements/structures of the same type and length; never a new DDIC object without approval.
