# Troubleshooting

## Spike (B3) failures

| Symptom | Cause | Fix |
|---|---|---|
| `$metadata` shows CamelCase properties or no `AJAX` | MPC_EXT `define` not active / old metadata cached | Activate MPC_EXT, bump `lc_gen_date_time`, run both cache cleanups |
| 501 / "Method CREATE_DEEP_ENTITY not implemented" | DPC_EXT not active or redefinition missing | Activate DPC_EXT; confirm the generated DPC is its superclass |
| 201 but navigation tables empty in the response | (a) request lacked the navigation property, or (b) this Gateway release serialises only expanded navigations | (a) send every `GT_*` as `[]`. (b) STOP, report `/IWFND/TRACES` output; design fallback is to return tables in a second call — needs owner sign-off |
| 400 "Property X has invalid value" | Edm type vs JSON value mismatch (e.g. Edm.Decimal sent as number) | Send decimals as strings; dates as 8-char strings or `""` |
| 400 "Invalid key predicate" on rows | `ROW_INDEX` missing or not an integer | Client must number rows 1..n |
| "Commit work during changeset processing not allowed" | Request came through `$batch` | Plain POST only (`useBatch: false`) |
| Short dump `CX_SY_ITAB_LINE_NOT_FOUND` in `load_form` / `set_button_visibility` | Parity P-17 / P-18 (data problem, same in Neptune) | Not a conversion bug; use a form whose approvers are configured |
| 403 CSRF | Token not fetched | GET with `X-CSRF-Token: Fetch` first (Gateway Client does this automatically) |
| Empty `GT_SYS_MESSAGE` although NEW_PROJECT failed | Behaviour — errors go to `sysMessage` only when `create_project` raises | compare with Neptune capture (P-27) |

## After go-live changes

- Any change to an ABAP structure used in the envelope appears in `$metadata` automatically (RTTI). Bump
  `lc_gen_date_time` and clean caches; rerun `check_metadata.py`.
- A new attribute that the UI must transfer: add it to `TS_AJAX_ROOT` (structure) or `TS_AJAX_DEEP`
  (table, with a `TS_<ATTR>` row type carrying `ROW_INDEX`), plus the registry files. Name = attribute name.
