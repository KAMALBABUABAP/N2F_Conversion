# Gateway API calls used by MPC_EXT / DPC_EXT — what to check if activation complains

The assets were written against the standard SEGW-generated code patterns (SAP_GWFND on S/4HANA 2022) and
checked offline with abaplint (parser + semantic check against stubs). They have not been activated on
your system. If activation reports an unknown method or parameter, look it up in SE24 and adapt the
**call** — keep every OData and ABAP name as it is.

| Used in | Call | Look up in SE24 | Typical fix if it differs |
|---|---|---|---|
| MPC_EXT | `model->create_entity_type( iv_entity_type_name, iv_def_entity_set )` | `/IWBEP/IF_MGW_ODATA_MODEL` | — (used by every generated MPC) |
| MPC_EXT | `model->get_entity_type( iv_entity_name )` | same | parameter name |
| MPC_EXT | `model->create_complex_type( <name> )` (positional) | same | — |
| MPC_EXT | `model->create_association( iv_association_name, iv_left_type, iv_right_type, iv_right_card, iv_left_card, iv_def_assoc_set )` | same | — |
| MPC_EXT | `model->create_association_set( iv_association_set_name, iv_left_entity_set_name, iv_right_entity_set_name, iv_association_name )` | same | — |
| MPC_EXT | `<entity>->create_property( iv_property_name, iv_abap_fieldname )` | `/IWBEP/IF_MGW_ODATA_ENTITY_TYP` | — |
| MPC_EXT | `<entity>->get_property( iv_property_name )` | same | parameter name |
| MPC_EXT | `<entity>->create_complex_property( iv_property_name, iv_complex_type_name, iv_abap_fieldname )` | same | if `iv_abap_fieldname` is missing: drop it and call `->set_abap_fieldname( )` on the returned `/IWBEP/IF_MGW_ODATA_CMPLX_PROP` |
| MPC_EXT | `<entity>->create_navigation_property( iv_property_name, iv_abap_fieldname, iv_association_name )` | same | — |
| MPC_EXT | `<entity>->create_entity_set( <name> )`, `->set_is_media( )`, `->bind_structure( iv_structure_name, iv_bind_conversions )` | same | — |
| MPC_EXT | `<complex>->create_property( … )`, `->bind_structure( … )` | `/IWBEP/IF_MGW_ODATA_CMPLX_TYPE` | — |
| MPC_EXT | `<property>->set_is_key( )`, `set_type_edm_string/decimal/int16/int32/int64/byte/double/binary( )`, `set_maxlength( iv_max_length )`, `set_precison( iv_precision )` *(SAP spelling)*, `set_creatable( )`, `set_updatable( )`, `set_as_content_type( )` | `/IWBEP/IF_MGW_ODATA_PROPERTY` | `set_type_edm_byte` absent → use `set_type_edm_int16` |
| MPC_EXT | `<entity set>->set_creatable/updatable/deletable/pageable/addressable( )` | `/IWBEP/IF_MGW_ODATA_ENTITY_SET` | drop a setter that does not exist |
| MPC_EXT | `get_last_modified` redefinition returning `rv_last_modified TYPE timestamp` | generated MPC | — |
| DPC_EXT | `/iwbep/if_mgw_appl_srv_runtime~create_deep_entity / create_entity / get_stream` redefinitions | `/IWBEP/IF_MGW_APPL_SRV_RUNTIME` | — |
| DPC_EXT | `io_data_provider->read_entry_data( IMPORTING es_data )` | `/IWBEP/IF_MGW_ENTRY_PROVIDER` | — |
| DPC_EXT | `copy_data_to_ref( EXPORTING is_data CHANGING cr_data )`, `set_header( is_header )` | `/IWBEP/CL_MGW_ABS_DATA` (superclass chain) | — |
| DPC_EXT | `/iwbep/if_mgw_appl_types=>ty_s_media_resource` (`value`, `mime_type`) | `/IWBEP/IF_MGW_APPL_TYPES` | — |
| DPC_EXT | `RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception EXPORTING textid = …=>business_error message = CONV #( … )` | `/IWBEP/CX_MGW_BUSI_EXCEPTION` | `MESSAGE` is `BAPI_MSG` (CHAR 220), not STRING — confirmed S4M 2026-10-18 (S3-B3); pass `CONV #( iv_text )` |

Model rules the code relies on (verify once with the spike, step B3):
- Deep-insert component names = navigation property names (`GT_KOSTL` etc.) — they are identical by design.
- A deep-insert response contains the navigation data present in the request → the UI always sends every
  navigation property (empty arrays when not sending).
- `bind_structure( iv_bind_conversions = abap_false )` → no conversion exits (Neptune parity; KOSTL stays
  `0000012345`).
