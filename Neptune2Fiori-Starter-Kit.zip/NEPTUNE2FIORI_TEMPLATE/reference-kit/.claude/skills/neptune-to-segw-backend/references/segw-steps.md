# SEGW and service registration — click paths

## Create the project (SAP GUI, transaction SEGW)

1. **Create Project** (white page icon).
   - Project: `ZDCI_UI_PROJECT_REQUEST` (SEGW allows up to 30 characters)
   - Description: `Project Code Request` (no "Neptune" in SAP texts — licence rule)
   - Project Type: *Service with SAP Annotations*; Generation Strategy: *Standard*
   - Package / transport: as given by the user.
2. Leave **Data Model** empty. The model is created in MPC_EXT (`n2f_define_envelope`, `n2f_define_attachment`).
3. **Generate Runtime Objects** (red/white wheel).
   - Accept the proposed class names (SEGW shortens them to fit 30 characters).
   - Technical service name: `ZDCI_UI_PROJECT_REQUEST_SRV`, version 1.
   - Record MPC, MPC_EXT, DPC, DPC_EXT names in `01-naming-registry.md`.
   - If SEGW refuses to generate because the model is empty: create entity type `AJAX` with the single
     property `AJAX_ID` (Edm.String, key, ABAP field name `AJAX_ID`) and **no** entity set, then generate.
     MPC_EXT already handles this: it reuses an existing `AJAX` entity type and `AJAX_ID` property
     (`get_entity_type` / `get_property` in TRY blocks) and rebinds the entity to `TS_AJAX_ROOT`.
4. Paste MPC_EXT and DPC_EXT sources (placeholders replaced), activate both.

## Register the service (Gateway hub, transaction /IWFND/MAINT_SERVICE)

1. **Add Service** → System Alias: the alias the other custom services on this hub use (often `LOCAL`
   on embedded deployments) → Technical Service Name `ZDCI_UI_PROJECT_REQUEST_SRV` → Get Services → Add
   Selected Services → package as given.
2. In the service list select it → **ICF Node** must be active (green). **Call Browser** →
   `.../ZDCI_UI_PROJECT_REQUEST_SRV/$metadata` must load.
3. After every MPC_EXT change: bump `lc_gen_date_time` in `get_last_modified`, then run
   `/IWFND/CACHE_CLEANUP` (all models) and `/IWBEP/CACHE_CLEANUP` (all models).

## Gateway Client (transaction /IWFND/GW_CLIENT)

- Request URI: `/sap/opu/odata/sap/ZDCI_UI_PROJECT_REQUEST_SRV/AJAXSet`
- HTTP Method: POST; header fields `Content-Type: application/json`, `Accept: application/json`
  (the client fetches the CSRF token itself).
- Paste a body from `assets/gateway-client/`. Expect HTTP 201.
- **Use as Request** on a response turns a `GET_DATA` result into the body for the next call: change
  `AJAX_ID`, remove the `__metadata` blocks, and turn each `{"results":[...]}` into a plain array.

## Error logs

`/IWFND/ERROR_LOG` (hub), `/IWBEP/ERROR_LOG` (backend), `ST22` (dumps — P-17/P-18 can dump on bad data,
exactly as in Neptune), `/IWFND/TRACES` (payload trace for a user).
