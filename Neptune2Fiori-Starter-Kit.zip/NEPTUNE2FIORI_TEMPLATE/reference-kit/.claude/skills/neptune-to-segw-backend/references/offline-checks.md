# Offline ABAP checks on the Mac (before pasting into SAP)

abaplint parses ABAP without a system. It catches syntax errors and wrong method calls between our own
classes. It cannot know SAP's Gateway signatures or your DDIC — activation in SAP stays the final word.

```zsh
# one-time
mkdir -p ~/n2f-lint && cd ~/n2f-lint && npm init -y >/dev/null && npm i @abaplint/cli
# check (abaplint wants lowercase file names ending in .clas.abap under src/)
mkdir -p ~/n2f-lint/src
for f in ~/<sap-dev>/projects/NEPTUNE2FIORI_PROJREQ/src/abap/*.clas.abap; do
  cp "$f" ~/n2f-lint/src/"$(basename "$f" | tr '[:upper:]' '[:lower:]')"
done
cp ~/<sap-dev>/projects/NEPTUNE2FIORI_PROJREQ/src/abap/abaplint.json ~/n2f-lint/
cd ~/n2f-lint && npx abaplint
```

Expected result: `0 issue(s)` with the shipped config (parser only). With `check_syntax` switched on, the
only findings are `ZHRC_*` constants (type group of the source system — unchanged from Neptune) and the
missing generated superclasses.
