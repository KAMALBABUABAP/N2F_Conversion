"""Convert ZCL_NAD_PROJECT_CODE_REQUEST (Neptune) into ZCL_UI_PROJECT_CODE_REQUEST (Neptune-free).

Every edit is an exact, counted replacement. If any expected count is off, the script aborts,
so the output can never silently drift from the source.

Usage: python3 -I convert_class.py <source.txt> <target.clas.abap> <diff-notes.md> [<transport>]

Original comments are kept. Every conversion comment is one short line starting with the
transport number (4th argument, default <TR>), e.g.  " S4MK900123 SERVER removed
"""
import re
import sys

src_path, out_path, notes_path = sys.argv[1], sys.argv[2], sys.argv[3]
TR = sys.argv[4] if len(sys.argv) > 4 else "<TR>"
with open(src_path, encoding="utf-8") as f:
    text = f.read().replace("\r\n", "\n")

notes = []


def sub(pattern, repl, expected, note, flags=0, literal=False):
    """Replace and assert the number of replacements."""
    global text
    if literal:
        count = text.count(pattern)
        if count != expected:
            sys.exit(f"ABORT: expected {expected} literal match(es) for {note!r}, found {count}")
        text = text.replace(pattern, repl)
    else:
        new_text, count = re.subn(pattern, repl, text, flags=flags)
        if count != expected:
            sys.exit(f"ABORT: expected {expected} match(es) for {note!r}, found {count}")
        text = new_text
    notes.append((note, expected))


# 1. Class name (definition + implementation)
sub("class ZCL_NAD_PROJECT_CODE_REQUEST definition",
    "class ZCL_UI_PROJECT_CODE_REQUEST definition", 1,
    "Class renamed ZCL_NAD_PROJECT_CODE_REQUEST -> ZCL_UI_PROJECT_CODE_REQUEST (definition)", literal=True)
sub("CLASS ZCL_NAD_PROJECT_CODE_REQUEST IMPLEMENTATION.",
    "CLASS ZCL_UI_PROJECT_CODE_REQUEST IMPLEMENTATION.", 1,
    "Class renamed (implementation)", literal=True)

# 2. Header comment
sub("\n\nclass ZCL_UI_PROJECT_CODE_REQUEST definition",
    "\n* N2F: ZCL_UI_PROJECT_CODE_REQUEST is a 1:1 copy of the class\n"
    "* N2F: ZCL_NAD_PROJECT_CODE_REQUEST with ONLY the source-framework runtime dependency removed.\n"
    "* N2F: Every method, attribute, type, constant, SELECT, COMMIT and quirk is unchanged.\n"
    "* N2F: Each changed line carries an 'N2F' comment. Do not refactor - parity first.\n"
    "class ZCL_UI_PROJECT_CODE_REQUEST definition", 1,
    "Header comment added", literal=True)

# 3. Interface removed
sub("  interfaces /NEPTUNE/IF_NAD_SERVER .\n",
    "* N2F: framework server INTERFACES statement removed. Its entry points HANDLE_ON_AJAX and\n"
    "* N2F: HANDLE_ON_REQUEST are re-declared below as public methods with the same names.\n", 1,
    "Removed INTERFACES /NEPTUNE/IF_NAD_SERVER", literal=True)

# 4. Neptune message type replaced by an identical local type + sysMessage table
sub("""    begin of ty_location,
           plant type werks_d,
           location type stort_t499s,
           text type text40,
         end of ty_location .
""",
    """    begin of ty_location,
           plant type werks_d,
           location type stort_t499s,
           text type text40,
         end of ty_location .
* N2F: TY_MESSAGE has the components of the framework message structure, standard data elements only
  types:
    BEGIN OF ty_message,
        field_name TYPE text50,
        type       TYPE bapi_mtype,
        id         TYPE symsgid,
        number     TYPE symsgno,
        message    TYPE bapi_msg,
        message_v1 TYPE symsgv,
        message_v2 TYPE symsgv,
        message_v3 TYPE symsgv,
        message_v4 TYPE symsgv,
      END OF ty_message .
  types:
    tt_message TYPE STANDARD TABLE OF ty_message WITH DEFAULT KEY .
""", 1, "Added TY_MESSAGE / TT_MESSAGE (copy of /NEPTUNE/MESSAGE components)", literal=True)

sub("  data GS_ERROR_MSG type /NEPTUNE/MESSAGE .\n",
    "  data GS_ERROR_MSG type TY_MESSAGE .  \" N2F: was framework message structure\n"
    "* N2F: GT_SYS_MESSAGE replaces SERVER->API_MESSAGE_CREATE( ) (UI model 'sysMessage')\n"
    "  data GT_SYS_MESSAGE type TT_MESSAGE .\n", 1,
    "GS_ERROR_MSG retyped; GT_SYS_MESSAGE added", literal=True)

# 5. Public entry points (same names as the Neptune interface methods)
sub("  class-methods CLASS_CONSTRUCTOR .\n",
    """  class-methods CLASS_CONSTRUCTOR .
* N2F: was framework interface method HANDLE_ON_AJAX (SERVER parameter removed)
  methods HANDLE_ON_AJAX
    importing
      !AJAX_ID type STRING
      !AJAX_VALUE type STRING optional .
* N2F: was framework interface method HANDLE_ON_REQUEST (response returned instead of SERVER->API_RESPONSE_XSTRING)
  methods HANDLE_ON_REQUEST
    importing
      !KEY type STRING
      !KEY_ID type STRING
    exporting
      !EV_DATA type XSTRING
      !EV_CONTENT_TYPE type STRING
      !EV_FILE_NAME type STRING .
""", 1, "Declared public HANDLE_ON_AJAX / HANDLE_ON_REQUEST", literal=True)

# 6. Method signatures: SERVER parameter removed
#    a) methods whose only importing parameter is SERVER, followed by 'raising'
sub(r"(\n  methods (\w+)\n)    importing\n      !SERVER type ref to /NEPTUNE/CL_NAD_SERVER\n    raising\n",
    r"\1    raising\n", 9,
    "SERVER removed from 9 methods whose only importing param was SERVER (CREATE_INIT, CREATE_FORM, "
    "SAVE_FORM, REJECT_FORM, CLOSE_FORM, CHANGE_FORM, RESUBMIT_FORM, CHECK_ERROR, UPDATE_PROCESS_REGION, ...)")
#    b) SERVER followed by more importing params (CREATE_FORM_WREF_ORDERID, GET_DATA)
sub(r"      !SERVER type ref to /NEPTUNE/CL_NAD_SERVER\n(      !IP_)",
    r"\1", 2, "SERVER removed from CREATE_FORM_WREF_ORDERID and GET_DATA signatures")
#    c) DELETE_FORM: SERVER was the only parameter
sub("  methods DELETE_FORM\n    importing\n      !SERVER type ref to /NEPTUNE/CL_NAD_SERVER .\n",
    "  methods DELETE_FORM .  \" N2F: SERVER parameter removed\n", 1,
    "DELETE_FORM signature: SERVER removed", literal=True)
#    d) REDIRECT_ERROR: returns the page instead of writing it to SERVER
sub("  methods REDIRECT_ERROR\n    importing\n      !SERVER type ref to /NEPTUNE/CL_NAD_SERVER .\n",
    "  methods REDIRECT_ERROR  \" N2F: returns the page instead of SERVER->API_RESPONSE_XSTRING\n"
    "    exporting\n      !EV_DATA type XSTRING\n      !EV_CONTENT_TYPE type STRING .\n", 1,
    "REDIRECT_ERROR signature: SERVER -> EV_DATA / EV_CONTENT_TYPE", literal=True)

# 7. Dispatcher implementation
sub("METHOD /neptune/if_nad_server~handle_on_ajax.",
    "METHOD handle_on_ajax.  \" N2F: was framework interface method handle_on_ajax", 1,
    "HANDLE_ON_AJAX implementation header", literal=True)
sub("          ls_neptune_message   TYPE /neptune/message,",
    "          ls_neptune_message   TYPE ty_message,  \" N2F: was framework message structure", 1,
    "ls_neptune_message retyped", literal=True)
sub(r"(CALL METHOD me->get_data\n\s*EXPORTING\n)\s*server\s*=\s*server\n",
    r"\1", 1, "GET_DATA call: server = server removed")
sub(r"CALL METHOD me->(\w+)\n\s*EXPORTING\n\s*server\s*=\s*server\.",
    r'CALL METHOD me->\1.  " N2F: SERVER parameter removed', 11,
    "11 'EXPORTING server = server.' calls reduced to 'CALL METHOD me->x.'")
sub(r"(CALL METHOD me->create_form_wref_orderid\n\s*EXPORTING\n)\s*server\s*=\s*server\n",
    r"\1", 1, "CREATE_FORM_WREF_ORDERID call: server removed")
sub(r"(?m)^(\s+)server->api_message_create\( ls_neptune_message \)\.",
    r'\1APPEND ls_neptune_message TO gt_sys_message.  " N2F: was server->api_message_create( )', 4,
    "4 active server->api_message_create( ) -> APPEND TO gt_sys_message (commented lines untouched)")

# 8. HANDLE_ON_REQUEST implementation
sub("METHOD /neptune/if_nad_server~handle_on_request.",
    "METHOD handle_on_request.  \" N2F: was framework interface method handle_on_request", 1,
    "HANDLE_ON_REQUEST implementation header", literal=True)
sub("redirect_error( server ).",
    "redirect_error( IMPORTING ev_data = ev_data ev_content_type = ev_content_type ).  \" N2F", 3,
    "3 redirect_error( server ) calls", literal=True)
sub("""        server->api_response_xstring(
          data         = lv_attachment_data
          content_type = lv_mime_type
          file_name    = lv_file_name
        ).""",
    """        ev_data         = lv_attachment_data.  " N2F: was server->api_response_xstring( )
        ev_content_type = lv_mime_type.
        ev_file_name    = lv_file_name.""", 1, "Attachment response returned via EV_* parameters", literal=True)

# 9. Empty Neptune interface methods removed
sub("\n\nMETHOD /neptune/if_nad_server~handle_on_response.\n  ENDMETHOD.\n", "\n", 1,
    "Removed empty HANDLE_ON_RESPONSE", literal=True)
sub("\n\nMETHOD /neptune/if_nad_server~handle_on_submit.\n  ENDMETHOD.\n", "\n", 1,
    "Removed empty HANDLE_ON_SUBMIT", literal=True)
sub("\n\n  method /NEPTUNE/IF_NAD_SERVER~HANDLE_ON_SYNC_IN.\n  endmethod.\n", "\n", 1,
    "Removed empty HANDLE_ON_SYNC_IN", literal=True)
sub("\n\n  method /NEPTUNE/IF_NAD_SERVER~HANDLE_ON_SYNC_OUT.\n  endmethod.\n", "\n", 1,
    "Removed empty HANDLE_ON_SYNC_OUT", literal=True)

# 10. REDIRECT_ERROR body
sub("""    server->api_response_xstring(
      data         = lr_contents_x
      content_type = 'text/html'
    ).""",
    """    ev_data         = lr_contents_x.  " N2F: was server->api_response_xstring( )
    ev_content_type = 'text/html'.""", 1, "REDIRECT_ERROR body returns the page", literal=True)

# 11. License removal: no object, type, variable, path or comment may contain "neptune" (owner decision 2026-10-14)
sub("i_url     = '/neptune/public/application/zdci_nad_customer_form/pages/attacherror.html'",
    "i_url     = '/SAP/BC/BSP/SAP/ZUI_PROJREQCODE/attacherror.html'  \" N2F: page moved into BSP ZUI_PROJREQCODE (was framework MIME path)",
    1, "REDIRECT_ERROR reads the error page from BSP ZUI_PROJREQCODE instead of the framework MIME folder", literal=True)
sub("ls_neptune_message", "ls_message", text.count("ls_neptune_message"),
    "Local variable ls_neptune_message renamed to ls_message (no framework name in code)", literal=True)

# 28. Lock calls off: ZCL_ND_CA_UTILITIES lock methods use the framework lock server; shared class owned by
#     another team (owner decision R-32, 2026-10-18). ENQUEUE_FORM is already commented in the original (P-63).
if re.search(r"(?mi)^[ \t]+zcl_nd_ca_utilities=>enqueue_form", text):
    sys.exit("ABORT: active ENQUEUE_FORM call found - group 28 expects none")
sub(r"(?m)^([ \t]+zcl_nd_ca_utilities=>dequeue_form\( gs_formdetails-form_guid \)\.)$",
    lambda m: f"* {TR} Lock call off, shared class owned by other team (P-63)\n*{m.group(1)}", 8,
    "Active ZCL_ND_CA_UTILITIES=>DEQUEUE_FORM calls commented out (shared lock methods owned by other team; "
    "ENQUEUE_FORM already commented in the original; P-63, R-32)")
if re.search(r"(?mi)^[ \t]+zcl_nd_ca_utilities=>(de|en)queue_form", text):
    sys.exit("ABORT: active lock call left after group 28")

# 12. Short conversion comments: one line, transport number + a few words (owner decision 2026-10-17)
SHORT = [
    (r"\n\* N2F: ZCL_UI_PROJECT_CODE_REQUEST is a 1:1 copy of the class\n\* N2F: ZCL_NAD_PROJECT_CODE_REQUEST[^\n]*\n\* N2F: Every method[^\n]*\n\* N2F: Each changed line[^\n]*\n",
     "\n* {TR} Copy of ZCL_NAD_PROJECT_CODE_REQUEST, framework removed\n"),
    (r"\* N2F: framework server INTERFACES statement removed\.[^\n]*\n\* N2F: HANDLE_ON_REQUEST are re-declared[^\n]*\n",
     "* {TR} Framework interface removed\n"),
    (r"\* N2F: TY_MESSAGE has the components[^\n]*", "* {TR} Local message type"),
    (r"\" N2F: was framework message structure", "\" {TR} Was framework type"),
    (r"\* N2F: GT_SYS_MESSAGE replaces[^\n]*", "* {TR} Replaces message API"),
    (r"\* N2F: was framework interface method HANDLE_ON_AJAX[^\n]*", "* {TR} Was interface method"),
    (r"\* N2F: was framework interface method HANDLE_ON_REQUEST[^\n]*", "* {TR} Was interface method"),
    (r"\" N2F: was framework interface method handle_on_\w+", "\" {TR} Was interface method"),
    (r"\" N2F: SERVER parameter removed", "\" {TR} SERVER removed"),
    (r"\" N2F: returns the page instead of SERVER->API_RESPONSE_XSTRING", "\" {TR} Returns page"),
    (r"\" N2F: was server->api_message_create\( \)", "\" {TR} Was message API"),
    (r"\" N2F: was server->api_response_xstring\( \)", "\" {TR} Was response API"),
    (r"\" N2F: page moved into BSP ZUI_PROJREQCODE \(was framework MIME path\)", "\" {TR} Page in BSP"),
    (r"\" N2F$", "\" {TR} Returns page"),
]
for pat, rep in SHORT:
    text = re.sub(pat, lambda m, r=rep: r.replace("{TR}", TR), text, flags=re.M)
if "N2F" in text:
    sys.exit("ABORT: long N2F comments left:\n" + "\n".join(l for l in text.split("\n") if "N2F" in l))

# Final guard: the generated class must not contain "neptune" anywhere (code, comments, literals)
leftover = [ln for ln in text.split("\n") if re.search(r"neptune", ln, re.I)]
if leftover:
    sys.exit("ABORT: 'neptune' still present:\n" + "\n".join(leftover))
leftover = [ln for ln in text.split("\n")
            if re.search(r"\bserver\b", ln, re.I) and not ln.lstrip().startswith("*") and TR not in ln]
if leftover:
    sys.exit("ABORT: SERVER references remain:\n" + "\n".join(leftover))

with open(out_path, "w", encoding="utf-8", newline="\n") as f:
    f.write(text)

with open(notes_path, "w", encoding="utf-8") as f:
    f.write("# ZCL_NAD_PROJECT_CODE_REQUEST -> ZCL_UI_PROJECT_CODE_REQUEST: complete change list\n\n")
    f.write("Generated by an exact-count converter. Everything not listed here is byte-identical "
            "to the Neptune source (apart from CRLF -> LF).\n\n")
    f.write("| # | Change | Occurrences |\n|---|---|---|\n")
    for i, (note, n) in enumerate(notes, 1):
        f.write(f"| {i} | {note} | {n} |\n")
print(f"OK: {len(notes)} change groups applied; wrote {out_path}")
