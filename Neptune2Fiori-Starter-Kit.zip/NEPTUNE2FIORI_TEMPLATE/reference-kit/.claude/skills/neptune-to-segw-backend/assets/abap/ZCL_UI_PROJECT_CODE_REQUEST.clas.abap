
* <TR> Copy of ZCL_NAD_PROJECT_CODE_REQUEST, framework removed
class ZCL_UI_PROJECT_CODE_REQUEST definition
  public
  final
  create public .

public section.
  type-pools FBCON .

* <TR> Framework interface removed

  types:
    BEGIN OF ty_proj_form.
        INCLUDE TYPE zmdg_proj_form.
        INCLUDE TYPE zmdg_s_proj_flgrp_visi.
        INCLUDE TYPE zmdg_s_proj_flgrp_expand.
        INCLUDE TYPE zmdg_proj_form_s_read_only.
        INCLUDE TYPE zmdg_proj_form_s_visible.
        INCLUDE TYPE zmdg_s_nad_order_buttons.
        INCLUDE TYPE zmdg_proj_form_s_editable.

        TYPES: kostl_text TYPE string.
    TYPES: is_dirty TYPE string.
    TYPES: requester_title TYPE string.
    TYPES: requester_email TYPE string.
    TYPES: prev_comments TYPE string.
    TYPES: navigation_visible  TYPE string.
    TYPES: display_or_edit  TYPE string.
    TYPES: page_header      TYPE string.
    TYPES: attributes_visible      TYPE string.
    TYPES: mode_button_visible     TYPE string.
    TYPES: mode_button_icon        TYPE string,
           can_attach type ddbool_d,
           project_id_out type string.


    TYPES: END OF ty_proj_form .
  types:
    BEGIN OF ty_wi_appr,
        steps             TYPE alv_string,
        step_status       TYPE alv_string,
        approverid        TYPE alv_string,
        approvername      TYPE alv_string,
        status_icon       TYPE alv_string,
        status_icon_color TYPE alv_string,
        status_date       TYPE alv_string.
    TYPES:
      END OF ty_wi_appr .
  types:
    BEGIN OF ty_fieldgroup,
        sign   TYPE char1,
        option TYPE char2,
        low    TYPE zform_fldgrp_id,
        high   TYPE zform_fldgrp_id.
    TYPES : END OF ty_fieldgroup .
  types:
    BEGIN OF s_value_text,
        value TYPE string,
        text  TYPE string,
      END OF s_value_text .
  types:
    BEGIN OF ty_value_text,
        value TYPE string,
        text  TYPE string,
      END OF ty_value_text .
  types:
    BEGIN OF ty_agent_list,
        otype TYPE otype,
        objid TYPE actorid,
        text  TYPE string,
      END OF ty_agent_list .
  types:
    BEGIN OF s_value_text_req,
        value    TYPE string,
        text     TYPE string,
        required TYPE string,
        project_type type string,
        project_subtype type string,
      END OF s_value_text_req .
  types:
    BEGIN OF s_company_code,
        region       TYPE string,
        company_code TYPE string,
        country      TYPE string,
        text         TYPE string,
      END OF s_company_code .
  types:
    BEGIN OF ty_orderdetails,
        output_ccode   TYPE string,
        output_ccenter TYPE string,
        project_code   TYPE string,
        internal_order TYPE string,
        error_desc     TYPE string,
        is_error       TYPE string.
    TYPES: END OF ty_orderdetails .
  types:
    BEGIN OF ty_additional_ccode,
        status     TYPE string,
        region     TYPE string,
        comp_code  TYPE string,
        comp_text  TYPE string,
        kostl_code TYPE string,
        kostl_text TYPE string,
        deletable  TYPE string.
        INCLUDE TYPE zmdg_s_proj_flgrp_visi.
        INCLUDE TYPE ty_orderdetails.
      TYPES:  END OF ty_additional_ccode .
  types:
    begin of ty_location,
           plant type werks_d,
           location type stort_t499s,
           text type text40,
         end of ty_location .
* <TR> Local message type
  types:
    BEGIN OF ty_message,
        field_name TYPE text50,
        type       TYPE bapi_mtype,
        id         TYPE symsgid,
        number     TYPE symsgno,
        message    TYPE bapi_msg,
        message_v1 TYPE symsgv,
        message_v2 TYPE symsgv,
        message_v3 TYPE symsgv,
        message_v4 TYPE symsgv,
      END OF ty_message .
  types:
    tt_message TYPE STANDARD TABLE OF ty_message WITH DEFAULT KEY .

  data:
    BEGIN OF wa_url_parameters,
        form_guid         TYPE string,
        proj              TYPE string,
        mode              TYPE string,
        from              TYPE string,
        processing_region TYPE string,
        company_code      TYPE string,
      END OF wa_url_parameters .
  data:
    BEGIN OF wa_program_state,
        program_state   TYPE string,
        program_message TYPE string,
        incorrect_field TYPE string,
      END OF wa_program_state .
  data:
    BEGIN OF wa_comments,
        comments TYPE string,
      END OF wa_comments .
  data:
    BEGIN OF wa_confirm_delete,
        delete_index TYPE string,
      END OF wa_confirm_delete .
  data GV_WI_ID type SWW_WIID .
  data:
    gt_appr            TYPE TABLE OF ty_wi_appr .
  data:
    gt_zca_form        TYPE TABLE OF zca_form .
  data:
    gt_zca_form_fldgrp TYPE TABLE OF zca_form_fldgrp .
  data:
    gt_zca_fldgrp_flds TYPE TABLE OF zca_fldgrp_flds .
  data:
    gt_zca_apprvr_list TYPE TABLE OF zca_apprvr_list .
  data:
    gt_zca_apprvr_attr TYPE TABLE OF zca_apprvr_attr .
  data:
    gt_zca_formdetail  TYPE TABLE OF zca_formdetail .
  data:
    gt_zca_stepdetail  TYPE TABLE OF zca_formdetail .
  data:
    gt_orderdetails    TYPE TABLE OF ty_orderdetails .
  data GT_ZCA_AGENT_LIST type ZCA_T_NAD_GL_AGENT .
  data GT_ATTACHMENTS type ZCA_FORM_ATTACHMENT_T .
  data:
    gt_fieldgroup      TYPE TABLE OF ty_fieldgroup .
  data:
    gt_request_type    TYPE TABLE OF ty_value_text .
  data:
    gt_project_subtype type table of ty_value_text .
  data:
    gt_exec_category   TYPE TABLE OF ty_value_text .
  data:
    gt_quadrant        TYPE TABLE OF ty_value_text .
  data:
    gt_initi_group TYPE TABLE OF zzmdg_initia_grp .
  data:
    gt_initi_grp TYPE TABLE OF zzmdg_initia_grp .
  data:
    gt_function        TYPE TABLE OF ty_value_text .
  data:
    gt_asset_class     TYPE TABLE OF ty_value_text .
  data:
    gt_itl_asset_class TYPE TABLE OF ty_value_text .
  data:
    gt_priority        TYPE TABLE OF ty_value_text .
  data:
    gt_geographylist   TYPE TABLE OF ty_value_text .
  data:
    gt_brands type table of ty_value_text .
  data:
    gt_locations type table of ty_location .
  data:
    gt_comp_code       TYPE TABLE OF ty_value_text .
  data:
    gt_add_comp_ccode  TYPE TABLE OF ty_value_text .
  data:
    gt_all_comp_code   TYPE TABLE OF ty_value_text .
  data:
    gt_kostl           TYPE TABLE OF ty_value_text .
  data:
    gt_currency        TYPE TABLE OF ty_value_text .
  data:
    gt_usstate         TYPE TABLE OF ty_value_text .
  data GT_EXCLUDE_CCODE type TRGR_COMPANY_CODE .
  data:
    gt_agent_list              TYPE STANDARD TABLE OF ty_agent_list .
  data:
    gt_auth_by_list            TYPE STANDARD TABLE OF ty_agent_list .
  data:
    gt_attachment_categories   TYPE TABLE OF s_value_text_req .
  data:
    gt_attachments_required    type table of zmdg_att_req .
  data:
    gt_prev_projcode           TYPE TABLE OF s_value_text .
  data:
    gt_prev_itl_projcode       TYPE TABLE OF s_value_text .
  data:
    gt_prev_imo_projcode       TYPE TABLE OF s_value_text .
  data:
    gt_order_type              TYPE TABLE OF s_value_text .
  data:
    gt_additional_ccode        TYPE TABLE OF ty_additional_ccode .
  data GS_APPR type TY_WI_APPR .
  data GS_PROJ_FORM type TY_PROJ_FORM .
  data GS_FORMDETAILS type ZCA_FORMDETAIL .
  data GS_STEPDETAIL type ZCA_STEPDETAIL .
  data GS_FORMHEADER type ZCA_S_NAD_GL_PAGEHEADER .
  data GS_EMPLOYEE_INFO type ZHCM_S_EMPLOYEE_INFO .
  data GS_ATTACHMENT type ZCA_FORM_ATTACHMENT .
  data GS_FIELDGROUP type TY_FIELDGROUP .
  data GS_ERROR_MSG type TY_MESSAGE .  " <TR> Was framework type
* <TR> Replaces message API
  data GT_SYS_MESSAGE type TT_MESSAGE .
  data GS_REQUEST_TYPE type TY_VALUE_TEXT .
  data GS_EXEC_CATEGORY type TY_VALUE_TEXT .
  data GS_QUADRANT type TY_VALUE_TEXT .
  data GS_INITI_GROUP type TY_VALUE_TEXT .
  data GS_FUNCTION type TY_VALUE_TEXT .
  data GS_ASSET_CLASS type TY_VALUE_TEXT .
  data GS_PRIORITY type TY_VALUE_TEXT .
  data GS_GEOGRAPHY type TY_VALUE_TEXT .
  data GS_KOSTL type TY_VALUE_TEXT .
  data GS_CURRENCY type TY_VALUE_TEXT .
  data GS_USSTATE type TY_VALUE_TEXT .
  data GS_ORDERTYPE type TY_VALUE_TEXT .
  data GS_ORDERDETAILS type TY_ORDERDETAILS .
  data GS_EMAIL_VALUE type ZMDG_S_PROJ_EMAIL .
  data GS_COMP_CODE type TY_VALUE_TEXT .
  data GS_MULTIPLECCODE type TY_ADDITIONAL_CCODE .
  data GC_FORM_NAME type ZFORM_NAME value 'PROJECT_REQUEST' ##NO_TEXT.
  data GC_FORM_VER type ZFORM_VER value '0001' ##NO_TEXT.
  data GC_FORMSTATUS_REJECTED type ZCA_FORM_STATUS value 'REJECTED' ##NO_TEXT.
  data GC_FORMSTATUS_RESENT type ZCA_FORM_STATUS value 'RESENT' ##NO_TEXT.
  data GC_FORMSTATUS_CANCELLED type ZCA_FORM_STATUS value 'CANCELLED' ##NO_TEXT.
  data GC_FORMSTATUS_DRAFT type ZCA_FORM_STATUS value 'DRAFT' ##NO_TEXT.
  data GC_FORMSTATUS_ERROR type ZCA_FORM_STATUS value 'ERROR' ##NO_TEXT.
  data GC_FORMSTATUS_INPROGRESS type ZCA_FORM_STATUS value 'INPROCESS' ##NO_TEXT.
  data GC_FORMSTATUS_COMPLETED type ZCA_FORM_STATUS value 'COMPLETED' ##NO_TEXT.
  data GC_STEPSTATUS_READY type ZCA_STEP_STATUS value 'READY' ##NO_TEXT.
  data GC_STEPSTATUS_SELECTED type ZCA_STEP_STATUS value 'SELECTED' ##NO_TEXT.
  data GC_STEPSTATUS_STARTED type ZCA_STEP_STATUS value 'STARTED' ##NO_TEXT.
  data GC_STEPSTATUS_ERROR type ZCA_STEP_STATUS value 'ERROR' ##NO_TEXT.
  data GC_STEPSTATUS_REJECT type ZCA_STEP_STATUS value 'REJECTED' ##NO_TEXT.
  data GC_STEPSTATUS_COMPLETED type ZCA_STEP_STATUS value 'COMPLETED' ##NO_TEXT.
  data GC_STEPSTATUS_WITHDRAWN type ZCA_STEP_STATUS value 'WITHDRAWN' ##NO_TEXT.
  data GC_STEPSTATUS_RESUBMIT type ZCA_STEP_STATUS value 'RESUBMIT' ##NO_TEXT.

  class-methods CLASS_CONSTRUCTOR .
* <TR> Was interface method
  methods HANDLE_ON_AJAX
    importing
      !AJAX_ID type STRING
      !AJAX_VALUE type STRING optional .
* <TR> Was interface method
  methods HANDLE_ON_REQUEST
    importing
      !KEY type STRING
      !KEY_ID type STRING
    exporting
      !EV_DATA type XSTRING
      !EV_CONTENT_TYPE type STRING
      !EV_FILE_NAME type STRING .
  class-methods CC_ALL_APPROVERS
    importing
      !IV_FORM_NAME type ZFORM_NAME
      !IV_PROCESSING_REGION type ZCACUSTPROCREG
      !IV_ONBEHALF_OF type CHAR20
    returning
      value(RT_AGENTS) type ZCA_T_NAD_GL_AGENT .
  class-methods GET_AGENTLIST
    importing
      !OTYPE type OTYPE
      !OBJID type ANY optional
    exporting
      !AGENT_LIST type ZCA_T_NAD_GL_AGENT
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods POPULATE_FIELD_EMAIL
    importing
      !IP_FORM type ZMDG_PROJ_FORM
    exporting
      !IO_EMAIL_VALUE type ZMDG_S_PROJ_EMAIL .
  class-methods CURRENCY_CONVERT_OUT
    importing
      !IV_CURRENCY type WAERS
    changing
      !CV_AMOUNT type ANY .
  class-methods CURRENCY_CONVERT_IN
    importing
      !IV_CURRENCY type WAERS
    changing
      !CV_AMOUNT type ANY .
protected section.

  methods CREATE_PROJECT
    raising
      ZCX_PROJECT_CODE_REQUEST
      ZCX_CA_FORM_EXCEPTIONS .
  methods SEND_ERROR_EMAIL .
  methods VALIDATE_BRAND_GEO
    raising
      ZCX_PROJECT_CODE_REQUEST .
private section.

  constants GC_TRUE type STRING value 'true' ##NO_TEXT.
  constants GC_FALSE type STRING value 'false' ##NO_TEXT.
  constants GC_EXPAND type STRING value 'Expanded' ##NO_TEXT.
  constants GC_COLLAPSE type STRING value 'Collapsed' ##NO_TEXT.

  methods CREATE_INIT
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods CREATE_FORM
    raising
      ZCX_CA_FORM_EXCEPTIONS
      ZCX_PROJECT_CODE_REQUEST .
  methods CREATE_INTERNAL_ORDER
    importing
      !INTL_ORDER_WITH_EXP type STRING optional
    returning
      value(RT_MESSAGES_OUT) type BAPIRET2_TT
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods CREATE_MULTI_INTERNAL_ORDER
    returning
      value(RT_MESSAGES_OUT) type BAPIRET2_TT
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods CREATE_FORM_WREF_ORDERID
    importing
      !IP_ORDERID type STRING
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods SUBMIT_FORM
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods SAVE_FORM
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods REJECT_FORM
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods DELETE_FORM .  " <TR> SERVER removed
  methods LOAD_FORM
    importing
      !IP_FORM_GUID type SYSUUID_C .
  methods CLOSE_FORM
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods CHANGE_FORM
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods RESUBMIT_FORM
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods CHECK_ERROR
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods GET_COSTCENTER
    importing
      !AJAX_VALUE type STRING .
  methods UPDATE_PROCESS_REGION
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods AGENT_SEARCH
    importing
      !AJAX_VALUE type STRING .
  methods AUTH_BY_SEARCH
    importing
      !AJAX_VALUE type STRING .
  methods SEARCH_PREV_CAP_PROJ_ID
    importing
      !AJAX_VALUE type STRING .
  methods SEARCH_PREV_ITL_PROJ_ID
    importing
      !AJAX_VALUE type STRING .
  methods SAVE_ATTACHMENTS
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods GET_ATTACHMENT_LIST .
  methods DELETE_ATTACHMENT .
  methods SET_HEADER
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods GET_AGENTS
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods GET_DATA
    importing
      !IP_VALUE type STRING
    raising
      ZCX_CA_FORM_EXCEPTIONS .
  methods GET_ON_BEHALF_DATA
    importing
      !AJAX_VALUE type STRING .
  methods GET_AUTHORIZED_BY_DATA
    importing
      !AJAX_VALUE type STRING .
  methods GET_APPROVERS
    importing
      !IP_FORM_GUID type SYSUUID_C optional .
  methods GET_USERDETAIL .
  methods REDIRECT_ERROR  " <TR> Returns page
    exporting
      !EV_DATA type XSTRING
      !EV_CONTENT_TYPE type STRING .
  methods CHECK_DIRTY .
  methods DEACTIVE_EXIST_PROJCODE
    importing
      value(IP_PREV_PROJ_CODE) type ZZDEPROJECT .
  methods GET_PROJ_CODE .
  methods CREATE_ITL_PROJ_CODE .
  methods CREATE_CLS_PROJ_CODE .
  methods CREATE_IMO_PROJ_CODE .
  methods POPULATE_F4_HELP .
  methods SET_MULTI_CCODE .
  methods GET_COMPANY_CODE .
  methods GET_ORDER_TYPE .
  methods GET_DEACTIVATE_CCODE .
  methods CLEAR_VALUE .
  methods RESET_VALUE .
  methods SET_FIELD_DEFAULT_VALUE .
  methods SET_FIELD_MANDATORY .
  methods SET_FIELD_VISIBLE .
  methods SET_FIELD_COND_VISIBLE .
  methods SET_FIELD_READ_ONLY .
  methods SET_BUTTON_VISIBILITY
    importing
      !IS_FORM_LOCKED type FLAG default 'X' .
  methods SET_FLDGRP_VISIBILITY
    importing
      !IS_FORM_LOCKED type FLAG default 'X' .
ENDCLASS.



CLASS ZCL_UI_PROJECT_CODE_REQUEST IMPLEMENTATION.


METHOD handle_on_ajax.  " <TR> Was interface method

    DATA: lx_ca_form_exception TYPE REF TO zcx_ca_form_exceptions,
          lx_project_request   type ref to zcx_project_code_request,
          ls_message   TYPE ty_message,  " <TR> Was framework type
          lt_return            TYPE bapiret2_tt,
          ls_return            TYPE bapiret2,
          ls_mail_send         TYPE boole_d,
          lv_mail_to_req       TYPE boole_d.

    CASE ajax_id.

      WHEN 'GET_DATA'.
        TRY.
            CALL METHOD me->get_data
              EXPORTING
                ip_value = ajax_value.
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
        ENDTRY.

      WHEN 'GET_EMPINFO'.
        CALL METHOD me->get_userdetail.

      WHEN 'GET_AGENTLIST'.
        try.
          CALL METHOD me->get_agents.

          catch zcx_ca_form_exceptions into lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
        endtry.

      WHEN 'CREATE'.
        TRY.
            CALL METHOD me->create_form.  " <TR> SERVER removed
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
          CATCH zcx_project_code_request into lx_project_request.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_project_request->get_text( ).
        ENDTRY.

      WHEN 'CHECK'.
        TRY.
            CALL METHOD me->check_error.  " <TR> SERVER removed
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
        ENDTRY.

      WHEN 'SAVE'.
        TRY.
            CALL METHOD me->save_form.  " <TR> SERVER removed
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
        ENDTRY.

      WHEN 'DELETE'.
        TRY.
            CALL METHOD me->delete_form.  " <TR> SERVER removed
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
        ENDTRY.

      WHEN 'REJECT'.
        TRY.
            CALL METHOD me->reject_form.  " <TR> SERVER removed
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
        ENDTRY.

      WHEN 'SUBMIT'.
        TRY.
          submit_form( ).

          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
          CLEANUP.
        ENDTRY.

      WHEN 'RESUBMIT'.
        TRY.
            CALL METHOD me->resubmit_form.  " <TR> SERVER removed
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
          CLEANUP.
        ENDTRY.

      WHEN 'CHANGE'.
        TRY.
            CALL METHOD me->change_form.  " <TR> SERVER removed
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
          CLEANUP.
        ENDTRY.

      WHEN 'CLOSE'.
        TRY.
            CALL METHOD me->close_form.  " <TR> SERVER removed
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
          CLEANUP.
        ENDTRY.

      WHEN 'DELETE_ATTACHMENT'.
        delete_attachment( ).

      WHEN 'BACK'.
        CALL METHOD me->check_dirty.

* D.Rempe - TODO: I don't want to deal with this, going to rewrite it.
*      WHEN 'NEW_INTENALORDER'.
*        TRY.
*            lt_return = create_internal_order( intl_order_with_exp = gc_false ).
*
*          CATCH zcx_ca_form_exceptions INTO DATA(lx_mdg_form_exception).
*            wa_program_state-program_state   = 'E'.
*            wa_program_state-program_message = lx_mdg_form_exception->get_text( ).
*
*            CLEAR ls_message.
*            ls_message-type = 'Error'.
*            ls_message-message = wa_program_state-program_message.
*            server->api_message_create( ls_message ).
*
*            LOOP AT lx_mdg_form_exception->error_table INTO ls_return.
*              CLEAR ls_message.
*              MOVE-CORRESPONDING ls_return TO ls_message.
*              server->api_message_create( ls_message ).
*            ENDLOOP.
*        ENDTRY.
** Once success - Proceed form to next level
*        TRY.
*            IF wa_program_state-program_state NE 'E'.
*
*              submit_form( ).
*
** Send Email to all previous agents once project code and internal order created successfully
** Get list of workflow ID based on form name and version
*              SELECT * FROM zca_apprvr_list INTO TABLE @DATA(lt_apprvr_list) WHERE form_name = @gc_form_name AND form_ver = @gc_form_ver.
*              LOOP AT lt_apprvr_list INTO DATA(ls_apprvr_list) WHERE appr_step NE 'BPC'.
** Update mail to requestor
*                IF ls_apprvr_list-workcenter_id IS INITIAL.
*                  lv_mail_to_req = 'X'.
*                ELSE.
*                  CLEAR lv_mail_to_req.
*                ENDIF.
*
*                CALL METHOD zmdg_send_email=>send_email
*                  EXPORTING
*                    form_guid          = gs_formdetails-form_guid
*                    step_guid          = gs_stepdetail-step_guid
*                    proj_req_fields    = gs_email_value
*                    repl_scenario_name = 'MDG_PROJ_RTR_APP_ALL'
*                    repl_workcenter_id = ls_apprvr_list-workcenter_id
*                    mail_to_requestor  = lv_mail_to_req
*                  IMPORTING
*                    is_mail_send       = ls_mail_send.
*              ENDLOOP.
*            ENDIF.
*          CATCH zcx_ca_form_exceptions. " Exceptions in forms
*        ENDTRY.
*
*      WHEN 'NEW_INTENALORDER_WEXP'.   "Create Internal Order with error/exceptional
*
*        TRY.
*            CALL METHOD create_internal_order EXPORTING intl_order_with_exp = gc_true.
*
*
*          CATCH zcx_ca_form_exceptions INTO lx_mdg_form_exception.
*
*        ENDTRY.
** Once success - Proceed form to next level
*        TRY.
*            submit_form( ).
*
** Send Email to all previous agents once project code and internal order created successfully
** Get list of workflow ID based on form name and version
*            SELECT * FROM zca_apprvr_list INTO TABLE lt_apprvr_list WHERE form_name = gc_form_name AND form_ver = gc_form_ver.
*            LOOP AT lt_apprvr_list INTO ls_apprvr_list WHERE appr_step NE 'BPC'.
*
*              IF ls_apprvr_list-workcenter_id IS INITIAL.
*                lv_mail_to_req = 'X'.
*              ELSE.
*                CLEAR lv_mail_to_req.
*              ENDIF.
*
*              CALL METHOD zmdg_send_email=>send_email
*                EXPORTING
*                  form_guid          = gs_formdetails-form_guid
*                  step_guid          = gs_stepdetail-step_guid
*                  proj_req_fields    = gs_email_value
*                  repl_scenario_name = 'MDG_PROJ_RTR_APP_ALL'
*                  repl_workcenter_id = ls_apprvr_list-workcenter_id
*                  mail_to_requestor  = lv_mail_to_req
*                IMPORTING
*                  is_mail_send       = ls_mail_send.
*            ENDLOOP.
*          CATCH zcx_ca_form_exceptions. " Exceptions in forms
*        ENDTRY.

      WHEN 'NEW_PROJECT'.
        try.
          create_project( ).

          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            CLEAR ls_message.
            ls_message-type = 'Error'.
            ls_message-message = lx_ca_form_exception->get_text( ).
            APPEND ls_message TO gt_sys_message.  " <TR> Was message API

            LOOP AT lx_ca_form_exception->error_table INTO ls_return.
              CLEAR ls_message.
              MOVE-CORRESPONDING ls_return TO ls_message.
              APPEND ls_message TO gt_sys_message.  " <TR> Was message API
            ENDLOOP.
          CATCH zcx_project_code_request into lx_project_request.
            CLEAR ls_message.
            ls_message-type = 'Error'.
            ls_message-message = lx_project_request->get_text( ).
            APPEND ls_message TO gt_sys_message.  " <TR> Was message API

            LOOP AT lx_project_request->messages INTO ls_return.
              CLEAR ls_message.
              MOVE-CORRESPONDING ls_return TO ls_message.
              APPEND ls_message TO gt_sys_message.  " <TR> Was message API
            ENDLOOP.
        endtry.

      WHEN 'DEQUEUE_FORM'.
        CALL METHOD me->check_dirty.
* <TR> Lock call off, shared class owned by other team (P-63)
*        zcl_nd_ca_utilities=>dequeue_form( gs_formdetails-form_guid ).

      WHEN 'AGENT_SEARCH'.
        CALL METHOD agent_search( ajax_value ).

      WHEN 'AUTH_BY_SEARCH'.
        CALL METHOD auth_by_search( ajax_value ).

      WHEN 'GET_ONBEHALF_ID'.
        TRY.
            get_on_behalf_data( ajax_value ).

          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
        ENDTRY.

      WHEN 'GET_AUTHBY_ID'.
        TRY.
            get_authorized_by_data( ajax_value ).

          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
        ENDTRY.

      WHEN 'GET_COSTCENTER'.
        TRY.
            get_costcenter( ajax_value ).

          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
          CLEANUP.
        ENDTRY.

      WHEN 'UPDATE_REGION'.
        TRY.
            CALL METHOD me->update_process_region.  " <TR> SERVER removed
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
          CLEANUP.
        ENDTRY.

    ENDCASE.
  ENDMETHOD.


METHOD handle_on_request.  " <TR> Was interface method
    DATA: lv_key                TYPE string,
          lv_form_guid          TYPE sysuuid_c,
          lv_attachment_uuid    TYPE string,
          lt_parameters         TYPE string_table,
          lv_parameter          TYPE string,
          lv_param_name         TYPE string,
          lv_value              TYPE string,
          lv_attachment_data    TYPE xstring,
          lv_mime_type          TYPE string,
          lv_file_name          TYPE string,
          lx_ca_form_exceptions TYPE REF TO zcx_ca_form_exceptions.

    lv_key = key.
    TRANSLATE lv_key TO UPPER CASE.

    CASE lv_key.
      WHEN 'ATTACHMENT'.
        IF key_id IS INITIAL.
          redirect_error( IMPORTING ev_data = ev_data ev_content_type = ev_content_type ).  " <TR> Returns page
          RETURN.
        ENDIF.

        SPLIT key_id AT ',' INTO TABLE lt_parameters.
        LOOP AT lt_parameters INTO lv_parameter.
          SPLIT lv_parameter AT '=' INTO lv_param_name lv_value.
          TRANSLATE lv_param_name TO UPPER CASE.
          CASE lv_param_name.
            WHEN 'FORM'.
              lv_form_guid = lv_value.
            WHEN 'ATT'.
              lv_attachment_uuid = lv_value.
          ENDCASE.
        ENDLOOP.

        IF lv_form_guid IS INITIAL
            OR lv_attachment_uuid IS INITIAL.
          redirect_error( IMPORTING ev_data = ev_data ev_content_type = ev_content_type ).  " <TR> Returns page
          RETURN.
        ENDIF.

        TRY.
            zcl_nd_ca_utilities=>get_attachment_data(
              EXPORTING
                iv_form_guid       = lv_form_guid
                iv_attachment_uuid = lv_attachment_uuid
              IMPORTING
                ev_attachment_data = lv_attachment_data
                ev_mime_type       = lv_mime_type
                ev_file_name       = lv_file_name
            ).

          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exceptions.

        ENDTRY.

        IF lv_attachment_data IS INITIAL.
          redirect_error( IMPORTING ev_data = ev_data ev_content_type = ev_content_type ).  " <TR> Returns page
          RETURN.
        ENDIF.

        ev_data         = lv_attachment_data.  " <TR> Was response API
        ev_content_type = lv_mime_type.
        ev_file_name    = lv_file_name.

        RETURN.
      WHEN OTHERS.
    ENDCASE.
  ENDMETHOD.




METHOD agent_search.
  DATA wa_agent_list TYPE ty_agent_list .

  TYPES: BEGIN OF ty_adrp,
           persnumber TYPE adrp-persnumber,
           name_text  TYPE adrp-name_text,
         END OF ty_adrp.

  DATA: it_adrp  TYPE STANDARD TABLE OF ty_adrp,
        it_usr21 TYPE STANDARD TABLE OF usr21,
        wa_usr21 TYPE usr21,
        wa_adrp  TYPE ty_adrp.

  DATA: ra_name TYPE RANGE OF adrp-mc_namefir,
        wa_name LIKE LINE OF ra_name.

  DATA: ls_usr02 TYPE usr02.
*--------------------------------------------------------------------*
* GET DATA
*--------------------------------------------------------------------*

  CHECK ajax_value IS NOT INITIAL.

* LastName
  wa_name-sign   = 'I'.
  wa_name-option = 'CP'.

  SPLIT ajax_value AT space INTO TABLE DATA(lt_name).
  LOOP AT lt_name INTO DATA(lw_name).
    CONCATENATE '*'
                lw_name
                '*'
                INTO wa_name-low.

    TRANSLATE wa_name-low TO UPPER CASE.
    APPEND wa_name TO ra_name.
  ENDLOOP.

* Get ADRP
  SELECT persnumber name_text
         FROM adrp
         INTO TABLE it_adrp
         WHERE mc_namefir IN ra_name
            OR mc_namelas IN ra_name
           AND pers_group IN ( 'BC01', 'BP' ) " Had to include BP for S4.
           AND date_from  LE sy-datum
           AND date_to    GE sy-datum.

* Any hit
  CHECK sy-subrc EQ 0.

* Get USR21
  SELECT *
         FROM usr21
         INTO TABLE it_usr21
         FOR ALL ENTRIES IN it_adrp
         WHERE persnumber EQ it_adrp-persnumber.

* Sorting
  SORT it_usr21 BY persnumber.


*--------------------------------------------------------------------*
* BUILD DATA
*--------------------------------------------------------------------*
  LOOP AT it_adrp INTO wa_adrp.
    READ TABLE it_usr21 INTO wa_usr21 WITH KEY persnumber = wa_adrp-persnumber BINARY SEARCH.

    CHECK sy-subrc EQ 0.

    wa_agent_list-otype = 'U'.
    wa_agent_list-objid = wa_usr21-bname.
    wa_agent_list-text  = wa_adrp-name_text.

*     Check if user is locked or valid dates are no current.
    SELECT SINGLE *
           INTO  ls_usr02
           FROM usr02
           WHERE bname = wa_usr21-bname
             AND gltgv LE sy-datum
             AND gltgb GE sy-datum
             AND uflag IN ( 0 , 128 ).

    IF sy-subrc = 0.

      APPEND wa_agent_list TO gt_agent_list.

    ENDIF.

  ENDLOOP.

* Sorting
  SORT gt_agent_list BY text.
  CLEAR wa_agent_list.

  INSERT wa_agent_list INTO gt_agent_list INDEX 1.

ENDMETHOD.


METHOD auth_by_search.
  DATA wa_agent_list TYPE ty_agent_list .

  TYPES: BEGIN OF ty_adrp,
           persnumber TYPE adrp-persnumber,
           name_text  TYPE adrp-name_text,
         END OF ty_adrp.

  DATA: it_adrp  TYPE STANDARD TABLE OF ty_adrp,
        it_usr21 TYPE STANDARD TABLE OF usr21,
        wa_usr21 TYPE usr21,
        wa_adrp  TYPE ty_adrp.

  DATA: ra_name TYPE RANGE OF adrp-mc_namefir,
        wa_name LIKE LINE OF ra_name.

  DATA: ls_usr02 TYPE usr02.
*--------------------------------------------------------------------*
* GET DATA
*--------------------------------------------------------------------*

  CHECK ajax_value IS NOT INITIAL.

* Name Search
  wa_name-sign   = 'I'.
  wa_name-option = 'CP'.

  SPLIT ajax_value AT space INTO TABLE DATA(lt_name).
  LOOP AT lt_name INTO DATA(lw_name).
    CONCATENATE '*'
                lw_name
                '*'
                INTO wa_name-low.

    TRANSLATE wa_name-low TO UPPER CASE.
    APPEND wa_name TO ra_name.
  ENDLOOP.

* Get ADRP
  SELECT persnumber name_text
         FROM adrp
         INTO TABLE it_adrp
         WHERE mc_namefir IN ra_name
            OR mc_namelas IN ra_name
           AND pers_group IN ( 'BC01', 'BP' ) " Had to include BP for S4.
           AND date_from  LE sy-datum
           AND date_to    GE sy-datum.

* Any hit
  CHECK sy-subrc EQ 0.

* Get USR21
  SELECT *
         FROM usr21
         INTO TABLE it_usr21
         FOR ALL ENTRIES IN it_adrp
         WHERE persnumber EQ it_adrp-persnumber.

* Sorting
  SORT it_usr21 BY persnumber.


*--------------------------------------------------------------------*
* BUILD DATA
*--------------------------------------------------------------------*
  LOOP AT it_adrp INTO wa_adrp.
    READ TABLE it_usr21 INTO wa_usr21 WITH KEY persnumber = wa_adrp-persnumber BINARY SEARCH.

    CHECK sy-subrc EQ 0.

    wa_agent_list-otype = 'U'.
    wa_agent_list-objid = wa_usr21-bname.
    wa_agent_list-text  = wa_adrp-name_text.


*     Check if user is locked or valid dates are no current.
    SELECT SINGLE *
           INTO  ls_usr02
           FROM usr02
           WHERE bname = wa_usr21-bname
             AND gltgv LE sy-datum
             AND gltgb GE sy-datum
             AND uflag IN ( 0 , 128 ).

    IF sy-subrc = 0.

      APPEND wa_agent_list TO gt_auth_by_list.

    ENDIF.

  ENDLOOP.

* Sorting
  SORT gt_auth_by_list BY text.
  CLEAR wa_agent_list.

  INSERT wa_agent_list INTO gt_auth_by_list INDEX 1.

ENDMETHOD.


METHOD change_form.
    DATA ls_proj_form         TYPE zmdg_proj_form.
    DATA lx_ca_form_exception TYPE REF TO zcx_ca_form_exceptions.
    DATA lx_proj              TYPE REF to zcx_project_code_request.
    DATA lv_objectname        TYPE string.
    DATA ls_email_value       TYPE zmdg_s_proj_email.
    DATA lv_formguid_updated  TYPE char1.

* Call shared workflow class to submit form
    DATA(lv_form_guid) = gs_formdetails-form_guid.
    DATA(lv_step_guid) = gs_stepdetail-step_guid.
    lv_objectname      = gs_proj_form-projectname.

    CALL METHOD clear_value.    "Clear value if the condition doesn't match

    currency_convert_in(
      exporting
        iv_currency = gs_proj_form-capex_req_curr
      changing
        cv_amount = gs_proj_form-capex_req_amount
    ).

* If the form GUID is initial.
    IF gs_formdetails-form_guid IS INITIAL.
* Including Internal Order - For Search App
      gs_proj_form-internal_no = wa_url_parameters-proj.
      TRY.
          CALL METHOD me->create_form.  " <TR> SERVER removed
          lv_formguid_updated = 'X'.        "Save as draft updated successfully
        CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
          wa_program_state-program_state   = 'E'.
          wa_program_state-program_message = lx_ca_form_exception->get_text( ).
          wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
        CATCH ZCX_PROJECT_CODE_REQUEST into lx_proj.
          wa_program_state-program_state   = 'E'.
          wa_program_state-program_message = lx_proj->get_text( ).
      ENDTRY.
      EXIT.
    ELSE.

* Call shared workflow class to Resubmit form
      lv_objectname      = gs_proj_form-projectname.

* Update Initiate By ID
      gs_proj_form-requester_id = sy-uname.

**Update Ver based on region
      CASE gs_proj_form-processing_region.
        WHEN 'E'.
          gc_form_ver = '0002'.
        WHEN 'A'.
          gc_form_ver = '0003'.
        WHEN OTHERS.
          gc_form_ver = '0001'.
      ENDCASE.

* Update Form Detail
      MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

      CALL METHOD populate_field_email
        EXPORTING
          ip_form        = ls_proj_form
        IMPORTING
          io_email_value = ls_email_value.

      TRY.
          zcl_nd_ca_mdg_workflow=>change_form(
            EXPORTING
              iv_form_name           = gc_form_name    " MDG - Form Name
              iv_form_version        = gc_form_ver     " MDG - Form Version
              iv_form_guid           = gs_formdetails-form_guid    " UUID in character form
              iv_step_guid           = gs_stepdetail-step_guid    " UUID in character form
              iv_email_object_name   = lv_objectname
              iv_proj_req_fields     = ls_email_value
            IMPORTING
               es_form_detail        = gs_formdetails
               es_current_step_detail_resub =  DATA(gs_currrent_stepdetail_resub)
               es_next_step_detail   = DATA(gs_nextstepdetail) ).

        CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
          wa_program_state-program_state   = 'E'.
          wa_program_state-program_message = lx_ca_form_exception->get_text( ).
          RETURN.
      ENDTRY.
* End of shared workflow class call.

* Update Multiple Company Code
* Check the condition before create multiple company code
      CLEAR ls_proj_form-more_addi_compcode.

* Update More additional company code
      LOOP AT gt_additional_ccode INTO gs_multipleccode WHERE status EQ 'sap-icon://add-document'.
        CONCATENATE gs_multipleccode-comp_code gs_multipleccode-kostl_code INTO DATA(lv_moreccode) SEPARATED BY '/'.
        IF ls_proj_form-more_addi_compcode IS INITIAL.
          ls_proj_form-more_addi_compcode = lv_moreccode.
        ELSE.
          CONCATENATE ls_proj_form-more_addi_compcode lv_moreccode INTO ls_proj_form-more_addi_compcode SEPARATED BY ','.
        ENDIF.
      ENDLOOP.

      IF lv_formguid_updated IS INITIAL.
        ls_proj_form-step_guid      = gs_currrent_stepdetail_resub-step_guid.
        MODIFY zmdg_proj_form FROM ls_proj_form.
        COMMIT WORK.
      ENDIF.

* Create duplicate record for STARTED Step Status
      IF gs_nextstepdetail-step_guid IS NOT INITIAL.
        CLEAR ls_proj_form-comments.
        ls_proj_form-step_guid      = gs_nextstepdetail-step_guid.
        MODIFY zmdg_proj_form FROM ls_proj_form.
        COMMIT WORK.
      ENDIF.

      IF NOT gt_attachments[] IS INITIAL.
        save_attachments( ).
      ENDIF.

* <TR> Lock call off, shared class owned by other team (P-63)
*      zcl_nd_ca_utilities=>dequeue_form( gs_formdetails-form_guid ).
    ENDIF.
  ENDMETHOD.


METHOD check_dirty.
* Check Is Dirty
    gs_proj_form-is_dirty = 'X'.
  ENDMETHOD.


METHOD check_error.
* D.Rempe - TODO: need to figure out how this multi-region thing is supposed to work. I can't have that in S4 projects.
*    DATA ls_region TYPE string.
*
** Allow user to select two region to create additional company code - Don't allow to select from 3 different region
*    IF wa_url_parameters-mode EQ 'EDIT'.
*      DELETE gt_additional_ccode WHERE status EQ space.
*      SORT gt_additional_ccode BY region.
*      DELETE ADJACENT DUPLICATES FROM gt_additional_ccode COMPARING region.
*
*      IF lines( gt_additional_ccode ) EQ 0.
*        RAISE EXCEPTION TYPE zcx_ca_form_exceptions
*          EXPORTING
*            textid = zcx_ca_form_exceptions=>addi_ccode_nochange.
*      ELSEIF lines( gt_additional_ccode ) GE 2.
*        RAISE EXCEPTION TYPE zcx_ca_form_exceptions
*          EXPORTING
*            textid = zcx_ca_form_exceptions=>addi_ccode_multiregion.
*      ENDIF.
*
** Check region in additional company code and region selected match
*      CASE wa_url_parameters-processing_region.
*        WHEN 'U'.
*          ls_region = 'US/LA'.
*        WHEN 'E'.
*          ls_region = 'Europe'.
*        WHEN 'A'.
*          ls_region = 'Asia'.
*      ENDCASE.
*
*      READ TABLE gt_additional_ccode INTO gs_multipleccode WITH KEY region = ls_region.
*      IF sy-subrc NE 0.
*        RAISE EXCEPTION TYPE zcx_ca_form_exceptions
*          EXPORTING
*            textid = zcx_ca_form_exceptions=>addi_ccode_region.
*      ENDIF.
*    ENDIF.
  ENDMETHOD.


METHOD class_constructor.

  ENDMETHOD.


METHOD clear_value.
** Clear Location/State if processing region is not USA
*    IF gs_proj_form-processing_region NE 'U'.
*      CLEAR gs_proj_form-state_us.
*    ENDIF.
*
** Clear Existing Project Code
*    IF gs_proj_form-replace_exit_prj NE 'true'.
*      CLEAR gs_proj_form-prev_proj_code.
*      CLEAR gs_proj_form-itl_prev_proj_code.
*      CLEAR gs_proj_form-imo_prev_proj_code.
*    ENDIF.
*
** Clear Company Code, Cost Center for Project Type 4
*    IF gs_proj_form-project_type = '4'.
*      CLEAR gs_proj_form-company_code.
*      CLEAR gs_proj_form-kostl.
*      CLEAR gs_proj_form-state_us.
*    ENDIF.
*
*    IF gs_proj_form-itl EQ 'Y' OR gs_proj_form-project_type EQ '2'.
*    ELSE.
*      CLEAR gs_proj_form-itl_req_amount.
*      CLEAR gs_proj_form-itl_req_curr.
*    ENDIF.

  ENDMETHOD.


METHOD close_form.
    DATA ls_proj_form TYPE zmdg_proj_form.
    DATA lx_ca_form_exception TYPE REF TO zcx_ca_form_exceptions.

* Call shared workflow class to Delete form
    TRY.
        zcl_nd_ca_mdg_workflow=>close_form(
          EXPORTING
            iv_form_guid           = gs_formdetails-form_guid
            iv_step_guid           = gs_stepdetail-step_guid
          IMPORTING
             es_form_detail        = gs_formdetails
             es_next_step_detail   = DATA(gs_nextstepdetail) ).

      CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
        wa_program_state-program_state   = 'E'.
        wa_program_state-program_message = lx_ca_form_exception->get_text( ).
        RETURN.
    ENDTRY.
* End of shared workflow class call.

* Clear Agent List
    CLEAR gs_formdetails-agent_id_list.
    MODIFY zca_formdetail FROM gs_formdetails.

    MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.
    ls_proj_form-step_guid = gs_nextstepdetail-step_guid.
    MODIFY zmdg_proj_form FROM ls_proj_form.

    COMMIT WORK.

    IF NOT gt_attachments[] IS INITIAL.
      save_attachments( ).
    ENDIF.

* <TR> Lock call off, shared class owned by other team (P-63)
*    zcl_nd_ca_utilities=>dequeue_form( gs_formdetails-form_guid ).
  ENDMETHOD.


METHOD create_cls_proj_code.
    DATA lt_zzdci_proj TYPE STANDARD TABLE OF zzdci_proj.
    DATA lv_next_no TYPE fico_nseq_no VALUE '0001'.
    DATA lv_existproj TYPE char4.
    DATA lw_zzdci_proj TYPE zzdci_proj.
    DATA lv_len TYPE i.
    DATA lv_htype TYPE dd01v-datatype.
    DATA lv_year TYPE char2.

* Check whether project code is already created - No duplicates ************************
    IF gs_proj_form-cls_proj_code(3) NE 'CLS'.
* Check End of month to update Year of Project Code request
      IF sy-datum+4(2) EQ '12'.
        lv_year = sy-datum+2(2) + 1.
      ELSE.
        lv_year = sy-datum+2(2).
      ENDIF.

      CONCATENATE 'CLS' lv_year '%' INTO DATA(lw_projcode).
      CONCATENATE 'CLS' lv_year INTO DATA(lw_propose_code).

* Read Existing Project Code
      SELECT * FROM zzdci_proj INTO TABLE lt_zzdci_proj WHERE zzproject LIKE lw_projcode.
      IF sy-subrc EQ 0.
*        SORT lt_zzdci_proj BY zzproject DESCENDING.
*        LOOP AT lt_zzdci_proj INTO lw_zzdci_proj.
        DATA(lv_count) = lines( lt_zzdci_proj ).

        READ TABLE lt_zzdci_proj INTO lw_zzdci_proj INDEX lv_count.

        lv_len = strlen( lw_zzdci_proj-zzproject ) - 4.
        lv_existproj = lw_zzdci_proj-zzproject+lv_len(4).
        CALL FUNCTION 'NUMERIC_CHECK'
          EXPORTING
            string_in = lv_existproj
          IMPORTING
            htype     = lv_htype.
        IF lv_htype = 'NUMC'.
          IF lv_next_no <= lv_existproj.
            lv_next_no = lv_existproj + 1.
          ENDIF.
        ENDIF.
*        ENDLOOP.
      ENDIF.

      CONCATENATE lw_propose_code lv_next_no INTO gs_proj_form-cls_proj_code SEPARATED BY '_'.

* Update Project Code
      lw_zzdci_proj-zzproject = gs_proj_form-cls_proj_code.
      lw_zzdci_proj-zzdescription = |{ gs_proj_form-cls_proj_code } { gs_proj_form-projectname }|.
      lw_zzdci_proj-labor_ind = 'X'.
      INSERT zzdci_proj FROM lw_zzdci_proj.
    ENDIF.
  ENDMETHOD.


METHOD create_form.
    DATA ls_proj_form   TYPE zmdg_proj_form.
    DATA lx_ca_form_exception TYPE REF TO zcx_ca_form_exceptions.
    DATA lv_objectname  TYPE string.
    DATA ls_email_value TYPE zmdg_s_proj_email.

* Call shared workflow class to submit form
    DATA(lv_form_guid) = gs_formdetails-form_guid.
    DATA(lv_step_guid) = gs_stepdetail-step_guid.
    lv_objectname      = gs_proj_form-projectname.

    CALL METHOD clear_value.    "Clear value if the condition doesn't match

* D.Rempe - 5/16/2024 - Was asked to remove this validation.
*    validate_brand_geo( ).

* Handle currency conversions for countries with more or less than 2 decimal places.
  currency_convert_in(
    exporting
      iv_currency = gs_proj_form-capex_req_curr
    changing
      cv_amount = gs_proj_form-capex_req_amount
  ).

**Update Ver based on region
    CASE gs_proj_form-processing_region.
      WHEN 'E'.
        gc_form_ver = '0002'.
      WHEN 'A'.
        gc_form_ver = '0003'.
      WHEN OTHERS.
        gc_form_ver = '0001'.
    ENDCASE.

* Populate value for email text
    MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

    CALL METHOD populate_field_email
      EXPORTING
        ip_form        = ls_proj_form
      IMPORTING
        io_email_value = ls_email_value.

    TRY.
        zcl_nd_ca_mdg_workflow=>submit_form(
          EXPORTING
            iv_form_name           = gc_form_name
            iv_form_version        = gc_form_ver
            iv_form_guid           = lv_form_guid
            iv_step_guid           = lv_step_guid
            iv_email_object_name   = lv_objectname
            iv_proj_req_fields     = ls_email_value
          IMPORTING
            es_form_detail         = gs_formdetails
            es_current_step_detail = gs_stepdetail
            es_next_step_detail    = DATA(gs_next_stepdetail)
        ).
      CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
        wa_program_state-program_state   = 'E'.
        wa_program_state-program_message = lx_ca_form_exception->get_text( ).
        RETURN.
    ENDTRY.
* End of shared workflow class call.

* Update Form Detail
* Update Additional Field

** 1 - Profit Center
*    SELECT SINGLE prctr INTO ls_proj_form-profit_center
*      FROM csks
*      WHERE kokrs = 'DCI'
*      AND   bukrs = ls_proj_form-company_code
*      AND   kostl = ls_proj_form-kostl
*      AND   datbi GE sy-datum
*      AND   datab LE sy-datum.
*
*    IF sy-subrc NE 0.
*      CLEAR ls_proj_form-profit_center.
*    ENDIF.
*
** Update Multiple Company Code
** Check the condition before create multiple company code
*    LOOP AT gt_additional_ccode INTO gs_multipleccode WHERE status NE 'sap-icon://add-document'.
*      CONCATENATE gs_multipleccode-comp_code gs_multipleccode-kostl_code INTO DATA(lv_multiplecc) SEPARATED BY '/'.     " CompanyCode + Cost Center
*      IF sy-tabix EQ 1.
*        ls_proj_form-additional_comp_code = lv_multiplecc.
*      ELSE.
*        CONCATENATE ls_proj_form-additional_comp_code lv_multiplecc INTO ls_proj_form-additional_comp_code SEPARATED BY ','.
*      ENDIF.
*    ENDLOOP.
*
*    CLEAR ls_proj_form-more_addi_compcode.
*
** Update More additional company code
*    LOOP AT gt_additional_ccode INTO gs_multipleccode WHERE status EQ 'sap-icon://add-document'.
*      CONCATENATE gs_multipleccode-comp_code gs_multipleccode-kostl_code INTO DATA(lv_moreccode) SEPARATED BY '/'.
*      IF ls_proj_form-more_addi_compcode IS INITIAL.
*        ls_proj_form-more_addi_compcode = lv_moreccode.
*      ELSE.
*        CONCATENATE ls_proj_form-more_addi_compcode lv_moreccode INTO ls_proj_form-more_addi_compcode SEPARATED BY ','.
*      ENDIF.
*    ENDLOOP.
*
*    IF ls_proj_form-cls EQ 'Y' AND ls_proj_form-itl EQ 'Y' AND ls_proj_form-project_type EQ '1'.
*      CLEAR ls_proj_form-additional_comp_code.
*    ENDIF.

    ls_proj_form-step_guid      = gs_stepdetail-step_guid.
    MODIFY zmdg_proj_form FROM ls_proj_form.
    COMMIT WORK.

* Create duplicate record for STARTED Step Status
    IF gs_next_stepdetail-step_guid IS NOT INITIAL.
      CLEAR ls_proj_form-comments.
      ls_proj_form-step_guid      = gs_next_stepdetail-step_guid.
      MODIFY zmdg_proj_form FROM ls_proj_form.
      COMMIT WORK.
    ENDIF.

    IF NOT gt_attachments[] IS INITIAL.
      save_attachments( ).
    ENDIF.

* <TR> Lock call off, shared class owned by other team (P-63)
*    zcl_nd_ca_utilities=>dequeue_form( gs_formdetails-form_guid ).

  ENDMETHOD.


METHOD create_form_wref_orderid.
    DATA lw_aufk TYPE aufk.
    DATA: lw_ccodes TYPE zmdg_prj_ccode.

    CLEAR gs_formdetails.
    CLEAR gs_stepdetail.

    gs_proj_form-proj_flgrp_0001 = 'Expanded'.
    gs_proj_form-proj_flgrp_0005 = 'Expanded'.
    gs_proj_form-proj_flgrp_0002 = 'Collapsed'.
    gs_proj_form-proj_flgrp_0003 = 'Collapsed'.
    gs_proj_form-proj_flgrp_0004 = 'Collapsed'.

*** Default all radio button to false
    gs_proj_form-replace_exit_prj = gc_false.
    gs_proj_form-fpa_approval = gc_false.
    gs_proj_form-rtr_approval = gc_false.
    gs_proj_form-bpc_approval = gc_false.


*** Read Order ID details from AUFK
    SELECT SINGLE * FROM aufk INTO lw_aufk WHERE aufnr = ip_orderid.
    IF sy-subrc EQ 0.
* Update Form details
      gs_proj_form-projectname    = lw_aufk-ktext.
      gs_proj_form-company_code   = lw_aufk-bukrs.
      gs_proj_form-kostl          = lw_aufk-kostv.

* Location
      IF lw_aufk-txjcd IS NOT INITIAL.
        gs_proj_form-state_us = lw_aufk-txjcd(2).
      ENDIF.

* Start and End date
      SELECT SINGLE * FROM coas INTO @DATA(lw_coas) WHERE aufnr = @ip_orderid.
      IF sy-subrc EQ 0.
        gs_proj_form-order_date             = lw_coas-user7.
        gs_proj_form-proj_completion_date   = lw_coas-user8.
        gs_proj_form-order_type             = lw_coas-auart.

        IF lw_coas-astkz IS NOT INITIAL.
          gs_proj_form-order_type             = 'Z060'.
        ENDIF.

*        CASE lw_coas-zzproject(3).
*          WHEN 'CAP'.
*            gs_proj_form-project_type = '1'.
*          WHEN 'ITL'.
*            gs_proj_form-project_type = '2'.
*          WHEN 'CLS'.
*            gs_proj_form-project_type = '3'.
*          WHEN OTHERS.
*            CLEAR gs_proj_form-project_type.
*        ENDCASE.
      ENDIF.

*** Form Field Group
      SELECT SINGLE * FROM zca_apprvr_list INTO @DATA(curr_agent) WHERE form_name = @gc_form_name AND form_ver = @gc_form_ver AND appr_seqno = '0001'.

      CALL METHOD me->set_header.

      CALL METHOD me->get_approvers.

      CALL METHOD me->set_button_visibility .

      CALL METHOD me->set_fldgrp_visibility
        EXPORTING
          is_form_locked = ''.

      CALL METHOD me->set_field_mandatory.

      CALL METHOD me->set_field_visible.

      CALL METHOD me->set_field_cond_visible.

      CALL METHOD me->set_field_read_only.

      CALL METHOD me->set_field_default_value.

* To set navigation and display button editable
      IF wa_url_parameters-mode EQ 'EDIT' OR wa_url_parameters-mode EQ 'DISPLAY'.
        gs_proj_form-navigation_visible = gc_true.
      ELSE.
        gs_proj_form-navigation_visible = gc_false.
      ENDIF.

      IF wa_url_parameters-mode EQ 'EDIT'.
        gs_proj_form-page_header        = 'Change Project Code Request'.
        gs_proj_form-mode_button_icon   = 'sap-icon://display'.
        gs_proj_form-display_or_edit    = 'EDIT'.
        gs_proj_form-request_from       = 'U'.
      ELSEIF wa_url_parameters-mode EQ 'DISPLAY'.
        gs_proj_form-page_header        = 'Display Order details'.
        gs_proj_form-mode_button_icon   = 'sap-icon://edit'.
        gs_proj_form-display_or_edit    = 'DISPLAY'.
        gs_proj_form-request_from       = 'U'.
      ENDIF.

      SELECT SINGLE * INTO lw_ccodes FROM zmdg_prj_ccode WHERE company_code EQ gs_proj_form-company_code.
      IF sy-subrc EQ 0.
        gs_proj_form-processing_region = lw_ccodes-processing_region.
      ENDIF.

** Update Cost Center
      SELECT SINGLE * FROM cskt INTO @DATA(lw_cskt) WHERE spras = 'E' AND kostl EQ @gs_proj_form-kostl.
      IF sy-subrc EQ 0.
        gs_proj_form-kostl_text = |{ lw_cskt-kostl } { lw_cskt-ltext }|.
      ENDIF.

** Make Project Type field enabled - If there is no value exist before
      IF wa_url_parameters-mode EQ 'EDIT' AND gs_proj_form-project_type IS INITIAL.
        gs_proj_form-e_project_type = gc_true.
        gs_proj_form-r_project_type = gc_true.
      ELSEIF wa_url_parameters-mode EQ 'DISPLAY' OR ( wa_url_parameters-mode EQ 'EDIT' AND gs_proj_form-project_type IS NOT INITIAL ).
        gs_proj_form-e_project_type = gc_false.
        gs_proj_form-r_project_type = gc_false.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD create_imo_proj_code.
    DATA lt_zzdci_proj TYPE STANDARD TABLE OF zzdci_proj.
    DATA lv_next_no TYPE fico_nseq_no VALUE '0001'.
    DATA lv_existproj TYPE char4.
    DATA lw_zzdci_proj TYPE zzdci_proj.
    DATA lv_len TYPE i.
    DATA lv_htype TYPE dd01v-datatype.
    DATA lv_year TYPE char2.

* Check whether project code is already created - No duplicates ************************
    IF gs_proj_form-cls_proj_code(3) NE 'IMO'.
* Check End of month to update Year of Project Code request
      IF sy-datum+4(2) EQ '12'.
        lv_year = sy-datum+2(2) + 1.
      ELSE.
        lv_year = sy-datum+2(2).
      ENDIF.

      CONCATENATE 'IMO' lv_year '%' INTO DATA(lw_projcode).
      CONCATENATE 'IMO' lv_year INTO DATA(lw_propose_code).

* Read Existing Project Code
      SELECT * FROM zzdci_proj INTO TABLE lt_zzdci_proj WHERE zzproject LIKE lw_projcode.
      IF sy-subrc EQ 0.
*        SORT lt_zzdci_proj BY zzproject DESCENDING.
*        LOOP AT lt_zzdci_proj INTO lw_zzdci_proj.
          DATA(lv_count) = lines( lt_zzdci_proj ).
          READ TABLE lt_zzdci_proj INTO lw_zzdci_proj INDEX lv_count.

          lv_len = strlen( lw_zzdci_proj-zzproject ) - 4.
          lv_existproj = lw_zzdci_proj-zzproject+lv_len(4).
          CALL FUNCTION 'NUMERIC_CHECK'
            EXPORTING
              string_in = lv_existproj
            IMPORTING
              htype     = lv_htype.
          IF lv_htype = 'NUMC'.
            IF lv_next_no <= lv_existproj.
              lv_next_no = lv_existproj + 1.
            ENDIF.
          ENDIF.
*        ENDLOOP.
      ENDIF.

      CONCATENATE lw_propose_code lv_next_no INTO gs_proj_form-cls_proj_code SEPARATED BY '_'.

* Update Project Code
      lw_zzdci_proj-zzproject = gs_proj_form-cls_proj_code.
      lw_zzdci_proj-zzdescription = |{ gs_proj_form-cls_proj_code } { gs_proj_form-projectname }|.
      lw_zzdci_proj-labor_ind = 'X'.
      INSERT zzdci_proj FROM lw_zzdci_proj.
    ENDIF.
  ENDMETHOD.


METHOD create_init.
    CLEAR gs_formdetails.
    CLEAR gs_stepdetail.

    gs_proj_form-proj_flgrp_0001 = 'Expanded'.
    gs_proj_form-proj_flgrp_0005 = 'Expanded'.
    gs_proj_form-proj_flgrp_0002 = 'Collapsed'.
    gs_proj_form-proj_flgrp_0003 = 'Collapsed'.
    gs_proj_form-proj_flgrp_0004 = 'Collapsed'.

*** Default all radio button to false
    gs_proj_form-replace_exit_prj = gc_false.
    gs_proj_form-fpa_approval = gc_false.
    gs_proj_form-rtr_approval = gc_false.
    gs_proj_form-bpc_approval = gc_false.

    gs_proj_form-page_header = 'New Project Code Request'.
    gs_proj_form-navigation_visible = 'false'.
    gs_proj_form-request_from = 'N'. "New Request

*** Form Field Group
    SELECT SINGLE * FROM zca_apprvr_list INTO @DATA(curr_agent) WHERE form_name = @gc_form_name AND form_ver = @gc_form_ver AND appr_seqno = '0001'.

    CALL METHOD me->set_header .

    CALL METHOD me->get_approvers.

    CALL METHOD me->set_button_visibility .

    CALL METHOD me->set_fldgrp_visibility
      EXPORTING
        is_form_locked = ''.

    CALL METHOD me->set_field_mandatory.

    CALL METHOD me->set_field_visible.

    CALL METHOD me->set_field_cond_visible.

    CALL METHOD me->set_field_read_only.

    CALL METHOD me->set_field_default_value.

    gs_proj_form-can_attach = 'X'.
  ENDMETHOD.


METHOD create_internal_order.
    DATA:
      lv_aufnr          TYPE aufnr,
      ls_prev_proj_code TYPE zzdeproject,
      lt_return         TYPE bapiret2_t,
      lt_itl_return     TYPE bapiret2_t,
      lt_cls_return     TYPE bapiret2_t,
      ls_proj_form      TYPE zmdg_proj_form,
      lv_message        TYPE alv_string.

    IF gs_proj_form-project_type NE '2'.
* Step 2 - Create New Project Code
      CALL METHOD get_proj_code.
* Step 4 - Create Internal Order
      MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

* Check Internal Order
      IF ls_proj_form-internal_no IS INITIAL.
        IF ls_proj_form-profit_center IS INITIAL AND ls_proj_form-project_type NE '4'.
* Update Order detail table
          gs_orderdetails-output_ccode   = ls_proj_form-company_code.
          gs_orderdetails-output_ccenter = ls_proj_form-kostl.
          gs_orderdetails-project_code   = ls_proj_form-project_code.
          gs_orderdetails-error_desc     = 'No valid profit center for Company Code and Cost Center'(e13).
          gs_orderdetails-is_error       = gc_true.
        ELSE.

          CALL FUNCTION 'Z_MDG_CREATE_INTERNALORDER'
            EXPORTING
              is_order    = ls_proj_form              " MDG - project code request Form
              is_projcode = ls_proj_form-project_code
            IMPORTING
              ev_aufnr    = lv_aufnr                  " Order Number
            TABLES
              et_return   = lt_return.                 " Return Parameter

          IF lv_aufnr IS NOT INITIAL.
* Update Order detail table
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-internal_order = ls_proj_form-internal_no = lv_aufnr.
            gs_orderdetails-project_code   = ls_proj_form-project_code.
            gs_orderdetails-error_desc     = |{ ls_proj_form-projectname } { '-' } { ls_proj_form-company_code } |.
            gs_orderdetails-is_error       = gc_false.

            CLEAR ls_proj_form-internal_no_err.       " Clear any error
            REFRESH lt_return.

* Delete existing Project Code if it selected
            IF gs_proj_form-prev_proj_code IS NOT INITIAL.
              ls_prev_proj_code = gs_proj_form-prev_proj_code.
              CALL METHOD deactive_exist_projcode EXPORTING ip_prev_proj_code = ls_prev_proj_code.
            ENDIF.

* Delete IMO existing Project Code if it selected
            IF gs_proj_form-imo_prev_proj_code IS NOT INITIAL.
              ls_prev_proj_code = gs_proj_form-imo_prev_proj_code.
              CALL METHOD deactive_exist_projcode EXPORTING ip_prev_proj_code = ls_prev_proj_code.
            ENDIF.

          ELSE.
            DELETE lt_return WHERE type NE 'E'.
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-project_code   = ls_proj_form-project_code.

            READ TABLE lt_return INTO DATA(lw_return) WITH KEY type = 'E'.
            IF sy-subrc EQ 0.
              LOOP AT lt_return INTO lw_return WHERE type = 'E'.
                IF sy-tabix EQ 1.
                  lv_message = lw_return-message.
                ELSE.
                  lv_message = | { '/' } { lv_message } { lw_return-message }|.
                ENDIF.
              ENDLOOP.
              gs_orderdetails-is_error       = gc_true.
              gs_orderdetails-error_desc = ls_proj_form-internal_no_err = lv_message.
* Delete existing Project Code
              IF gs_proj_form-prev_proj_code IS NOT INITIAL AND intl_order_with_exp EQ gc_true.
                ls_prev_proj_code = gs_proj_form-prev_proj_code.
                CALL METHOD deactive_exist_projcode EXPORTING ip_prev_proj_code = ls_prev_proj_code.
              ENDIF.
* Delete IMO existing Project Code if it selected
              IF gs_proj_form-imo_prev_proj_code IS NOT INITIAL.
                ls_prev_proj_code = gs_proj_form-imo_prev_proj_code.
                CALL METHOD deactive_exist_projcode EXPORTING ip_prev_proj_code = ls_prev_proj_code.
              ENDIF.

            ENDIF.
          ENDIF.
        ENDIF.

        APPEND gs_orderdetails TO gt_orderdetails.
        MOVE-CORRESPONDING ls_proj_form TO gs_proj_form.
      ELSE.
* Update Order detail table
        gs_orderdetails-output_ccode   = ls_proj_form-company_code.
        gs_orderdetails-output_ccenter = ls_proj_form-kostl.
        gs_orderdetails-internal_order = ls_proj_form-internal_no.
        gs_orderdetails-project_code   = ls_proj_form-project_code.
        gs_orderdetails-error_desc     = |{ ls_proj_form-projectname } { '-' } { ls_proj_form-company_code }|.
        gs_orderdetails-is_error       = gc_false.
        APPEND gs_orderdetails TO gt_orderdetails.
      ENDIF.
    ENDIF.

*** Create ITL Internal Order *************************************************************
    IF gs_proj_form-project_type EQ '2' OR gs_proj_form-itl = 'Y'.
      CLEAR lv_aufnr.
      CLEAR lv_message.
      CLEAR gs_orderdetails.

      CALL METHOD create_itl_proj_code.

      MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

* Check Internal Order
      IF ls_proj_form-itl_internal_no IS INITIAL.
        IF ls_proj_form-profit_center IS INITIAL.
* Update Order detail table
          gs_orderdetails-output_ccode   = ls_proj_form-company_code.
          gs_orderdetails-output_ccenter = ls_proj_form-kostl.
          gs_orderdetails-project_code   = ls_proj_form-itl_proj_code.
          gs_orderdetails-error_desc     = 'No valid profit center for Company Code and Cost Center'(e13).
          gs_orderdetails-is_error       = gc_true.
        ELSE.
          CALL FUNCTION 'Z_MDG_CREATE_INTERNALORDER'
            EXPORTING
              is_order    = ls_proj_form              " MDG - project code request Form
              is_projcode = ls_proj_form-itl_proj_code
            IMPORTING
              ev_aufnr    = lv_aufnr                  " Order Number
            TABLES
              et_return   = lt_itl_return.            " Return Parameter

          IF lv_aufnr IS NOT INITIAL.
* Update Order detail table
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-internal_order = ls_proj_form-itl_internal_no = lv_aufnr.
            gs_orderdetails-project_code   = ls_proj_form-itl_proj_code.
            gs_orderdetails-error_desc     = |{ ls_proj_form-projectname } { '-' } { ls_proj_form-company_code }|.
            gs_orderdetails-is_error       = gc_false.
* Clear any error
            CLEAR ls_proj_form-itl_int_no_error.

            IF gs_proj_form-itl_prev_proj_code IS NOT INITIAL.
              ls_prev_proj_code = gs_proj_form-itl_prev_proj_code.
              CALL METHOD deactive_exist_projcode EXPORTING ip_prev_proj_code = ls_prev_proj_code.
            ENDIF.

          ELSE.
            DELETE lt_itl_return WHERE type NE 'E'.
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-project_code   = ls_proj_form-itl_proj_code.
            gs_orderdetails-is_error       = gc_true.

            READ TABLE lt_itl_return INTO lw_return WITH KEY type = 'E'.
            IF sy-subrc EQ 0.
              APPEND LINES OF lt_itl_return TO lt_return.
              LOOP AT lt_itl_return INTO lw_return WHERE type = 'E'.
                IF sy-tabix EQ 1.
                  lv_message = lw_return-message.
                ELSE.
                  lv_message = | { '/' } { lv_message } { lw_return-message }|.
                ENDIF.
              ENDLOOP.
              gs_orderdetails-error_desc = ls_proj_form-itl_int_no_error = lv_message.

              IF gs_proj_form-itl_prev_proj_code IS NOT INITIAL AND intl_order_with_exp EQ gc_true.
                ls_prev_proj_code = gs_proj_form-itl_prev_proj_code.
                CALL METHOD deactive_exist_projcode EXPORTING ip_prev_proj_code = ls_prev_proj_code.
              ENDIF.

            ENDIF.
          ENDIF.
        ENDIF.

        APPEND gs_orderdetails TO gt_orderdetails.
        MOVE-CORRESPONDING ls_proj_form TO gs_proj_form.
      ELSE.
* Update Order detail table
        gs_orderdetails-output_ccode   = ls_proj_form-company_code.
        gs_orderdetails-output_ccenter = ls_proj_form-kostl.
        gs_orderdetails-internal_order = ls_proj_form-itl_internal_no.
        gs_orderdetails-project_code   = ls_proj_form-itl_proj_code.
        gs_orderdetails-error_desc     = |{ ls_proj_form-projectname } { '-' } { ls_proj_form-company_code }|.
        APPEND gs_orderdetails TO gt_orderdetails.
      ENDIF.

    ENDIF.

    MOVE-CORRESPONDING ls_proj_form TO gs_proj_form.

*** Create CLS Internal Order *************************************************************
    IF ( gs_proj_form-project_type EQ '1' OR gs_proj_form-project_type EQ '5' ) AND gs_proj_form-cls = 'Y'.
      CLEAR lv_aufnr.
      CLEAR lv_message.
      CLEAR gs_orderdetails.

      CALL METHOD create_cls_proj_code.

      MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

* Check Internal Order
      IF ls_proj_form-cls_internal_no IS INITIAL.
        CALL FUNCTION 'Z_MDG_CREATE_INTERNALORDER'
          EXPORTING
            is_order    = ls_proj_form              " MDG - project code request Form
            is_projcode = ls_proj_form-cls_proj_code
          IMPORTING
            ev_aufnr    = lv_aufnr                  " Order Number
          TABLES
            et_return   = lt_cls_return.            " Return Parameter

        IF lv_aufnr IS NOT INITIAL.
* Update Order detail table
          gs_orderdetails-output_ccode   = ls_proj_form-company_code.
          gs_orderdetails-output_ccenter = ls_proj_form-kostl.
          gs_orderdetails-internal_order = ls_proj_form-cls_internal_no = lv_aufnr.
          gs_orderdetails-project_code   = ls_proj_form-cls_proj_code.
          gs_orderdetails-error_desc     = |{ ls_proj_form-projectname } { '-' } { ls_proj_form-company_code }|.
          gs_orderdetails-is_error       = gc_false.
* Clear any error
          CLEAR ls_proj_form-cls_int_no_error.

        ELSE.
          DELETE  lt_cls_return WHERE type NE 'E'.
          gs_orderdetails-output_ccode   = ls_proj_form-company_code.
          gs_orderdetails-output_ccenter = ls_proj_form-kostl.
          gs_orderdetails-project_code   = ls_proj_form-cls_proj_code.
          gs_orderdetails-is_error       = gc_true.
          READ TABLE lt_itl_return INTO lw_return WITH KEY type = 'E'.
          IF sy-subrc EQ 0.
            APPEND LINES OF lt_cls_return TO lt_return.

            LOOP AT lt_cls_return INTO lw_return WHERE type = 'E'.
              IF sy-tabix EQ 1.
                lv_message = lw_return-message.
              ELSE.
                lv_message = | { '/' } { lv_message } { lw_return-message }|.
              ENDIF.
            ENDLOOP.
            gs_orderdetails-error_desc = ls_proj_form-cls_int_no_error = lv_message.
          ENDIF.
        ENDIF.

        APPEND gs_orderdetails TO gt_orderdetails.
        MOVE-CORRESPONDING ls_proj_form TO gs_proj_form.
      ELSE.
* Update Order detail table
        gs_orderdetails-output_ccode   = ls_proj_form-company_code.
        gs_orderdetails-output_ccenter = ls_proj_form-kostl.
        gs_orderdetails-internal_order = ls_proj_form-cls_internal_no.
        gs_orderdetails-project_code   = ls_proj_form-cls_proj_code.
        gs_orderdetails-error_desc     = |{ ls_proj_form-projectname } { '-' } { ls_proj_form-company_code }|.
        gs_orderdetails-is_error       = gc_false.
        APPEND gs_orderdetails TO gt_orderdetails.
      ENDIF.

    ENDIF.

    MOVE-CORRESPONDING ls_proj_form TO gs_proj_form.

* Check any error to report back
    READ TABLE gt_orderdetails INTO gs_orderdetails WITH KEY is_error = gc_true.
    IF sy-subrc EQ 0.
      lw_return-message = TEXT-e14.
      APPEND lw_return TO lt_return.

      gs_proj_form-submitwth_err = gc_true.

      wa_program_state-program_state = 'E'.
      wa_program_state-program_message = TEXT-e14.

    ENDIF.

* Check to create Multiple Internal Order for different company code
    TRY.
        CALL METHOD me->create_multi_internal_order
          RECEIVING
            rt_messages_out = rt_messages_out.
      CATCH zcx_ca_form_exceptions. " Exceptions in share point forms
    ENDTRY.

** Check to raise exceptional
    READ TABLE gt_orderdetails INTO gs_orderdetails WITH KEY is_error = gc_true.

    IF sy-subrc EQ 0 AND intl_order_with_exp EQ gc_false.
      MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.
      MODIFY zmdg_proj_form FROM ls_proj_form.
      RAISE EXCEPTION TYPE zcx_ca_form_exceptions
        EXPORTING
          textid      = zcx_ca_form_exceptions=>internal_order_error
          error_table = lt_return.
    ENDIF.

  ENDMETHOD.


METHOD create_itl_proj_code.
    DATA lt_zzdci_proj TYPE STANDARD TABLE OF zzdci_proj.
    DATA lv_next_no TYPE fico_nseq_no VALUE '0001'.
    DATA lv_existproj TYPE char4.
    DATA lw_zzdci_proj TYPE zzdci_proj.
    DATA lv_len TYPE i.
    DATA lv_htype TYPE dd01v-datatype.
    DATA lv_year TYPE char2.

* Check whether project code is already created - No duplicates ************************
    IF gs_proj_form-itl_proj_code(3) NE 'ITL'.
* Check End of month to update Year of Project Code request
      IF sy-datum+4(2) EQ '12'.
        lv_year = sy-datum+2(2) + 1.
      ELSE.
        lv_year = sy-datum+2(2).
      ENDIF.

      CONCATENATE 'ITL' lv_year '%' INTO DATA(lw_projcode).
      CONCATENATE 'ITL' lv_year INTO DATA(lw_propose_code).

* Read Existing Project Code
      SELECT * FROM zzdci_proj INTO TABLE lt_zzdci_proj WHERE zzproject LIKE lw_projcode.
      IF sy-subrc EQ 0.
*        SORT lt_zzdci_proj BY zzproject DESCENDING.
        DATA(lv_count) = lines( lt_zzdci_proj ).

        READ TABLE lt_zzdci_proj INTO lw_zzdci_proj INDEX lv_count.

*        LOOP AT lt_zzdci_proj INTO lw_zzdci_proj.
        lv_len = strlen( lw_zzdci_proj-zzproject ) - 4.
        lv_existproj = lw_zzdci_proj-zzproject+lv_len(4).
        CALL FUNCTION 'NUMERIC_CHECK'
          EXPORTING
            string_in = lv_existproj
          IMPORTING
            htype     = lv_htype.
        IF lv_htype = 'NUMC'.
          IF lv_next_no <= lv_existproj.
            lv_next_no = lv_existproj + 1.
          ENDIF.
        ENDIF.
*        ENDLOOP.
      ENDIF.

      CONCATENATE lw_propose_code lv_next_no INTO gs_proj_form-itl_proj_code SEPARATED BY '_'.

* Update Project Code
      lw_zzdci_proj-zzproject = gs_proj_form-itl_proj_code.
      lw_zzdci_proj-zzdescription = |{ gs_proj_form-itl_proj_code } { gs_proj_form-projectname }|.
      lw_zzdci_proj-labor_ind = 'X'.
      INSERT zzdci_proj FROM lw_zzdci_proj.
    ENDIF.
  ENDMETHOD.


METHOD create_multi_internal_order.
    TYPES: BEGIN OF ty_ccode_kostl,
             bukrs           TYPE bukrs,
             kostl           TYPE kostl,
             project_code    TYPE aufnr,
             internal_no     TYPE char20,
             itl_proj_code   TYPE aufnr,
             itl_internal_no TYPE char20,
             cls_proj_code   TYPE aufnr,
             cls_internal_no TYPE char20,
             status          TYPE char1,
           END OF ty_ccode_kostl.

    DATA:
      lv_aufnr                  TYPE aufnr,
      lt_return                 TYPE bapiret2_t,
      lt_itl_return             TYPE bapiret2_t,
      ls_proj_form              TYPE zmdg_proj_form,
      ls_proj_form_01           TYPE zmdg_proj_form,
      lv_message                TYPE alv_string,
      lv_update_add_ccode       TYPE alv_string,
      lv_update_additionalccode TYPE alv_string,
      lv_update_addinternalno   TYPE alv_string,
      lv_report_error           TYPE boole_d,
      ls_ccode_kostl            TYPE ty_ccode_kostl,
      lt_ccode_kostl            TYPE STANDARD TABLE OF ty_ccode_kostl.

* To create Internal Order
    MOVE-CORRESPONDING gs_proj_form TO ls_proj_form_01.

    SPLIT gs_proj_form-additional_comp_code AT ',' INTO TABLE DATA(it_add_comp_code).

* Built combination of CCode and Cost Center table
    LOOP AT it_add_comp_code INTO DATA(wa_add_comp_code).
      SPLIT wa_add_comp_code AT '/' INTO    DATA(lv_ccode)
                                            DATA(lv_ccenter)
                                            DATA(lv_project_code)
                                            DATA(lv_internal_no)
                                            DATA(lv_itl_proj_code)
                                            DATA(lv_itl_internal_no)
                                            DATA(lv_status)
                                            DATA(lv_cls_proj_code)
                                            DATA(lv_cls_internal_no).

      CONDENSE lv_ccode.
      CONDENSE lv_ccenter.
      CONDENSE lv_project_code.
      CONDENSE lv_internal_no.
      CONDENSE lv_itl_proj_code.
      CONDENSE lv_itl_internal_no.
      CONDENSE lv_cls_proj_code.
      CONDENSE lv_cls_internal_no.
      CONDENSE lv_status.

      ls_ccode_kostl-bukrs = lv_ccode.
      ls_ccode_kostl-kostl = lv_ccenter.
      ls_ccode_kostl-project_code = lv_project_code.
      ls_ccode_kostl-internal_no = lv_internal_no.
      ls_ccode_kostl-itl_proj_code = lv_itl_proj_code.
      ls_ccode_kostl-itl_internal_no = lv_itl_internal_no.
      ls_ccode_kostl-cls_proj_code = lv_cls_proj_code.
      ls_ccode_kostl-cls_internal_no = lv_cls_internal_no.
      ls_ccode_kostl-status = lv_status.
      APPEND ls_ccode_kostl TO lt_ccode_kostl.
    ENDLOOP.

* Include more additional company code
    SPLIT gs_proj_form-more_addi_compcode AT ',' INTO TABLE it_add_comp_code.
    LOOP AT it_add_comp_code INTO wa_add_comp_code.
      CLEAR ls_ccode_kostl.
      SPLIT wa_add_comp_code AT '/' INTO lv_ccode lv_ccenter.

      CONDENSE lv_ccode.
      CONDENSE lv_ccenter.

      READ TABLE lt_ccode_kostl INTO ls_ccode_kostl WITH KEY bukrs = lv_ccode kostl = lv_ccenter.
      IF sy-subrc NE 0.
        ls_ccode_kostl-bukrs = lv_ccode.
        ls_ccode_kostl-kostl = lv_ccenter.
        APPEND ls_ccode_kostl TO lt_ccode_kostl.
      ENDIF.
    ENDLOOP.

    LOOP AT gt_additional_ccode INTO gs_multipleccode.

* Check if Internal Order is created before
      LOOP AT lt_ccode_kostl INTO ls_ccode_kostl WHERE bukrs = gs_multipleccode-comp_code AND kostl = gs_multipleccode-kostl_code.
        gs_orderdetails-output_ccode   = ls_ccode_kostl-bukrs.
        gs_orderdetails-output_ccenter = ls_ccode_kostl-kostl.
        lv_project_code                = ls_ccode_kostl-project_code.
        lv_internal_no                 = ls_ccode_kostl-internal_no.
        lv_itl_proj_code               = ls_ccode_kostl-itl_proj_code.
        lv_itl_internal_no             = ls_ccode_kostl-itl_internal_no.
        lv_cls_proj_code               = ls_ccode_kostl-cls_proj_code.
        lv_cls_internal_no             = ls_ccode_kostl-cls_internal_no.
        lv_status                      = ls_ccode_kostl-status.

* Update Req. Status
        IF lv_status EQ 'S'.

* CAPEX - Update Order detail table
          IF lv_internal_no IS NOT INITIAL.
            lv_update_add_ccode = | { gs_orderdetails-output_ccode } { '/' } { gs_orderdetails-output_ccenter } { '/' } { lv_project_code } { '/' } { lv_internal_no }|. " CAPEX
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { '' } { '/' } { '' } { '/' } { 'S' }|. " ITL
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { '' } { '/' } { '' } |. "CLS

            gs_orderdetails-output_ccode   = gs_orderdetails-output_ccode.
            gs_orderdetails-output_ccenter = gs_orderdetails-output_ccenter.
            gs_orderdetails-internal_order = lv_internal_no.
            gs_orderdetails-project_code   = lv_project_code.
            gs_orderdetails-error_desc     = |{ gs_proj_form-projectname } { '-' } { gs_orderdetails-output_ccode } |.
            gs_orderdetails-is_error       = gc_false.
            lv_aufnr                       = lv_internal_no.

* ITL - Update Order detail table
          ELSEIF lv_itl_internal_no IS NOT INITIAL.
            lv_update_add_ccode = | { gs_orderdetails-output_ccode } { '/' } { gs_orderdetails-output_ccenter } { '/' } { '' } { '/' } { '' }|. " CAPEX
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { lv_itl_proj_code } { '/' } { lv_itl_internal_no } { '/' } { 'S' }|. " ITL
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { '' } { '/' } { '' }|. "CLS

            gs_orderdetails-output_ccode   = gs_orderdetails-output_ccode.
            gs_orderdetails-output_ccenter = gs_orderdetails-output_ccenter.
            gs_orderdetails-internal_order = lv_itl_internal_no.
            gs_orderdetails-project_code   = lv_itl_proj_code.
            gs_orderdetails-error_desc     = |{ gs_proj_form-projectname } { '-' } { gs_orderdetails-output_ccode }|.
            gs_orderdetails-is_error       = gc_false.
            lv_aufnr                       = lv_itl_internal_no.

* CLS - Update Order detail table
          ELSEIF lv_cls_internal_no IS NOT INITIAL.
            lv_update_add_ccode = | { gs_orderdetails-output_ccode } { '/' } { gs_orderdetails-output_ccenter } { '/' } { '' } { '/' } { '' }|. " CAPEX
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { '' } { '/' } { '' } { '/' } { 'S' }|. " ITL
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { lv_cls_proj_code } { '/' } { lv_cls_internal_no }|. "CLS

            gs_orderdetails-output_ccode   = gs_orderdetails-output_ccode.
            gs_orderdetails-output_ccenter = gs_orderdetails-output_ccenter.
            gs_orderdetails-internal_order = lv_cls_internal_no.
            gs_orderdetails-project_code   = lv_cls_proj_code.
            gs_orderdetails-error_desc     = |{ gs_proj_form-projectname } { '-' } { gs_orderdetails-output_ccode }|.
            gs_orderdetails-is_error       = gc_false.
            lv_aufnr                       = lv_cls_internal_no.
          ENDIF.

          IF lv_update_additionalccode IS INITIAL.
            lv_update_additionalccode = lv_update_add_ccode.
          ELSE.
            lv_update_additionalccode = | { lv_update_additionalccode } { ',' } { lv_update_add_ccode } |.
          ENDIF.

          IF lv_update_addinternalno IS INITIAL.
            lv_update_addinternalno = lv_aufnr.
          ELSE.
            lv_update_addinternalno = |{ lv_update_addinternalno } { ',' } { lv_aufnr }|.
          ENDIF.

          APPEND gs_orderdetails TO gt_orderdetails.
          CONTINUE.
        ENDIF.

*Update CAPEX ********************************
        IF gs_proj_form-project_type NE '2' AND ( ( lv_internal_no IS INITIAL     AND lv_status IS INITIAL ) OR
                                                  ( lv_internal_no IS NOT INITIAL AND lv_project_code IS NOT INITIAL AND lv_status = 'E') ).
* Clear existing code
          CLEAR gs_orderdetails.

* To create Internal Order
          MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

* Update Company Code & Cost Center
          ls_proj_form-company_code = gs_multipleccode-comp_code.
          ls_proj_form-kostl        = gs_multipleccode-kostl_code.
          ls_proj_form-project_code = ls_proj_form-project_code.

* Update Profit Center
          SELECT SINGLE prctr INTO ls_proj_form-profit_center
            FROM csks
            WHERE kokrs = 'DCI'
            AND   kostl = ls_proj_form-kostl
            AND   bukrs = ls_proj_form-company_code
            AND   datbi GE sy-datum
            AND   datab LE sy-datum.

          IF ls_proj_form-profit_center IS INITIAL OR sy-subrc NE 0.
* Update Order detail table
            lv_report_error = 'X'.
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-project_code   = ls_proj_form-project_code.
            gs_orderdetails-error_desc     = TEXT-e13.
            gs_orderdetails-is_error       = gc_true.

* Concatenate all values
            lv_update_add_ccode = | { ls_proj_form-company_code } { '/' } { ls_proj_form-kostl } { '/' } { ls_proj_form-project_code } { '/' } { gs_orderdetails-error_desc }|. " CAPEX
            lv_update_add_ccode = | { lv_update_add_ccode }       { '/' } { '' } { '/' } { '' } { '/' } { 'E' }|. " ITL
            lv_update_add_ccode = | { lv_update_add_ccode }       { '/' } { '' } { '/' } { '' }|. "CLS

            IF lv_update_additionalccode IS INITIAL.
              lv_update_additionalccode = lv_update_add_ccode.
            ELSE.
              lv_update_additionalccode = | { lv_update_additionalccode } { ',' } { lv_update_add_ccode } |.
            ENDIF.

            APPEND gs_orderdetails TO gt_orderdetails.
            CONTINUE.
          ENDIF.

          CLEAR lv_aufnr.
          REFRESH lt_return.

          CALL FUNCTION 'Z_MDG_CREATE_INTERNALORDER'
            EXPORTING
              is_order    = ls_proj_form              " MDG - project code request Form
              is_projcode = ls_proj_form-project_code
            IMPORTING
              ev_aufnr    = lv_aufnr                  " Order Number
            TABLES
              et_return   = lt_return.                 " Return Parameter

          IF lv_aufnr IS NOT INITIAL.
* Update Order detail table
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-internal_order = ls_proj_form-internal_no = lv_aufnr.
            gs_orderdetails-project_code   = ls_proj_form-project_code.
            gs_orderdetails-is_error       = gc_false.
* Concatenate all values
            lv_update_add_ccode = | { ls_proj_form-company_code } { '/' } { ls_proj_form-kostl } { '/' } { ls_proj_form-project_code } { '/' } { ls_proj_form-internal_no }|. " CAPEX
            lv_update_add_ccode = | { lv_update_add_ccode }       { '/' } { '' } { '/' } { '' } { '/' } { 'S' }|. " ITL
            lv_update_add_ccode = | { lv_update_add_ccode }       { '/' } { '' } { '/' } { '' }|. "CLS

            IF lv_update_additionalccode IS INITIAL.
              lv_update_additionalccode = lv_update_add_ccode.
            ELSE.
              lv_update_additionalccode = | { lv_update_additionalccode } { ',' } { lv_update_add_ccode } |.
            ENDIF.

            IF lv_update_addinternalno IS INITIAL.
              lv_update_addinternalno = lv_aufnr.
            ELSE.
              lv_update_addinternalno = |{ lv_update_addinternalno } { ',' } { lv_aufnr }|.
            ENDIF.

            gs_orderdetails-error_desc     = |{ ls_proj_form-projectname } { '-' } { ls_proj_form-company_code }|.
* Clear any error
            CLEAR ls_proj_form-internal_no_err.
            REFRESH lt_return.

          ELSE.

            DELETE lt_return WHERE type NE 'E'.
* Update Order detail table
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-project_code   = ls_proj_form-project_code.

            READ TABLE lt_return INTO DATA(lw_return) WITH KEY type = 'E'.
            IF sy-subrc EQ 0.
              LOOP AT lt_return INTO lw_return WHERE type = 'E'.
                IF sy-tabix EQ 1.
                  lv_message = lw_return-message.
                ELSE.
                  lv_message = | { '/' } { lv_message } { lw_return-message }|.
                ENDIF.
              ENDLOOP.
              lv_report_error = 'X'.
              gs_orderdetails-is_error   = gc_true.
              gs_orderdetails-error_desc = ls_proj_form-internal_no_err = lw_return-message.

* Concatenate all values
              lv_update_add_ccode = | { ls_proj_form-company_code } { '/' } { ls_proj_form-kostl } { '/' } { ls_proj_form-project_code } { '/' } { gs_orderdetails-error_desc }|. " CAPEX
              lv_update_add_ccode = | { lv_update_add_ccode }       { '/' } { '' } { '/' } { '' } { '/' } { 'E' }|. " ITL
              lv_update_add_ccode = | { lv_update_add_ccode }       { '/' } { '' } { '/' } { '' }|. "CLS

              IF lv_update_additionalccode IS INITIAL.
                lv_update_additionalccode = lv_update_add_ccode.
              ELSE.
                lv_update_additionalccode = | { lv_update_additionalccode } { ',' } { lv_update_add_ccode } |.
              ENDIF.
            ENDIF.
          ENDIF.
          APPEND gs_orderdetails TO gt_orderdetails.
        ENDIF.


*** Create ITL Internal Order *************************************************************
        IF gs_proj_form-project_type EQ '2' OR gs_proj_form-itl = 'Y' AND ( ( lv_itl_internal_no IS INITIAL     AND lv_status IS INITIAL ) OR
                                                  ( lv_itl_internal_no IS NOT INITIAL AND lv_itl_proj_code IS NOT INITIAL AND lv_status = 'E') ).
          CLEAR lv_aufnr.
          CLEAR lv_message.
          CLEAR gs_orderdetails.

          MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

* Update Company Code & Cost Center
          ls_proj_form-company_code = gs_multipleccode-comp_code.
          ls_proj_form-kostl        = gs_multipleccode-kostl_code.
          ls_proj_form-itl_proj_code = ls_proj_form-itl_proj_code.

* Update Profit Center
          SELECT SINGLE prctr INTO ls_proj_form-profit_center
            FROM csks
            WHERE kokrs = 'DCI'
            AND   kostl = ls_proj_form-kostl
            AND   bukrs = ls_proj_form-company_code
            AND   datbi GE sy-datum
            AND   datab LE sy-datum.

          IF sy-subrc NE 0.
* Update Order detail table
            lv_report_error = 'X'.
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-project_code   = ls_proj_form-itl_proj_code.
            gs_orderdetails-error_desc     = TEXT-e13.
            gs_orderdetails-is_error       = gc_true.

* Concatenate all values
            lv_update_add_ccode = | { ls_proj_form-company_code } { '/' } { ls_proj_form-kostl } { '/' } { '' } { '/' } { '' }|. " CAPEX
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { ls_proj_form-itl_proj_code } { '/' } { gs_orderdetails-error_desc } { '/' } { 'S' }|." ITL
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { '' } { '/' } { '' }|. "CLS

            IF lv_update_additionalccode IS INITIAL.
              lv_update_additionalccode = lv_update_add_ccode.
            ELSE.
              lv_update_additionalccode = | { lv_update_additionalccode } { ',' } { lv_update_add_ccode } |.
            ENDIF.

            APPEND gs_orderdetails TO gt_orderdetails.
            CONTINUE.
          ENDIF.

          CLEAR lv_aufnr.
          REFRESH lt_itl_return.

          CALL FUNCTION 'Z_MDG_CREATE_INTERNALORDER'
            EXPORTING
              is_order    = ls_proj_form              " MDG - project code request Form
              is_projcode = ls_proj_form-itl_proj_code
            IMPORTING
              ev_aufnr    = lv_aufnr                  " Order Number
            TABLES
              et_return   = lt_itl_return.            " Return Parameter

          IF lv_aufnr IS NOT INITIAL.
* Update Order detail table
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-internal_order = ls_proj_form-itl_internal_no = lv_aufnr.
            gs_orderdetails-project_code   = ls_proj_form-itl_proj_code.
            gs_orderdetails-is_error       = gc_false.
* Concatenate all values
            lv_update_add_ccode = | { ls_proj_form-company_code } { '/' } { ls_proj_form-kostl } { '/' } { '' } { '/' } { '' }|. " CAPEX
            lv_update_add_ccode = | { lv_update_add_ccode }       { '/' } { ls_proj_form-itl_proj_code } { '/' } {  ls_proj_form-itl_internal_no } { '/' } { 'S' }|." ITL
            lv_update_add_ccode = | { lv_update_add_ccode }       { '/' } { '' } { '/' } { '' }|. "CLS

            IF lv_update_additionalccode IS INITIAL.
              lv_update_additionalccode = lv_update_add_ccode.
            ELSE.
              lv_update_additionalccode = | { lv_update_additionalccode } { ',' } { lv_update_add_ccode } |.
            ENDIF.

            IF lv_update_addinternalno IS INITIAL.
              lv_update_addinternalno = lv_aufnr.
            ELSE.
              lv_update_addinternalno = |{ lv_update_addinternalno } { ',' } { lv_aufnr }|.
            ENDIF.

            gs_orderdetails-error_desc     = |{ ls_proj_form-projectname } { '-' } { ls_proj_form-company_code }|.
* Clear any error
            CLEAR ls_proj_form-itl_int_no_error.
            REFRESH lt_return.

          ELSE.
* Update Order detail table
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-project_code   = ls_proj_form-itl_proj_code.

            READ TABLE lt_itl_return INTO lw_return WITH KEY type = 'E'.
            IF sy-subrc EQ 0.
              APPEND LINES OF lt_itl_return TO lt_return.
              LOOP AT lt_itl_return INTO lw_return WHERE type = 'E'.
                IF sy-tabix EQ 1.
                  lv_message = lw_return-message.
                ELSE.
                  lv_message = | { '/' } { lv_message } { lw_return-message }|.
                ENDIF.
              ENDLOOP.

              lv_report_error = 'X'.
              gs_orderdetails-is_error   = gc_true.
              gs_orderdetails-error_desc = ls_proj_form-itl_int_no_error = lv_message.

* Concatenate all values
              lv_update_add_ccode = | { ls_proj_form-company_code } { '/' } { ls_proj_form-kostl } { '/' } { '' } { '/' } { '' }|. " CAPEX
              lv_update_add_ccode = | { lv_update_add_ccode }       { '/' } { ls_proj_form-itl_proj_code } { '/' } {  gs_orderdetails-error_desc } { '/' } { 'E' }|." ITL
              lv_update_add_ccode = | { lv_update_add_ccode }       { '/' } { '' } { '/' } { '' }|. "CLS

              IF lv_update_additionalccode IS INITIAL.
                lv_update_additionalccode = lv_update_add_ccode.
              ELSE.
                lv_update_additionalccode = | { lv_update_additionalccode } { ',' } { lv_update_add_ccode } |.
              ENDIF.

            ENDIF.
          ENDIF.
          APPEND gs_orderdetails TO gt_orderdetails.
        ENDIF.

*** Create CLS Internal Order *************************************************************
        IF ( gs_proj_form-project_type EQ '1' OR gs_proj_form-project_type EQ '5' ) AND gs_proj_form-cls = 'Y' AND
                                                  ( ( lv_cls_internal_no IS INITIAL     AND lv_status IS INITIAL ) OR
                                                  ( lv_cls_internal_no IS NOT INITIAL AND lv_cls_proj_code IS NOT INITIAL AND lv_status = 'E') ).

          CLEAR lv_aufnr.
          CLEAR lv_message.
          CLEAR gs_orderdetails.

          MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

* Update Company Code & Cost Center
          ls_proj_form-company_code  = gs_multipleccode-comp_code.
          ls_proj_form-kostl         = gs_multipleccode-kostl_code.
          ls_proj_form-cls_proj_code = ls_proj_form_01-cls_proj_code.

* Update Profit Center
          SELECT SINGLE prctr INTO ls_proj_form-profit_center
            FROM csks
            WHERE kokrs = 'DCI'
            AND   kostl = ls_proj_form-kostl
            AND   bukrs = ls_proj_form-company_code
            AND   datbi GE sy-datum
            AND   datab LE sy-datum.

          IF sy-subrc NE 0.
* Update Order detail table
            lv_report_error = 'X'.
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-project_code   = ls_proj_form-cls_proj_code.
            gs_orderdetails-error_desc     = TEXT-e13.
            gs_orderdetails-is_error       = gc_true.

* Concatenate all values
            lv_update_add_ccode = | { ls_proj_form-company_code } { '/' } { ls_proj_form-kostl } { '/' } { '' } { '/' } { '' }|. " CAPEX
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { '' } { '/' } { '' } { '/' } { 'E' }|." ITL
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { ls_proj_form-cls_proj_code } { '/' } { gs_orderdetails-error_desc }|. "CLS

            IF lv_update_additionalccode IS INITIAL.
              lv_update_additionalccode = lv_update_add_ccode.
            ELSE.
              lv_update_additionalccode = | { lv_update_additionalccode } { ',' } { lv_update_add_ccode } |.
            ENDIF.


            APPEND gs_orderdetails TO gt_orderdetails.
            CONTINUE.
          ENDIF.

          CLEAR lv_aufnr.
          REFRESH lt_itl_return.

          CALL FUNCTION 'Z_MDG_CREATE_INTERNALORDER'
            EXPORTING
              is_order    = ls_proj_form              " MDG - project code request Form
              is_projcode = ls_proj_form-cls_proj_code
            IMPORTING
              ev_aufnr    = lv_aufnr                  " Order Number
            TABLES
              et_return   = lt_itl_return.            " Return Parameter

          IF lv_aufnr IS NOT INITIAL.
* Update Order detail table
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-internal_order = ls_proj_form-cls_internal_no = lv_aufnr.
            gs_orderdetails-project_code   = ls_proj_form-cls_proj_code.
            gs_orderdetails-is_error       = gc_false.
* Concatenate all values
            lv_update_add_ccode = | { ls_proj_form-company_code } { '/' } { ls_proj_form-kostl } { '/' } { '' } { '/' } { '' }|. " CAPEX
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { '' } { '/' } { '' } { '/' } { 'S' }|. " ITL
            lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { ls_proj_form-cls_proj_code } { '/' } { ls_proj_form-cls_internal_no }|. "CLS

            IF lv_update_additionalccode IS INITIAL.
              lv_update_additionalccode = lv_update_add_ccode.
            ELSE.
              lv_update_additionalccode = | { lv_update_additionalccode } { ',' } { lv_update_add_ccode } |.
            ENDIF.

            IF lv_update_addinternalno IS INITIAL.
              lv_update_addinternalno = lv_aufnr.
            ELSE.
              lv_update_addinternalno = |{ lv_update_addinternalno } { ',' } { lv_aufnr }|.
            ENDIF.

            gs_orderdetails-error_desc     = |{ ls_proj_form-projectname } { '-' } { ls_proj_form-company_code }|.
* Clear any error
            CLEAR ls_proj_form-itl_int_no_error.
            REFRESH lt_return.

          ELSE.
* Update Order detail table
            gs_orderdetails-output_ccode   = ls_proj_form-company_code.
            gs_orderdetails-output_ccenter = ls_proj_form-kostl.
            gs_orderdetails-project_code   = ls_proj_form-cls_proj_code.

            READ TABLE lt_itl_return INTO lw_return WITH KEY type = 'E'.
            IF sy-subrc EQ 0.
              APPEND LINES OF lt_itl_return TO lt_return.
              LOOP AT lt_itl_return INTO lw_return WHERE type = 'E'.
                IF sy-tabix EQ 1.
                  lv_message = lw_return-message.
                ELSE.
                  lv_message = | { '/' } { lv_message } { lw_return-message }|.
                ENDIF.
              ENDLOOP.

              lv_report_error = 'X'.
              gs_orderdetails-is_error   = gc_true.
              gs_orderdetails-error_desc = ls_proj_form-itl_int_no_error = lv_message.

* Concatenate all values
              lv_update_add_ccode = | { ls_proj_form-company_code } { '/' } { ls_proj_form-kostl } { '/' } { '' } { '/' } { '' }|. " CAPEX
              lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { '' } { '/' } { '' } { '/' } { 'E' }|.                                            " ITL
              lv_update_add_ccode = | { lv_update_add_ccode }          { '/' } { ls_proj_form-cls_proj_code } { '/' } { gs_orderdetails-error_desc }|. "CLS

              IF lv_update_additionalccode IS INITIAL.
                lv_update_additionalccode = lv_update_add_ccode.
              ELSE.
                lv_update_additionalccode = | { lv_update_additionalccode } { ',' } { lv_update_add_ccode } |.
              ENDIF.

            ENDIF.
          ENDIF.
          APPEND gs_orderdetails TO gt_orderdetails.
        ENDIF.
      ENDLOOP.
    ENDLOOP.
* Update Additional Company Code
    ls_proj_form_01-additional_comp_code = lv_update_additionalccode.
    ls_proj_form_01-cons_internalno      = lv_update_addinternalno.

*** Update Consolidate Internal Order No field
**      SPLIT lv_update_additionalccode AT ',' INTO TABLE it_add_comp_code.
**
**      LOOP AT it_add_comp_code INTO wa_additional_ccode.
**        CLEAR lv_aufnr.
**
**        SPLIT wa_additional_ccode AT '/' INTO gs_orderdetails-output_ccode
**                                              gs_orderdetails-output_ccenter
**                                              lv_project_code
**                                              lv_internal_no
**                                              lv_itl_proj_code
**                                              lv_itl_internal_no
**                                              lv_status
**                                              lv_cls_proj_code
**                                              lv_cls_internal_no.
**        CONDENSE gs_orderdetails-output_ccode.
**        CONDENSE gs_orderdetails-output_ccenter.
**        CONDENSE lv_project_code.
**        CONDENSE lv_internal_no.
**        CONDENSE lv_itl_proj_code.
**        CONDENSE lv_itl_internal_no.
**        CONDENSE lv_cls_proj_code.
**        CONDENSE lv_cls_internal_no.
**        CONDENSE lv_status.
**
**        IF lv_status = 'S' AND lv_internal_no IS NOT INITIAL.
**          lv_aufnr = lv_internal_no.
**        ELSEIF lv_status = 'S' AND lv_itl_internal_no IS NOT INITIAL.
**          lv_aufnr = lv_itl_internal_no.
**        ELSEIF lv_status = 'S' AND lv_cls_internal_no IS NOT INITIAL.
**          lv_aufnr = lv_cls_internal_no.
**        ENDIF.
**
**        IF lv_aufnr IS NOT INITIAL.
**          IF lv_update_addinternalno IS INITIAL.
**            lv_update_addinternalno = lv_aufnr.
**          ELSE.
**            lv_update_addinternalno = |{ lv_update_addinternalno } { ',' } { lv_aufnr }|.
**          ENDIF.
**        ENDIF.
**      ENDLOOP.

    MOVE-CORRESPONDING ls_proj_form_01 TO gs_proj_form.

* Update Error message - To report back
    IF lv_report_error = 'X'.
      lw_return-message = TEXT-e14.
      APPEND lw_return TO lt_return.

      wa_program_state-program_state = 'E'.
      wa_program_state-program_message = TEXT-e14.
      gs_proj_form-submitwth_err = gc_true.
    ENDIF.
  ENDMETHOD.


METHOD deactive_exist_projcode.
    IF ip_prev_proj_code IS NOT INITIAL.
      SELECT SINGLE * FROM zzdci_proj INTO @DATA(lw_zzdci_proj) WHERE zzproject = @ip_prev_proj_code.
      IF sy-subrc EQ 0.
        CLEAR lw_zzdci_proj-cap_active.
        CLEAR lw_zzdci_proj-labor_ind.
        MODIFY zzdci_proj FROM lw_zzdci_proj.
        COMMIT WORK.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD delete_attachment.
    DATA: lx_ca_form_exceptions TYPE REF TO zcx_ca_form_exceptions.
    DATA: lv_index TYPE sy-index.

    CHECK gt_attachments IS NOT INITIAL.

    lv_index = wa_confirm_delete-delete_index + 1.

    gs_attachment = gt_attachments[ lv_index ].


    TRY.
        zcl_nd_ca_utilities=>delete_attachment_from_form(
          iv_form_guid = gs_formdetails-form_guid
          iv_attachment_uuid = gs_attachment-uuid ).
      CATCH zcx_ca_form_exceptions INTO lx_ca_form_exceptions.
        wa_program_state-program_state   = 'E'.
        wa_program_state-program_message = lx_ca_form_exceptions->get_text( ).
        RETURN.
    ENDTRY.
  ENDMETHOD.


METHOD delete_form.
    DATA lx_ca_form_exception TYPE REF TO zcx_ca_form_exceptions.

* Call shared workflow class to Delete form
    TRY.
        zcl_nd_ca_mdg_workflow=>delete_form(
          EXPORTING
            iv_form_guid   = gs_formdetails-form_guid
          IMPORTING
            es_form_detail = DATA(ls_form_detail)
            et_step_detail = DATA(lt_step_detail) ).

      CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
        wa_program_state-program_state   = 'E'.
        wa_program_state-program_message = lx_ca_form_exception->get_text( ).
        RETURN.
    ENDTRY.
* End of shared workflow class call.

* Delete Project Form data
    LOOP AT lt_step_detail INTO DATA(lw_step_detail).
      DELETE FROM zmdg_proj_form WHERE step_guid = lw_step_detail-step_guid.
    ENDLOOP.

    COMMIT WORK.

    IF NOT gt_attachments[] IS INITIAL.
      delete_attachment( ).
    ENDIF.

* <TR> Lock call off, shared class owned by other team (P-63)
*    zcl_nd_ca_utilities=>dequeue_form( gs_formdetails-form_guid ).

  ENDMETHOD.


METHOD get_agentlist.
    DATA lt_stru_objec  TYPE TABLE OF objec.
    DATA lw_agent       TYPE zca_s_nad_gl_agent.
    DATA lt_uname_range TYPE slim_sel_user.
    DATA lw_uname_range TYPE slim_sel_user_str.
    DATA lt_user        TYPE TABLE OF zca_user_alv.
    DATA lv_objid       TYPE hrobjid.

    IF otype = zhrc_wc_cd.

      MOVE objid TO lv_objid.

      CALL FUNCTION 'RH_STRUC_GET'
        EXPORTING
          act_otype       = zhrc_wc_cd
          act_objid       = lv_objid
          act_wegid       = 'US_RESP'
          act_plvar       = '01'
          act_begda       = sy-datum
          act_endda       = sy-datum
          authority_check = zhrc_skip_auth_check
        TABLES
          result_objec    = lt_stru_objec
        EXCEPTIONS
          no_plvar_found  = 1
          no_entry_found  = 2
          OTHERS          = 3.
      IF sy-subrc <> 0.
        RAISE EXCEPTION TYPE zcx_ca_form_exceptions
          EXPORTING
            textid = zcx_ca_form_exceptions=>agent_not_found.
        EXIT.
      ELSE.
** Built User Table
        lt_uname_range = VALUE #( FOR line IN lt_stru_objec
                                    WHERE ( otype = 'US' )
                                    ( sign = zhrc_include
                                      option = zhrc_equal
                                      low    = line-realo
                                      high   = '' ) ).
      ENDIF.
    ELSEIF otype = 'US'.
      lw_uname_range-sign   = zhrc_include.
      lw_uname_range-option = zhrc_equal.
      lw_uname_range-low    = objid.
      APPEND lw_uname_range TO lt_uname_range.
    ENDIF.

    IF lt_uname_range IS NOT INITIAL.
* Get the User Name from SU01
      CALL FUNCTION 'Z_BAPI_BC_USER_GETLIST'
        EXPORTING
          i_datum = sy-datum
        TABLES
          s_bname = lt_uname_range
          et_user = lt_user.     " User Maintenance ALVs

      LOOP AT lt_user INTO DATA(lw_user).
        lw_agent-agent_id       = lw_user-bname.
        lw_agent-agent_email    = lw_user-user_email.
        CONCATENATE lw_user-name_first lw_user-name_last INTO lw_agent-agent_name SEPARATED BY space.
        APPEND lw_agent TO agent_list.
      ENDLOOP.
    ENDIF.
  ENDMETHOD.


METHOD get_agents.

    gt_zca_agent_list = zcl_nd_ca_mdg_workflow=>get_agents_of_approval_step(
      iv_form_guid     = gs_formdetails-form_guid
      iv_agent_id_list = gs_formdetails-agent_id_list
      iv_work_center   = gs_formdetails-workcenter_id
    ).

  ENDMETHOD.


METHOD get_approvers.
    TYPES : BEGIN OF ty_user,
              sign   TYPE char1,
              option TYPE char2,
              low    TYPE syuname,
              high   TYPE syuname.
    TYPES : END OF ty_user.

    DATA lt_user           TYPE STANDARD TABLE OF zca_user_alv.
    DATA lt_approver_user  TYPE TABLE OF ty_user.
    DATA lv_index          TYPE sy-tabix.
    DATA lv_step_cnt       TYPE i.
    DATA lv_dummy_date     TYPE dats.

**Update Ver based on region
    CASE gs_proj_form-processing_region.
      WHEN 'E'.
        gc_form_ver = '0002'.
      WHEN 'A'.
        gc_form_ver = '0003'.
      WHEN OTHERS.
        gc_form_ver = '0001'.
    ENDCASE.

*Get list of steps****************************************************
    SELECT * FROM zca_apprvr_list INTO TABLE @DATA(lt_apprvr_list) WHERE form_name = @gc_form_name AND
                                                                         form_ver  = @gc_form_ver.
    IF sy-subrc NE 0.
      EXIT.
    ENDIF.

    SORT lt_apprvr_list BY appr_seqno.

    IF ip_form_guid IS NOT INITIAL.
*Get ALL STEP Details*************************************************
      SELECT * FROM zca_stepdetail INTO TABLE @DATA(lt_stepdetails) WHERE form_guid = @ip_form_guid ORDER BY completion_date , completion_time.
      IF sy-subrc NE 0.
        EXIT.
      ENDIF.

** Built Range table
      lt_approver_user  = VALUE #( FOR line IN lt_stepdetails
                                  ( sign = zhrc_include
                                    option = zhrc_equal
                                    low    = line-processed_by
                                    high   = '' ) ).

* Get PERNR based on User
      IF lt_approver_user IS NOT INITIAL.
* Get the User Name from SU01
        CALL FUNCTION 'Z_BAPI_BC_USER_GETLIST'
          EXPORTING
            i_datum = lv_dummy_date "sy-datum
          TABLES
            s_bname = lt_approver_user
            et_user = lt_user.
      ENDIF.
    ENDIF.


    READ TABLE  lt_stepdetails INTO DATA(ls_step)           "DEVK9A0J7G
      WITH KEY completion_date = 00000000.                  "DEVK9A0J7G
    IF sy-subrc EQ 0.                                       "DEVK9A0J7G
      DELETE lt_stepdetails INDEX sy-tabix.                 "DEVK9A0J7G
      APPEND ls_step TO lt_stepdetails.                     "DEVK9A0J7G
    ENDIF.                                                  "DEVK9A0J7G

    IF lt_stepdetails IS NOT INITIAL.
      LOOP AT lt_stepdetails INTO DATA(lw_stepdetails).

        IF lw_stepdetails-appr_seqno EQ 1.                  "DEVK9A0J7G
          lv_step_cnt = lv_step_cnt + 1.                    "DEVK9A0J7G
        ENDIF.                                              "DEVK9A0J7G

* Get Approver Description
        TRY.
            DATA(lw_apprvr_list) = lt_apprvr_list[ appr_step = lw_stepdetails-appr_step ].
            gs_appr-steps = lw_apprvr_list-appr_desc.
          CATCH cx_sy_itab_line_not_found.
        ENDTRY.

        IF lv_step_cnt > 1 AND                              "DEVK9A0J7G
           lw_stepdetails-appr_seqno EQ 1.                  "DEVK9A0J7G
          CONCATENATE gs_appr-steps 'Resubmit'              "DEVK9A0J7G
                 INTO gs_appr-steps SEPARATED BY space.     "DEVK9A0J7G
        ENDIF.                                              "DEVK9A0J7G

* Get PERNR based on Processed by ID
        TRY.
            DATA(lw_user) = lt_user[ bname = lw_stepdetails-processed_by ].
            IF lw_stepdetails-completion_date IS INITIAL.
              CLEAR lw_user.
            ENDIF.
          CATCH cx_sy_itab_line_not_found.
            CLEAR lw_user.
        ENDTRY.

*****************************ICON Color and Status*************************
        IF lw_stepdetails-step_status EQ gc_stepstatus_completed.
          gs_appr-status_icon_color = 'Green'.
          gs_appr-status_icon       = 'sap-icon://accept'.
          gs_appr-status_date       = lw_stepdetails-completion_date.
          gs_appr-step_status       = 'Completed'.

        ELSEIF lw_stepdetails-step_status EQ gc_stepstatus_withdrawn.
          gs_appr-status_icon_color = 'Red'.
          gs_appr-status_icon       = 'sap-icon://stop'.
          gs_appr-status_date       = lw_stepdetails-completion_date.
          gs_appr-step_status       = 'Withdrawn'.

        ELSEIF lw_stepdetails-step_status EQ gc_stepstatus_reject.
          gs_appr-status_icon_color = 'Red'.
          gs_appr-status_icon       = 'sap-icon://decline'.
          gs_appr-status_date       = lw_stepdetails-completion_date.
          gs_appr-step_status       = 'Rejected'.

        ELSEIF lw_stepdetails-step_status EQ gc_stepstatus_started.
          gs_appr-status_icon_color = 'Green'.
          gs_appr-status_icon       = 'sap-icon://pending'.
          gs_appr-step_status       = 'Pending'.
* Check for Draft
          IF gs_formdetails-form_status = gc_formstatus_draft.
            gs_appr-step_status       = 'Saved as Draft'.
            gs_appr-status_date       = lw_stepdetails-completion_date.
          ENDIF.
        ENDIF.

        CONCATENATE lw_user-name_first lw_user-name_last INTO gs_appr-approvername SEPARATED BY space.
        gs_appr-approverid   = lw_stepdetails-processed_by.

        APPEND gs_appr TO gt_appr.
        CLEAR gs_appr.
      ENDLOOP.
    ENDIF.

    TRY.
        lv_index = line_index( lt_apprvr_list[ appr_step = lw_stepdetails-appr_step ] ).
        lv_index = lv_index + 1.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    LOOP AT lt_apprvr_list INTO DATA(lw_apprvr_list1) FROM lv_index.
      gs_appr-steps             = lw_apprvr_list1-appr_desc.
      gs_appr-status_icon       = 'sap-icon://pending'.
      APPEND gs_appr TO gt_appr.
    ENDLOOP.

  ENDMETHOD.


METHOD get_attachment_list.
    DATA: lv_form_guid TYPE sysuuid_c.
    REFRESH gt_attachments.

    lv_form_guid = gs_formdetails-form_guid.
    gt_attachments = zcl_nd_ca_utilities=>read_attachments_of_form( lv_form_guid ).
  ENDMETHOD.


METHOD get_authorized_by_data.
*    DATA: ls_user_info TYPE zca_user_info,
*          lv_user      TYPE xubname.
*
*    lv_user  = ajax_value.
*
*    IF lv_user IS INITIAL.
*      CLEAR gs_proj_form-auth_by_name.
*      CLEAR gs_proj_form-auth_by_id.
*    else.
*
*    zcl_nd_ca_utilities=>get_information_from_user(
*      EXPORTING
*        iv_user_id = lv_user
*      IMPORTING
*        es_user_info = ls_user_info
*        ).
*    gs_proj_form-requester_title       = ls_user_info-title.
*    gs_proj_form-requester_email       = ls_user_info-email.
*
*      CLEAR gs_proj_form-auth_by_name.
*      CLEAR gs_proj_form-auth_by_id.
  ENDMETHOD.


METHOD get_company_code.
    DATA: lt_ccodes       TYPE TABLE OF  zmdg_prj_ccode.

    select mdg~company_code t001~butxt
        into table gt_comp_code
        from zmdg_prj_ccode as mdg
        inner join t001 on t001~bukrs = mdg~company_code
        where mdg~processing_region = gs_proj_form-processing_region
          and exists ( select count( * ) from t093c where bukrs = mdg~company_code )
        order by t001~bukrs.


*     select t001~bukrs, t001~butxt
*      into table @gt_comp_code
*      FROM t001
*      INNER JOIN t093c on t001~bukrs = t093c~bukrs
*                      and t093c~afapl = 'ZUS1'
*      ORDER BY t001~bukrs.

      INSERT  INITIAL LINE INTO gt_comp_code INDEX 1.
  ENDMETHOD.


METHOD get_costcenter.
    DATA lt_range_kostl TYPE ranges_kostl_tt.
    DATA ra_kostl_text TYPE RANGE OF cskt-ltext.
    DATA wa_kostl_text LIKE LINE OF ra_kostl_text.

    IF wa_url_parameters-company_code IS NOT INITIAL.
      SELECT * FROM csks INTO TABLE @DATA(lt_csks) WHERE bukrs EQ @wa_url_parameters-company_code AND bkzkp NE 'X' AND datbi GE @sy-datum.
      IF sy-subrc EQ 0.
        SORT lt_csks BY kostl.
        DELETE ADJACENT DUPLICATES FROM lt_csks COMPARING kostl.

* Get Test of Cost Center
        lt_range_kostl   = VALUE #( FOR line IN lt_csks
                                      ( sign = zhrc_include
                                        option = zhrc_equal
                                        low    = line-kostl
                                        high   = '' ) ).
* Check Text
        wa_kostl_text-sign   = 'I'.
        wa_kostl_text-option = 'CP'.
        CONCATENATE '*' ajax_value  '*' INTO wa_kostl_text-low.
        TRANSLATE wa_kostl_text-low TO UPPER CASE.
        APPEND wa_kostl_text TO ra_kostl_text.

        SELECT * FROM cskt INTO TABLE @DATA(lt_cskt) WHERE spras = 'E' AND kostl IN @lt_range_kostl AND ltext IN @ra_kostl_text.
        IF sy-subrc EQ 0.
          SORT lt_cskt BY kostl.
          DELETE ADJACENT DUPLICATES FROM lt_cskt COMPARING kostl.
          gt_kostl  = VALUE #( FOR line1 IN lt_cskt
                                      ( value = line1-kostl
                                        text  = |{ line1-kostl } { line1-ltext }| ) ).
          INSERT INITIAL LINE INTO gt_kostl INDEX 1.
        ENDIF.
      ENDIF.
    ENDIF.

  ENDMETHOD.


METHOD get_data.
    DATA lv_form_guid   TYPE sysuuid_c.
    DATA lv_can_change  TYPE flag.
    DATA lx_ca_form_exception TYPE REF TO zcx_ca_form_exceptions.
    DATA lw_agent       TYPE zca_s_nad_gl_agent.

    SPLIT wa_url_parameters-form_guid AT '/' INTO lv_form_guid DATA(lv_request_type).

* Check form detail
    IF lv_request_type EQ 'create'.
      CLEAR lv_form_guid.
    ENDIF.

    IF ( gs_formdetails-form_status EQ gc_formstatus_draft AND gs_formdetails-form_guid IS NOT INITIAL AND lv_request_type IS INITIAL ) OR
       ( lv_form_guid IS INITIAL AND wa_url_parameters-mode = 'DISPLAY').
      lv_form_guid = gs_formdetails-form_guid.
    ENDIF.

    IF lv_form_guid IS INITIAL AND wa_url_parameters-proj IS NOT INITIAL AND wa_url_parameters-from = 'search'. "The request came from search
      TRY.
          CALL METHOD me->create_form_wref_orderid
            EXPORTING
              ip_orderid = wa_url_parameters-proj.
        CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
          wa_program_state-program_state   = 'E'.
          wa_program_state-program_message = lx_ca_form_exception->get_text( ).
          wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
      ENDTRY.
    ELSEIF lv_form_guid IS INITIAL.
      TRY.
          CALL METHOD me->create_init.  " <TR> SERVER removed
        CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
          wa_program_state-program_state   = 'E'.
          wa_program_state-program_message = lx_ca_form_exception->get_text( ).
          wa_program_state-incorrect_field = lx_ca_form_exception->incorrect_field.
      ENDTRY.
    ELSE.
      CALL METHOD me->get_approvers
        EXPORTING
          ip_form_guid = lv_form_guid.

      CALL METHOD me->load_form
        EXPORTING
          ip_form_guid = lv_form_guid.

      CALL METHOD me->set_header.

* { Begin of ENHC0058096 - Check User Name based on possible agent
      READ TABLE gt_zca_agent_list INTO lw_agent WITH KEY agent_id = sy-uname.
      IF sy-subrc EQ 0 OR wa_url_parameters-mode EQ 'EDIT' OR wa_url_parameters-mode EQ 'CHANGE'.
        TRY.
*            zcl_nd_ca_utilities=>enqueue_form( lv_form_guid ).
            lv_can_change = 'X'.
          CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
            wa_program_state-program_state   = 'E'.
            wa_program_state-program_message = lx_ca_form_exception->get_text( ).
            CLEAR lv_can_change.
        ENDTRY.
      ELSE.
        CLEAR lv_can_change.
      ENDIF.
* } End of ENHC0058096

      CALL METHOD me->set_field_mandatory.

      CALL METHOD me->set_field_visible.

      CALL METHOD me->set_field_cond_visible.

      CALL METHOD me->set_field_read_only.

      CALL METHOD me->set_fldgrp_visibility
        EXPORTING
          is_form_locked = lv_can_change.

      CALL METHOD me->set_button_visibility
        EXPORTING
          is_form_locked = lv_can_change.

* To set navigation and display button editable
      IF wa_url_parameters-mode EQ 'EDIT' OR wa_url_parameters-mode EQ 'DISPLAY'.
        gs_proj_form-navigation_visible = gc_true.
      ELSE.
        gs_proj_form-navigation_visible = gc_false.
      ENDIF.

      IF wa_url_parameters-mode EQ 'EDIT'.
        gs_proj_form-page_header        = 'Change Project Code Request'.
        gs_proj_form-mode_button_icon   = 'sap-icon://display'.
        gs_proj_form-display_or_edit    = 'EDIT'.
        gs_proj_form-request_from       = 'U'.
      ELSEIF wa_url_parameters-mode EQ 'DISPLAY'.
        gs_proj_form-page_header        = 'Display Project Code Request'.
        gs_proj_form-mode_button_icon   = 'sap-icon://edit'.
        gs_proj_form-display_or_edit    = 'DISPLAY'.
        gs_proj_form-request_from       = 'U'.
      ENDIF.

* Reset Previous Value
      IF wa_url_parameters-mode  EQ 'EDIT' OR gs_proj_form-request_from = 'U'.
        CALL METHOD reset_value.
      ENDIF.

    ENDIF.

    CALL METHOD me->populate_f4_help.

* D.Rempe - not relevant for S4 project creation.
** Set Additional Field visible based on condition
*    IF gs_proj_form-itl IS NOT INITIAL.
*      gs_proj_form-v_itl = gc_true.
*    ENDIF.
*
*    IF gs_proj_form-cls IS NOT INITIAL.
*      gs_proj_form-v_cls = gc_true.
*    ENDIF.
*
*    IF gs_proj_form-is_software_req IS NOT INITIAL.
*      gs_proj_form-v_is_software_req = gc_true.
*    ENDIF.
*
** Populate multiple Company Code
*    CALL METHOD me->set_multi_ccode.
  ENDMETHOD.


METHOD get_deactivate_ccode.
    DATA: lt_setvalues TYPE TABLE OF rgsb4,
          lv_set       TYPE sethier-setid,
          lv_setinfo   TYPE setinfo.

* Set Name Entered Directly on the screen (Get ID)
    CALL FUNCTION 'G_SET_GET_ID_FROM_NAME'
      EXPORTING
        shortname                = 'ZFI_VAL-BUKRS_CLOSED'
      IMPORTING
        new_setid                = lv_set
        set_info                 = lv_setinfo
      EXCEPTIONS
        no_set_found             = 1
        no_set_picked_from_popup = 2
        table_field_not_found    = 3
        fields_dont_match        = 4
        wrong_subclass           = 5
        error_message            = 9.

* read set values
    CALL FUNCTION 'G_SET_GET_ALL_VALUES'
      EXPORTING
        setnr         = lv_set
      TABLES
        set_values    = lt_setvalues
      EXCEPTIONS
        set_not_found = 1.

* Populate Selections with FROM/TO values
    IF lt_setvalues IS NOT INITIAL.

      gt_exclude_ccode  = VALUE #( FOR line IN lt_setvalues
                                  ( sign = 'E'
                                    option = 'EQ'
                                    low    = line-from
                                    high   = line-to ) ).

    ENDIF.
  ENDMETHOD.


METHOD get_on_behalf_data.
    DATA: ls_user_info TYPE zca_user_info,
          lv_user      TYPE xubname.

    lv_user  = ajax_value.

    IF lv_user IS INITIAL.
      lv_user = sy-uname.
      CLEAR gs_proj_form-onbehalf_name.
      CLEAR gs_proj_form-onbehalf_id.
    ENDIF.

    zcl_nd_ca_utilities=>get_information_from_user(
      EXPORTING
        iv_user_id = lv_user
      IMPORTING
        es_user_info = ls_user_info
        ).
    gs_proj_form-requester_title       = ls_user_info-title.
    gs_proj_form-requester_email       = ls_user_info-email.
  ENDMETHOD.


METHOD get_order_type.
    DATA: lt_dd07v_tab_a TYPE STANDARD TABLE OF dd07v,
          lt_dd07v_tab_n TYPE STANDARD TABLE OF dd07v,
          lw_dd07v_tab_a TYPE dd07v.

    TYPES: BEGIN OF ty_project_type,
             sign   TYPE tvarv_sign,
             option TYPE  tvarv_opti,
             low    TYPE zmdg_ordertype,
             high   TYPE zmdg_ordertype,
           END OF ty_project_type.

    DATA: ls_project_type TYPE ty_project_type.
    DATA: lt_project_type TYPE STANDARD TABLE OF ty_project_type.

**Update Order Type - Based on processing Region*
    CALL FUNCTION 'DD_DOMA_GET'
      EXPORTING
        domain_name   = 'ZMDG_ORDERTYPE'
      TABLES
        dd07v_tab_a   = lt_dd07v_tab_a
        dd07v_tab_n   = lt_dd07v_tab_n
      EXCEPTIONS
        illegal_value = 1
        op_failure    = 2
        OTHERS        = 3.
    IF sy-subrc EQ 0.
      LOOP AT lt_dd07v_tab_a INTO lw_dd07v_tab_a.
        gs_ordertype-value = lw_dd07v_tab_a-domvalue_l.
        gs_ordertype-text  = lw_dd07v_tab_a-ddtext.
        APPEND gs_ordertype TO gt_order_type.
      ENDLOOP.
      INSERT INITIAL LINE INTO gt_order_type INDEX 1. " Blank Entries
    ENDIF.

*- Filter order type based on project type
*--- 1 > Z045 and Z051 (global)
*--- 2 > Z045 (global)
*--- 3 > Z045, Z051, and Z060 (global)
*--- 4 > Z060 (global)
    IF gs_proj_form-project_type IS NOT INITIAL.
      ls_project_type-sign = 'I'.
      ls_project_type-option = 'EQ'.
      CASE gs_proj_form-project_type.
        WHEN '1' OR '5'.
          IF gs_proj_form-itl = 'Y'.
            ls_project_type-low = 'Z045'.
            APPEND ls_project_type TO lt_project_type.
            gs_proj_form-order_type = 'Z045'.
          ELSE.
            ls_project_type-low = 'Z045'.
            APPEND ls_project_type TO lt_project_type.
            ls_project_type-low = 'Z051'.
            APPEND ls_project_type TO lt_project_type.
          ENDIF.
        WHEN '2'.
          ls_project_type-low = 'Z045'.
          APPEND ls_project_type TO lt_project_type.
          gs_proj_form-order_type = 'Z045'.
        WHEN '3' OR '4'.
          ls_project_type-low = 'Z060'.
          APPEND ls_project_type TO lt_project_type.
          gs_proj_form-order_type = 'Z060'.
      ENDCASE.

      DELETE gt_order_type WHERE value NOT IN lt_project_type.

      IF lines( gt_order_type ) GT 1.
        INSERT INITIAL LINE INTO gt_order_type INDEX 1. " Blank Entries
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD get_proj_code.
    DATA lt_zzdci_proj TYPE STANDARD TABLE OF zzdci_proj.
    DATA lv_next_no TYPE fico_nseq_no VALUE '0001'.
    DATA lv_existproj TYPE char4.
    DATA lw_zzdci_proj TYPE zzdci_proj.
    DATA lv_len TYPE i.
    DATA lv_htype TYPE dd01v-datatype.
    DATA lv_year TYPE char2.

    IF gs_proj_form-project_type IS NOT INITIAL.
      IF sy-datum+4(2) EQ '12'.
        lv_year = sy-datum+2(2) + 1.
      ELSE.
        lv_year = sy-datum+2(2).
      ENDIF.

      CASE gs_proj_form-project_type.
        WHEN '1' OR '4'.
          CONCATENATE 'CAP' lv_year '%' INTO DATA(lw_projcode).
          CONCATENATE 'CAP' lv_year INTO DATA(lw_propose_code).
        WHEN '2'.
          CONCATENATE 'ITL' lv_year '%' INTO lw_projcode.
          CONCATENATE 'ITL' lv_year INTO lw_propose_code.
        WHEN '3'.
          CONCATENATE 'CLS' lv_year '%' INTO lw_projcode.
          CONCATENATE 'CLS' lv_year INTO lw_propose_code.
        WHEN '5'.
          CONCATENATE 'IMO' lv_year '%' INTO lw_projcode.
          CONCATENATE 'IMO' lv_year INTO lw_propose_code.
      ENDCASE.

* Check whether project code is already created - No duplicates ************************
      IF lw_propose_code(3) NE gs_proj_form-project_code(3).
* Read Existing Project Code
        SELECT * FROM zzdci_proj INTO TABLE lt_zzdci_proj WHERE zzproject LIKE lw_projcode.
        IF sy-subrc EQ 0.
          DATA(lv_count) = lines( lt_zzdci_proj ).

          READ TABLE lt_zzdci_proj INTO lw_zzdci_proj INDEX lv_count.

*          SORT lt_zzdci_proj BY zzproject DESCENDING.
*          LOOP AT lt_zzdci_proj INTO lw_zzdci_proj.

          lv_len = strlen( lw_zzdci_proj-zzproject ) - 4.
          lv_existproj = lw_zzdci_proj-zzproject+lv_len(4).

          CALL FUNCTION 'NUMERIC_CHECK'
            EXPORTING
              string_in = lv_existproj
            IMPORTING
              htype     = lv_htype.
          IF lv_htype = 'NUMC'.
            IF lv_next_no <= lv_existproj.
              lv_next_no = lv_existproj + 1.
            ENDIF.
          ENDIF.

*          ENDLOOP.
        ENDIF.

        CONCATENATE lw_propose_code lv_next_no INTO gs_proj_form-project_code SEPARATED BY '_'.

* Update Project Code
        lw_zzdci_proj-zzproject = gs_proj_form-project_code.
        lw_zzdci_proj-zzdescription = |{ gs_proj_form-project_code } { gs_proj_form-projectname }|.

        IF gs_proj_form-project_type EQ '4'  AND gs_proj_form-order_type EQ 'Z060'.
          lw_zzdci_proj-cap_active = ''.
        ELSEIF ( gs_proj_form-project_type EQ '1' OR gs_proj_form-project_type EQ '4' OR gs_proj_form-project_type EQ '5' ) AND gs_proj_form-order_type NE 'Z060'.
          lw_zzdci_proj-cap_active = 'X'.
        ELSEIF gs_proj_form-project_type EQ '2' AND gs_proj_form-order_type NE 'Z060'.
          lw_zzdci_proj-labor_ind = 'X'.
        ENDIF.
        INSERT zzdci_proj FROM lw_zzdci_proj.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD get_userdetail.
    DATA lw_user_range TYPE  slim_sel_user_str.
    DATA lt_uname_range TYPE slim_sel_user.
    DATA lt_user        TYPE TABLE OF zca_user_alv.
    DATA lv_initiate_by TYPE syuname.
    DATA lv_dummy_date  TYPE dats.

    IF gs_proj_form-requester_id IS NOT INITIAL.
      lv_initiate_by = gs_proj_form-requester_id.
    ELSE.
      lv_initiate_by = gs_formdetails-initiated_by.
    ENDIF.

    IF lv_initiate_by IS NOT INITIAL.
      lw_user_range-sign = 'I'.
      lw_user_range-option = 'EQ'.
      lw_user_range-low  = lv_initiate_by.
      APPEND lw_user_range TO lt_uname_range.

      CALL FUNCTION 'Z_BAPI_BC_USER_GETLIST'
        EXPORTING
          i_datum = lv_dummy_date
        TABLES
          s_bname = lt_uname_range
          et_user = lt_user.

      TRY.
          DATA(lw_user) = lt_user[ bname = lv_initiate_by ].
        CATCH cx_sy_itab_line_not_found.
          EXIT.
      ENDTRY.
    ENDIF.

* Full Name
    CONCATENATE lw_user-name_first lw_user-name_last INTO gs_employee_info-ename SEPARATED BY space.

* Get PERNR based on First and Last Name
    SELECT SINGLE * FROM pa0002 INTO @DATA(lw_p0002) WHERE zzvorna = @lw_user-name_first AND zznachn = @lw_user-name_last.
    IF sy-subrc EQ 0.
      gs_employee_info-pernr = lw_p0002-pernr.
    ENDIF.

* Email ID
    gs_employee_info-email = lw_user-user_email.

* Telephone No.
    SELECT  SINGLE usr21~persnumber AS person,
                   usr21~addrnumber AS address_no,
                   adr2~telnr_long  AS tele_no
                 INTO @DATA(lw_tele)
                 FROM usr21
                 INNER JOIN adr2 ON adr2~persnumber = usr21~persnumber AND
                                    adr2~addrnumber = usr21~addrnumber
                    WHERE usr21~bname = @lw_user-bname.
    IF sy-subrc EQ 0.
      CONCATENATE 'tel:' lw_tele-tele_no INTO gs_employee_info-phone SEPARATED BY space.
      gs_employee_info-phone_text = lw_tele-tele_no.
    ENDIF.

  ENDMETHOD.


METHOD load_form.

    TYPES : BEGIN OF ty_stepguid,
              sign   TYPE char1,
              option TYPE char2,
              low    TYPE sysuuid_c,
              high   TYPE sysuuid_c.
    TYPES : END OF ty_stepguid.

* Get the Preferred First and last Name
    DATA lv_date(10)       TYPE c.
    DATA lt_stepguid_range TYPE STANDARD TABLE OF ty_stepguid.
    DATA lw_stepdetail     TYPE zca_stepdetail.
    DATA: lv_userid TYPE xubname.

* Read Form GUID
    SELECT SINGLE * FROM zca_formdetail INTO gs_formdetails WHERE form_guid EQ ip_form_guid.
    IF sy-subrc NE 0.
      EXIT.
    ELSE.
* Update form version
      gc_form_ver = gs_formdetails-form_ver.
    ENDIF.

* Read all Step GUID based on FORM ID for COMMENTS
    SELECT * FROM zca_stepdetail INTO TABLE @DATA(lt_proj_formsteps) WHERE form_guid EQ @gs_formdetails-form_guid ORDER BY
                                 completion_date DESCENDING , completion_time DESCENDING.
    IF sy-subrc EQ 0.
* Read latest Project Form Value
      READ TABLE lt_proj_formsteps INTO gs_stepdetail WITH KEY step_status = 'STARTED'.
      IF sy-subrc NE 0.
*        READ TABLE lt_proj_formsteps INTO gs_stepdetail WITH KEY step_status = 'REJECTED'.
*        IF sy-subrc NE 0.
        gs_stepdetail  = lt_proj_formsteps[ 1 ].
*        ENDIF.
      ENDIF.

* Incase if the form is rejected - But back to status where BPC completed
      IF wa_url_parameters-from = 'search' AND
         ( gs_stepdetail-step_status = 'REJECTED' OR gs_stepdetail-step_status = 'WITHDRAWN' OR gs_stepdetail-step_status = 'ERROR' ).

        READ TABLE lt_proj_formsteps INTO gs_stepdetail WITH KEY appr_step = 'BPC' step_status = 'COMPLETED'.
        IF sy-subrc EQ 0.

        ENDIF.
      ENDIF.

* Built Range Table to read comments
      lt_stepguid_range = VALUE #( FOR line IN lt_proj_formsteps
                                  ( sign = zhrc_include
                                    option = zhrc_equal
                                    low    = line-step_guid
                                    high   = '' ) ).
    ENDIF.

*    IF sy-subrc EQ 0.
** Read latest Project Form Value
*      gs_stepdetail  = lt_proj_formsteps[ 1 ].  " Assign 1st record
*
** Overwrite if the 1st record is not BPC and COMPLETED
*      IF gs_stepdetail-appr_step NE 'BPC' AND gs_stepdetail-step_status NE 'COMPLETED'.
*        IF sy-subrc EQ 0.
*          READ TABLE lt_proj_formsteps INTO gs_stepdetail WITH KEY step_status = 'STARTED'.
*          IF sy-subrc NE 0.
*            READ TABLE lt_proj_formsteps INTO gs_stepdetail WITH KEY step_status = 'REJECTED'.
*            IF sy-subrc NE 0 OR ( sy-subrc EQ 0 AND wa_url_parameters-from = 'search' ).
*              gs_stepdetail  = lt_proj_formsteps[ 1 ].
*            ENDIF.
*          ENDIF.
*        ENDIF.
*      ENDIF.
** Built Range Table to read comments
*      lt_stepguid_range = VALUE #( FOR line IN lt_proj_formsteps
*                                  ( sign = zhrc_include
*                                    option = zhrc_equal
*                                    low    = line-step_guid
*                                    high   = '' ) ).
*    ENDIF.

* Read all entries of Form table to build comments
    SELECT * FROM zmdg_proj_form INTO TABLE @DATA(gt_proj_form) WHERE step_guid IN @lt_stepguid_range.

* Format Previous Comments
    LOOP AT gt_proj_form INTO DATA(ls_proj_form) WHERE comments IS NOT INITIAL.
      lw_stepdetail = lt_proj_formsteps[ step_guid = ls_proj_form-step_guid ].

      DATA(lw_apprname) = gt_appr[ approverid = lw_stepdetail-processed_by ].

      WRITE lw_stepdetail-completion_date TO lv_date.

      CONCATENATE  gs_proj_form-prev_comments '[ ' lv_date ' ] -' INTO gs_proj_form-prev_comments.
      CONCATENATE  gs_proj_form-prev_comments lw_apprname-approvername zhrc_colon ls_proj_form-comments INTO gs_proj_form-prev_comments SEPARATED BY space.

      CONCATENATE  gs_proj_form-prev_comments cl_abap_char_utilities=>newline INTO gs_proj_form-prev_comments SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
    ENDLOOP.

    CLEAR gs_stepdetail-comments.

* No.of entries in table
*    DESCRIBE TABLE gt_proj_form LINES DATA(lv_lines).
* Read latest Project Form Value
    TRY.
        ls_proj_form = gt_proj_form[ step_guid = gs_stepdetail-step_guid ].
        MOVE-CORRESPONDING ls_proj_form TO gs_proj_form.
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

* Get Attachment
    get_attachment_list( ).

* Update Order detail table
    CLEAR gs_orderdetails.
    IF gs_proj_form-project_code IS NOT INITIAL.
      gs_orderdetails-output_ccode = gs_proj_form-company_code.
      gs_orderdetails-output_ccenter = gs_proj_form-kostl.
      gs_orderdetails-project_code = gs_proj_form-project_code.

      IF gs_proj_form-internal_no IS NOT INITIAL.
        gs_orderdetails-internal_order = gs_proj_form-internal_no.
        gs_orderdetails-error_desc = |{ gs_proj_form-projectname } { '-' }  { gs_proj_form-company_code } |.
      ELSE.
        gs_orderdetails-error_desc = gs_proj_form-internal_no_err.
      ENDIF.
      APPEND gs_orderdetails TO gt_orderdetails.
    ENDIF.

** Update ITL Project details
    CLEAR gs_orderdetails.
    IF gs_proj_form-itl_proj_code IS NOT INITIAL.
      gs_orderdetails-project_code = gs_proj_form-itl_proj_code.
      gs_orderdetails-output_ccode = gs_proj_form-company_code.
      gs_orderdetails-output_ccenter = gs_proj_form-kostl.

      IF gs_proj_form-itl_internal_no IS NOT INITIAL.
        gs_orderdetails-internal_order = gs_proj_form-itl_internal_no.
        gs_orderdetails-error_desc = |{ gs_proj_form-projectname } { '-' }  { gs_proj_form-company_code }|.
      ELSE.
        gs_orderdetails-error_desc = gs_proj_form-itl_int_no_error.
        gs_orderdetails-is_error   = gc_true.
      ENDIF.
      APPEND gs_orderdetails TO gt_orderdetails.
    ENDIF.

** Update CLS Project details
    CLEAR gs_orderdetails.
    IF gs_proj_form-cls_proj_code IS NOT INITIAL.
      gs_orderdetails-project_code = gs_proj_form-cls_proj_code.
      gs_orderdetails-output_ccode = gs_proj_form-company_code.
      gs_orderdetails-output_ccenter = gs_proj_form-kostl.

      IF gs_proj_form-cls_internal_no IS NOT INITIAL.
        gs_orderdetails-internal_order = gs_proj_form-cls_internal_no.
        gs_orderdetails-error_desc = |{ gs_proj_form-projectname } { '-' } { gs_proj_form-company_code } |.
      ELSE.
        gs_orderdetails-error_desc = gs_proj_form-cls_int_no_error.
        gs_orderdetails-is_error   = gc_true.
      ENDIF.
      APPEND gs_orderdetails TO gt_orderdetails.
    ENDIF.

*** Update Additional Company Code and Cost Center
    SPLIT gs_proj_form-additional_comp_code AT ',' INTO TABLE DATA(it_add_comp_code).
    LOOP AT it_add_comp_code INTO DATA(wa_additional_ccode).
      CLEAR gs_orderdetails.
      SPLIT wa_additional_ccode AT '/' INTO gs_orderdetails-output_ccode gs_orderdetails-output_ccenter
                                            DATA(lv_project_code)
                                            DATA(lv_internal_no)
                                            DATA(lv_itl_proj_code)
                                            DATA(lv_itl_internal_no)
                                            DATA(lv_status)
                                            DATA(lv_cls_proj_code)
                                            DATA(lv_cls_internal_no).
      CONDENSE gs_orderdetails-output_ccode.
      CONDENSE gs_orderdetails-output_ccenter.
      CONDENSE lv_project_code.
      CONDENSE lv_internal_no.
      CONDENSE lv_itl_proj_code.
      CONDENSE lv_itl_internal_no.
      CONDENSE lv_cls_proj_code.
      CONDENSE lv_cls_internal_no.
      CONDENSE lv_status.

* Update Order detail table
      IF lv_project_code IS NOT INITIAL.
        gs_orderdetails-project_code = lv_project_code.

        IF lv_internal_no IS NOT INITIAL AND lv_status = 'S'.
          gs_orderdetails-internal_order = lv_internal_no.
          gs_orderdetails-error_desc = |{ gs_proj_form-projectname } { '-' } { gs_orderdetails-output_ccode } |.
        ELSE.
          gs_orderdetails-error_desc = lv_internal_no.
          gs_orderdetails-is_error   = gc_true.
        ENDIF.
        APPEND gs_orderdetails TO gt_orderdetails.
      ENDIF.

** Update ITL Project details
      IF lv_itl_proj_code IS NOT INITIAL.
        gs_orderdetails-project_code = lv_itl_proj_code.

        IF lv_itl_internal_no IS NOT INITIAL AND lv_status = 'S'.
          gs_orderdetails-internal_order = lv_itl_internal_no.
          gs_orderdetails-error_desc = | { gs_proj_form-projectname } { '-' } { gs_orderdetails-output_ccode } |.
        ELSE.
          gs_orderdetails-error_desc = lv_itl_internal_no.
        ENDIF.
        APPEND gs_orderdetails TO gt_orderdetails.
      ENDIF.

** Update CLS Project details
      IF lv_cls_proj_code IS NOT INITIAL.
        gs_orderdetails-project_code = lv_cls_proj_code.

        IF lv_cls_internal_no IS NOT INITIAL AND lv_status = 'S'.
          gs_orderdetails-internal_order = lv_cls_internal_no.
          gs_orderdetails-error_desc = | { gs_proj_form-projectname } { '-' } { gs_orderdetails-output_ccode } |.
        ELSE.
          gs_orderdetails-error_desc = lv_cls_internal_no.
        ENDIF.
        APPEND gs_orderdetails TO gt_orderdetails.
      ENDIF.
    ENDLOOP.

** Update Cost Center
    SELECT SINGLE * FROM cskt INTO @DATA(lw_cskt) WHERE spras = 'E' AND kostl EQ @gs_proj_form-kostl.
    IF sy-subrc EQ 0.
      gs_proj_form-kostl_text = |{ lw_cskt-kostl } { lw_cskt-ltext }|.
    ENDIF.


    IF wa_url_parameters-mode EQ 'EDIT' AND wa_url_parameters-from = 'search' AND gs_formdetails-appr_step = 'BPC'.
      lv_userid = sy-uname.
    ELSE.
      lv_userid = gs_proj_form-requester_id.
    ENDIF.

    zcl_nd_ca_utilities=>get_information_from_user(
      EXPORTING
        iv_user_id   = lv_userid
      IMPORTING
        es_user_info = DATA(lw_uname) ).

    gs_proj_form-requester_id    = lv_userid.
    gs_proj_form-requester_name  = lw_uname-name.
    gs_proj_form-requester_title = lw_uname-title.
    gs_proj_form-requester_email = lw_uname-email.


    if not gs_proj_form-project_id is initial.
      call function 'CONVERSION_EXIT_PROJN_OUTPUT'
        exporting
          input  = gs_proj_form-project_id
        importing
          output = gs_proj_form-project_id_out.
    endif.

    if not gs_proj_form-capex_req_amount is initial
        and not gs_proj_form-capex_req_curr is initial.
      currency_convert_out(
        exporting
          iv_currency = gs_proj_form-capex_req_curr
        changing
          cv_amount = gs_proj_form-capex_req_amount
      ).
    endif.
  ENDMETHOD.


METHOD  populate_f4_help.
    DATA: lt_dd07v_tab_a TYPE STANDARD TABLE OF dd07v,
          lt_dd07v_tab_n TYPE STANDARD TABLE OF dd07v.
    DATA: lt_att_req TYPE TABLE OF zmdg_att_req,
          ls_att_req TYPE zmdg_att_req.
    DATA: lt_range_kostl TYPE ranges_kostl_tt,
          ls_geo type ty_value_text.

    TYPES: BEGIN OF s_001,
             bukrs TYPE bukrs,
             butxt TYPE butxt,
             land1 TYPE land1,
           END OF s_001.

* #1: Request Type
    CALL FUNCTION 'DD_DOMA_GET'
      EXPORTING
        domain_name   = 'ZMDG_PROJ_TYPE'
      TABLES
        dd07v_tab_a   = lt_dd07v_tab_a
        dd07v_tab_n   = lt_dd07v_tab_n
      EXCEPTIONS
        illegal_value = 1
        op_failure    = 2
        OTHERS        = 3.
    IF sy-subrc EQ 0.
      LOOP AT lt_dd07v_tab_a INTO DATA(lw_dd07v_tab_a).
        gs_request_type-value = lw_dd07v_tab_a-domvalue_l.
        gs_request_type-text = lw_dd07v_tab_a-ddtext.
        APPEND gs_request_type TO gt_request_type.
      ENDLOOP.
      INSERT INITIAL LINE INTO gt_request_type INDEX 1. " Blank Entries
    ENDIF.

* #2: Executive Category
    SELECT * INTO TABLE @DATA(gt_exec_cat) FROM zzmdg_exec_categ.
    IF sy-subrc EQ 0.
      SORT gt_exec_cat BY exec_category_id.

      gt_exec_category  = VALUE #( FOR line9 IN gt_exec_cat
                                 ( value = line9-exec_category_id
                                   text  = line9-exec_category_text ) ).

      INSERT INITIAL LINE INTO gt_exec_category INDEX 1. " Blank Entries
    ENDIF.


* #3: Quadrant
    CALL FUNCTION 'DD_DOMA_GET'
      EXPORTING
        domain_name   = 'ZMDG_QUADRANT'
      TABLES
        dd07v_tab_a   = lt_dd07v_tab_a
        dd07v_tab_n   = lt_dd07v_tab_n
      EXCEPTIONS
        illegal_value = 1
        op_failure    = 2
        OTHERS        = 3.
    IF sy-subrc EQ 0.
      LOOP AT lt_dd07v_tab_a INTO lw_dd07v_tab_a.
        gs_quadrant-value = lw_dd07v_tab_a-domvalue_l.
        gs_quadrant-text  = lw_dd07v_tab_a-ddtext.
        APPEND gs_quadrant TO gt_quadrant.
      ENDLOOP.
      INSERT INITIAL LINE INTO gt_quadrant INDEX 1. " Blank Entries
    ENDIF.

* #4: Initiative group
    SELECT * INTO TABLE @DATA(gt_init_grp) FROM zzmdg_initia_grp.
    IF sy-subrc EQ 0.
      SORT gt_init_grp BY initiative_grp_id.

      gt_initi_group  = VALUE #( FOR line10 IN gt_init_grp
                                 ( exec_category_id   = line10-exec_category_id
                                   initiative_grp_id  = line10-initiative_grp_id
                                   initiative_grp_txt = line10-initiative_grp_txt ) ).

      INSERT INITIAL LINE INTO gt_initi_group INDEX 1. " Blank Entries

* Copy the result
      MOVE gt_initi_group[] TO gt_initi_grp[].
    ENDIF.

* #6: Asset Class
*    IF gs_proj_form-processing_region NE 'A'.
    SELECT * INTO TABLE @DATA(gt_invprof) FROM taprft WHERE spras = 'E' AND
                                                            ( ivpro = 'Z00001' OR
                                                              ivpro = 'Z00002' OR
                                                              ivpro = 'Z00003' OR
                                                              ivpro = 'Z00004' OR
                                                              ivpro = 'Z00010' OR
                                                              ivpro = 'Z00011' ).

*    ELSE.
*      SELECT * INTO TABLE gt_invprof FROM taprft WHERE spras = 'E' AND ivpro LIKE 'Z%'.

*    ENDIF.

    IF sy-subrc EQ 0.
      SORT gt_invprof BY ivpro.
* If Project Type = ITL default Asset Class to Z00003 '
      IF gs_proj_form-project_type = 2.
        DELETE gt_invprof WHERE ivpro NE 'Z00003'.
      ENDIF.

      gt_asset_class  = VALUE #( FOR line7 IN gt_invprof
                                 ( value = line7-ivpro
                                   text  = line7-invtxt ) ).

      INSERT INITIAL LINE INTO gt_asset_class INDEX 1. " Blank Entries
    ENDIF.

* #6: ITL Asset Class
    SELECT * INTO TABLE gt_invprof  FROM taprft WHERE spras = 'E' AND
                                                            ( ivpro = 'Z00003' ).
    IF sy-subrc EQ 0.
      SORT gt_invprof BY ivpro.

      gt_itl_asset_class  = VALUE #( FOR line7 IN gt_invprof
                                 ( value = line7-ivpro
                                   text  = line7-invtxt ) ).
      gs_proj_form-itl_asset_class = 'Z00003'.
    ENDIF.


* #7: Priority
    CALL FUNCTION 'DD_DOMA_GET'
      EXPORTING
        domain_name   = 'ZMDG_PRIORITY'
      TABLES
        dd07v_tab_a   = lt_dd07v_tab_a
        dd07v_tab_n   = lt_dd07v_tab_n
      EXCEPTIONS
        illegal_value = 1
        op_failure    = 2
        OTHERS        = 3.
    IF sy-subrc EQ 0.
      LOOP AT lt_dd07v_tab_a INTO lw_dd07v_tab_a.
        gs_priority-value = lw_dd07v_tab_a-domvalue_l.
        gs_priority-text  = lw_dd07v_tab_a-ddtext.
        APPEND gs_priority TO gt_priority.
      ENDLOOP.
      INSERT INITIAL LINE INTO gt_priority INDEX 1. " Blank Entries
    ENDIF.

*#5: Populate Catalogries
    SELECT category description INTO TABLE gt_attachment_categories
        FROM zmdgattcategory
        WHERE form_name = gc_form_name
        ORDER BY description.

    INSERT INITIAL LINE INTO gt_attachment_categories INDEX 1. " Blank Entries

    select * into table gt_attachments_required
        from zmdg_att_req.

*    IF gt_attachment_categories IS NOT INITIAL.
** Flag attachment categories which are required.
*     SELECT * INTO TABLE lt_att_req FROM zmdg_att_req WHERE form_name = gc_form_name.
*     IF sy-subrc = 0.
*        LOOP AT gt_attachment_categories ASSIGNING FIELD-SYMBOL(<category>).
*          READ TABLE lt_att_req INTO ls_att_req
*              WITH KEY att_category = <category>-value
*                       country = space
*                       project_type = <category>
*          IF sy-subrc = 0.
*            <category>-required = ls_att_req-required.
*          ENDIF.
*
*          IF NOT <category>-required IS INITIAL.
*            <category>-required = 'true'.
*          ELSE.
*            <category>-required = 'false'.
*          ENDIF.
*        ENDLOOP.
*      ENDIF.
*
*      INSERT INITIAL LINE INTO gt_attachment_categories INDEX 1. " Blank Entries
*    ENDIF.


*#8  Previous Project code - CAP/CLS Project
    SELECT * INTO TABLE @DATA(gt_prevcode) FROM zzdci_proj WHERE zzproject NOT LIKE 'ITL%'.
    IF sy-subrc EQ 0.
      SORT gt_prevcode BY zzproject.
      DELETE ADJACENT DUPLICATES FROM gt_prevcode COMPARING zzproject.

* Delete existing deactivated record
      IF gs_proj_form-proj_flgrp_0001 EQ gc_true.
        DELETE gt_prevcode WHERE cap_active EQ '' AND labor_ind EQ ''.
      ENDIF.

      gt_prev_projcode  = VALUE #( FOR line1 IN gt_prevcode
                                 ( value = line1-zzproject
                                   text  = line1-zzdescription ) ).

      INSERT INITIAL LINE INTO gt_prev_projcode INDEX 1. " Blank Entries
    ENDIF.

*#8  Previous Project code - CAP Project
    SELECT * INTO TABLE gt_prevcode FROM zzdci_proj WHERE zzproject LIKE 'ITL%'.
    IF sy-subrc EQ 0.
      SORT gt_prevcode BY zzproject.
      DELETE ADJACENT DUPLICATES FROM gt_prevcode COMPARING zzproject.

* Delete existing deactivated record
      IF gs_proj_form-proj_flgrp_0001 EQ gc_true.
        DELETE gt_prevcode WHERE cap_active EQ '' AND labor_ind EQ ''.
      ENDIF.

      gt_prev_itl_projcode  = VALUE #( FOR line1 IN gt_prevcode
                                 ( value = line1-zzproject
                                   text  = line1-zzdescription ) ).

      INSERT INITIAL LINE INTO gt_prev_itl_projcode INDEX 1. " Blank Entries
    ENDIF.

*#8a  Previous Project code - IMO Project
    SELECT * INTO TABLE gt_prevcode FROM zzdci_proj WHERE zzproject LIKE 'IMO%'.
    IF sy-subrc EQ 0.
      SORT gt_prevcode BY zzproject.
      DELETE ADJACENT DUPLICATES FROM gt_prevcode COMPARING zzproject.

* Delete existing deactivated record
      IF gs_proj_form-proj_flgrp_0001 EQ gc_true.
        DELETE gt_prevcode WHERE cap_active EQ '' AND labor_ind EQ ''.
      ENDIF.

      gt_prev_imo_projcode  = VALUE #( FOR line1 IN gt_prevcode
                                 ( value = line1-zzproject
                                   text  = line1-zzdescription ) ).

      INSERT INITIAL LINE INTO gt_prev_imo_projcode INDEX 1. " Blank Entries
    ENDIF.

*#9  Currency
    SELECT * INTO TABLE @DATA(gt_tcurt) FROM tcurt WHERE spras = 'E' ORDER BY waers.
    IF sy-subrc EQ 0.
      SORT gt_tcurt BY waers.

      DELETE ADJACENT DUPLICATES FROM gt_tcurt COMPARING waers.

      gt_currency  = VALUE #( FOR line2 IN gt_tcurt
                                 ( value = line2-waers
                                   text  = line2-ltext ) ).


      INSERT INITIAL LINE INTO gt_currency INDEX 1. " Blank Entries

****To pick Top 3******************************************************************
      READ TABLE gt_tcurt INTO DATA(gw_tcurt) WITH KEY waers = 'USD'.
      IF sy-subrc EQ 0.
        DELETE gt_currency WHERE value = 'USD'.
        gs_currency-value = gw_tcurt-waers.
        gs_currency-text = gw_tcurt-ltext.
        INSERT gs_currency INTO gt_currency INDEX 2.
      ENDIF.

      READ TABLE gt_tcurt INTO gw_tcurt WITH KEY waers = 'GBP'.
      IF sy-subrc EQ 0.
        DELETE gt_currency WHERE value = 'GBP'.
        gs_currency-value = gw_tcurt-waers.
        gs_currency-text = gw_tcurt-ltext.
        INSERT gs_currency INTO gt_currency INDEX 3.
      ENDIF.

      READ TABLE gt_tcurt INTO gw_tcurt WITH KEY waers = 'EUR'.
      IF sy-subrc EQ 0.
        DELETE gt_currency WHERE value = 'EUR'.
        gs_currency-value = gw_tcurt-waers.
        gs_currency-text = gw_tcurt-ltext.
        INSERT gs_currency INTO gt_currency INDEX 4.
      ENDIF.
    ENDIF.

**#9 US State
    SELECT * INTO TABLE @DATA(gt_statelist) FROM t005u WHERE spras = 'E' AND land1 = 'US'.
    IF sy-subrc EQ 0.
      SORT gt_statelist BY bland.
      DELETE ADJACENT DUPLICATES FROM gt_statelist COMPARING bland.

      gt_usstate  = VALUE #( FOR line4 IN gt_statelist
                                 ( value = line4-bland
                                   text  = line4-bezei ) ).

      INSERT INITIAL LINE INTO gt_usstate INDEX 1. " Blank Entries
    ENDIF.

******Company Code - Based on Processing Region*************
    CALL METHOD get_company_code.

** Get Order Type based on processing region
    CALL METHOD get_order_type.
** Get list of cost center based on Company Code in form

    IF gs_proj_form-company_code IS NOT INITIAL.
      IF gs_proj_form-proj_flgrp_0001 EQ gc_true.
        SELECT * FROM csks INTO TABLE @DATA(lt_csks) WHERE bukrs EQ @gs_proj_form-company_code AND bkzkp NE 'X' AND datbi GE @sy-datum.
      ELSE.
        SELECT * FROM csks INTO TABLE lt_csks WHERE bukrs EQ gs_proj_form-company_code AND kostl EQ gs_proj_form-kostl.
      ENDIF.

      IF sy-subrc EQ 0.
        SORT lt_csks BY kostl.
        DELETE ADJACENT DUPLICATES FROM lt_csks COMPARING kostl.
        lt_range_kostl   = VALUE #( FOR line IN lt_csks
                                      ( sign = zhrc_include
                                        option = zhrc_equal
                                        low    = line-kostl
                                        high   = '' ) ).

        SELECT * FROM cskt INTO TABLE @DATA(lt_cskt) WHERE spras = 'E' AND kostl IN @lt_range_kostl.
        IF sy-subrc EQ 0.
          gt_kostl  = VALUE #( FOR line6 IN lt_cskt
                                      ( value = line6-kostl
                                        text  = line6-ltext ) ).

          INSERT INITIAL LINE INTO gt_kostl INDEX 1.
        ENDIF.
      ENDIF.
    ENDIF.

*   Project subtypes
    select project_subtype description
        into table gt_project_subtype
        from zps_proj_subtypt
        where language = 'E'
        order by project_subtype.

*   Geography
    select geography name
        into table gt_geographylist
        from ztgeography_t
        where spras = 'E'
          and geography <> '#'
        order by geography.

*   Order US ahead of the other entries.
    read table gt_geographylist into ls_geo
        with key value = 'US'.
    if sy-subrc = 0.
      delete gt_geographylist index sy-tabix.
      insert ls_geo into gt_geographylist index 1.
    endif.

*   Brand
    select brand name
        into table gt_brands
        from ztbrand_t
        where spras = 'E'
          and brand <> '*'
        order by brand.

*   Locations
    select werks stand ktext into table gt_locations
        from t499s
        where werks = ' '
        order by stand.

    insert initial line into gt_project_subtype index 1.
  ENDMETHOD.


METHOD populate_field_email.
    DATA: lv_index              TYPE numc2,
          lv_update_email_value TYPE char30,
          lv_amount(20)         type c,
          lv_left               type string,
          lv_right              type string.
***Method - Used to populate fields used in email text******

* Get Text for Processing Region
    IF ip_form-processing_region EQ 'U'.
      io_email_value-region = 'US/LA'.
    ELSEIF ip_form-processing_region = 'E'.
      io_email_value-region = 'Europe'.
    ELSEIF ip_form-processing_region EQ 'A'.
      io_email_value-region = 'Asia'.
    ENDIF.

* Get Text for Exective Category
*    lv_value = ip_form-exec_category.
    SELECT SINGLE exec_category_text INTO @DATA(lv_cata_text) FROM zzmdg_exec_categ WHERE exec_category_id = @ip_form-exec_category.
    IF sy-subrc EQ 0.
      io_email_value-exec_category_t = lv_cata_text.
    ENDIF.

* Get Text for Initiative Group
    SELECT SINGLE initiative_grp_txt INTO @DATA(lv_initi_grp_txt) FROM zzmdg_initia_grp WHERE initiative_grp_id = @ip_form-initiative_group.
    IF sy-subrc EQ 0.
      io_email_value-initiative_group_t = lv_initi_grp_txt.
    ENDIF.

    io_email_value-requestor_name = ip_form-requester_name.
    io_email_value-projectname    = ip_form-projectname.
    io_email_value-proj_desc      = ip_form-proj_desc.
    io_email_value-justification  = ip_form-buss_justify.
    io_email_value-comp_code      = ip_form-company_code.
    io_email_value-kostl_code     = ip_form-kostl.

    io_email_value-company_code   = io_email_value-comp_code.
    io_email_value-cost_center    = io_email_value-kostl_code.

    io_email_value-brand          = ip_form-brand.
    io_email_value-geography      = ip_form-geography.
    io_email_value-capid          = ip_form-capid.

    write ip_form-capex_req_amount to lv_amount left-justified currency ip_form-capex_req_curr.
    io_email_value-amount = lv_amount && ` ` && ip_form-capex_req_curr.

    if not ip_form-project_id is initial.
      call function 'CONVERSION_EXIT_PROJN_OUTPUT'
        exporting
          input  = ip_form-project_id
        importing
          output = io_email_value-project_id.
    endif.

*Check Project Code for all 3 types**********************************
    IF ip_form-project_code IS NOT INITIAL.
      io_email_value-comp_code      = ip_form-company_code.
      io_email_value-kostl_code     = ip_form-kostl.
      io_email_value-internal_no    = ip_form-internal_no.
      io_email_value-project_code    = ip_form-project_code.

      IF ip_form-internal_no IS INITIAL.
        io_email_value-project_order_name = TEXT-e15.
      ELSE.
        io_email_value-project_order_name = |{ ip_form-projectname }  { '-' }  { ip_form-company_code } |.
      ENDIF.

    ENDIF.

    IF ip_form-itl_proj_code IS NOT INITIAL.
      io_email_value-itl_comp_code  = ip_form-company_code.
      io_email_value-itl_kostl_code = ip_form-kostl.
      io_email_value-itl_internal_no    = ip_form-itl_internal_no .
      io_email_value-itl_proj_code       = ip_form-itl_proj_code.

      IF io_email_value-itl_internal_no IS INITIAL.
        io_email_value-itl_proj_order_name = TEXT-e16.
      ELSE.
        io_email_value-itl_proj_order_name = |{ ip_form-projectname }  { '-' }  { ip_form-company_code } |.
      ENDIF.
    ENDIF.

    IF ip_form-cls_proj_code IS NOT INITIAL.
      io_email_value-cls_comp_code  = ip_form-company_code.
      io_email_value-cls_kostl_code = ip_form-kostl.
      io_email_value-cls_internal_no = ip_form-cls_internal_no .
      io_email_value-cls_proj_code       = ip_form-cls_proj_code.

      IF io_email_value-cls_internal_no IS INITIAL.
        io_email_value-itl_proj_order_name = TEXT-e17.
      ELSE.
        io_email_value-cls_proj_order_name = |{ ip_form-projectname }  { '-' }  { ip_form-company_code } |.
      ENDIF.
    ENDIF.

    io_email_value-url_text3 = 'Project Request Form'.


* For Multiple company code
*    IF ip_form-additional_comp_code IS NOT INITIAL.
*      SPLIT ip_form-additional_comp_code AT ',' INTO TABLE DATA(lt_additional_compcode).
*      LOOP AT lt_additional_compcode INTO DATA(lw_additional_compcode).
*        lv_index = sy-tabix.
*        SPLIT lw_additional_compcode AT '/' INTO DATA(lv_company_code)
*                                                 DATA(lv_kostl)
*                                                 DATA(lv_project_code)
*                                                 DATA(lv_internal_no)
*                                                 DATA(lv_itl_proj_code)
*                                                 DATA(lv_itl_internal_no)
*                                                 DATA(lv_status)
*                                                 DATA(lv_cls_proj_code)
*                                                 DATA(lv_cls_internal_no).
*
*        CONDENSE lv_company_code.
*        CONDENSE lv_kostl.
*        CONDENSE lv_project_code.
*        CONDENSE lv_internal_no.
*        CONDENSE lv_itl_proj_code.
*        CONDENSE lv_itl_internal_no.
*        CONDENSE lv_cls_proj_code.
*        CONDENSE lv_cls_internal_no.
*        CONDENSE lv_status.
*
*        IF lv_project_code IS NOT INITIAL.
*          CONCATENATE 'COMP_CODE' lv_index INTO  lv_update_email_value SEPARATED BY '_'.
*          ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO FIELD-SYMBOL(<fs>).
*          IF sy-subrc EQ 0.
*            <fs> = lv_company_code.
*          ENDIF.
*
*          CONCATENATE 'KOSTL_CODE' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*          ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*          IF sy-subrc EQ 0.
*            <fs> = lv_kostl.
*          ENDIF.
*        ELSEIF lv_itl_proj_code IS NOT INITIAL.
*          CONCATENATE 'ITL_COMP_CODE' lv_index INTO  lv_update_email_value SEPARATED BY '_'.
*          ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*          IF sy-subrc EQ 0.
*            <fs> = lv_company_code.
*          ENDIF.
*
*          CONCATENATE 'ITL_KOSTL_CODE' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*          ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*          IF sy-subrc EQ 0.
*            <fs> = lv_kostl.
*          ENDIF.
*        ELSEIF lv_cls_proj_code IS NOT INITIAL.
*          CONCATENATE 'CLS_COMP_CODE' lv_index INTO  lv_update_email_value SEPARATED BY '_'.
*          ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*          IF sy-subrc EQ 0.
*            <fs> = lv_company_code.
*          ENDIF.
*
*          CONCATENATE 'CLS_KOSTL_CODE' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*          ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*          IF sy-subrc EQ 0.
*            <fs> = lv_kostl.
*          ENDIF.
*        ENDIF.
*
*        CONCATENATE 'PROJECT_CODE' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*        ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*        IF sy-subrc EQ 0.
*          <fs> = lv_project_code.
*        ENDIF.
*
*        CONCATENATE 'INTERNAL_NO' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*        ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*        IF sy-subrc EQ 0 AND lv_status NE 'E'.
*          <fs> = lv_internal_no.
*        ELSE.
*          CLEAR <fs>.
*        ENDIF.
*
*        IF lv_project_code IS NOT INITIAL.
*          CONCATENATE 'PROJECT_ORDER_NAME' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*          ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*          IF sy-subrc EQ 0 AND lv_status NE 'E'.
*            <fs> = |{ ip_form-projectname }  { '-' }  { lv_company_code } |.
*          ELSE.
*            <fs> = lv_internal_no.
*          ENDIF.
*        ENDIF.
*
*        CONCATENATE 'ITL_PROJ_CODE' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*        ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*        IF sy-subrc EQ 0.
*          <fs> = lv_itl_proj_code.
*        ENDIF.
*
*        CONCATENATE 'ITL_INTERNAL_NO' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*        ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*        IF sy-subrc EQ 0 AND lv_status NE 'E'.
*          <fs> = lv_itl_internal_no.
*        ELSE.
*          CLEAR <fs>.
*        ENDIF.
*
*        CONCATENATE 'CLS_PROJ_CODE' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*        ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*        IF sy-subrc EQ 0.
*          <fs> = lv_cls_proj_code.
*        ENDIF.
*
*        CONCATENATE 'CLS_INTERNAL_NO' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*        ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*        IF sy-subrc EQ 0 AND lv_status NE 'E'.
*          <fs> = lv_cls_internal_no.
*        ELSE.
*          CLEAR <fs>.
*        ENDIF.
*
*        IF lv_itl_proj_code IS NOT INITIAL.
*          CONCATENATE 'ITL_PROJ_ORDER_NAME' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*          ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*          IF sy-subrc EQ 0 AND lv_status NE 'E'.
*            <fs> = |{ ip_form-projectname }  { '-' }  { lv_company_code } |.
*          ELSE.
*            <fs> = lv_itl_internal_no.
*          ENDIF.
*        ENDIF.
*
*        IF lv_cls_proj_code IS NOT INITIAL.
*          CONCATENATE 'CLS_PROJ_ORDER_NAME' lv_index INTO lv_update_email_value SEPARATED BY '_'.
*          ASSIGN COMPONENT lv_update_email_value OF STRUCTURE io_email_value TO <fs>.
*          IF sy-subrc EQ 0 AND lv_status NE 'E'.
*            <fs> = |{ ip_form-projectname }  { '-' }  { lv_company_code } |.
*          ELSE.
*            <fs> = lv_cls_internal_no.
*          ENDIF.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
  ENDMETHOD.


METHOD redirect_error.
    DATA: lr_mime_api   TYPE REF TO if_mr_api,
          lr_contents_x TYPE xstring.

    lr_mime_api = cl_mime_repository_api=>get_api( ).
    lr_mime_api->get(
      EXPORTING
        i_url     = '/SAP/BC/BSP/SAP/ZUI_PROJREQCODE/attacherror.html'  " <TR> Page in BSP
      IMPORTING
        e_content = lr_contents_x
    ).

    ev_data         = lr_contents_x.  " <TR> Was response API
    ev_content_type = 'text/html'.
  ENDMETHOD.


METHOD reject_form.
    DATA ls_proj_form           TYPE zmdg_proj_form.
    DATA lx_ca_form_exception   TYPE REF TO zcx_ca_form_exceptions.
    DATA lv_objectname          TYPE string.
    DATA ls_email_value         TYPE zmdg_s_proj_email.

* Call shared workflow class.
    lv_objectname = ls_proj_form-projectname.

    CALL METHOD clear_value.    "Clear value if the condition doesn't match

    currency_convert_in(
      exporting
        iv_currency = gs_proj_form-capex_req_curr
      changing
        cv_amount = gs_proj_form-capex_req_amount
    ).

* Update Proj Form
    MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.
    ls_proj_form-comments = wa_comments-comments.

    CALL METHOD populate_field_email
      EXPORTING
        ip_form        = ls_proj_form
      IMPORTING
        io_email_value = ls_email_value.

    TRY.
        zcl_nd_ca_mdg_workflow=>reject_form(
          EXPORTING
            iv_form_name           = gc_form_name
            iv_form_version        = gc_form_ver
            iv_form_guid           = gs_formdetails-form_guid
            iv_step_guid           = gs_stepdetail-step_guid
            iv_email_object_name   = lv_objectname
            iv_comments            = ls_proj_form-comments
            iv_proj_req_fields     = ls_email_value
          IMPORTING
            es_form_detail         = gs_formdetails
            es_current_step_detail = gs_stepdetail ).

      CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
        wa_program_state-program_state   = 'E'.
        wa_program_state-program_message = lx_ca_form_exception->get_text( ).
        RETURN.
    ENDTRY.
* End of shared workflow class call.
    ls_proj_form-step_guid      = gs_stepdetail-step_guid.
    MODIFY zmdg_proj_form FROM ls_proj_form.

    COMMIT WORK.

    IF NOT gt_attachments[] IS INITIAL.
      save_attachments( ).
    ENDIF.

* <TR> Lock call off, shared class owned by other team (P-63)
*    zcl_nd_ca_utilities=>dequeue_form( gs_formdetails-form_guid ).

  ENDMETHOD.


METHOD reset_value.
    DATA lw_zca_appste TYPE zca_apprvr_attr.
    DATA lt_formfields TYPE STANDARD TABLE OF zca_fldgrp_flds.
    DATA lw_formfields TYPE zca_fldgrp_flds.

* Chk Form Status
    IF gs_stepdetail-appr_step EQ 'BPC' AND gs_stepdetail-step_status EQ 'COMPLETED' AND wa_url_parameters-mode NE 'EDIT'.
      EXIT.
    ELSE.
* Reset Value based on approval step
      SELECT SINGLE * INTO lw_zca_appste FROM zca_apprvr_attr WHERE form_name = gs_formdetails-form_name AND
                                                                    form_ver = gs_formdetails-form_ver   AND
                                                                    appr_step = gs_formdetails-appr_step.

      IF sy-subrc EQ 0 AND lw_zca_appste-fldgrp_id NE 'PROJ_FLGRP_0001'. " Don't reset any value for requester field group
        SELECT * FROM zca_fldgrp_flds INTO TABLE lt_formfields WHERE form_name = gs_formdetails-form_name AND
                                                                     form_ver  = gs_formdetails-form_ver  AND
                                                                     fldgrp_id = lw_zca_appste-fldgrp_id  AND
                                                                     editable = 'X'.
        IF sy-subrc EQ 0.
          LOOP AT lt_formfields INTO lw_formfields.
            ASSIGN COMPONENT lw_formfields-field_name OF STRUCTURE gs_proj_form TO FIELD-SYMBOL(<fs>).
            IF <fs> IS ASSIGNED.
              <fs> = lw_formfields-def_value. " Get default value
            ENDIF.
          ENDLOOP.
        ENDIF.
      ENDIF.
    ENDIF.
  ENDMETHOD.


METHOD resubmit_form.

    DATA ls_proj_form         TYPE zmdg_proj_form.
    DATA lx_ca_form_exception TYPE REF TO zcx_ca_form_exceptions.
    DATA lv_objectname        TYPE string.
    DATA ls_email_value       TYPE zmdg_s_proj_email.

    CALL METHOD clear_value.    "Clear value if the condition doesn't match

* Call shared workflow class to Resubmit form

    lv_objectname      = gs_proj_form-projectname.

    CALL METHOD clear_value.    "Clear value if the condition doesn't match

    currency_convert_in(
      exporting
        iv_currency = gs_proj_form-capex_req_curr
      changing
        cv_amount = gs_proj_form-capex_req_amount
    ).

**Update Ver based on region
    CASE gs_proj_form-processing_region.
      WHEN 'E'.
        gc_form_ver = '0002'.
      WHEN 'A'.
        gc_form_ver = '0003'.
      WHEN OTHERS.
        gc_form_ver = '0001'.
    ENDCASE.

* Update Form Detail
    MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

    CALL METHOD populate_field_email
      EXPORTING
        ip_form        = ls_proj_form
      IMPORTING
        io_email_value = ls_email_value.

    TRY.
        zcl_nd_ca_mdg_workflow=>resubmit_form(
          EXPORTING
            iv_form_name           = gc_form_name    " MDG - Form Name
            iv_form_version        = gc_form_ver     " MDG - Form Version
            iv_form_guid           = gs_formdetails-form_guid    " UUID in character form
            iv_step_guid           = gs_stepdetail-step_guid    " UUID in character form
            iv_email_object_name   = lv_objectname
            iv_proj_req_fields     = ls_email_value
          IMPORTING
             es_form_detail        = gs_formdetails
             es_current_step_detail_resub =  DATA(gs_currrent_stepdetail_resub)
             es_next_step_detail   = DATA(gs_nextstepdetail) ).

      CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
        wa_program_state-program_state   = 'E'.
        wa_program_state-program_message = lx_ca_form_exception->get_text( ).
        RETURN.
    ENDTRY.
* End of shared workflow class call.
* Update Form Detail
* Update Additional Field

* 1 - Profit Center
    SELECT SINGLE prctr INTO ls_proj_form-profit_center
      FROM csks
      WHERE kokrs = 'DCI'
      AND   bukrs = ls_proj_form-company_code
      AND   kostl = ls_proj_form-kostl
      AND   datbi GE sy-datum
      AND   datab LE sy-datum.

    IF sy-subrc NE 0.
      CLEAR ls_proj_form-profit_center.
    ENDIF.

* D.Rempe - not for S4 project request.
** Update Multiple Company Code
** Check the condition before create multiple company code
*    CLEAR ls_proj_form-additional_comp_code.
*    CLEAR ls_proj_form-more_addi_compcode.
*
*    LOOP AT gt_additional_ccode INTO gs_multipleccode.
*      CONCATENATE gs_multipleccode-comp_code gs_multipleccode-kostl_code INTO DATA(lv_multiplecc) SEPARATED BY '/'.     " CompanyCode + Cost Center
*      IF sy-tabix EQ 1.
*        ls_proj_form-additional_comp_code = lv_multiplecc.
*      ELSE.
*        CONCATENATE ls_proj_form-additional_comp_code lv_multiplecc INTO ls_proj_form-additional_comp_code SEPARATED BY ','.
*      ENDIF.
*
*      IF gs_multipleccode-status EQ 'sap-icon://add-document'.
*        CONCATENATE gs_multipleccode-comp_code gs_multipleccode-kostl_code INTO DATA(lv_moreccode) SEPARATED BY '/'.
*        IF ls_proj_form-more_addi_compcode IS INITIAL.
*          ls_proj_form-more_addi_compcode = lv_moreccode.
*        ELSE.
*          CONCATENATE ls_proj_form-more_addi_compcode lv_moreccode INTO ls_proj_form-more_addi_compcode SEPARATED BY ','.
*        ENDIF.
*      ENDIF.
*    ENDLOOP.
*
*    IF ls_proj_form-cls EQ 'Y' AND ls_proj_form-itl EQ 'Y' AND ls_proj_form-project_type EQ '1'.
*      CLEAR ls_proj_form-additional_comp_code.
*    ENDIF.

    ls_proj_form-step_guid      = gs_currrent_stepdetail_resub-step_guid.
    MODIFY zmdg_proj_form FROM ls_proj_form.
    COMMIT WORK.

* Create duplicate record for STARTED Step Status
    IF gs_nextstepdetail-step_guid IS NOT INITIAL.
      CLEAR ls_proj_form-comments.
      ls_proj_form-step_guid      = gs_nextstepdetail-step_guid.
      MODIFY zmdg_proj_form FROM ls_proj_form.
      COMMIT WORK.
    ENDIF.

    IF NOT gt_attachments[] IS INITIAL.
      save_attachments( ).
    ENDIF.

* <TR> Lock call off, shared class owned by other team (P-63)
*    zcl_nd_ca_utilities=>dequeue_form( gs_formdetails-form_guid ).

  ENDMETHOD.


METHOD save_attachments.
    DATA: lr_utilities  TYPE REF TO zcl_nd_ca_utilities,
          lv_form_guid  TYPE sysuuid_c,
          lv_file_data  TYPE xstring,
          lv_error      TYPE flag,
          ls_zmdgattach TYPE zmdgattach.


    FIELD-SYMBOLS: <attachment> TYPE zca_form_attachment.

    lv_form_guid = gs_formdetails-form_guid.

    CREATE OBJECT lr_utilities.

    LOOP AT gt_attachments ASSIGNING <attachment>
        WHERE uuid IS INITIAL.
      CALL FUNCTION 'SCMS_BASE64_DECODE_STR'
        EXPORTING
          input  = <attachment>-file_data
        IMPORTING
          output = lv_file_data
        EXCEPTIONS
          OTHERS = 1.

      <attachment>-uuid = lr_utilities->add_attachment_to_form(
        iv_form_guid   = lv_form_guid
        iv_doc_name    = <attachment>-file_name
        iv_doc_content = lv_file_data
      ).

      IF <attachment>-uuid IS INITIAL.
        lv_error = 'X'.
        DELETE gt_attachments.
        CONTINUE.
      ELSE.
*     Don't pass attachment data back in the response.
        CLEAR <attachment>-file_data.
*     Save categorization
        CLEAR ls_zmdgattach.
        ls_zmdgattach-form_guid     = lv_form_guid.
        ls_zmdgattach-attachment_id = <attachment>-uuid.
        ls_zmdgattach-category      = <attachment>-category.
        MODIFY zmdgattach FROM ls_zmdgattach.
      ENDIF.
    ENDLOOP.

    IF NOT lv_error IS INITIAL.
*   Some attachments could not be uploaded.
      RAISE EXCEPTION TYPE zcx_ca_form_exceptions
        EXPORTING
          textid = zcx_ca_form_exceptions=>attachment_failure.
      RETURN.
    ENDIF.
  ENDMETHOD.


METHOD save_form.
    DATA ls_proj_form TYPE zmdg_proj_form.
    DATA lx_ca_form_exception TYPE REF TO zcx_ca_form_exceptions.

**Update Ver based on region
    CASE gs_proj_form-processing_region.
      WHEN 'E'.
        gc_form_ver = '0002'.
      WHEN 'A'.
        gc_form_ver = '0003'.
      WHEN OTHERS.
        gc_form_ver = '0001'.
    ENDCASE.

    currency_convert_in(
      exporting
        iv_currency = gs_proj_form-capex_req_curr
      changing
        cv_amount = gs_proj_form-capex_req_amount
    ).

* Call shared workflow class.
    TRY.
        zcl_nd_ca_mdg_workflow=>save_draft(
          EXPORTING
            iv_form_name    = gc_form_name
            iv_form_version = gc_form_ver
            iv_form_guid    = gs_formdetails-form_guid
            iv_step_guid    = gs_stepdetail-step_guid
          IMPORTING
            es_form_detail  = gs_formdetails
            es_step_detail  = gs_stepdetail
        ).
      CATCH zcx_ca_form_exceptions INTO lx_ca_form_exception.
    ENDTRY.

* Update Form Detail
    MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

* D.Rempe - not for S4 project creation.
** Update Multiple Company Code
*    LOOP AT gt_additional_ccode INTO gs_multipleccode WHERE status NE 'sap-icon://add-document'.
*      CONCATENATE gs_multipleccode-comp_code gs_multipleccode-kostl_code INTO DATA(lv_multiplecc) SEPARATED BY '/'.     " CompanyCode + Cost Center
*
*      IF sy-tabix EQ 1.
*        ls_proj_form-additional_comp_code = lv_multiplecc.
*      ELSE.
*        CONCATENATE ls_proj_form-additional_comp_code lv_multiplecc INTO ls_proj_form-additional_comp_code SEPARATED BY ','.
*      ENDIF.
*    ENDLOOP.
*
*    IF ls_proj_form-cls EQ 'Y' AND ls_proj_form-itl EQ 'Y' AND ls_proj_form-project_type EQ '1'.
*      CLEAR ls_proj_form-additional_comp_code.
*    ENDIF.

    ls_proj_form-step_guid  = gs_stepdetail-step_guid.
    MODIFY zmdg_proj_form FROM ls_proj_form.
    IF sy-subrc NE 0.
    ENDIF.

    IF NOT gt_attachments[] IS INITIAL.
      save_attachments( ).
    ENDIF.
* End of shared workflow class call.

  ENDMETHOD.


METHOD search_prev_cap_proj_id.
    DATA wa_agent_list TYPE ty_agent_list .

    TYPES: BEGIN OF ty_adrp,
             persnumber TYPE adrp-persnumber,
             name_text  TYPE adrp-name_text,
           END OF ty_adrp.

    DATA: it_adrp  TYPE STANDARD TABLE OF ty_adrp,
          it_usr21 TYPE STANDARD TABLE OF usr21,
          wa_usr21 TYPE usr21,
          wa_adrp  TYPE ty_adrp.

    DATA: ra_name TYPE RANGE OF adrp-mc_namefir,
          wa_name LIKE LINE OF ra_name.


*--------------------------------------------------------------------*
* GET DATA
*--------------------------------------------------------------------*

    CHECK ajax_value IS NOT INITIAL.

* LastName
    wa_name-sign   = 'I'.
    wa_name-option = 'CP'.

    CONCATENATE '*'
                ajax_value
                '*'
                INTO wa_name-low.

    TRANSLATE wa_name-low TO UPPER CASE.
    APPEND wa_name TO ra_name.

* Get ADRP
    SELECT persnumber name_text
           FROM adrp
           INTO TABLE it_adrp
           WHERE mc_namefir IN ra_name
              OR mc_namelas IN ra_name
             AND pers_group EQ 'BC01'
             AND date_from  LE sy-datum
             AND date_to    GE sy-datum.

* Any hit
    CHECK sy-subrc EQ 0.

* Get USR21
    SELECT *
           FROM usr21
           INTO TABLE it_usr21
           FOR ALL ENTRIES IN it_adrp
           WHERE persnumber EQ it_adrp-persnumber.

* Sorting
    SORT it_usr21 BY persnumber.


*--------------------------------------------------------------------*
* BUILD DATA
*--------------------------------------------------------------------*
    LOOP AT it_adrp INTO wa_adrp.
      READ TABLE it_usr21 INTO wa_usr21 WITH KEY persnumber = wa_adrp-persnumber BINARY SEARCH.

      CHECK sy-subrc EQ 0.

      wa_agent_list-otype = 'U'.
      wa_agent_list-objid = wa_usr21-bname.
      wa_agent_list-text  = wa_adrp-name_text.
      APPEND wa_agent_list TO gt_agent_list.
    ENDLOOP.

* Sorting
    SORT gt_agent_list BY text.
    CLEAR wa_agent_list.

    INSERT wa_agent_list INTO gt_agent_list INDEX 1.

  ENDMETHOD.


METHOD search_prev_itl_proj_id.
    DATA wa_agent_list TYPE ty_agent_list .

    TYPES: BEGIN OF ty_adrp,
             persnumber TYPE adrp-persnumber,
             name_text  TYPE adrp-name_text,
           END OF ty_adrp.

    DATA: it_adrp  TYPE STANDARD TABLE OF ty_adrp,
          it_usr21 TYPE STANDARD TABLE OF usr21,
          wa_usr21 TYPE usr21,
          wa_adrp  TYPE ty_adrp.

    DATA: ra_name TYPE RANGE OF adrp-mc_namefir,
          wa_name LIKE LINE OF ra_name.


*--------------------------------------------------------------------*
* GET DATA
*--------------------------------------------------------------------*

    CHECK ajax_value IS NOT INITIAL.

* LastName
    wa_name-sign   = 'I'.
    wa_name-option = 'CP'.

    CONCATENATE '*'
                ajax_value
                '*'
                INTO wa_name-low.

    TRANSLATE wa_name-low TO UPPER CASE.
    APPEND wa_name TO ra_name.

* Get ADRP
    SELECT persnumber name_text
           FROM adrp
           INTO TABLE it_adrp
           WHERE mc_namefir IN ra_name
              OR mc_namelas IN ra_name
             AND pers_group EQ 'BC01'
             AND date_from  LE sy-datum
             AND date_to    GE sy-datum.

* Any hit
    CHECK sy-subrc EQ 0.

* Get USR21
    SELECT *
           FROM usr21
           INTO TABLE it_usr21
           FOR ALL ENTRIES IN it_adrp
           WHERE persnumber EQ it_adrp-persnumber.

* Sorting
    SORT it_usr21 BY persnumber.


*--------------------------------------------------------------------*
* BUILD DATA
*--------------------------------------------------------------------*
    LOOP AT it_adrp INTO wa_adrp.
      READ TABLE it_usr21 INTO wa_usr21 WITH KEY persnumber = wa_adrp-persnumber BINARY SEARCH.

      CHECK sy-subrc EQ 0.

      wa_agent_list-otype = 'U'.
      wa_agent_list-objid = wa_usr21-bname.
      wa_agent_list-text  = wa_adrp-name_text.
      APPEND wa_agent_list TO gt_agent_list.
    ENDLOOP.

* Sorting
    SORT gt_agent_list BY text.
    CLEAR wa_agent_list.

    INSERT wa_agent_list INTO gt_agent_list INDEX 1.

  ENDMETHOD.


METHOD set_button_visibility.
    DATA lt_dfies TYPE dfies_tab.
    TYPES : BEGIN OF ty_agentid,
              sign   TYPE char1,
              option TYPE char2,
              low    TYPE zform_appragent,
              high   TYPE zform_appragent.
    TYPES : END OF ty_agentid.

    DATA lv_myrequest   TYPE boole_d.
    DATA lv_initiate_by TYPE syuname.

* Step 1
* Disable All button and enable based on role and approval step
    CALL FUNCTION 'DDIF_FIELDINFO_GET'
      EXPORTING
        tabname   = 'ZMDG_S_NAD_ORDER_BUTTONS'
      TABLES
        dfies_tab = lt_dfies.

    LOOP AT lt_dfies INTO DATA(lw_dfies) WHERE fieldname NE 'FORM_GUID'.
      ASSIGN COMPONENT lw_dfies-fieldname OF STRUCTURE gs_proj_form TO FIELD-SYMBOL(<fs>).
      <fs> = gc_false.
    ENDLOOP.

* Check whether form is currently processed by other user
    CHECK is_form_locked IS NOT INITIAL.

    if is_form_locked = 'X'.
      gs_proj_form-can_attach = 'X'.
    endif.

* Check Form Status
    IF ( gs_formdetails-form_status EQ gc_formstatus_completed OR gs_formdetails-form_status EQ gc_formstatus_cancelled ) AND wa_url_parameters-mode NE 'EDIT'.
      EXIT.
    ENDIF.

* Update Form Intiated by
    IF gs_proj_form-requester_id IS NOT INITIAL.
      lv_initiate_by = gs_proj_form-requester_id.
    ELSE.
      lv_initiate_by = gs_formdetails-initiated_by.
    ENDIF.

* Read Approver List
    SELECT * FROM zca_apprvr_list INTO TABLE @DATA(lt_apprvr_list) WHERE form_name = @gc_form_name AND form_ver = @gc_form_ver.


    IF gs_formdetails-form_guid IS NOT INITIAL.
      gs_proj_form-form_guid = gs_formdetails-form_guid.
      DATA(lw_apprvr_list) = lt_apprvr_list[ appr_step = gs_formdetails-appr_step ].

      IF lv_initiate_by EQ sy-uname AND lw_apprvr_list-appr_seqno EQ '0001'.
        lv_myrequest = 'X'.
      ELSE.
        lv_myrequest = ''.
      ENDIF.
    ELSE.
      lv_myrequest = 'X'.
    ENDIF.

* #1 Check Authorization for WITHDRAWN/Close Button**********************************************************************
    IF gs_formdetails-form_status EQ gc_formstatus_rejected AND lv_initiate_by EQ sy-uname AND wa_url_parameters-mode NE 'DISPLAY' AND
               ( gs_formdetails-form_status = 'REJECTED' AND gs_proj_form-request_from NE 'U' AND wa_url_parameters-from NE 'search').
      gs_proj_form-withdrawn = gc_true.
      gs_proj_form-save      = gc_true.
      gs_proj_form-resubmit  = gc_true.
      EXIT.
    ELSEIF gs_formdetails-form_status EQ gc_formstatus_rejected AND lv_initiate_by EQ sy-uname AND wa_url_parameters-mode NE 'DISPLAY' AND
               ( gs_formdetails-form_status = 'REJECTED' AND gs_proj_form-request_from EQ 'U' AND wa_url_parameters-mode NE 'EDIT').
      gs_proj_form-withdrawn = gc_true.
      EXIT.
    ELSEIF ( gs_formdetails-form_status EQ gc_formstatus_rejected AND lv_initiate_by NE sy-uname AND wa_url_parameters-mode NE 'EDIT' ) OR wa_url_parameters-mode EQ 'DISPLAY'.
      EXIT.
    ENDIF.

* #2 Check Authorization for Create Button**********************************************************************
    IF lv_myrequest EQ 'X' AND wa_url_parameters-mode NE 'EDIT'.
      gs_proj_form-create = gc_true.
      gs_proj_form-save = gc_true.
*      EXIT.   "Removed so users could see delete and change buttons as per ENHC0017317
    ELSEIF wa_url_parameters-mode EQ 'EDIT' AND ( gs_formdetails-appr_step EQ 'BUDGET_MANAGER' OR gs_formdetails-appr_step IS INITIAL ).
      gs_proj_form-change = gc_true.
      EXIT.
    ENDIF.

* #3 Check Authorization for DELETE DRAFT Button**********************************************************************
    IF gs_formdetails-form_guid IS NOT INITIAL AND gs_formdetails-form_status = gc_formstatus_draft AND lv_initiate_by EQ sy-uname.
      gs_proj_form-delete = gc_true.
    ENDIF.

** #4 Check Authorization to enable SUBMIT Button**********************************************************************
    IF lv_myrequest EQ ''.
      TRY.
          DATA(lw_agent) = gt_zca_agent_list[ agent_id = sy-uname ].
          gs_proj_form-submit = gc_true.
        CATCH cx_sy_itab_line_not_found.
      ENDTRY.
    ENDIF.

** #5 Check Authorization to enable Reject Button**********************************************************************
    IF lv_myrequest EQ '' AND lw_apprvr_list-reject_ind = 'X'.
      TRY.
          DATA(lw_agent1) = gt_zca_agent_list[ agent_id = sy-uname ].
          gs_proj_form-reject = gc_true.
        CATCH cx_sy_itab_line_not_found.
      ENDTRY.
    ENDIF.

** #5 Check Authorization and error message to enable submit with error Button**********************************************************************
* Check Is there any error while submitting multiple company code
    READ TABLE gt_orderdetails INTO DATA(gw_orddetail) WITH KEY is_error = gc_true.
    IF sy-subrc EQ 0 AND lv_myrequest EQ '' AND lw_apprvr_list-reject_ind = 'X' AND gs_proj_form-proj_flgrp_0003 EQ 'true'.
      TRY.
          lw_agent = gt_zca_agent_list[ agent_id = sy-uname ].
          gs_proj_form-submitwth_err = gc_true.
        CATCH cx_sy_itab_line_not_found.
      ENDTRY.
    ENDIF.
  ENDMETHOD.


METHOD set_field_cond_visible.
** Cond #1: Hide Asset Class for project type - CAPEX(Upload Company)
    IF gs_proj_form-project_type EQ '4'.
      CLEAR gs_proj_form-asset_class.
      gs_proj_form-v_asset_class = gc_false.
      gs_proj_form-r_asset_class = gc_false.
    ENDIF.

* Don't display Authorized by and Authorized Date for the old form
    IF gs_proj_form-auth_by_id IS NOT INITIAL.
      gs_proj_form-r_auth_by_id = gc_true.
      gs_proj_form-r_auth_by_date = gc_true.
    ELSEIF wa_url_parameters-mode EQ '' AND
            gs_formdetails-appr_step = 'BUDGET_MANAGER'.
      gs_proj_form-r_auth_by_id = gc_true.
      gs_proj_form-r_auth_by_date = gc_true.
    ELSE.
      gs_proj_form-r_auth_by_id = gc_false.
      gs_proj_form-r_auth_by_date = gc_false.
    ENDIF.
  ENDMETHOD.


METHOD set_field_default_value.
    zcl_nd_ca_utilities=>get_information_from_user(
      IMPORTING
        es_user_info = DATA(lw_uname) ).

    gs_proj_form-requester_id   = sy-uname.
    gs_proj_form-requester_name = lw_uname-name.
    gs_proj_form-requester_title = lw_uname-title.
    gs_proj_form-requester_email = lw_uname-email.

** Default Processing Region to US
    gs_proj_form-processing_region = 'U'.
    gs_proj_form-prev_proj_code = ''.

  ENDMETHOD.


METHOD set_field_mandatory.

    DATA lr_data_spec       TYPE REF TO cl_abap_structdescr.
    DATA lt_components      TYPE abap_component_tab.
    DATA ls_component       TYPE abap_componentdescr.

    DATA lt_fldgrplist      TYPE abap_component_tab.
    DATA ls_fldgrplist      TYPE abap_componentdescr.

    DATA lv_fieldname       TYPE string.

    FIELD-SYMBOLS: <field> TYPE string.

    lr_data_spec ?= cl_abap_structdescr=>describe_by_name( 'ZMDG_PROJ_FORM_S_READ_ONLY' ).
    lt_components = lr_data_spec->get_components( ).

    lr_data_spec ?= cl_abap_structdescr=>describe_by_name( 'ZMDG_S_PROJ_FLGRP_VISI' ).
    lt_fldgrplist = lr_data_spec->get_components( ).

* Step 1: Set all field as Non-Mandatory Field********************************************
    LOOP AT lt_components INTO ls_component.
      IF ls_component-name(2) = 'R_'.
        ASSIGN COMPONENT ls_component-name OF STRUCTURE gs_proj_form TO <field>.
        IF sy-subrc = 0.
          <field> = gc_false.
        ENDIF.
      ENDIF.
    ENDLOOP.
* Set mandatory only for new project request
    "    IF wa_url_parameters-mode EQ 'EDIT' AND gs_formdetails-appr_step NE 'BUDGET_MANAGER'.

* Get the list of Field Group to show the mandatory field
    LOOP AT lt_fldgrplist INTO ls_fldgrplist.
      ASSIGN COMPONENT ls_fldgrplist-name OF STRUCTURE gs_proj_form TO <field>.
      gs_fieldgroup-sign   = zhrc_include.
      gs_fieldgroup-option = zhrc_equal.
      gs_fieldgroup-low    = ls_fldgrplist-name.
      APPEND gs_fieldgroup TO gt_fieldgroup.
    ENDLOOP.

*Get Mandatory Field List********************************************
    SELECT * FROM zca_fldgrp_flds INTO TABLE @DATA(lt_mandatory_fields) WHERE form_name = @gc_form_name AND form_ver = @gc_form_ver AND mandatory EQ @abap_true.

    IF gt_fieldgroup IS NOT INITIAL.
      DELETE lt_mandatory_fields WHERE fldgrp_id NOT IN gt_fieldgroup.
    ENDIF.

    LOOP AT lt_mandatory_fields INTO DATA(ls_mandatory_fields).
      CONCATENATE 'R_' ls_mandatory_fields-field_name INTO lv_fieldname.
      ASSIGN COMPONENT lv_fieldname OF STRUCTURE gs_proj_form TO <field>.
      IF sy-subrc EQ 0.
        <field> = gc_true.
      ENDIF.
    ENDLOOP.
*    ENDIF.
  ENDMETHOD.


METHOD set_field_read_only.

    DATA lr_data_spec       TYPE REF TO cl_abap_structdescr.
    DATA lt_components      TYPE abap_component_tab.
    DATA ls_component       TYPE abap_componentdescr.
    DATA lv_fieldname       TYPE string.

    FIELD-SYMBOLS: <field> TYPE string.

    lr_data_spec ?= cl_abap_structdescr=>describe_by_name( 'ZMDG_PROJ_FORM_S_EDITABLE' ).
    lt_components = lr_data_spec->get_components( ).

* Step 1: Set all field Read Only - False********************************************
    LOOP AT lt_components INTO ls_component.
      IF ls_component-name(2) = 'E_'.
        ASSIGN COMPONENT ls_component-name OF STRUCTURE gs_proj_form TO <field>.
        IF sy-subrc = 0.
          <field> = gc_false.
        ENDIF.
      ENDIF.
    ENDLOOP.

*Overwrite Editable Fields********************************************
    SELECT * FROM zca_fldgrp_flds INTO TABLE @DATA(lt_readonly_fields) WHERE form_name = @gc_form_name AND form_ver = @gc_form_ver AND editable EQ @abap_true.
    LOOP AT lt_readonly_fields INTO DATA(ls_readonly_fields).
      CONCATENATE 'E_' ls_readonly_fields-field_name INTO lv_fieldname.
      ASSIGN COMPONENT lv_fieldname OF STRUCTURE gs_proj_form TO <field>.
      IF sy-subrc EQ 0.
        <field> = gc_true.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


METHOD set_field_visible.

    DATA lr_data_spec       TYPE REF TO cl_abap_structdescr.
    DATA lt_components      TYPE abap_component_tab.
    DATA ls_component       TYPE abap_componentdescr.

    DATA lt_fldgrplist      TYPE abap_component_tab.
    DATA ls_fldgrplist      TYPE abap_componentdescr.

    DATA lv_fieldname       TYPE string.

    FIELD-SYMBOLS: <field> TYPE string.

    lr_data_spec ?= cl_abap_structdescr=>describe_by_name( 'ZMDG_PROJ_FORM_S_VISIBLE' ).
    lt_components = lr_data_spec->get_components( ).

    lr_data_spec ?= cl_abap_structdescr=>describe_by_name( 'ZMDG_S_PROJ_FLGRP_VISI' ).
    lt_fldgrplist = lr_data_spec->get_components( ).

* Step 1: Set all field Visible********************************************
    LOOP AT lt_components INTO ls_component.
      IF ls_component-name(2) = 'V_'.
        ASSIGN COMPONENT ls_component-name OF STRUCTURE gs_proj_form TO <field>.
        IF sy-subrc = 0.
          <field> = gc_true.
        ENDIF.
      ENDIF.
    ENDLOOP.

*Get Field List************************************************************
    SELECT * FROM zca_fldgrp_flds INTO TABLE @DATA(lt_visible_fields) WHERE form_name = @gc_form_name AND form_ver = @gc_form_ver AND visible EQ @abap_false.
    IF sy-subrc EQ 0.
      LOOP AT lt_fldgrplist INTO ls_fldgrplist.
        ASSIGN COMPONENT ls_fldgrplist-name OF STRUCTURE gs_proj_form TO <field>.
        IF sy-subrc = 0 AND <field> = gc_true.
          gs_fieldgroup-sign   = zhrc_include.
          gs_fieldgroup-option = zhrc_equal.
          gs_fieldgroup-low    = ls_fldgrplist-name.
          APPEND gs_fieldgroup TO gt_fieldgroup.
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF gt_fieldgroup IS NOT INITIAL.
      DELETE lt_visible_fields WHERE fldgrp_id NOT IN gt_fieldgroup.
    ENDIF.

    LOOP AT lt_visible_fields INTO DATA(ls_mandatory_fields).
      CONCATENATE 'V_' ls_mandatory_fields-field_name INTO lv_fieldname.
      ASSIGN COMPONENT lv_fieldname OF STRUCTURE gs_proj_form TO <field>.
      IF sy-subrc EQ 0.
        <field> = gc_false.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.


METHOD set_fldgrp_visibility.

  TYPES : BEGIN OF ty_agentid,
            sign   TYPE char1,
            option TYPE char2,
            low    TYPE zform_appragent,
            high   TYPE zform_appragent.
  TYPES : END OF ty_agentid.

* Get the Preferred First and last Name
  DATA lt_dfies       TYPE dfies_tab.
  DATA lv_myrequest   TYPE boole_d.
  DATA lv_initiate_by TYPE syuname.
  DATA ls_formcompleted TYPE boole_d.
  DATA ls_possible_agent TYPE  boole_d.

* Chk Form Status
  IF gs_stepdetail-appr_step EQ 'BPC' AND gs_stepdetail-step_status EQ 'COMPLETED' AND wa_url_parameters-mode NE 'EDIT'.
    ls_formcompleted = 'X'.
  ENDIF.

*Field Group Visibility***********************************************
  CALL FUNCTION 'DDIF_FIELDINFO_GET'
    EXPORTING
      tabname   = 'ZMDG_S_PROJ_FLGRP_VISI'
    TABLES
      dfies_tab = lt_dfies.

  LOOP AT lt_dfies INTO DATA(lw_dfies).
    ASSIGN COMPONENT lw_dfies-fieldname OF STRUCTURE gs_proj_form TO FIELD-SYMBOL(<fs1>).
    <fs1> = 'false'.
  ENDLOOP.

*Set Expand/Collapse********************************************************
  CALL FUNCTION 'DDIF_FIELDINFO_GET'
    EXPORTING
      tabname   = 'ZMDG_S_PROJ_FLGRP_EXPAND'
    TABLES
      dfies_tab = lt_dfies.

  LOOP AT lt_dfies INTO lw_dfies.
    ASSIGN COMPONENT lw_dfies-fieldname OF STRUCTURE gs_proj_form TO FIELD-SYMBOL(<fs2>).

    IF ls_formcompleted NE 'X'.
      <fs2> = gc_collapse.
    ELSE.
      <fs2> = gc_expand.
    ENDIF.
  ENDLOOP.

* Update Form Intiated by
  IF gs_proj_form-requester_id IS NOT INITIAL.
    lv_initiate_by = gs_proj_form-requester_id.
  ELSE.
    lv_initiate_by = gs_formdetails-initiated_by.
  ENDIF.

* Check whether form is currently processed by other user
  IF is_form_locked IS NOT INITIAL AND wa_url_parameters-mode IS INITIAL.
    EXIT.
  ENDIF.

*******************Check Form Status *********************************
  IF gs_formdetails-form_status NE gc_formstatus_cancelled AND
     gs_formdetails-form_status NE gc_formstatus_completed AND
     gs_formdetails-form_status NE space AND
     wa_url_parameters-mode IS INITIAL.
    EXIT.
  ENDIF.

*******************Check Reject *********************************
  IF gs_formdetails-form_status EQ gc_formstatus_rejected AND lv_initiate_by NE sy-uname AND wa_url_parameters-from NE 'search'.
    EXIT.
  ENDIF.


*******************Check Form Status - Completed *************************
  IF ls_formcompleted EQ 'X'.
    EXIT.
  ENDIF.

*******************Enable SECTION to Edit****************************
  IF ( gs_formdetails-workcenter_id EQ '00000000' AND gs_formdetails-agent_id_list IS INITIAL ) OR
     ( gs_formdetails-form_status   EQ gc_formstatus_rejected ).
    SELECT SINGLE * FROM zca_apprvr_list INTO @DATA(lw_apprvr_list) WHERE form_name = @gc_form_name AND
                                                                          form_ver  = @gc_form_ver  AND
                                                                          appr_seqno = '0001'.           " First Step
    IF sy-subrc NE 0.
      EXIT.
    ENDIF.

    lv_myrequest = 'X'.
    ls_possible_agent = 'X'.
    gs_formdetails-appr_step = lw_apprvr_list-appr_step.
  ELSE.
*******************Check SY-UNAME exit in Possible Agent List before proceed****************************
    TRY.
        DATA(lw_possible_agent) = gt_zca_agent_list[ agent_id = sy-uname ].
        ls_possible_agent = 'X'.
      CATCH cx_sy_itab_line_not_found.
        CLEAR ls_possible_agent.
    ENDTRY.
  ENDIF.

  IF gs_formdetails-appr_step IS NOT INITIAL.
    SELECT * FROM zca_apprvr_attr INTO TABLE @DATA(lt_apprvr_attr) WHERE form_name = @gc_form_name AND
                                                                         form_ver  = @gc_form_ver  AND
                                                                         appr_step = @gs_formdetails-appr_step.
    IF sy-subrc NE 0.
      EXIT.
    ENDIF.

    LOOP AT lt_apprvr_attr INTO DATA(lw_apprv_attr).
      ASSIGN COMPONENT lw_apprv_attr-fldgrp_id OF STRUCTURE gs_proj_form TO FIELD-SYMBOL(<fs3>).
      IF sy-subrc EQ 0 AND ls_possible_agent EQ 'X'.
        <fs3> = 'true'.
      ENDIF.

*       D.Rempe - alllow RTR and FP&A to edit submitted forms.
      IF wa_url_parameters-mode = 'CHANGE'
          AND lw_apprv_attr-fldgrp_id = 'PROJ_FLGRP_0002' OR lw_apprv_attr-fldgrp_id = 'PROJ_FLGRP_0003'
          AND ls_possible_agent = 'X'.
        gs_proj_form-proj_flgrp_0001 = 'true'.
      ENDIF.

      IF <fs3> IS ASSIGNED AND gs_formdetails-form_status = 'REJECTED' AND gs_proj_form-request_from EQ 'U' AND
         ( lw_apprv_attr-fldgrp_id EQ 'PROJ_FLGRP_0001' OR lw_apprv_attr-fldgrp_id EQ 'PROJ_FLGRP_0005' ).
        <fs3> = 'false'.

        ASSIGN COMPONENT 'PROJ_FLGRP_0005' OF STRUCTURE gs_proj_form TO <fs3>.
        IF sy-subrc EQ 0.
          <fs3> = 'false'.
        ENDIF.

      ENDIF.

      CONCATENATE lw_apprv_attr-fldgrp_id 'MOD' INTO DATA(lv_fieldname) SEPARATED BY '_'.
      ASSIGN COMPONENT lv_fieldname OF STRUCTURE gs_proj_form TO <fs3>.
      IF sy-subrc EQ 0.
        <fs3> = gc_expand.  " For Section to EXPAND
      ENDIF.

      IF lw_apprv_attr-fldgrp_id EQ 'PROJ_FLGRP_0001'.
        CONCATENATE 'PROJ_FLGRP_0005' 'MOD' INTO lv_fieldname SEPARATED BY '_'.
        ASSIGN COMPONENT lv_fieldname OF STRUCTURE gs_proj_form TO <fs3>.
        IF sy-subrc EQ 0.
          <fs3> = gc_expand.
        ENDIF.
      ENDIF.

      IF wa_url_parameters-mode = 'EDIT' AND
       ( lw_apprv_attr-fldgrp_id EQ 'PROJ_FLGRP_0001' OR lw_apprv_attr-fldgrp_id EQ 'PROJ_FLGRP_0005' ).
        ASSIGN COMPONENT lw_apprv_attr-fldgrp_id OF STRUCTURE gs_proj_form TO <fs3>.
        IF sy-subrc EQ 0.
          <fs3> = 'false'.  " For Section to edit
        ENDIF.

        ASSIGN COMPONENT 'PROJ_FLGRP_0005' OF STRUCTURE gs_proj_form TO <fs3>.
        IF sy-subrc EQ 0." AND ls_possible_agent EQ 'X'.
          <fs3> = 'true'.  " For Section to edit
        ENDIF.

*        ELSEIF wa_url_parameters-mode = 'CHANGE' AND lw_apprv_attr-fldgrp_id EQ 'PROJ_FLGRP_0001' AND
*               ( gs_formdetails-form_status = 'REJECTED' AND gs_proj_form-request_from EQ 'U' ).
*
*          ASSIGN COMPONENT lw_apprv_attr-fldgrp_id OF STRUCTURE gs_proj_form TO <fs3>.
*          IF sy-subrc EQ 0  AND ls_possible_agent EQ 'X'.
*            <fs3> = 'true'.  " For Section to edit
*          ENDIF.
*
*          ASSIGN COMPONENT 'PROJ_FLGRP_0005' OF STRUCTURE gs_proj_form TO <fs3>.
*          IF sy-subrc EQ 0  AND ls_possible_agent EQ 'X'.
*            <fs3> = 'true'.  " For Section to edit
*          ENDIF.
      ELSEIF wa_url_parameters-mode = 'DISPLAY'.
        ASSIGN COMPONENT lw_apprv_attr-fldgrp_id OF STRUCTURE gs_proj_form TO <fs3>.
        IF sy-subrc EQ 0.
          <fs3> = 'false'.  " For Section to edit
        ENDIF.

        ASSIGN COMPONENT 'PROJ_FLGRP_0005' OF STRUCTURE gs_proj_form TO <fs3>.
        IF sy-subrc EQ 0.
          <fs3> = 'false'.  " For Section to edit
        ENDIF.
      ENDIF.

    ENDLOOP.

  ENDIF.

*   D.Rempe - don't allow completed forms to be edited.
  IF gs_formdetails-form_status = 'COMPLETED'.
    gs_proj_form-proj_flgrp_0001 = 'false'.
    gs_proj_form-proj_flgrp_0002 = 'false'.
    gs_proj_form-proj_flgrp_0003 = 'false'.
    gs_proj_form-proj_flgrp_0004 = 'false'.
    gs_proj_form-proj_flgrp_0005 = 'false'.
    gs_proj_form-can_attach = ''.
  ELSEIF gs_formdetails-form_status = 'DRAFT'.   " E. Mukusha - allow edit in DRAFT
    gs_proj_form-proj_flgrp_0001 = 'true'.
    gs_proj_form-proj_flgrp_0002 = 'false'.
    gs_proj_form-proj_flgrp_0003 = 'false'.
    gs_proj_form-proj_flgrp_0004 = 'false'.
    gs_proj_form-proj_flgrp_0005 = 'true'.
    gs_proj_form-can_attach = abap_true.
  ENDIF.
ENDMETHOD.


METHOD set_header.
    DATA: lv_date TYPE sy-datum.
    DATA: lv_time TYPE sy-uzeit.
    DATA: lv_date_c(10) TYPE c.
    DATA: lv_time_c(10) TYPE c.
    DATA: lw_agent_list TYPE zca_s_nad_gl_agent.

    IF gs_formdetails-form_guid IS NOT INITIAL AND NOT ( wa_url_parameters-mode EQ 'EDIT' AND wa_url_parameters-from = 'search' AND gs_formdetails-appr_step = 'BPC' ).
      MOVE-CORRESPONDING gs_formdetails TO gs_formheader.
      MOVE gs_formdetails-latest_startdate    TO lv_date.
      MOVE gs_formdetails-latest_starttime    TO lv_time.
      gs_formdetails-initiated_by = gs_proj_form-requester_id.
    ELSE.
      gs_formdetails-initiated_by = sy-uname.
      lv_date                     = sy-datum.
      lv_time                     = sy-uzeit.
      gs_formheader-current_step  = 'Unsaved Draft'.
    ENDIF.

    WRITE lv_date     TO lv_date_c.                    " Format Date and Time
    WRITE lv_time     TO lv_time_c.
    MOVE  lv_date_c   TO gs_formheader-start_date.
    MOVE  lv_time_c   TO gs_formheader-start_time.

*Object Name**********************************************************
    IF gs_proj_form-projectname IS NOT INITIAL.
      gs_formheader-object_name = gs_proj_form-projectname.
    ELSE.
      gs_formheader-object_name = 'New project code request'.
    ENDIF.

*Get Approver Step Detail*********************************************************
    IF gs_formdetails-appr_step IS NOT INITIAL.
      SELECT SINGLE * FROM zca_apprvr_list INTO @DATA(lw_apprvr_list) WHERE form_name = @gc_form_name AND form_ver = @gc_form_ver AND appr_step  = @gs_formdetails-appr_step.
      IF sy-subrc EQ 0.
        gs_formheader-current_step = lw_apprvr_list-appr_desc.
      ENDIF.
    ENDIF.

*Current Agent List***************************************************
    IF gs_formdetails-agent_id_list IS NOT INITIAL.
      CLEAR lw_apprvr_list-workcenter_id.
    ENDIF.

    gt_zca_agent_list = zcl_nd_ca_mdg_workflow=>get_agents_of_approval_step(
      iv_form_guid     = gs_formdetails-form_guid
      iv_agent_id_list = gs_formdetails-agent_id_list
      iv_work_center   = lw_apprvr_list-workcenter_id
    ).

    LOOP AT gt_zca_agent_list INTO lw_agent_list.
      CASE sy-tabix.
        WHEN 1.
          gs_formheader-current_agent = lw_agent_list-agent_name.
        WHEN 2.
          CONCATENATE gs_formheader-current_agent lw_agent_list-agent_name INTO gs_formheader-current_agent SEPARATED BY ' / '.
        WHEN OTHERS.
          CONCATENATE gs_formheader-current_agent 'more' INTO gs_formheader-current_agent SEPARATED BY '...'.
          EXIT.
      ENDCASE.
    ENDLOOP.

*Requester ID*********************************************************
    CALL METHOD me->get_userdetail.
    gs_formheader-initiated_by = gs_employee_info-ename.

*Check Current Agent**************************************************
    IF gs_formheader-current_agent IS INITIAL.
      gs_formheader-current_agent = gs_employee_info-ename.
    ENDIF.

    IF gs_formdetails-form_status = gc_formstatus_completed.
      gs_formheader-current_step = 'Complete'.
      CLEAR gs_formheader-current_agent.
    ENDIF.

    IF gs_formdetails-form_status = gc_formstatus_cancelled.
      gs_formheader-current_step = 'Withdrawn'.
      CLEAR gs_formheader-current_agent.
    ENDIF.

    IF wa_url_parameters-mode EQ 'EDIT' AND wa_url_parameters-from = 'search' AND gs_formdetails-appr_step = 'BPC' .
      gs_formheader-current_step  = 'Unsaved Draft'.
      gs_formheader-current_agent = gs_employee_info-ename.
    ENDIF.

  ENDMETHOD.


METHOD set_multi_ccode.

    DATA: lt_ccodes TYPE TABLE OF  zmdg_prj_ccode.
    DATA: lw_ccode  TYPE zmdg_prj_ccode.

* Get list of company code - To include region in the multiple company code
    SELECT * INTO TABLE lt_ccodes FROM zmdg_prj_ccode.
    IF sy-subrc NE 0.
      REFRESH lt_ccodes.
    ENDIF.

* Populate Multiple Company Code
    SPLIT gs_proj_form-additional_comp_code AT ',' INTO TABLE DATA(lt_compcode).
    SPLIT gs_proj_form-more_addi_compcode   AT ',' INTO TABLE DATA(lt_more_compcode).

    LOOP AT lt_compcode INTO DATA(lw_multicompcode).
      SPLIT lw_multicompcode AT '/' INTO DATA(lv_companycode)
                                         DATA(lv_costcenter)
                                         DATA(lv_projcode)
                                         DATA(lv_internalorderno)
                                         DATA(lv_itl_projcode)
                                         DATA(lv_itl_order)
                                         DATA(lv_status)
                                         DATA(lv_cls_projcode)
                                         DATA(lv_cls_order).

* Get Company Code Text
      CONDENSE lv_companycode.
      CONDENSE lv_costcenter.

      CONCATENATE lv_companycode lv_costcenter INTO DATA(lv_concate_ccode) SEPARATED BY '/' .

      READ TABLE gt_all_comp_code INTO gs_comp_code WITH KEY value = lv_companycode.
      IF sy-subrc EQ 0.
        gs_multipleccode-comp_code = lv_companycode.
        gs_multipleccode-comp_text = gs_comp_code-text.
      ENDIF.

* Get Company Code Text
      IF lv_costcenter IS NOT INITIAL.
        SELECT SINGLE * FROM cskt INTO @DATA(lw_cskt) WHERE spras = 'E' AND kostl EQ @lv_costcenter.
        IF sy-subrc EQ 0.
          gs_multipleccode-kostl_code = lv_costcenter.
          gs_multipleccode-kostl_text = lw_cskt-ltext.
        ENDIF.
      ENDIF.

* Get Region
      READ TABLE lt_ccodes INTO lw_ccode WITH KEY company_code = lv_companycode.
      IF sy-subrc EQ 0.
        CASE lw_ccode-processing_region.
          WHEN 'U'.
            gs_multipleccode-region = 'US/LA'.
          WHEN 'E'.
            gs_multipleccode-region = 'Europe'.
          WHEN 'A'.
            gs_multipleccode-region = 'Asia'.
        ENDCASE.
      ELSE.
        CLEAR gs_multipleccode-region .
      ENDIF.

* Set delete function only when Order didn't get created
      IF lv_internalorderno IS INITIAL AND lv_itl_order IS INITIAL AND lv_cls_order IS INITIAL AND
gs_formdetails-appr_step = 'BUDGET_MANAGER' AND gs_formdetails-form_status NE gc_formstatus_completed AND wa_url_parameters-mode NE 'DISPLAY'.
        gs_multipleccode-deletable = gc_true.
      ELSE.
        gs_multipleccode-deletable = gc_false.
      ENDIF.

* Update Status ICON
      READ TABLE lt_more_compcode INTO DATA(lw_more_compcode) WITH KEY table_line = lv_concate_ccode.
      IF sy-subrc EQ 0.
        gs_multipleccode-status    = 'sap-icon://document'.
        DELETE lt_more_compcode INDEX sy-tabix.
      ELSE.
        gs_multipleccode-status    = ''.
      ENDIF.

      APPEND gs_multipleccode TO gt_additional_ccode.
    ENDLOOP.

    IF lv_projcode IS NOT INITIAL.
      DELETE ADJACENT DUPLICATES FROM gt_additional_ccode COMPARING comp_code kostl_code.
    ENDIF.

* Include More Additional company code
    LOOP AT lt_more_compcode INTO lw_multicompcode.
      SPLIT lw_multicompcode AT '/' INTO lv_companycode
                                         lv_costcenter.

* Get Company Code Text
      CONDENSE lv_companycode.
      CONDENSE lv_costcenter.

      READ TABLE gt_all_comp_code INTO gs_comp_code WITH KEY value = lv_companycode.
      IF sy-subrc EQ 0.
        gs_multipleccode-comp_code = lv_companycode.
        gs_multipleccode-comp_text = gs_comp_code-text.
      ENDIF.

* Get Company Code Text
      IF lv_costcenter IS NOT INITIAL.
        SELECT SINGLE * FROM cskt INTO lw_cskt WHERE spras = 'E' AND kostl EQ lv_costcenter.
        IF sy-subrc EQ 0.
          gs_multipleccode-kostl_code = lv_costcenter.
          gs_multipleccode-kostl_text = lw_cskt-ltext.
        ENDIF.
      ENDIF.

* Set delete function only when Order didn't get created
      IF lv_internalorderno IS INITIAL AND lv_itl_order IS INITIAL AND lv_cls_order IS INITIAL AND
gs_formdetails-appr_step = 'BUDGET_MANAGER' AND gs_formdetails-form_status NE gc_formstatus_completed AND wa_url_parameters-mode NE 'DISPLAY'.
        gs_multipleccode-deletable = gc_true.
      ELSE.
        gs_multipleccode-deletable = gc_false.
      ENDIF.

* Update Status ICON
      gs_multipleccode-status    = 'sap-icon://document'.

* Get Region
      READ TABLE lt_ccodes INTO lw_ccode WITH KEY company_code = lv_companycode.
      IF sy-subrc EQ 0.
        CASE lw_ccode-processing_region.
          WHEN 'U'.
            gs_multipleccode-region = 'US/LA'.
          WHEN 'E'.
            gs_multipleccode-region = 'Europe'.
          WHEN 'A'.
            gs_multipleccode-region = 'Asia'.
        ENDCASE.
      ELSE.
        CLEAR gs_multipleccode-region .
      ENDIF.

      APPEND gs_multipleccode TO gt_additional_ccode.
    ENDLOOP.

  ENDMETHOD.


METHOD submit_form.
    DATA ls_proj_form       TYPE zmdg_proj_form.
    DATA lv_objectname      TYPE string.

* Call shared workflow class to submit form
    DATA(lv_form_guid) = gs_formdetails-form_guid.
    DATA(lv_step_guid) = gs_stepdetail-step_guid.
    lv_objectname = gs_proj_form-projectname.

    CALL METHOD clear_value.    "Clear value if the condition doesn't match

  currency_convert_in(
    exporting
      iv_currency = gs_proj_form-capex_req_curr
    changing
      cv_amount = gs_proj_form-capex_req_amount
  ).

* Update Form Detail
    MOVE-CORRESPONDING gs_proj_form TO ls_proj_form.

**Update Ver based on region
    CASE gs_proj_form-processing_region.
      WHEN 'E'.
        gc_form_ver = '0002'.
      WHEN 'A'.
        gc_form_ver = '0003'.
      WHEN OTHERS.
        gc_form_ver = '0001'.
    ENDCASE.

    CALL METHOD populate_field_email
      EXPORTING
        ip_form        = ls_proj_form
      IMPORTING
        io_email_value = gs_email_value.

        zcl_nd_ca_mdg_workflow=>approve_form(
          EXPORTING
            iv_form_name           = gc_form_name
            iv_form_version        = gc_form_ver
            iv_form_guid           = lv_form_guid
            iv_step_guid           = lv_step_guid
            iv_email_object_name   = lv_objectname
            iv_proj_req_fields     = gs_email_value
          IMPORTING
            es_form_detail         = gs_formdetails
            es_current_step_detail = gs_stepdetail
            es_next_step_detail    = DATA(gs_next_stepdetail)
        ).

* End of shared workflow class call.

* D.Rempe - not for S4 project creation.
* Update Multiple Company Code
*    IF ls_proj_form-additional_comp_code IS INITIAL.
*      LOOP AT gt_additional_ccode INTO gs_multipleccode.
*        CONCATENATE gs_multipleccode-comp_code gs_multipleccode-kostl_code INTO DATA(lv_multiplecc) SEPARATED BY '/'.     " CompanyCode + Cost Center
*
*        IF sy-tabix EQ 1.
*          ls_proj_form-additional_comp_code = lv_multiplecc.
*        ELSE.
*          CONCATENATE ls_proj_form-additional_comp_code lv_multiplecc INTO ls_proj_form-additional_comp_code SEPARATED BY ','.
*        ENDIF.
*      ENDLOOP.
*    ENDIF.
*
** Clear more additional company code once it's updated by BPC
*    IF gs_formdetails-appr_step = 'BPC' AND gs_formdetails-form_status = gc_formstatus_completed.
*      CLEAR ls_proj_form-more_addi_compcode.
*    ENDIF.

    ls_proj_form-step_guid      = gs_stepdetail-step_guid.
    MODIFY zmdg_proj_form FROM ls_proj_form.
    COMMIT WORK.

* Create duplicate record for STARTED Step Status
    IF gs_next_stepdetail-step_guid IS NOT INITIAL.
      CLEAR ls_proj_form-comments.
      ls_proj_form-step_guid      = gs_next_stepdetail-step_guid.
      MODIFY zmdg_proj_form FROM ls_proj_form.
      COMMIT WORK.
    ENDIF.

    IF NOT gt_attachments[] IS INITIAL.
      save_attachments( ).
    ENDIF.

* <TR> Lock call off, shared class owned by other team (P-63)
*    zcl_nd_ca_utilities=>dequeue_form( gs_formdetails-form_guid ).

  ENDMETHOD.


METHOD update_process_region.
    IF wa_url_parameters-processing_region IS NOT INITIAL.
      gs_proj_form-processing_region = wa_url_parameters-processing_region.
**Update Ver based on region
      CASE gs_proj_form-processing_region.
        WHEN 'E'.
          gc_form_ver = '0002'.
        WHEN 'A'.
          gc_form_ver = '0003'.
        WHEN OTHERS.
          gc_form_ver = '0001'.
      ENDCASE.

**Update Company Code - Based on Region******************************
      CALL METHOD get_company_code.

** Get Order Type based on processing region - D.Rempe: irrelevant.
*      CALL METHOD get_order_type.

**Clear Cost Center - Because the user have to select updated company code in FRONT-End to populate Cost Center**
      REFRESH gt_kostl[].

    ENDIF.
  ENDMETHOD.




method CC_ALL_APPROVERS.
  data: lt_workcenters  type table of hrobjid,
        lv_workcenter   type hrobjid,
        lv_form_guid    type sysuuid_c,
        lv_form_version type zform_ver,
        lt_users        type zca_t_nad_gl_agent,
        ls_agent        type zca_s_nad_gl_agent,
        lv_user_id      type xubname.

  CASE iv_processing_region.
    WHEN 'E'.
      lv_form_version = '0002'.
    WHEN 'A'.
      lv_form_version = '0003'.
    WHEN OTHERS.
      lv_form_version = '0001'.
  ENDCASE.

  select workcenter_id into table lt_workcenters
      from zca_apprvr_list
      where form_name = iv_form_name
        and form_ver = lv_form_version
        and workcenter_id > 0
        and appr_seqno > 1.

  loop at lt_workcenters into lv_workcenter.
    refresh lt_users.
    try.
      lt_users = zcl_nd_ca_mdg_workflow=>get_agents_of_approval_step(
        iv_form_guid = lv_form_guid
        iv_work_center = lv_workcenter
      ).

      catch zcx_ca_form_exceptions.
        continue.
    endtry.

    append lines of lt_users to rt_agents.
  endloop.

* Add the on-behalf user, if they were filled in.
  if not iv_onbehalf_of is initial.
    lv_user_id = iv_onbehalf_of.

    clear ls_agent.
    ls_agent-agent_id = iv_onbehalf_of.
    ls_agent-agent_name = zcl_nd_ca_utilities=>get_name_from_user( lv_user_id ).
    append ls_agent to rt_agents.
  endif.

  sort rt_agents by agent_id.
  delete adjacent duplicates from rt_agents comparing agent_id.

  export AGENTS from rt_agents  to memory id 'ZMDG_CC'.
endmethod.


method CREATE_PROJECT.
  data: ls_project type zps_project_update,
        lv_template type ps_vorspsp,
        lv_subtemplate_id type zmdg_proj_subtype,
        lt_return type table of bapiret2,
        ls_return type bapiret2,
        ls_zmdg_proj_form type zmdg_proj_form,
        lv_project_subtype type zmdg_proj_subtype,
        lv_budget type flag.

  ls_project-description = gs_proj_form-projectname.
  ls_project-controlling_area = '1000'.
  ls_project-company_code = gs_proj_form-company_code.
  ls_project-completion_date = gs_proj_form-proj_completion_date.
  ls_project-cost_center = gs_proj_form-kostl.
  ls_project-profit_center = gs_proj_form-profit_center.
  ls_project-cap_id = gs_proj_form-capid.
  ls_project-brand = gs_proj_form-brand.
  ls_project-geography = gs_proj_form-geography.
  ls_project-budget = gs_proj_form-capex_req_amount.
  ls_project-budget_currency = gs_proj_form-capex_req_curr.
  ls_project-location = gs_proj_form-location.

  if not gs_proj_form-resp_lead is initial.
*   Read existing VERNR from TCJ04, insert new record if not found.
    ls_project-person_responsible = zcl_nd_project_utility=>insert_tcj04( gs_proj_form-resp_lead ).
  endif.

* If a project was already created, attempt to update it.
  ls_project-project = gs_proj_form-project_id.

  if gs_proj_form-project_type = '5'.
    lv_project_subtype = gs_proj_form-project_subtype.
  else.
    lv_project_subtype = '00'.
  endif.

  if gs_proj_form-project_type = '6'.
    lv_budget = ''.
  else.
    lv_budget = 'X'.
  endif.

  select single standard_wbs into lv_template
      from zps_template_map
      where project_type = gs_proj_form-project_type
        and project_subtype = lv_project_subtype.

  if sy-subrc <> 0.
    raise exception type zcx_project_code_request
      exporting
        textid = zcx_project_code_request=>project_type_invalid
        project_type = gs_proj_form-project_type.
  endif.

  call function 'Z_PS_COPY_TEMPLATE'
    exporting
      iv_template = lv_template
      is_project = ls_project
      iv_update_budget = lv_budget
      iv_settlement = lv_budget
    importing
      ev_project = gs_proj_form-project_id
    tables
      return = lt_return.

  read table lt_return with key type = 'E' transporting no fields.
  if sy-subrc = 0 or gs_proj_form-project_id is initial.
    send_error_email( ).

*   Project creation either didn't work out, or there were issues releasing the project.
    if not gs_proj_form-project_id is initial.
*     In this case, the project was created ok, but it either wasn't updated or wasn't released.
*     The form needs to be updated with the project id.
      clear ls_zmdg_proj_form.
      move-corresponding gs_proj_form to ls_zmdg_proj_form.
      modify zmdg_proj_form from ls_zmdg_proj_form.
      commit work.

      raise exception type zcx_project_code_request
        exporting
          textid = zcx_project_code_request=>created_but_not_released
          project_id = gs_proj_form-project_id
          messages = lt_return.
    else.
*     In this case, the project was not created at all.
      raise exception type zcx_project_code_request
        exporting
          textid = zcx_project_code_request=>error_during_creation
          messages = lt_return.
    endif.
  else.
*   Project was created and released.
    cc_all_approvers(
      iv_form_name = gc_form_name
      iv_processing_region = gs_proj_form-processing_region
      iv_onbehalf_of = gs_proj_form-onbehalf_id
    ).
    submit_form( ).
  endif.

  if not gs_proj_form-project_id is initial.
    call function 'CONVERSION_EXIT_PROJN_OUTPUT'
      exporting
        input  = gs_proj_form-project_id
      importing
        output = gs_proj_form-project_id_out.
  endif.
endmethod.


method SEND_ERROR_EMAIL.
  data: ls_proj_form   type zmdg_proj_form,
        ls_proj_email  type zmdg_s_proj_email,
        lv_form_guid   type sysuuid_c,
        lv_object_name type string.

  select single form_guid into lv_form_guid
      from zca_stepdetail
      where step_guid = gs_proj_form-step_guid.

  move-corresponding gs_proj_form to ls_proj_form.
  populate_field_email(
    exporting
      ip_form = ls_proj_form
    importing
      io_email_value = ls_proj_email
  ).

  zmdg_send_email=>send_email(
    form_guid   = lv_form_guid
    step_guid   = gs_proj_form-step_guid
    object_name = lv_object_name
    action      = 'ERROR'
    proj_req_fields = ls_proj_email
  ).

  commit work.
endmethod.


method VALIDATE_BRAND_GEO.
  select count( * ) from ztrr_cc_brand
      where bukrs = gs_proj_form-company_code
        and brand = gs_proj_form-brand.
  if sy-subrc <> 0.
    raise exception type zcx_project_code_request
      exporting
        textid = zcx_project_code_request=>brand_not_valid
        brand = gs_proj_form-brand
        company_code = gs_proj_form-company_code.
  endif.

  select count( * ) from ztrr_cc_geo
      where bukrs = gs_proj_form-company_code
        and geography = gs_proj_form-geography.
  if sy-subrc <> 0.
    raise exception type zcx_project_code_request
      exporting
        textid = zcx_project_code_request=>geography_not_valid
        geography = gs_proj_form-geography
        company_code = gs_proj_form-company_code.
  endif.
endmethod.


method CURRENCY_CONVERT_IN.
  data: lv_amount type dec11_4.

  try.
    lv_amount = cv_amount.

    call function 'CURRENCY_AMOUNT_DISPLAY_TO_SAP'
      exporting
        currency = iv_currency
        amount_display = lv_amount
      importing
        amount_internal = lv_amount
      exceptions
        others = 1.

    cv_amount = lv_amount.

    catch CX_SY_CONVERSION_NO_NUMBER.
      cv_amount = 0.
  endtry.
endmethod.


method CURRENCY_CONVERT_OUT.
  data: lv_amount type dec11_4.

  try.
    lv_amount = cv_amount.

    call function 'CURRENCY_AMOUNT_SAP_TO_DISPLAY'
      exporting
        currency = iv_currency
        amount_internal = lv_amount
      importing
        amount_display = lv_amount
      exceptions
        others = 1.

    cv_amount = lv_amount.

    catch CX_SY_CONVERSION_NO_NUMBER.
      cv_amount = 0.
  endtry.
endmethod.
ENDCLASS.