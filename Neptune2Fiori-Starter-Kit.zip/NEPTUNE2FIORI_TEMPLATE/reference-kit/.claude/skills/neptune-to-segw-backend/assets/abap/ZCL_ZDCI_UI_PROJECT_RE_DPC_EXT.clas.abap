* <TR> Data provider for ZDCI_UI_PROJECT_REQUEST_SRV, no business logic
CLASS zcl_zdci_ui_project_re_dpc_ext DEFINITION
  PUBLIC
  INHERITING FROM zcl_zdci_ui_project_re_dpc
  CREATE PUBLIC.

  PUBLIC SECTION.
    METHODS /iwbep/if_mgw_appl_srv_runtime~create_deep_entity REDEFINITION.
    METHODS /iwbep/if_mgw_appl_srv_runtime~create_entity REDEFINITION.
    METHODS /iwbep/if_mgw_appl_srv_runtime~get_stream REDEFINITION.

  PROTECTED SECTION.

  PRIVATE SECTION.
    TYPES ty_ajax TYPE zcl_zdci_ui_project_re_mpc_ext=>ts_ajax_deep.

    METHODS n2f_dispatch
      CHANGING
        cs_ajax TYPE ty_ajax.
    METHODS n2f_send_to_app
      IMPORTING
        is_ajax TYPE ty_ajax
        io_app  TYPE REF TO zcl_ui_project_code_request.
    METHODS n2f_receive_from_app
      IMPORTING
        io_app  TYPE REF TO zcl_ui_project_code_request
      CHANGING
        cs_ajax TYPE ty_ajax.
    METHODS n2f_raise
      IMPORTING
        iv_text TYPE string
      RAISING
        /iwbep/cx_mgw_busi_exception.
ENDCLASS.



CLASS zcl_zdci_ui_project_re_dpc_ext IMPLEMENTATION.


  METHOD /iwbep/if_mgw_appl_srv_runtime~create_deep_entity.
*   original AJAX call (payload always carries the navigation properties)
    DATA ls_ajax TYPE ty_ajax.

    IF iv_entity_set_name <> 'AJAXSet'.
      n2f_raise( |Entity set { iv_entity_set_name } is not creatable| ).
    ENDIF.

    io_data_provider->read_entry_data( IMPORTING es_data = ls_ajax ).
    n2f_dispatch( CHANGING cs_ajax = ls_ajax ).
    copy_data_to_ref( EXPORTING is_data = ls_ajax
                      CHANGING  cr_data = er_deep_entity ).
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~create_entity.
*   Same call when a client sends no navigation properties (flat payload).
    DATA ls_ajax TYPE ty_ajax.

    IF iv_entity_set_name <> 'AJAXSet'.
      n2f_raise( |Entity set { iv_entity_set_name } is not creatable| ).
    ENDIF.

    io_data_provider->read_entry_data( IMPORTING es_data = ls_ajax ).
    n2f_dispatch( CHANGING cs_ajax = ls_ajax ).
    copy_data_to_ref( EXPORTING is_data = ls_ajax
                      CHANGING  cr_data = er_entity ).
  ENDMETHOD.


  METHOD /iwbep/if_mgw_appl_srv_runtime~get_stream.
*   Replaces the original handle_on_request key 'ATTACHMENT', key_id 'FORM=...,ATT=...'
    DATA ls_stream TYPE /iwbep/if_mgw_appl_types=>ty_s_media_resource.
    DATA lv_form   TYPE string.
    DATA lv_att    TYPE string.

    IF iv_entity_set_name <> 'ATTACHMENTSet'.
      n2f_raise( |Entity set { iv_entity_set_name } has no media stream| ).
    ENDIF.

    LOOP AT it_key_tab INTO DATA(ls_key).
      CASE ls_key-name.
        WHEN 'FORM'.
          lv_form = ls_key-value.
        WHEN 'ATT'.
          lv_att = ls_key-value.
      ENDCASE.
    ENDLOOP.

    DATA(lo_app) = NEW zcl_ui_project_code_request( ).
    lo_app->handle_on_request( EXPORTING key             = `ATTACHMENT`
                                         key_id          = |FORM={ lv_form },ATT={ lv_att }|
                               IMPORTING ev_data         = ls_stream-value
                                         ev_content_type = ls_stream-mime_type
                                         ev_file_name    = DATA(lv_file_name) ).

    IF lv_file_name IS NOT INITIAL.
      set_header( VALUE #( name  = 'Content-Disposition'
                           value = |inline; filename="{ lv_file_name }"| ) ).
    ENDIF.

    copy_data_to_ref( EXPORTING is_data = ls_stream
                      CHANGING  cr_data = er_stream ).
  ENDMETHOD.


  METHOD n2f_dispatch.
*   Exactly the original request cycle: fresh instance per call.
    DATA(lo_app) = NEW zcl_ui_project_code_request( ).
    n2f_send_to_app( is_ajax = cs_ajax
                     io_app  = lo_app ).
    lo_app->handle_on_ajax( ajax_id    = cs_ajax-ajax_id
                            ajax_value = cs_ajax-ajax_value ).
    n2f_receive_from_app( EXPORTING io_app  = lo_app
                          CHANGING  cs_ajax = cs_ajax ).
  ENDMETHOD.


  METHOD n2f_send_to_app.
*   Envelope component X -> public attribute X (same name). Generic, so every
*   field the UI sends lands exactly where the original deserializer put it.
    FIELD-SYMBOLS <ls_src>  TYPE any.
    FIELD-SYMBOLS <lt_src>  TYPE ANY TABLE.
    FIELD-SYMBOLS <ls_tgt>  TYPE any.
    FIELD-SYMBOLS <lt_tgt>  TYPE ANY TABLE.
    FIELD-SYMBOLS <ls_row>  TYPE any.
    FIELD-SYMBOLS <ls_line> TYPE any.
    DATA lr_line TYPE REF TO data.

    DATA(lo_descr) = CAST cl_abap_structdescr( cl_abap_typedescr=>describe_by_data( is_ajax ) ).

    LOOP AT lo_descr->get_included_view( ) INTO DATA(ls_comp)
         WHERE name <> 'AJAX_ID' AND name <> 'AJAX_VALUE'.
      DATA(lv_attr) = ls_comp-name.

      CASE ls_comp-type->kind.
        WHEN cl_abap_typedescr=>kind_struct.
          UNASSIGN: <ls_src>, <ls_tgt>.
          ASSIGN COMPONENT lv_attr OF STRUCTURE is_ajax TO <ls_src>.
          ASSIGN io_app->(lv_attr) TO <ls_tgt>.
          IF <ls_src> IS ASSIGNED AND <ls_tgt> IS ASSIGNED.
            MOVE-CORRESPONDING <ls_src> TO <ls_tgt>.
          ENDIF.

        WHEN cl_abap_typedescr=>kind_table.
          UNASSIGN: <lt_src>, <lt_tgt>.
          ASSIGN COMPONENT lv_attr OF STRUCTURE is_ajax TO <lt_src>.
          ASSIGN io_app->(lv_attr) TO <lt_tgt>.
          IF <lt_src> IS ASSIGNED AND <lt_tgt> IS ASSIGNED.
            CLEAR <lt_tgt>.
            LOOP AT <lt_src> ASSIGNING <ls_row>.
              CREATE DATA lr_line LIKE LINE OF <lt_tgt>.
              ASSIGN lr_line->* TO <ls_line>.
              MOVE-CORRESPONDING <ls_row> TO <ls_line>.   " ROW_INDEX has no target -> dropped
              INSERT <ls_line> INTO TABLE <lt_tgt>.
            ENDLOOP.
          ENDIF.
      ENDCASE.
    ENDLOOP.
  ENDMETHOD.


  METHOD n2f_receive_from_app.
*   Public attribute X -> envelope component X; tables get ROW_INDEX 1..n.
    FIELD-SYMBOLS <ls_src>   TYPE any.
    FIELD-SYMBOLS <lt_src>   TYPE ANY TABLE.
    FIELD-SYMBOLS <ls_tgt>   TYPE any.
    FIELD-SYMBOLS <lt_tgt>   TYPE ANY TABLE.
    FIELD-SYMBOLS <ls_row>   TYPE any.
    FIELD-SYMBOLS <ls_line>  TYPE any.
    FIELD-SYMBOLS <lv_index> TYPE any.
    DATA lr_line  TYPE REF TO data.
    DATA lv_index TYPE i.

    DATA(lo_descr) = CAST cl_abap_structdescr( cl_abap_typedescr=>describe_by_data( cs_ajax ) ).

    LOOP AT lo_descr->get_included_view( ) INTO DATA(ls_comp)
         WHERE name <> 'AJAX_ID' AND name <> 'AJAX_VALUE'.
      DATA(lv_attr) = ls_comp-name.

      CASE ls_comp-type->kind.
        WHEN cl_abap_typedescr=>kind_struct.
          UNASSIGN: <ls_src>, <ls_tgt>.
          ASSIGN io_app->(lv_attr) TO <ls_src>.
          ASSIGN COMPONENT lv_attr OF STRUCTURE cs_ajax TO <ls_tgt>.
          IF <ls_src> IS ASSIGNED AND <ls_tgt> IS ASSIGNED.
            CLEAR <ls_tgt>.
            MOVE-CORRESPONDING <ls_src> TO <ls_tgt>.
          ENDIF.

        WHEN cl_abap_typedescr=>kind_table.
          UNASSIGN: <lt_src>, <lt_tgt>.
          ASSIGN io_app->(lv_attr) TO <lt_src>.
          ASSIGN COMPONENT lv_attr OF STRUCTURE cs_ajax TO <lt_tgt>.
          IF <lt_src> IS ASSIGNED AND <lt_tgt> IS ASSIGNED.
            CLEAR <lt_tgt>.
            lv_index = 0.
            LOOP AT <lt_src> ASSIGNING <ls_row>.
              lv_index = lv_index + 1.
              CREATE DATA lr_line LIKE LINE OF <lt_tgt>.
              ASSIGN lr_line->* TO <ls_line>.
              MOVE-CORRESPONDING <ls_row> TO <ls_line>.
              ASSIGN COMPONENT 'ROW_INDEX' OF STRUCTURE <ls_line> TO <lv_index>.
              IF <lv_index> IS ASSIGNED.
                <lv_index> = lv_index.
                UNASSIGN <lv_index>.
              ENDIF.
              INSERT <ls_line> INTO TABLE <lt_tgt>.
            ENDLOOP.
          ENDIF.
      ENDCASE.
    ENDLOOP.
  ENDMETHOD.


  METHOD n2f_raise.
    RAISE EXCEPTION TYPE /iwbep/cx_mgw_busi_exception
      EXPORTING
        textid  = /iwbep/cx_mgw_busi_exception=>business_error
        message = CONV #( iv_text ).
  ENDMETHOD.
ENDCLASS.
