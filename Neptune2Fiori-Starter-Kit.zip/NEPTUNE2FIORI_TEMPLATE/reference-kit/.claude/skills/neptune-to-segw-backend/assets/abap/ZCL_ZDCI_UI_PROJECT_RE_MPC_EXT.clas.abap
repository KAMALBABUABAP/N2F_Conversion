* <TR> OData model built from class types (RTTI)
CLASS zcl_zdci_ui_project_re_mpc_ext DEFINITION
  PUBLIC
  INHERITING FROM zcl_zdci_ui_project_re_mpc
  CREATE PUBLIC.

  PUBLIC SECTION.

*   ---- Structures carried as complex properties of AJAX --------------------
*   Anonymous structures of ZCL_UI_PROJECT_CODE_REQUEST, re-declared field by field
    TYPES:
      BEGIN OF ts_wa_url_parameters,
        form_guid         TYPE string,
        proj              TYPE string,
        mode              TYPE string,
        from              TYPE string,
        processing_region TYPE string,
        company_code      TYPE string,
      END OF ts_wa_url_parameters.
    TYPES:
      BEGIN OF ts_wa_program_state,
        program_state   TYPE string,
        program_message TYPE string,
        incorrect_field TYPE string,
      END OF ts_wa_program_state.
    TYPES:
      BEGIN OF ts_wa_comments,
        comments TYPE string,
      END OF ts_wa_comments.
    TYPES:
      BEGIN OF ts_wa_confirm_delete,
        delete_index TYPE string,
      END OF ts_wa_confirm_delete.
*   Named types
    TYPES ts_gs_proj_form     TYPE zcl_ui_project_code_request=>ty_proj_form.
    TYPES ts_gs_formdetails   TYPE zca_formdetail.
    TYPES ts_gs_stepdetail    TYPE zca_stepdetail.
    TYPES ts_gs_formheader    TYPE zca_s_nad_gl_pageheader.
    TYPES ts_gs_employee_info TYPE zhcm_s_employee_info.
    TYPES ts_gs_attachment    TYPE zca_form_attachment.
    TYPES ts_gs_multipleccode TYPE zcl_ui_project_code_request=>ty_additional_ccode.

*   ---- Table rows: ROW_INDEX (OData key) + the ABAP row type ----------------
    TYPES BEGIN OF ts_gt_appr.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_wi_appr.
    TYPES END OF ts_gt_appr.
    TYPES tt_gt_appr TYPE STANDARD TABLE OF ts_gt_appr WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_attachments.
    TYPES row_index TYPE i.
    INCLUDE TYPE zca_form_attachment.
    TYPES END OF ts_gt_attachments.
    TYPES tt_gt_attachments TYPE STANDARD TABLE OF ts_gt_attachments WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_zca_agent_list.
    TYPES row_index TYPE i.
    INCLUDE TYPE zca_s_nad_gl_agent.
    TYPES END OF ts_gt_zca_agent_list.
    TYPES tt_gt_zca_agent_list TYPE STANDARD TABLE OF ts_gt_zca_agent_list WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_orderdetails.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_orderdetails.
    TYPES END OF ts_gt_orderdetails.
    TYPES tt_gt_orderdetails TYPE STANDARD TABLE OF ts_gt_orderdetails WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_additional_ccode.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_additional_ccode.
    TYPES END OF ts_gt_additional_ccode.
    TYPES tt_gt_additional_ccode TYPE STANDARD TABLE OF ts_gt_additional_ccode WITH DEFAULT KEY.

*   One row type per TY_VALUE_TEXT attribute (OData types are named after the attribute)
    TYPES BEGIN OF ts_gt_request_type.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_request_type.
    TYPES tt_gt_request_type TYPE STANDARD TABLE OF ts_gt_request_type WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_project_subtype.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_project_subtype.
    TYPES tt_gt_project_subtype TYPE STANDARD TABLE OF ts_gt_project_subtype WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_exec_category.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_exec_category.
    TYPES tt_gt_exec_category TYPE STANDARD TABLE OF ts_gt_exec_category WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_initi_group.
    TYPES row_index TYPE i.
    INCLUDE TYPE zzmdg_initia_grp.
    TYPES END OF ts_gt_initi_group.
    TYPES tt_gt_initi_group TYPE STANDARD TABLE OF ts_gt_initi_group WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_initi_grp.
    TYPES row_index TYPE i.
    INCLUDE TYPE zzmdg_initia_grp.
    TYPES END OF ts_gt_initi_grp.
    TYPES tt_gt_initi_grp TYPE STANDARD TABLE OF ts_gt_initi_grp WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_asset_class.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_asset_class.
    TYPES tt_gt_asset_class TYPE STANDARD TABLE OF ts_gt_asset_class WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_itl_asset_class.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_itl_asset_class.
    TYPES tt_gt_itl_asset_class TYPE STANDARD TABLE OF ts_gt_itl_asset_class WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_currency.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_currency.
    TYPES tt_gt_currency TYPE STANDARD TABLE OF ts_gt_currency WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_usstate.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_usstate.
    TYPES tt_gt_usstate TYPE STANDARD TABLE OF ts_gt_usstate WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_comp_code.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_comp_code.
    TYPES tt_gt_comp_code TYPE STANDARD TABLE OF ts_gt_comp_code WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_add_comp_ccode.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_add_comp_ccode.
    TYPES tt_gt_add_comp_ccode TYPE STANDARD TABLE OF ts_gt_add_comp_ccode WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_kostl.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_kostl.
    TYPES tt_gt_kostl TYPE STANDARD TABLE OF ts_gt_kostl WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_geographylist.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_geographylist.
    TYPES tt_gt_geographylist TYPE STANDARD TABLE OF ts_gt_geographylist WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_brands.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_value_text.
    TYPES END OF ts_gt_brands.
    TYPES tt_gt_brands TYPE STANDARD TABLE OF ts_gt_brands WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_locations.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_location.
    TYPES END OF ts_gt_locations.
    TYPES tt_gt_locations TYPE STANDARD TABLE OF ts_gt_locations WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_agent_list.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_agent_list.
    TYPES END OF ts_gt_agent_list.
    TYPES tt_gt_agent_list TYPE STANDARD TABLE OF ts_gt_agent_list WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_auth_by_list.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_agent_list.
    TYPES END OF ts_gt_auth_by_list.
    TYPES tt_gt_auth_by_list TYPE STANDARD TABLE OF ts_gt_auth_by_list WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_prev_projcode.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>s_value_text.
    TYPES END OF ts_gt_prev_projcode.
    TYPES tt_gt_prev_projcode TYPE STANDARD TABLE OF ts_gt_prev_projcode WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_order_type.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>s_value_text.
    TYPES END OF ts_gt_order_type.
    TYPES tt_gt_order_type TYPE STANDARD TABLE OF ts_gt_order_type WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_attachment_categories.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>s_value_text_req.
    TYPES END OF ts_gt_attachment_categories.
    TYPES tt_gt_attachment_categories TYPE STANDARD TABLE OF ts_gt_attachment_categories WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_attachments_required.
    TYPES row_index TYPE i.
    INCLUDE TYPE zmdg_att_req.
    TYPES END OF ts_gt_attachments_required.
    TYPES tt_gt_attachments_required TYPE STANDARD TABLE OF ts_gt_attachments_required WITH DEFAULT KEY.

    TYPES BEGIN OF ts_gt_sys_message.
    TYPES row_index TYPE i.
    INCLUDE TYPE zcl_ui_project_code_request=>ty_message.
    TYPES END OF ts_gt_sys_message.
    TYPES tt_gt_sys_message TYPE STANDARD TABLE OF ts_gt_sys_message WITH DEFAULT KEY.

*   ---- Root entity AJAX: keys + the 11 structures (bound to the entity) -----
    TYPES:
      BEGIN OF ts_ajax_root,
        ajax_id           TYPE string,
        ajax_value        TYPE string,
        wa_url_parameters TYPE ts_wa_url_parameters,
        wa_program_state  TYPE ts_wa_program_state,
        wa_comments       TYPE ts_wa_comments,
        wa_confirm_delete TYPE ts_wa_confirm_delete,
        gs_proj_form      TYPE ts_gs_proj_form,
        gs_formdetails    TYPE ts_gs_formdetails,
        gs_stepdetail     TYPE ts_gs_stepdetail,
        gs_formheader     TYPE ts_gs_formheader,
        gs_employee_info  TYPE ts_gs_employee_info,
        gs_attachment     TYPE ts_gs_attachment,
        gs_multipleccode  TYPE ts_gs_multipleccode,
      END OF ts_ajax_root.

*   ---- Deep structure for read_entry_data / copy_data_to_ref ----------------
*   Component names = navigation property names = class attribute names.
    TYPES BEGIN OF ts_ajax_deep.
    INCLUDE TYPE ts_ajax_root.
    TYPES gt_appr                  TYPE tt_gt_appr.
    TYPES gt_attachments           TYPE tt_gt_attachments.
    TYPES gt_zca_agent_list        TYPE tt_gt_zca_agent_list.
    TYPES gt_orderdetails          TYPE tt_gt_orderdetails.
    TYPES gt_additional_ccode      TYPE tt_gt_additional_ccode.
    TYPES gt_request_type          TYPE tt_gt_request_type.
    TYPES gt_project_subtype       TYPE tt_gt_project_subtype.
    TYPES gt_exec_category         TYPE tt_gt_exec_category.
    TYPES gt_initi_group           TYPE tt_gt_initi_group.
    TYPES gt_initi_grp             TYPE tt_gt_initi_grp.
    TYPES gt_asset_class           TYPE tt_gt_asset_class.
    TYPES gt_itl_asset_class       TYPE tt_gt_itl_asset_class.
    TYPES gt_currency              TYPE tt_gt_currency.
    TYPES gt_usstate               TYPE tt_gt_usstate.
    TYPES gt_comp_code             TYPE tt_gt_comp_code.
    TYPES gt_add_comp_ccode        TYPE tt_gt_add_comp_ccode.
    TYPES gt_kostl                 TYPE tt_gt_kostl.
    TYPES gt_geographylist         TYPE tt_gt_geographylist.
    TYPES gt_brands                TYPE tt_gt_brands.
    TYPES gt_locations             TYPE tt_gt_locations.
    TYPES gt_agent_list            TYPE tt_gt_agent_list.
    TYPES gt_auth_by_list          TYPE tt_gt_auth_by_list.
    TYPES gt_prev_projcode         TYPE tt_gt_prev_projcode.
    TYPES gt_order_type            TYPE tt_gt_order_type.
    TYPES gt_attachment_categories TYPE tt_gt_attachment_categories.
    TYPES gt_attachments_required  TYPE tt_gt_attachments_required.
    TYPES gt_sys_message           TYPE tt_gt_sys_message.
    TYPES END OF ts_ajax_deep.

*   ---- Media entity replacing handle_on_request key 'ATTACHMENT' ------------
    TYPES:
      BEGIN OF ts_attachment,
        form      TYPE string,
        att       TYPE string,
        mime_type TYPE string,
        file_name TYPE string,
      END OF ts_attachment.

    CONSTANTS gc_self TYPE string VALUE 'ZCL_ZDCI_UI_PROJECT_RE_MPC_EXT'.

    METHODS define REDEFINITION.
    METHODS get_last_modified REDEFINITION.

  PROTECTED SECTION.

  PRIVATE SECTION.
    METHODS n2f_define_envelope
      RAISING
        /iwbep/cx_mgw_med_exception.
    METHODS n2f_define_attachment
      RAISING
        /iwbep/cx_mgw_med_exception.
    METHODS n2f_add_properties
      IMPORTING
        io_entity  TYPE REF TO /iwbep/if_mgw_odata_entity_typ OPTIONAL
        io_complex TYPE REF TO /iwbep/if_mgw_odata_cmplx_type OPTIONAL
        io_struct  TYPE REF TO cl_abap_structdescr
      RAISING
        /iwbep/cx_mgw_med_exception.
    METHODS n2f_set_edm_type
      IMPORTING
        io_property TYPE REF TO /iwbep/if_mgw_odata_property
        io_type     TYPE REF TO cl_abap_datadescr
      RAISING
        /iwbep/cx_mgw_med_exception.
    METHODS n2f_bind_name
      IMPORTING
        io_struct      TYPE REF TO cl_abap_structdescr
      RETURNING
        VALUE(rv_name) TYPE string.
ENDCLASS.



CLASS zcl_zdci_ui_project_re_mpc_ext IMPLEMENTATION.


  METHOD define.
    super->define( ).
    n2f_define_envelope( ).
    n2f_define_attachment( ).
  ENDMETHOD.


  METHOD get_last_modified.
*   <TR> Bump timestamp on every change
    CONSTANTS lc_gen_date_time TYPE timestamp VALUE '20261012120000'.
    rv_last_modified = super->get_last_modified( ).
    IF rv_last_modified LT lc_gen_date_time.
      rv_last_modified = lc_gen_date_time.
    ENDIF.
  ENDMETHOD.


  METHOD n2f_define_envelope.
    DATA ls_deep TYPE ts_ajax_deep.
    DATA lo_property TYPE REF TO /iwbep/if_mgw_odata_property.

    DATA(lo_deep) = CAST cl_abap_structdescr( cl_abap_typedescr=>describe_by_data( ls_deep ) ).

*   Root entity type AJAX (keys = handle_on_ajax parameter names).
*   Normally SEGW models nothing; if SEGW insisted on a minimal AJAX entity
*   (see segw-steps.md), reuse it instead of creating it twice.
    DATA lo_ajax TYPE REF TO /iwbep/if_mgw_odata_entity_typ.
    TRY.
        lo_ajax = model->get_entity_type( iv_entity_name = 'AJAX' ).
      CATCH /iwbep/cx_mgw_med_exception.
        lo_ajax = model->create_entity_type( iv_entity_type_name = 'AJAX'
                                             iv_def_entity_set   = abap_false ).
    ENDTRY.
    TRY.
        lo_property = lo_ajax->get_property( iv_property_name = 'AJAX_ID' ).
      CATCH /iwbep/cx_mgw_med_exception.
        lo_property = lo_ajax->create_property( iv_property_name  = 'AJAX_ID'
                                                iv_abap_fieldname = 'AJAX_ID' ).
    ENDTRY.
    lo_property->set_is_key( ).
    lo_property->set_type_edm_string( ).
    lo_property->set_creatable( abap_true ).
    lo_property = lo_ajax->create_property( iv_property_name  = 'AJAX_VALUE'
                                            iv_abap_fieldname = 'AJAX_VALUE' ).
    lo_property->set_type_edm_string( ).
    lo_property->set_creatable( abap_true ).

    DATA(lo_ajax_set) = lo_ajax->create_entity_set( 'AJAXSet' ).
    lo_ajax_set->set_creatable( abap_true ).
    lo_ajax_set->set_updatable( abap_false ).
    lo_ajax_set->set_deletable( abap_false ).
    lo_ajax_set->set_pageable( abap_false ).
    lo_ajax_set->set_addressable( abap_true ).

*   One complex type per structure attribute, one entity type per table attribute
    LOOP AT lo_deep->get_included_view( ) INTO DATA(ls_comp)
         WHERE name <> 'AJAX_ID' AND name <> 'AJAX_VALUE'.

      DATA(lv_name) = CONV /iwbep/med_external_name( ls_comp-name ).

      CASE ls_comp-type->kind.

        WHEN cl_abap_typedescr=>kind_struct.
          DATA(lo_struct) = CAST cl_abap_structdescr( ls_comp-type ).
          DATA(lo_complex) = model->create_complex_type( lv_name ).
          n2f_add_properties( io_complex = lo_complex
                              io_struct  = lo_struct ).
          lo_complex->bind_structure( iv_structure_name   = n2f_bind_name( lo_struct )
                                      iv_bind_conversions = abap_false ).
          lo_ajax->create_complex_property( iv_property_name      = lv_name
                                            iv_complex_type_name  = lv_name
                                            iv_abap_fieldname     = CONV #( ls_comp-name ) ).

        WHEN cl_abap_typedescr=>kind_table.
          DATA(lo_line) = CAST cl_abap_structdescr(
                            CAST cl_abap_tabledescr( ls_comp-type )->get_table_line_type( ) ).
          DATA(lo_entity) = model->create_entity_type( iv_entity_type_name = lv_name
                                                       iv_def_entity_set   = abap_false ).
          n2f_add_properties( io_entity = lo_entity
                              io_struct = lo_line ).
          lo_entity->bind_structure( iv_structure_name   = n2f_bind_name( lo_line )
                                     iv_bind_conversions = abap_false ).

          DATA(lo_set) = lo_entity->create_entity_set( |{ lv_name }Set| ).
          lo_set->set_creatable( abap_true ).
          lo_set->set_updatable( abap_false ).
          lo_set->set_deletable( abap_false ).
          lo_set->set_pageable( abap_false ).
          lo_set->set_addressable( abap_false ).

          model->create_association( iv_association_name = |AJAX_{ lv_name }|
                                     iv_left_type        = 'AJAX'
                                     iv_right_type       = lv_name
                                     iv_right_card       = 'M'
                                     iv_left_card        = '1'
                                     iv_def_assoc_set    = abap_false ).
          model->create_association_set( iv_association_set_name  = |AJAX_{ lv_name }Set|
                                         iv_left_entity_set_name  = 'AJAXSet'
                                         iv_right_entity_set_name = |{ lv_name }Set|
                                         iv_association_name      = |AJAX_{ lv_name }| ).
          lo_ajax->create_navigation_property( iv_property_name    = lv_name
                                               iv_abap_fieldname   = CONV #( ls_comp-name )
                                               iv_association_name = |AJAX_{ lv_name }| ).

        WHEN OTHERS.
*         Only structures and tables exist in TS_AJAX_DEEP besides the keys.
          CONTINUE.
      ENDCASE.
    ENDLOOP.

    lo_ajax->bind_structure( iv_structure_name   = |{ gc_self }=>TS_AJAX_ROOT|
                             iv_bind_conversions = abap_false ).
  ENDMETHOD.


  METHOD n2f_define_attachment.
    DATA lo_property TYPE REF TO /iwbep/if_mgw_odata_property.

    DATA(lo_att) = model->create_entity_type( iv_entity_type_name = 'ATTACHMENT'
                                              iv_def_entity_set   = abap_false ).
    lo_property = lo_att->create_property( iv_property_name = 'FORM' iv_abap_fieldname = 'FORM' ).
    lo_property->set_is_key( ).
    lo_property->set_type_edm_string( ).
    lo_property = lo_att->create_property( iv_property_name = 'ATT' iv_abap_fieldname = 'ATT' ).
    lo_property->set_is_key( ).
    lo_property->set_type_edm_string( ).
    lo_property = lo_att->create_property( iv_property_name = 'MIME_TYPE' iv_abap_fieldname = 'MIME_TYPE' ).
    lo_property->set_type_edm_string( ).
    lo_property->set_as_content_type( ).
    lo_property = lo_att->create_property( iv_property_name = 'FILE_NAME' iv_abap_fieldname = 'FILE_NAME' ).
    lo_property->set_type_edm_string( ).
    lo_att->set_is_media( ).
    lo_att->bind_structure( iv_structure_name   = |{ gc_self }=>TS_ATTACHMENT|
                            iv_bind_conversions = abap_false ).

    DATA(lo_set) = lo_att->create_entity_set( 'ATTACHMENTSet' ).
    lo_set->set_creatable( abap_false ).
    lo_set->set_updatable( abap_false ).
    lo_set->set_deletable( abap_false ).
    lo_set->set_pageable( abap_false ).
    lo_set->set_addressable( abap_true ).
  ENDMETHOD.


  METHOD n2f_add_properties.
    DATA lo_property TYPE REF TO /iwbep/if_mgw_odata_property.

*   get_included_view flattens INCLUDEs (TY_PROJ_FORM has seven of them).
    LOOP AT io_struct->get_included_view( ) INTO DATA(ls_comp).
      IF io_entity IS BOUND.
        lo_property = io_entity->create_property( iv_property_name  = CONV #( ls_comp-name )
                                                  iv_abap_fieldname = CONV #( ls_comp-name ) ).
      ELSE.
        lo_property = io_complex->create_property( iv_property_name  = CONV #( ls_comp-name )
                                                   iv_abap_fieldname = CONV #( ls_comp-name ) ).
      ENDIF.
      n2f_set_edm_type( io_property = lo_property
                        io_type     = ls_comp-type ).
      IF ls_comp-name = 'ROW_INDEX'.
        lo_property->set_is_key( ).
      ENDIF.
      lo_property->set_creatable( abap_true ).
      lo_property->set_updatable( abap_true ).
    ENDLOOP.
  ENDMETHOD.


  METHOD n2f_bind_name.
*   RTTI absolute name -> name accepted by bind_structure:
*   '\TYPE=ZCA_FORMDETAIL'                 -> 'ZCA_FORMDETAIL'
*   '\CLASS=ZCL_X\TYPE=TY_Y'               -> 'ZCL_X=>TY_Y' (same form SEGW generates)
*   Works whether a TYPES alias resolves to its own name or to the referenced type.
    DATA lv_class TYPE string.
    DATA lv_type  TYPE string.

    SPLIT io_struct->absolute_name AT '\' INTO TABLE DATA(lt_parts).
    LOOP AT lt_parts INTO DATA(lv_part).
      IF lv_part CP 'CLASS=*'.
        lv_class = substring_after( val = lv_part sub = '=' ).
      ELSEIF lv_part CP 'TYPE=*'.
        lv_type = substring_after( val = lv_part sub = '=' ).
      ENDIF.
    ENDLOOP.

    IF lv_class IS INITIAL.
      rv_name = lv_type.
    ELSE.
      rv_name = |{ lv_class }=>{ lv_type }|.
    ENDIF.
  ENDMETHOD.


  METHOD n2f_set_edm_type.
    DATA lo_elem TYPE REF TO cl_abap_elemdescr.

    IF io_type->kind <> cl_abap_typedescr=>kind_elem.
*     Nested structures/tables do not occur below the envelope level.
      io_property->set_type_edm_string( ).
      RETURN.
    ENDIF.
    lo_elem = CAST cl_abap_elemdescr( io_type ).

    CASE lo_elem->type_kind.
      WHEN cl_abap_typedescr=>typekind_char
        OR cl_abap_typedescr=>typekind_num
        OR cl_abap_typedescr=>typekind_date
        OR cl_abap_typedescr=>typekind_time.
        io_property->set_type_edm_string( ).
        io_property->set_maxlength( iv_max_length = lo_elem->length / cl_abap_char_utilities=>charsize ).
*       <TR> D/T as char: yyyyMMdd, not ISO
        IF lo_elem->type_kind = cl_abap_typedescr=>typekind_date OR lo_elem->type_kind = cl_abap_typedescr=>typekind_time.
          io_property->set_internal_type( cl_abap_typedescr=>typekind_char ).
        ENDIF.
      WHEN cl_abap_typedescr=>typekind_string.
        io_property->set_type_edm_string( ).
      WHEN cl_abap_typedescr=>typekind_packed.
        io_property->set_type_edm_decimal( ).
*       Gateway API: set_maxlength = precision, set_precison = scale
        io_property->set_maxlength( iv_max_length = lo_elem->length * 2 - 1 ).
        io_property->set_precison( iv_precision = lo_elem->decimals ).
      WHEN cl_abap_typedescr=>typekind_int.
        io_property->set_type_edm_int32( ).
      WHEN cl_abap_typedescr=>typekind_int2.
        io_property->set_type_edm_int16( ).
      WHEN cl_abap_typedescr=>typekind_int1.
        io_property->set_type_edm_byte( ).
      WHEN cl_abap_typedescr=>typekind_int8.
        io_property->set_type_edm_int64( ).
      WHEN cl_abap_typedescr=>typekind_float.
        io_property->set_type_edm_double( ).
      WHEN cl_abap_typedescr=>typekind_hex
        OR cl_abap_typedescr=>typekind_xstring.
        io_property->set_type_edm_binary( ).
      WHEN OTHERS.
        io_property->set_type_edm_string( ).
    ENDCASE.
  ENDMETHOD.
ENDCLASS.
