#!/usr/bin/env python3
"""Check the live $metadata of ZDCI_UI_PROJECT_REQUEST_SRV against the naming registry.

Get the metadata (browser, logged on) and save it:
    https://<host>/sap/opu/odata/sap/ZDCI_UI_PROJECT_REQUEST_SRV/$metadata?sap-client=<client>
Then (macOS, zsh):
    python3 check_metadata.py ~/Downloads/metadata.xml

Exit code 0 = all checks pass. Every failure line says what to fix.
"""
import sys
import xml.etree.ElementTree as ET

STRUCTURES = ["WA_URL_PARAMETERS", "WA_PROGRAM_STATE", "WA_COMMENTS", "WA_CONFIRM_DELETE", "GS_PROJ_FORM",
              "GS_FORMDETAILS", "GS_STEPDETAIL", "GS_FORMHEADER", "GS_EMPLOYEE_INFO", "GS_ATTACHMENT",
              "GS_MULTIPLECCODE"]
TABLES = ["GT_APPR", "GT_ATTACHMENTS", "GT_ZCA_AGENT_LIST", "GT_ORDERDETAILS", "GT_ADDITIONAL_CCODE",
          "GT_REQUEST_TYPE", "GT_PROJECT_SUBTYPE", "GT_EXEC_CATEGORY", "GT_INITI_GROUP", "GT_INITI_GRP",
          "GT_ASSET_CLASS", "GT_ITL_ASSET_CLASS", "GT_CURRENCY", "GT_USSTATE", "GT_COMP_CODE", "GT_ADD_COMP_CCODE",
          "GT_KOSTL", "GT_GEOGRAPHYLIST", "GT_BRANDS", "GT_LOCATIONS", "GT_AGENT_LIST", "GT_AUTH_BY_LIST",
          "GT_PREV_PROJCODE", "GT_ORDER_TYPE", "GT_ATTACHMENT_CATEGORIES", "GT_ATTACHMENTS_REQUIRED", "GT_SYS_MESSAGE"]

VT = ["VALUE", "TEXT"]
# Fields that must exist (from the class and the DDIC printouts). Extra live fields are fine.
MUST = {
    "WA_URL_PARAMETERS": ["FORM_GUID", "PROJ", "MODE", "FROM", "PROCESSING_REGION", "COMPANY_CODE"],
    "WA_PROGRAM_STATE": ["PROGRAM_STATE", "PROGRAM_MESSAGE", "INCORRECT_FIELD"],
    "WA_COMMENTS": ["COMMENTS"],
    "WA_CONFIRM_DELETE": ["DELETE_INDEX"],
    "GS_PROJ_FORM": ["STEP_GUID", "PROCESSING_REGION", "REQUESTER_NAME", "REQUESTER_ID", "PROJECTNAME", "PROJECT_TYPE",
                     "CAPEX_REQ_AMOUNT", "CAPEX_REQ_CURR", "COMPANY_CODE", "KOSTL", "ORDER_DATE", "PROJ_COMPLETION_DATE",
                     "BRAND", "LOCATION", "CAPID", "PROJECT_ID", "PROJECT_SUBTYPE", "COMMENTS",
                     "PROJ_FLGRP_0001", "PROJ_FLGRP_0001_MOD", "R_KOSTL", "V_KOSTL", "E_KOSTL",
                     "CREATE", "SUBMITWTH_ERR", "RESUBMIT", "KOSTL_TEXT", "PREV_COMMENTS", "CAN_ATTACH", "PROJECT_ID_OUT"],
    "GS_FORMDETAILS": ["FORM_GUID", "FORM_NAME", "FORM_VER", "INITIATED_BY", "FORM_STATUS", "APPR_STEP",
                       "AGENT_ID_LIST", "WORKCENTER_ID", "START_DATE", "LATEST_STARTTIME"],
    "GS_STEPDETAIL": ["FORM_GUID", "STEP_GUID", "APPR_SEQNO", "APPR_STEP", "STEP_STATUS", "PROCESSED_BY",
                      "COMPLETION_DATE", "COMMENTS"],
    "GS_FORMHEADER": ["FORM_GUID", "INITIATED_BY", "START_DATE", "START_TIME", "OBJECT_NAME", "CURRENT_STEP",
                      "CURRENT_AGENT", "COMMENTS"],
    "GS_EMPLOYEE_INFO": ["PERNR", "ENAME", "EMAIL", "PHONE", "PHONE_TEXT", "CELL", "OTHER"],
    "GS_ATTACHMENT": ["ICON", "FILE_NAME", "MIME_TYPE", "FILE_DATA", "UUID", "CATEGORY", "CATEGORY_TEXT"],
    "GS_MULTIPLECCODE": ["STATUS", "REGION", "COMP_CODE", "COMP_TEXT", "KOSTL_CODE", "KOSTL_TEXT", "DELETABLE",
                         "PROJ_FLGRP_0001", "OUTPUT_CCODE", "IS_ERROR"],
    "GT_APPR": ["STEPS", "STEP_STATUS", "APPROVERID", "APPROVERNAME", "STATUS_ICON", "STATUS_ICON_COLOR", "STATUS_DATE"],
    "GT_ATTACHMENTS": ["ICON", "FILE_NAME", "UUID", "CATEGORY", "CATEGORY_TEXT"],
    "GT_ZCA_AGENT_LIST": ["AGENT_ID", "AGENT_NAME", "AGENT_EMAIL"],
    "GT_ORDERDETAILS": ["OUTPUT_CCODE", "OUTPUT_CCENTER", "PROJECT_CODE", "INTERNAL_ORDER", "ERROR_DESC", "IS_ERROR"],
    "GT_ADDITIONAL_CCODE": ["STATUS", "REGION", "COMP_CODE", "COMP_TEXT", "KOSTL_CODE", "KOSTL_TEXT", "DELETABLE"],
    "GT_INITI_GROUP": ["EXEC_CATEGORY_ID", "INITIATIVE_GRP_ID", "INITIATIVE_GRP_TXT"],
    "GT_INITI_GRP": ["EXEC_CATEGORY_ID", "INITIATIVE_GRP_ID", "INITIATIVE_GRP_TXT"],
    "GT_LOCATIONS": ["PLANT", "LOCATION", "TEXT"],
    "GT_AGENT_LIST": ["OTYPE", "OBJID", "TEXT"],
    "GT_AUTH_BY_LIST": ["OTYPE", "OBJID", "TEXT"],
    "GT_ATTACHMENT_CATEGORIES": ["VALUE", "TEXT", "REQUIRED", "PROJECT_TYPE", "PROJECT_SUBTYPE"],
    "GT_ATTACHMENTS_REQUIRED": ["FORM_NAME", "ATT_CATEGORY", "REQUIRED"],
    "GT_SYS_MESSAGE": ["FIELD_NAME", "TYPE", "ID", "NUMBER", "MESSAGE", "MESSAGE_V1", "MESSAGE_V4"],
}
for t in ["GT_REQUEST_TYPE", "GT_PROJECT_SUBTYPE", "GT_EXEC_CATEGORY", "GT_ASSET_CLASS", "GT_ITL_ASSET_CLASS",
          "GT_CURRENCY", "GT_USSTATE", "GT_COMP_CODE", "GT_ADD_COMP_CCODE", "GT_KOSTL", "GT_GEOGRAPHYLIST",
          "GT_BRANDS", "GT_PREV_PROJCODE", "GT_ORDER_TYPE"]:
    MUST[t] = VT
DATES = {"GS_PROJ_FORM": ["ORDER_DATE", "PROJ_COMPLETION_DATE", "AUTH_BY_DATE"], "GS_FORMDETAILS": ["START_DATE"],
         "GS_STEPDETAIL": ["COMPLETION_DATE"]}
DECIMALS = {"GS_PROJ_FORM": ["CAPEX_REQ_AMOUNT", "ITL_REQ_AMOUNT", "CAPEX_TI_AMOUNT"]}


def local(tag):
    return tag.split("}")[-1]


def main():
    root = ET.parse(sys.argv[1]).getroot()
    ets, cts = {}, {}
    for el in root.iter():
        if local(el.tag) == "EntityType":
            ets[el.get("Name")] = el
        elif local(el.tag) == "ComplexType":
            cts[el.get("Name")] = el
    sets = {el.get("Name") for el in root.iter() if local(el.tag) == "EntitySet"}
    errors = []

    def props(el):
        return {p.get("Name"): p for p in el if local(p.tag) == "Property"}

    def keys(el):
        return [r.get("Name") for k in el if local(k.tag) == "Key" for r in k]

    ajax = ets.get("AJAX")
    if ajax is None:
        errors.append("EntityType AJAX missing (MPC_EXT n2f_define_envelope not active?)")
    else:
        if keys(ajax) != ["AJAX_ID"]:
            errors.append(f"AJAX key must be [AJAX_ID], is {keys(ajax)}")
        if "AJAX_VALUE" not in props(ajax):
            errors.append("AJAX.AJAX_VALUE missing")
        navs = {n.get("Name") for n in ajax if local(n.tag) == "NavigationProperty"}
        for s in STRUCTURES:
            p = props(ajax).get(s)
            if p is None:
                errors.append(f"AJAX complex property {s} missing")
            elif not p.get("Type", "").endswith("." + s):
                errors.append(f"AJAX.{s} must be of complex type {s}, is {p.get('Type')}")
        for t in TABLES:
            if t not in navs:
                errors.append(f"AJAX navigation property {t} missing")
    if "AJAXSet" not in sets:
        errors.append("EntitySet AJAXSet missing")

    for s in STRUCTURES:
        if s not in cts:
            errors.append(f"ComplexType {s} missing")
    for t in TABLES:
        if t not in ets:
            errors.append(f"EntityType {t} missing")
        elif keys(ets[t]) != ["ROW_INDEX"]:
            errors.append(f"EntityType {t} key must be [ROW_INDEX], is {keys(ets[t])}")
        if t + "Set" not in sets:
            errors.append(f"EntitySet {t}Set missing")

    for name, fields in MUST.items():
        el = cts.get(name) if name in STRUCTURES else ets.get(name)
        if el is None:
            continue
        have = props(el)
        for f in fields:
            if f not in have:
                errors.append(f"{name}.{f} missing (property names must equal ABAP component names)")
        lower = [n for n in have if n != n.upper()]
        if lower:
            errors.append(f"{name}: non-ABAP (CamelCase) property names {lower[:5]}")
    for name, fields in DATES.items():
        el = cts.get(name)
        for f in fields if el is not None else []:
            p = props(el).get(f)
            if p is not None and (p.get("Type") != "Edm.String" or p.get("MaxLength") != "8"):
                errors.append(f"{name}.{f} must be Edm.String MaxLength 8 (Neptune yyyyMMdd), is {p.get('Type')} {p.get('MaxLength')}")
    for name, fields in DECIMALS.items():
        el = cts.get(name)
        for f in fields if el is not None else []:
            p = props(el).get(f)
            if p is not None and p.get("Type") != "Edm.Decimal":
                errors.append(f"{name}.{f} must be Edm.Decimal, is {p.get('Type')}")

    att = ets.get("ATTACHMENT")
    if att is None:
        errors.append("EntityType ATTACHMENT missing")
    else:
        if keys(att) != ["FORM", "ATT"]:
            errors.append(f"ATTACHMENT keys must be [FORM, ATT], are {keys(att)}")
        if not any(k.endswith("HasStream") and v == "true" for k, v in att.attrib.items()):
            errors.append("ATTACHMENT must be a media entity (m:HasStream=\"true\")")
    if "ATTACHMENTSet" not in sets:
        errors.append("EntitySet ATTACHMENTSet missing")

    if errors:
        print(f"{len(errors)} problem(s):")
        for e in errors:
            print(" - " + e)
        sys.exit(1)
    print(f"$metadata OK: AJAX + {len(STRUCTURES)} complex types + {len(TABLES)} table entity types + ATTACHMENT.")


if __name__ == "__main__":
    main()
