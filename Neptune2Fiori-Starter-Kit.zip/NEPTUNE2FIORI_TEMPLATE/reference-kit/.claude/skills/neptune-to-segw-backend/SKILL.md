---
name: neptune-to-segw-backend
description: Convert the Neptune backend of ZDCI_NAD_PROJECT_REQUEST (class ZCL_NAD_PROJECT_CODE_REQUEST) into a SEGW OData V2 service ZDCI_UI_PROJECT_REQUEST_SRV with a Neptune-free copy ZCL_UI_PROJECT_CODE_REQUEST, apple-to-apple (same names, same behaviour). Use for any ABAP, SEGW, MPC_EXT, DPC_EXT, Gateway Client, $metadata or backend-parity task in this project.
---

# Neptune → SEGW backend (ZDCI_NAD_PROJECT_REQUEST)

## Before anything

1. Load the registry skill `nad-project-request-registry` and read `01-naming-registry.md`,
   `02-envelope-and-odata-names.md`, `04-ajax-dispatch-inventory.md`, `05-parity-log.md`.
2. The rules are fixed by the project owner: **no name changes**, **behaviour parity including bugs**,
   **SEGW OData V2** (no RAP, no Fiori elements). The only new objects are in `01-naming-registry.md`.
3. Reach SAP through the **SAP ADT MCP server** (ABAP Development Tools for VS Code) when it is available
   in the session — rules in `common/mcp/README.md` (workspace root):
   - Before the first write of a session, state system ID + client and get the user's "yes". Write to the
     **DEV** system only. Never write to QA or PRD; never release transports.
   - Use it to read SE11/SE24 definitions, create/update the ABAP classes from `src/abap/`, run the syntax
     check, activate, and run ABAP Unit / class checks. Always show the activation log result to the user.
   - What the MCP server cannot do (typically SEGW project creation/generation, `/IWFND/MAINT_SERVICE`,
     cache cleanup, Gateway Client) the user does in SAP GUI with the click paths in `references/segw-steps.md`
     and reports back.
   - If no ADT MCP tools are present, fall back: prepare code + click paths, the user pastes/activates and
     reports back. Never claim an activation or test result you did not see.
4. Ask the user once for: ABAP package, transport request, system/client for the Gateway hub. These are
   environment facts, not new names.

## Architecture in one picture

```
UI5 app ──POST AJAXSet (deep insert, one per Neptune AJAX call)──▶ DPC_EXT
                                                                    │ new ZCL_UI_PROJECT_CODE_REQUEST
                                                                    │ envelope component X → attribute X
                                                                    │ handle_on_ajax( ajax_id, ajax_value )
                                                                    │ attribute X → envelope component X
UI5 app ◀──────────────── response (same envelope) ─────────────────┘
UI5 app ──GET ATTACHMENTSet(FORM='…',ATT='…')/$value──▶ DPC_EXT get_stream → handle_on_request
```
MPC_EXT builds the whole OData model from ABAP types with RTTI, so every OData name is the ABAP name.
After B3b the same model is imported into SEGW and MPC_EXT keeps only the deep structure and the bindings.

## Assets (ready to use)

| File | What |
|---|---|
| `assets/abap/ZCL_UI_PROJECT_CODE_REQUEST.clas.abap` (working copy: `src/abap/`) | The converted logic class. Generated from the Neptune source by `assets/convert_class.py`; 28 counted change groups listed in `references/class-conversion-changes.md`; every new comment is one short line starting with the transport number |
| `assets/abap/ZCL_ZDCI_UI_PROJECT_RE_MPC_EXT.clas.abap` | Code-based model: AJAX envelope (11 complex + 27 table navigation properties) + ATTACHMENT media entity |
| `assets/abap/ZCL_ZDCI_UI_PROJECT_RE_DPC_EXT.clas.abap` | Runtime: create_deep_entity / create_entity / get_stream |
| `assets/gateway-client/*.json` | Request bodies for `/IWFND/GW_CLIENT` |
| `assets/abaplint.json` | Offline syntax check config |
| `scripts/check_metadata.py` | Verifies live `$metadata` against the registry |
| `../nad-project-request-registry/scripts/parity_diff.py` | Diffs a Neptune response with the OData response |

All three ABAP files pass the abaplint parser; MPC_EXT/DPC_EXT also pass a semantic check against stubbed
Gateway interfaces. The Gateway API calls are written to the standard SEGW signatures — if activation
reports a signature mismatch, fix the **call** per `references/gateway-api-checklist.md`, never a name.

## Procedure

Track these as tasks. Do not skip B3 — it proves the design on the real Gateway before anything else.

### B0 — Confirm DDIC and dependencies (read-only)
- In SE11 confirm the live field lists of `ZMDG_PROJ_FORM`, `ZMDG_PROJ_FORM_S_READ_ONLY`,
  `ZMDG_PROJ_FORM_S_VISIBLE`, `ZMDG_PROJ_FORM_S_EDITABLE`, `ZMDG_ATT_REQ` (printouts in `DB Model/` are older;
  see `09-source-of-truth.md`). Note new fields in the registry; nothing else to do — RTTI picks them up.
- Confirm the shared objects exist and are unchanged: `ZCL_ND_CA_MDG_WORKFLOW`, `ZCL_ND_CA_UTILITIES`,
  `ZMDG_SEND_EMAIL`, `ZCL_ND_PROJECT_UTILITY`, `Z_MDG_CREATE_INTERNALORDER`, `Z_PS_COPY_TEMPLATE`,
  `Z_BAPI_BC_USER_GETLIST`, `ZCX_CA_FORM_EXCEPTIONS`, `ZCX_PROJECT_CODE_REQUEST`, type group with `ZHRC_*`.

### B1 — Create `ZCL_UI_PROJECT_CODE_REQUEST`

**Comments (owner decision 2026-10-17):** keep every original comment of the Neptune class as it is. Every new conversion comment is **one short line**: the transport number, then a few words — e.g. `" S4MK900123 SERVER removed` or `* S4MK900123 Local message type`. No multi-line explanations in code; details go in the registries/docs. The converter writes `<TR>`; B1 runs it with the workbench transport from `.env` so `<TR>` becomes the real number. The only original lines touched are old commented-out lines that used the variable `ls_neptune_message` (renamed `ls_message`, licence rule).
Run: `python3 -I assets/convert_class.py "docs/neptune-source/Backend Class/ProjectRequest App.txt" src/abap/ZCL_UI_PROJECT_CODE_REQUEST.clas.abap references/class-conversion-changes.md <SAP_TRANSPORT_WB>`.

1. Prove the asset matches the current Neptune source (catches any drift since the kit was built):
   ```zsh
   python3 .claude/skills/neptune-to-segw-backend/assets/convert_class.py \
     "docs/neptune-source/Backend Class/ProjectRequest App.txt" /tmp/ZCL_UI_PROJECT_CODE_REQUEST.clas.abap /tmp/changes.md
   diff /tmp/ZCL_UI_PROJECT_CODE_REQUEST.clas.abap src/abap/ZCL_UI_PROJECT_CODE_REQUEST.clas.abap && echo SAME
   ```
   If the Neptune class in the system is newer than the repo file, download it (SE24 → source-based view),
   save it over `docs/neptune-source/Backend Class/ProjectRequest App.txt`, and rerun the converter. The converter aborts if an
   expected edit point moved — then read the abort message, adjust **only** the match pattern, rerun.
2. Create the class in the package from `src/abap/ZCL_UI_PROJECT_CODE_REQUEST.clas.abap` — via the ADT MCP
   server (create class → write source → activate, after confirming DEV system/client/package/transport), or
   the user does it in ADT/SE24. Activate. Allowed fixes during activation: none to logic. If a type group must be declared explicitly
   (e.g. `TYPE-POOLS zhrc.`), add exactly that line with `" <transport> activation` and log it.
3. Verify with the user (or ADT): method list = Neptune class method list + `HANDLE_ON_AJAX`,
   `HANDLE_ON_REQUEST` − the six `/NEPTUNE/IF_NAD_SERVER~*` methods. Attributes identical + `GT_SYS_MESSAGE`.

### B2 — SEGW project and runtime objects
Click path in `references/segw-steps.md`. Project `ZDCI_UI_PROJECT_REQUEST`, no entity types modelled in
SEGW (the model is code-based until B3b imports it). Generate runtime objects; record the four generated class names in
`01-naming-registry.md`. Service `ZDCI_UI_PROJECT_REQUEST_SRV`.

### B3 — Spike: prove the envelope on this Gateway (stop if it fails)
1. The assets already carry the generated names (set in B2, `01-naming-registry.md`):
   `ZCL_ZDCI_UI_PROJECT_RE_MPC(_EXT)`, `ZCL_ZDCI_UI_PROJECT_RE_DPC(_EXT)`. Check `gc_self` in MPC_EXT holds
   `ZCL_ZDCI_UI_PROJECT_RE_MPC_EXT` and replace `<TR>` with the workbench transport in `src/abap/`.
2. Write MPC_EXT and DPC_EXT from `src/abap/` (ADT MCP or the user), activate. Register the service in `/IWFND/MAINT_SERVICE` (system alias as
   used by the other services on this hub). Run `/IWFND/CACHE_CLEANUP` and `/IWBEP/CACHE_CLEANUP`.
3. Save `$metadata` and run `python3 .claude/skills/neptune-to-segw-backend/scripts/check_metadata.py metadata.xml`.
   Must print `$metadata OK`.
4. In `/IWFND/GW_CLIENT`: POST `/sap/opu/odata/sap/ZDCI_UI_PROJECT_REQUEST_SRV/AJAXSet`, header
   `Content-Type: application/json`, `Accept: application/json`, body `assets/gateway-client/00_spike_GET_DATA_new.json`.
   **Pass criteria** (all set by `create_init` / `populate_f4_help`, independent of customizing):
   HTTP 201; `GS_PROJ_FORM.PAGE_HEADER = "New Project Code Request"`, `GS_PROJ_FORM.REQUEST_FROM = "N"`,
   `GS_PROJ_FORM.CAN_ATTACH = "X"`, `GS_PROJ_FORM.PROCESSING_REGION = "U"`; `GT_CURRENCY.results` and
   `GT_REQUEST_TYPE.results` non-empty; every row carries `ROW_INDEX` 1..n.
   If tables come back empty although `GET_DATA` filled them, or the call fails, STOP and report with the
   `/IWFND/ERROR_LOG` entry — see `references/troubleshooting.md` §Spike.

### B3b — Import the proven model into SEGW (owner requirement 2026-10-18)
Only after B3 passed. Goal: the SEGW **Data Model** folder shows the full model (entity types, entity sets,
all properties, complex types, associations/navigation properties, `ATTACHMENT` media entity), with names
and types identical to the model proven in B3. Never model or rename anything by hand in SEGW.
1. Keep the B3 `$metadata` that printed `$metadata OK` as `docs/capture/metadata-B3.xml` and the B3 spike
   response as `docs/capture/spike-B3.json`.
2. `MPC_EXT` (`src/abap/`): remove the model creation from `define` (`create_entity_type`,
   `create_complex_type`, `create_*property`, `create_entity_set`, `create_association(_set)`) — after the
   import SEGW's MPC creates them and a second create fails. Keep `super->define( )` plus only what SEGW
   cannot express: the deep type `TS_AJAX_DEEP` (used by DPC_EXT `create_deep_entity`), the `TS_*` types, and
   a `bind_structure` per entity/complex type to the same `MPC_EXT` type as in B3 (MPC cannot reference
   types of its subclass). Bump `lc_gen_date_time`. Do not activate yet.
3. SEGW → project → right-click **Data Model** → **Import** → **Data Model from File** → `metadata-B3.xml`
   → Custom Import → select all artifacts → Finish. Check the folder: entity types `AJAX`, 27 table types,
   `ATTACHMENT` (**Media** ticked — set it if the import did not), 11 complex types, 27 associations and
   association sets, navigation properties on `AJAX`, entity set flags as in the metadata.
4. **Generate Runtime Objects** (same names as B2, nothing renamed). Activate MPC_EXT and DPC_EXT; run
   `/IWFND/CACHE_CLEANUP` and `/IWBEP/CACHE_CLEANUP`.
5. Save the new `$metadata` as `docs/capture/metadata-B3b.xml`; `check_metadata.py` must print
   `$metadata OK`, and every name, key, Edm type, MaxLength/Precision/Scale, nullable flag, association and
   navigation property must equal `metadata-B3.xml` (element order may differ).
6. Re-run the spike body; `parity_diff.py docs/capture/spike-B3.json <new response>` → no difference.
   Any difference or failure: STOP, restore the B3 `MPC_EXT` from git, report with `/IWFND/ERROR_LOG`.

### B4 — Every AJAX ID
For each row of `04-ajax-dispatch-inventory.md` run the call in Gateway Client (bodies in
`assets/gateway-client/`, or take a `GET_DATA` response, change `AJAX_ID`, post it back). For state-changing
calls use a test form and check the DB effects listed in the inventory (SE16: `ZMDG_PROJ_FORM`,
`ZCA_FORMDETAIL`, `ZCA_STEPDETAIL`, `ZMDGATTACH`). Expected parity behaviour (e.g. P-01 `CHECK` no-op, P-04
`NEW_INTENALORDER_WEXP` no-op) is a **pass**.

### B5 — Parity against Neptune
With the capture from `06-capture-neptune-payloads.md`, for each AJAX ID save the Neptune response body and
the OData response body, then:
```zsh
python3 .claude/skills/nad-project-request-registry/scripts/parity_diff.py neptune_SAVE.json odata_SAVE.json --ignore FORM_GUID STEP_GUID START_TIME LATEST_STARTTIME
```
Every difference is either fixed (only in DPC_EXT/MPC_EXT or the registry, never by changing the class
logic) or logged as a new `P-xx`.

### B6 — Attachment stream
Open `…/ATTACHMENTSet(FORM='<FORM_GUID>',ATT='<UUID>')/$value` for an existing attachment → file opens.
With a wrong `ATT` → the Neptune error page HTML (P-20).

### B7 — Handover
Tell the frontend skill: service URL, the generated class names, every confirmed/changed registry row,
and any new `P-xx`. Transport: class, SEGW project, MPC/DPC(_EXT), service registration (customizing
transport on the hub), and role/authorization for `S_SERVICE` of the new service.

## Guardrails

- **Licence removal (owner decision 2026-10-14):** no SAP object, type, data element, structure, variable,
  MIME/ICF path or literal used by the new solution may start with or contain `NEPTUNE` or use `/NEPTUNE/`.
  The converter enforces this for `ZCL_UI_PROJECT_CODE_REQUEST` (change groups 26–27, final guard) and
  `verify_kit.py` checks all ABAP. Dependencies (DDIC, shared `ZCL_ND_*` classes, FMs) are scanned in B0.
  Every case goes to `docs/replacements/` (register R-xx + `<session>-replacements.txt`); replacements are
  standard SAP data elements/structures of the same type and length.
- The error page of `redirect_error` is read from `/SAP/BC/BSP/SAP/ZUI_PROJREQCODE/attacherror.html`, so B6
  needs the BSP deployed (or test B6 after S6).

- Never edit business logic in `ZCL_UI_PROJECT_CODE_REQUEST`. Any behavioural difference you find is a
  parity question, not a fix. The only allowed ABAP changes are those in `class-conversion-changes.md`.
- Never add `COMMIT WORK` to DPC_EXT; the class commits where Neptune did (P-12 relies on the implicit commit).
- Never put Send/Receive filtering in the backend — the UI owns it, as Neptune's AJAX objects did.
- Never rename OData artifacts to CamelCase; the UI binds with ABAP names.
- The UI must call the service **without `$batch`** (`useBatch: false` / plain POST): the class issues
  `COMMIT WORK`, which Gateway forbids inside a change set.

## References

- `references/class-conversion-changes.md` — the 28 change groups (generated, authoritative)
- `references/segw-steps.md` — SEGW / registration click paths
- `references/gateway-api-checklist.md` — every Gateway API call used, what to check if activation complains
- `references/troubleshooting.md` — errors and fixes
- `references/offline-checks.md` — abaplint on the Mac
