---
name: n2f-s2-close-gaps
description: S2 — close the gaps listed in docs/coverage-report.md, verbatim from Neptune
disable-model-invocation: true
---

Work as the custom agent `neptune-ui5-converter` (`.claude/agents/neptune-ui5-converter.md`; best: start this session with `claude --agent neptune-ui5-converter`): follow its rules.

Session S2 (close gaps). Work through `docs/coverage-report.md` and `.claude/skills/neptune-to-ui5-frontend/references/spec-gaps.md`, one area at a time (show me the plan for an area before editing).
- Copy Neptune attributes, bindings and event code exactly, following `binding-rules.md` and `js-port-rules.md`. Only the listed mechanical replacements are allowed.
- Remove each `TODO(SPEC-MISSING)` / `TODO(CAPTURE)` marker you close; set `evidence: "CAP"` in `AjaxConfig.js` for confirmed AJAX rows; update registries `03`, `04`, `08` and `spec-gaps.md` in the same change.
- A behaviour that looks wrong stays as Neptune has it → new `P-xx` in `05-parity-log.md`.
- After each area run `python3 .claude/scripts/verify_kit.py` and `npm run test:unit` and show the results. Stop after each area for my review.

**Replacement log (licence removal):** names that start with or contain `NEPTUNE` (or use `/NEPTUNE/`) must not appear in anything the new solution uses in SAP. Log every one you find in `docs/replacements/S2-replacements.txt` (format and rules: `docs/replacements/framework-replacement-register.md`; write `RESULT: none found` if none) and add rows to the register. Replace with standard SAP data elements/structures of the same type and length; never a new DDIC object without approval.
