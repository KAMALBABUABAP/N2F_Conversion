---
name: abap-adt-workflow
description: Safe ABAP development through the SAP ADT MCP server — confirm target, read before write, write, syntax check, activate, test, and report every step in the standard ABAP response format. Use for any task that creates, changes, activates or tests ABAP objects in SAP.
---

# ABAP development through the SAP ADT MCP server

> **Change log** (latest first — add a row for every change)
>
> | Date | Change | Why | By |
> |---|---|---|---|
> | 2026-10-17 | First version, draft for team review | Shared standards for the sap-dev workspace (set up with the NEPTUNE2FIORI_PROJREQ project) | KB |

Workspace rules: `common/mcp/README.md` (DEV only, never release transports) and `common/standards/*.md`.
A project `CLAUDE.md` can override standards (e.g. "do not refactor copied classes") — check it first.

## 1. Before the first write of a session (mandatory)

1. Read `.env` of the project (system ID, client, package, transport). Never print passwords.
2. If the server is a multi-system router (it has `ListSapSystems`): call it, confirm `SAP_SYSTEM_ID` is listed, and
   pass `system` = `SAP_SYSTEM_ID` and `client` = `SAP_CLIENT` on **every** tool call — never rely on the server's
   default system. Then call one read-only ADT tool and state what you are connected to.
3. Ask, and wait for an explicit "yes":
   > Target: system `<SID>` client `<CLNT>`, package `<PKG>`, transport `<TR>`. Objects to create/change: `<list>`. Proceed?
4. Not DEV, or any value unknown → stop and ask. No write without the "yes".

## 2. The loop for every object

| Step | What you do | Stop if |
|---|---|---|
| 1 Read | Read the current source / DDIC from SAP (it may differ from the repo); note version and lock owner | object locked by someone else |
| 2 Compare | Diff SAP source vs the file in `src/abap/`; explain differences | SAP is newer than the repo → ask before overwriting |
| 3 Write | Create the object if it does not exist (package + transport), write the source from `src/abap/` | write refused |
| 4 Check | Run the syntax check; fix only what the task allows (a copied class: no logic changes) | errors you may not fix → report |
| 5 Activate | Activate; read the activation log | inactive objects remain |
| 6 Test | Run ABAP Unit / ATC where the standards require it (`testing-abap-unit.md`) | failures |
| 7 Record | Add the transport/object to `transports/transport-log.md`; update registries if a name was generated | — |
| 8 Licence scan | Search what you wrote and what it uses for names containing `NEPTUNE` or the `/NEPTUNE/` namespace; replace with standard SAP data elements/structures (same type/length) and log in the project's replacement log, if the project has one | a hit you cannot replace without a new DDIC object → ask |

Never: release transports, delete objects without an explicit instruction naming them, write to QA/PRD,
change another developer's locked object, "improve" code outside the task.

## 3. What the ADT MCP server usually cannot do

SEGW generation, `/IWFND/MAINT_SERVICE`, `/IWFND/CACHE_CLEANUP` + `/IWBEP/CACHE_CLEANUP`, `/IWFND/GW_CLIENT`,
PFCG, launchpad customizing. Give the developer the exact SAP GUI click path and the expected result, then
wait for their report. Re-check `common/mcp/README.md` §2 — the tool inventory may have grown.

## 4. Standard ABAP response format (end every step with this)

```markdown
### Result — <step / object>
**Target:** <SID>/<client> · package <PKG> · transport <TR>
**Done:** <what was read / created / written / activated / tested>
**Evidence:** <tool result in one line each: syntax check OK | activation OK | ABAP Unit 12/12 | ATC 0 P1/P2>
**Not done / blocked:** <item + reason, or "none">
**Files changed:** <repo paths>  ·  **Registry/transport log updated:** <yes/no + which>
**Your next action:** <exact SAP GUI step or decision needed, or "none">
```
Report only what a tool actually returned. If a tool call failed, show its error text, not a summary.
