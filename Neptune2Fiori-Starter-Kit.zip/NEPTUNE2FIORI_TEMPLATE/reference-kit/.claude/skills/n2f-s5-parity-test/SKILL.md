---
name: n2f-s5-parity-test
description: S5 — Neptune vs UI5 parity test with payload diffs
disable-model-invocation: true
---

Session S5 (parity). Guide me through `.claude/skills/neptune-to-ui5-frontend/references/test-plan.md` §2 and §3, one row at a time.
For each row I paste (or save under `docs/capture/`) the Neptune and the UI5 request/response bodies; run
`python3 .claude/skills/nad-project-request-registry/scripts/parity_diff.py <neptune.json> <odata.json> --ignore FORM_GUID STEP_GUID START_TIME LATEST_STARTTIME`
and run the matching SQL from `queries/` (ADT MCP read-only, or I run it). Classify every difference: fix in UI (do it, verbatim rules) or new `P-xx` item. Keep a results table in `docs/parity-results.md`.

**Replacement log (licence removal):** names that start with or contain `NEPTUNE` (or use `/NEPTUNE/`) must not appear in anything the new solution uses in SAP. Log every one you find in `docs/replacements/S5-replacements.txt` (format and rules: `docs/replacements/framework-replacement-register.md`; write `RESULT: none found` if none) and add rows to the register. Replace with standard SAP data elements/structures of the same type and length; never a new DDIC object without approval.
