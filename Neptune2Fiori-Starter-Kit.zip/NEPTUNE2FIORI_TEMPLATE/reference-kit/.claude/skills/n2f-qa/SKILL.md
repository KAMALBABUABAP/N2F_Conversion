---
name: n2f-qa
description: Q&A — answer questions about the Neptune app or the conversion; never edits files
disable-model-invocation: true
---

Read-only session.

Answer my question using the registry skill (`.claude/skills/nad-project-request-registry/references/`), `CLAUDE.md` and the Neptune sources in `docs/neptune-source/`. Cite the file (and line where useful). Do not edit files and do not write to SAP. If the answer is not in the files, say so and mark it as an assumption.

Question: <question, taken from the text after the command>

**Replacement log (licence removal):** names that start with or contain `NEPTUNE` (or use `/NEPTUNE/`) must not appear in anything the new solution uses in SAP. Log every one you find in `docs/replacements/qa-replacements.txt` (format and rules: `docs/replacements/framework-replacement-register.md`; write `RESULT: none found` if none) and add rows to the register. Read-only session: propose replacements, do not apply them.
