# Deployment — BSP `ZUI_PROJREQCODE` and launchpad (Mac, zsh)

## 1. One-time tools

```zsh
brew install node@20            # or newer LTS
node --version && npm --version
cd ~/<sap-dev>/projects/NEPTUNE2FIORI_PROJREQ/src/ui5/zdci_nad_project_request
npm install                     # installs @sap/ux-ui5-tooling (fiori CLI), @ui5/cli, @ui5/linter
```
VS Code with the "SAP Fiori tools - Extension Pack" is optional; everything below works in the terminal,
in Claude Code.

## 2. Fill the environment facts

`ui5.yaml` and `ui5-deploy.yaml`: `<gateway-host>`, `<port>`, `<client>`; `ui5-deploy.yaml` also
`<PACKAGE>` and `<TRANSPORT>` (ask the user; create the transport in SE09 first). `app.name` stays
`ZUI_PROJREQCODE`. Credentials: the deploy prompts for user/password; or set them only in the shell:
```zsh
export FIORI_TOOLS_USER='<user>'; export FIORI_TOOLS_PASSWORD='<password>'   # do not commit
```
and add `credentials: { username: env:FIORI_TOOLS_USER, password: env:FIORI_TOOLS_PASSWORD }` under
`target` in `ui5-deploy.yaml`.

The user needs `S_DEVELOP` for BSP objects and authorization for `/UI5/ABAP_REPOSITORY_SRV` (activate it
in `/IWFND/MAINT_SERVICE` if the deploy reports 404/403 on it).

## 3. Build and deploy

```zsh
npm run build                   # dist/ - check it contains Component-preload.js
npm run deploy                  # build + upload to BSP ZUI_PROJREQCODE in the transport
```
Check: SE80 → BSP Application `ZUI_PROJREQCODE` exists; SICF node `/sap/bc/ui5_ui5/sap/zui_projreqcode`
is active. Direct test: `https://<host>:<port>/sap/bc/ui5_ui5/sap/zui_projreqcode/index.html?sap-client=<client>`.
After redeploys run report `/UI5/APP_INDEX_CALCULATE` for `ZUI_PROJREQCODE` if the launchpad shows old code.

## 4. Launchpad — reuse the existing Neptune tile

Find the catalog/target mapping that launches the Neptune app today (`/UI2/FLPD_CUST` or the Launchpad
App Manager `/UI2/FLPAM`). Keep its **semantic object, action and tile texts** (no new names). Change only
the target:

| Field | Value |
|---|---|
| Application type | SAPUI5 Fiori App |
| Title | unchanged |
| URL | `/sap/bc/ui5_ui5/sap/zui_projreqcode` |
| ID | `zdci_nad_project_request` |
| Parameters | keep `form_guid` pass-through (read by `getUrlParameters()`) |

If the business wants Neptune and UI5 in parallel, that needs a second tile = a new name → ask the owner.

The app is also started as a child component by the Neptune parent list app (component data
`{ child: true }`). If that parent app is converted later, it must create this component with
`componentData: { child: true }` and talk over the EventBus channel `discoveryFiori.ZDCI_NAD_PROJECT_REQUEST`
(`util/discoveryFiori.js`) — verify against the original `discoveryFiori.js` (spec-gaps C1, C5).

## 5. Undeploy / rollback

```zsh
npm run undeploy                # removes the BSP (asks for the transport)
```
Rollback during hypercare = point the target mapping back to the Neptune URL.
