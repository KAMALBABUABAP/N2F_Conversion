# AjaxRuntime — the Neptune AJAX runtime on OData V2

## One call

`controller.getOnlineSaveAsDraft()` → `AjaxRuntime.call(controller, "SAVE", value)`:

1. `GET $metadata` once per service (cached) → property names and Edm types of every complex/entity type.
2. CSRF token: `GET <service>/` with `X-CSRF-Token: Fetch` (cached; refetched once on 403 "Required").
3. Body = `{ AJAX_ID, AJAX_VALUE, <Send attributes…>, <every GT_*> }`:
   - for each Send pair `[model, ATTR]` of `AjaxConfig[AJAX_ID]` the model data is converted
     JSON → ABAP (registry `07` + Edm type) and only properties that exist in `$metadata` are kept;
   - tables get `ROW_INDEX` 1..n; tables not sent go as `[]`.
4. `POST <service>/AJAXSet` (plain JSON, no `$batch`, `sap-client` from the page URL if present).
5. On 201: for each Receive pair the attribute is converted ABAP → JSON (`results` unwrapped,
   `__metadata`/`ROW_INDEX` removed) and `model.setData(copy)` — exactly Neptune's receive.
   Then `controller["<AJAX_ID>_ajaxSuccess"]()`.
6. On HTTP/OData error: `controller["<AJAX_ID>_ajaxError"](error)` (`error.message` = Gateway text).

## AjaxConfig format

```js
SAVE: { fn: "getOnlineSaveAsDraft", evidence: "DOC",
        send:    [["cntr_formdetails","GS_FORMDETAILS"], ...],
        receive: [["cntr_formdetails","GS_FORMDETAILS"], ...] }
```
`evidence`: `DOC` (from `Ajax/*.md`), `INF` (inferred — confirm by capture), `CAP` (confirmed).
To confirm a row: compare the HAR report (registry `06`) of that AJAX call — the JSON keys of the Neptune
request are the Send attributes, those of the response the Receive attributes — then fix the arrays and
set `evidence: "CAP"`. Also update registry `04`.

## Conversions (registry 07)

| Kind | Receive (ABAP → JSON) | Send (JSON → ABAP) |
|---|---|---|
| BOOL_TF | `'true'` → `true`, else `false` | `true/false` → `'true'/'false'` |
| BOOL_X | `'X'` → `true`, else `false` | `true/false` → `'X'/''` |
| DATE / TIME | `'00000000'` / `'000000'` → `''` | unchanged (`''` = initial) |
| DECIMAL and any Edm.Decimal/Int64/Double | string → number | Edm.Decimal → string, Int → integer |
| Edm.String with MaxLength | — | cut to MaxLength (ABAP MOVE semantics) |

## Attachments

`AjaxRuntime.attachmentUrl(controller, FORM_GUID, UUID)` → `<service>/ATTACHMENTSet(FORM='…',ATT='…')/$value`
(the backend's `get_stream` calls `HANDLE_ON_REQUEST( key = 'ATTACHMENT' )`). Uploads travel inside the
envelope as base64 in `GT_ATTACHMENTS-FILE_DATA`, exactly like Neptune.

## Troubleshooting

| Symptom (browser DevTools → Network) | Cause | Fix |
|---|---|---|
| `$metadata` 404/403 | service not registered / no `S_SERVICE` | backend B3, role |
| POST 403 | CSRF token missing (proxy dropped header) | check `ui5.yaml` proxy; reload |
| POST 400 "Property X is invalid" | a field not in `$metadata` sneaked in — should be impossible; or a nav property sent as object | check `_buildPayload` output in console |
| POST 400 "invalid value" for a decimal | value not numeric | Neptune would also fail; capture what Neptune sends |
| POST 500 | ABAP dump (see `/IWFND/ERROR_LOG`, ST22) — P-17/P-18 are known | backend skill troubleshooting |
| 201 but a dropdown stays empty | Receive list lacks that model, or the backend did not send the table | `AjaxConfig` / backend B3 |
| control stays busy | AJAX object without handler (P-04, P-37) | capture the Neptune handler |
| `"true"` shown as text / always visible | field missing from registry `07` | add it to `07` + both JSON copies |
