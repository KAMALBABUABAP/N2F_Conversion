# Spec gaps — every inferred element and how to close it

The repo lacks some Neptune specs. The kit fills each gap with the smallest plausible version built only
from existing Neptune names, and marks it. Close every row with the Neptune designer / HAR capture
(registry `06`), then remove the marker and tick the row here.

Find all markers:
```zsh
grep -rn "TODO(SPEC-MISSING)\|TODO(CAPTURE)\|SHIM-RECONSTRUCTED" webapp
```

## A. Missing UI specs (view bindings + event code)

| # | Area / controls | What the kit did | Close by copying from the designer |
|---|---|---|---|
| A1 | ~~`subsectionRequester`~~ | — | **closed** — events S2b (P-43/P-44); attributes S2a from export 00729–01200 (`PROJ_FLGRP_0005`, `ONBEHALF_ID`, `RESP_LEAD_NAME`, `V_AUTH_BY_ID`, texts; P-55, P-56, P-57) |
| A2 | ~~`sfBudgetProj` (project name … ITL currency)~~ | — | **closed** — events S2b; attributes S2a from export 00948–01051 (radio `editable`, texts, `visible=false` fields; invented `selected` expressions removed → P-59; odd bindings P-58) |
| A3 | ~~`subsectionFPA` / `RTR` / `BPC`~~ | — | **closed** — events S2b (P-50); attributes S2a from export 00964–01239: texts, `moreBlocks`, `visible=false` subsection/table/selects (P-60), DISABLED controls removed (P-56) |
| A4 | ~~`hcAttributes`, `vlAttributesBlock1/2`~~ | — | **closed S2a** — export 00776–00812: `hcAttributes` is the `headerContent` aggregation node (no control, invented `ATTRIBUTES_VISIBLE` removed); `attrStartDate`/`attrCurrentStep` are `ObjectStatus`; titles `Budget Manager`, `Requested at`, `Current step`, `Current Agent` |
| A5 | ~~Header buttons `btnNavBack`, `btnPrevOrder`, `btnToggleEdit`, `btnNextOrder`, `titlePagePCreate`~~ | — | **closed** — press code S2b; attributes S2a (export 00716/00633/01179/01181/01180: all three action buttons `visible = NAVIGATION_VISIBLE`, `MODE_BUTTON_VISIBLE` not used) |
| A6 | `oObjectEmpName`, `oObjectAgent` press | → `GET_EMPINFO` + `diaEmployeeInfo.openBy`, `GET_AGENTLIST` + `diaAgents.open()` | **closed S2b** — export 00809/00812: busy on + `getOnlineGetEmplInfo(oObjectEmpName.getText())` / `getOnlineGetAgent()`; the dialogs are opened by the ported ajaxSuccess |
| A7 | ~~`oSelectUSState`, `inpGeography`, `inpCapNumber` values~~ | — | **closed S2a** — `GEOGRAPHY`/`CAPID` confirmed (export 01213/01214, + `V_GEOGRAPHY`, `V_CAPID`, label "Planning ID" + tooltip); `oSelectUSState` DISABLED → removed (P-56) |
| A8 | Upload buttons `btnFPAApprovalAtt`, `btnAttCAPEXLicenseUpload`, `btnAttSoftwareLicenseUpload`, `btnAttAccountingUpload` | → `fu.open()` / `fu.open("CAPEX_LICENSE" / "SOFTWARE_LICENSE" / "ACCOUNTING")` | **press code closed S2b** — export 01242/01233/01234/01235: `fu.categorySelect.setSelectedKey("FPA_APPROVAL" / "CAPEX_LICENSE" / "SOFTWARE_LICENSE" / "ACCOUNTING")` + `fu.uploadDialog.open()`; `categorySelect` → C1/S2d |
| A9 | `btnDeleteCCode`, `inpMultiCostCenter` VH | remove the pressed row; same company-code gate as `inpCostCenter` | **closed S2b** — export 01143/01157/01154/01144 (row index from the event `id`, `dirty.setDirty(true)`; beforeOpen fully commented) |
| A10 | ~~`diaSearchPrevProj`~~ | — | **closed** — events S2b (P-47); dialog DISABLED in the original → fragment removed S2a (P-56) |
| A11 | ~~`diaEmployeeInfo` labels~~ | — | **closed S2a** — export 00786–00797: literal label texts, ids as in the kit |
| A12 | ~~SelectDialog item `description` bindings~~ | — | **closed S2a** — export: `diaGeography`/`diaBrand`/`diaLocation` items use `info` (`VALUE`/`VALUE`/`LOCATION`); on-behalf/auth-by/cost-center items have only `title` (auth-by title P-55) |

## B. Missing AJAX information

| # | Item | Kit | Close by |
|---|---|---|---|
| B1 | ~~Send/Receive of every `INF` row in `AjaxConfig.js`~~ | **closed S2c** — all 23 rows `CAP` from the XML export IT_MODEL (unresolved rows P-40, dead objects P-39, `sysMessage` channel P-42) | — |
| B2 | ~~Handlers of `NEW_PROJECT`~~ | **closed S2c** — export 01237 ported (P-27 closed) | — |
| B3 | ~~Handlers of `AGENT_SEARCH`, `AUTH_BY_SEARCH`, `GET_COSTCENTER`, `UPDATE_REGION`, `GET_EMPINFO`, `GET_AGENTLIST`, `DELETE_ATTACHMENT`~~ | **closed S2c** — export code ported (also `CREATE`, `GET_AUTHBY_ID`, `GET_ONBEHALF_ID`, `NEW_INTENALORDER_WEXP`, `DEQUEUE_FORM`, `BACK`, `CHECK` error) | — |
| B4 | ~~AJAX object names of `GET_EMPINFO`, `GET_AGENTLIST`~~ | **closed S2b** — press code ported from the export (00809/00812), `getOnlineAjax` deleted | — |
| B5 | ~~`diaMessages`~~ | **closed S2c** — not a control in the export; call guarded, `diaMessage` fallback removed (P-36) | — |

## D. Left over from S2b (area 2) for S2a

| # | Item | Why open |
|---|---|---|
| D1 | ~~`butAgentOK_press`, `btnMessageClose_press`~~ | **closed S2a** — both buttons added to `<dependents>` (`oPageDialogs` content, never shown; P-46) |
| D2 | ~~formatters `txtDTableApproversSTATUS_DATE_text`, `attrStartDate_text`, `txtProjectID_text`~~ | **closed S2a** — all three wired into the `text` bindings (export 00475/00779/01239) |
| D3 | ~~`inpPersonResponsible`~~ | **closed S2a** — `showValueHelp`/`valueHelpOnly`/`maxLength`/`description` from export 01236 |
| D4 | ~~`oEmpPhone`~~ | **closed S2a** — export 00861: `text=PHONE_TEXT`, `href=PHONE`; inferred `tel:` removed (P-49) |

## C. Shared resources

| # | Item | Kit | Close by |
|---|---|---|---|
| C1 | ~~`discoveryFiori.js` (ChildComponent, DirtyHandler, FileUploader, showMessage, addExpandButtons)~~ **closed S2d (2026-10-18)** | `util/discoveryFiori.js` ported from `docs/neptune-export/discoveryFiori.js` (no `SHIM-RECONSTRUCTED` left); `TODO(S2d)` callers removed. Launchpad replacements P-51/P-52, kit adaptations P-53/P-54. `ParentComponent`, `displayAttachment` not ported (R-25, R-26) | done |
| C2 | ~~`app.css`~~ | — | **closed S2a** — byte copy of the original MIME `app.css` (= export IT_CSS_DESKTOP + header) |
| C3 | ~~Hidden text controls~~ | — | **closed S2a** — all 19 Translate texts copied verbatim into `i18n.properties` (registry 03) |
| C4 | Template files | `Templates/README.md` | copy the two `.xlsx` files — open: owner supplies the correct files in `docs/neptune-export/`; copy as `webapp/Templates/CAPEX Licenses Questionnaire.xlsx` and `Accounting Questionnaire.xlsx` (href names, S2a) |
| C5 | Parent list app contract (`listRef`, `listIndex`, `loadRequest` event, `form-saved`) | original `window` events, kept 1:1 (S2d, P-51) — see "C5 event contract" below | the list-app project hosts this app with the same events; adapt only the shim |
| C6 | Attachment error page `webapp/attacherror.html` (`TODO(CAPTURE)`, review S2 R-10) | placeholder page with a generic text; served from `/SAP/BC/BSP/SAP/ZUI_PROJREQCODE/attacherror.html` (P-20, register R-08) | open — owner supplies the original `attacherror.html` of the shared app `zdci_nad_customer_form` (old MIME `pages/` folder); copy its content into `webapp/attacherror.html`, remove the `TODO(CAPTURE)` marker, then close P-20 / R-08 |

### C5 event contract (for the list-app conversion project)

`util/discoveryFiori.js` `ChildComponent(caller, "ZDCI_NAD_PROJECT_REQUEST", loadRequest)` uses the original
`window` events (no EventBus, no Neptune runtime):

| Direction | Event name | Payload | When |
|---|---|---|---|
| child → parent | `ZDCI_NAD_PROJECT_REQUESTchild-loaded` (`Event`, no dash) | — | child constructor (`onInit`) |
| parent → child | `data-from-parent` (`CustomEvent`) | `detail: { FORM, ID, FROM, PROJREQ }` → `loadRequest(evt)` | parent opens a form (original `ParentComponent.eventDispatcher` after `child-loaded` + `onAfterShow`) |
| child → parent | `ZDCI_NAD_PROJECT_REQUEST-data-from-child` (`CustomEvent`) | `detail: { event: "form-saved" }` (+ other fields per handler) | after save/submit/back etc. (`dc.sendToParent`) |
| child → parent | `go-back` (`Event`) | — | `dc.goBack()` |

The parent embeds the child with `ComponentContainer` + `componentData: { child: true }` (original
`loadSubComponent`). Without a parent (launchpad tile, no `data-from-parent` received) `goBack()` also navigates
back with `CrossApplicationNavigation.backToPreviousApp()` / `history.go(-1)` (P-51).
