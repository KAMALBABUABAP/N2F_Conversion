# JS port rules — Neptune function → controller method

## The pattern

```js
// Neptune (form.txt)
function validate_date() {
    var error = false;
    if (dpOrderCompDate.getDateValue() < dporderdate.getDateValue()) {
        dpOrderCompDate.setValueState(sap.ui.core.ValueState.Error);
        ...
```
```js
// UI5 (Main.controller.js)
validate_date: function () {
    var dpOrderCompDate = this.byId("dpOrderCompDate"), dporderdate = this.byId("dporderdate");   // aliases
    var error = false;                                                                             // verbatim
    if (dpOrderCompDate.getDateValue() < dporderdate.getDateValue()) {
        dpOrderCompDate.setValueState(ValueState.Error);                                           // mechanical
        ...
```
1. Method name = Neptune function name.
2. First lines = **local aliases** for every Neptune global the body uses:
   - control `X` → `var X = this.byId("X")`
   - model `modelX` → `var modelX = this.model("X")`
   - another Neptune function `f` → `var f = this.f.bind(this)` (keeps the call site unchanged)
   - Neptune globals `dc`, `dirty`, `fu`, `userField`, `listRef`, `listIndex`, `isDirty` → `this.<name>`
   - hidden text `txtX` → `var txtX = this._txt("txtX")` (has `getText()`)
3. Body = Neptune body, verbatim, except the mechanical replacements below.
4. Event handlers are named `<controlId>_<event>` (e.g. `butSave_press`, `diaReject_beforeOpen`) and get
   UI5's `oEvent`; Neptune's `oEvent` is the same object.
5. AJAX handlers are named `<AJAX_ID>_ajaxSuccess` / `<AJAX_ID>_ajaxError`; `AjaxRuntime` calls them.

## Mechanical replacements (the only allowed edits)

| Neptune | UI5 | Why |
|---|---|---|
| `modelX.oData` | `modelX.getData()` | public API |
| `modelX.oData.F = v;` without `refresh()` | `modelX.getData().F = v; // PARITY: no refresh` | keep the missing refresh |
| `sap.ui.core.ValueState.X` | `ValueState.X` (from `sap/ui/core/library`) | module import |
| `sap.m.MessageToast.show` | `MessageToast.show` | module import |
| `new sap.m.Dialog/Button/Text(...)`, `new sap.ui.core.Item`, `new sap.ui.model.Filter` | imported classes | module import |
| `x instanceof sap.m.Input` (etc.) | `x instanceof Input` | module import |
| `jQuery.sap.require("…")` | remove, leave a comment | module import |
| `$.each` | `jQuery.each` (imported `sap/ui/thirdparty/jquery`) | no global |
| `oEvent.oSource` | `oEvent.getSource()` | same object |
| `ctx.getBindingContext()` | `ctx.getBindingContext("<model of that list/dialog>")` | named models |
| control id string given to a UI5 API (`scrollToSection("sectionAttachments")`) | `getControlName("sectionAttachments")` → `this.createId(...)` | view-prefixed ids |
| `debugger` | `// debugger (Neptune source)` | testers' devtools |
| `loadCSS(...)` | not ported — `css/app.css` in manifest | |
| Neptune URL `/neptune/...?key=attachment` | `AjaxRuntime.attachmentUrl(...)` (P-34) | Neptune handler gone |
| `getOnlineX()` | unchanged; `getOnlineX` is a controller method calling `AjaxRuntime.call` | |

Anything else — a fix, a rename, a refactor, "simplifying" duplicate `refresh()` calls, removing dead
branches — is **not allowed**. Duplicate Neptune functions (e.g. `addDirtyEvents` ×3, `getControlName` ×2)
are ported once with a comment, because JavaScript used the last definition and they are identical.

## When Neptune code calls something that does not exist

Keep the call and guard it, mark it, log it: `if (typeof this.f === "function") { this.f(); } // PARITY P-xx`.
Examples: `getOnlineoTreeTable()` (P-19), `setNavVisible()` (P-32), `diaMessages` (P-36).

## When the Neptune code is not available (TODO(SPEC-MISSING))

Write the smallest plausible handler using only existing Neptune functions and names, mark it
`TODO(SPEC-MISSING)` with the reason, and list it in `spec-gaps.md`. Replace it with the real code from
the designer as soon as it is captured.
