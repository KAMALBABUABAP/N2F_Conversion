# Binding rules — Neptune → SAPUI5 XML

## 1. Models

Every Neptune control with a **Model Source** owns its own JSON model. In UI5 that is a named
`JSONModel` on the view, named exactly like the control (`util/ModelRegistry.js`, registry `03`).
Two controls with the same Model Source (e.g. `diaReject` and `diaCreate`, both `WA_COMMENTS`) get two
separate models — `AjaxRuntime` gives each a deep copy.

## 2. Property bindings

| Neptune (designer) | UI5 XML |
|---|---|
| `{ATTR-FIELD}` on a control | `{X>/FIELD}` — **X = nearest ancestor-or-self whose Model Source is ATTR** |
| `{GS_PROJ_FORM-PREV_COMMENTS}` inside `subsectionComments` | `{subsectionComments>/PREV_COMMENTS}` (own model wins over `oPageProj`) |
| `{GS_PROJ_FORM-SAVE}` on `butSave` (page footer) | `{oPageProj>/SAVE}` |
| `{WA_COMMENTS-COMMENTS}` on `oTextAreaReject` (in `diaReject`) | `{diaReject>/COMMENTS}` |
| `{DS_PROJ_FORM-…}`, `{DT_ADDITIONAL_CCODE-…}` (spec OCR) | read as `GS_`/`GT_` (registry `09`) |
| literal `true`/`false`/text | literal |

Boolean properties (`visible`, `enabled`, `required`, `state`) get real booleans because `AjaxRuntime`
applies registry `07` on receive. Do **not** add formatters such as `=== 'true'`.

## 3. Lists and tables (Model Source on the list/table)

```xml
<List id="listAttachments" items="{path: 'listAttachments>/', templateShareable: false}">
  <items><ObjectListItem id="listItemAttachment" title="{listAttachments>FILE_NAME}"/></items>
</List>
```
Neptune `{GT_ATTACHMENTS-FILE_NAME}` in the template → `{listAttachments>FILE_NAME}` (relative, no `/`).
Keep the template's Neptune id; UI5 makes clone ids `<template>-<list>-<index>` like Neptune, so code that
reads `sId.split("-").pop()` (listAttachments delete) still works.

## 4. Select / MultiComboBox with a Model Source

The Select's own model feeds only its items; the selected key binds by rule 2:
```xml
<Select id="oSelectCompCode" selectedKey="{oPageProj>/COMPANY_CODE}"
        items="{path: 'oSelectCompCode>/', templateShareable: false}">
  <core:Item key="{oSelectCompCode>VALUE}" text="{oSelectCompCode>TEXT}"/>
</Select>
```
Neptune "Value Field"/"Label Field" → `key`/`text`. Do **not** set `forceSelection`: the export never sets it
(`UM5_SELECT` rows carry only `change`, `enabled`, `selectedKey`, `setEnableCache`, `setInitLoad`, `visible`),
so the original ran with the UI5 default `true` — a list without a blank row pre-selects its first entry, and a
stored key that is not in the list is replaced by the first item through the two-way binding (owner decision
review S2 R-2, 2026-10-18). `setEnableCache`/`setInitLoad=cache` are Neptune-only — drop them.
`oSelectInitPrd_Grp` keeps its binding although `updateinitgrp()` rebuilds its items in code (same in Neptune).

## 5. Dialogs

- Each dialog is a fragment in `view/fragments/<dialogId>.fragment.xml`, included with
  `<core:Fragment fragmentName="zdci_nad_project_request.view.fragments.<id>" type="XML"/>` in
  `oPageProj`'s `<dependents>` → ids get the view prefix, `this.byId("<id>")` works, models propagate.
- Neptune `leftButton`/`rightButton` → `beginButton`/`endButton` (same visual order: left = begin).
- `beginButton`/`endButton` associations pointing to buttons → put the button in that aggregation.
- `SelectDialog` with a Model Source: `items="{path:'<dialogId>>/', templateShareable:false}"`, item
  template `StandardListItem title="{<dialogId>>TEXT}"`.

## 6. Containers and non-Form content

`UM5_OPSUBC` with `position=MoreBlock` (`RequesterBlock`, `ProjDetailBlock`, `attachBlock1`, `CommentsBlock`, …) = no
runtime control; forms go directly into `uxap:moreBlocks`. Each child is its own ObjectPage block, which gives the two-column
layout (layout parity L-01…L-04, 2026-10-20). Mark the place with a one-line comment
`<!-- <id> = moreBlocks aggregation node of the original designer, no runtime control -->`.
HBox/VBox/Table inside a SimpleForm log "not valid Form content" warnings in the console — harmless, kept
because the Neptune tree has them there (`validateRequiredAll` walks the same structure).

## 7. Things that are not controls

- Data-only containers (`cntr_formdetails`, `cntr_stepdetails`, `UrlParameters`, `ProgramState`,
  `CompanyCodes`, `AttachmentCategories`, `AttachmentsRequired`) are models only.
- Hidden text controls (`txtSaveDraft`, …) are i18n keys with the same names.
- `oShell` is the standalone `index.html` container only; the launchpad provides the shell.
- `oBusyIndicator` → `oApp.setBusy()` (App busy indicator, `busyIndicatorDelay="0"`).
- `oPageDialogs` → the `<dependents>` aggregation.

## 8. Ids that conflict between documents

`oDDraftText` vs `sDDraftText`, `oSelectMultiCCode` vs `oSelectMultiCCCode`, `diaMessages` vs
`diaMessage`, `cFormEmployeeInfo` vs `oFormEmployeeInfo`. The kit uses the value noted in the fragment
comment; confirm in the Neptune designer and fix the id if it differs (that is a correction, not a rename).
**Outcome S2a (2026-10-18):** the XML export decided every conflict — export spelling used: `oDDraftText`, `oSelectMultiCCode`, `diaMessage` (`diaMessages` is not a control, P-36), `oFormEmployeeInfo`, `listOnBehalf_Person`.
