# Test plan

## 1. Offline (every change)

| Check | Command (in the app folder) | Pass |
|---|---|---|
| JS syntax | `for f in webapp/**/*.js(N); do node --check $f || echo BAD $f; done` | no `BAD` |
| XML well-formed | `for f in webapp/view/**/*.xml(N); do xmllint --noout $f; done` | silent |
| Conversion unit test | `npm run test:unit` | `9 tests passed` (or more) |
| Browser smoke test | `npm run start-smoke &` then `npm run test:smoke` | `all smoke checks passed` |
| Kit consistency | `python3 ../../../.claude/scripts/verify_kit.py` | `KIT OK` |

### Lint
`npm run lint` (UI5 linter) checks UI5 **2.x** readiness. On this 1.102/1.108 app these findings are
expected and accepted: `manifest.json` version 1 / min UI5 version, `valueHelpOnly` deprecated,
`sap.ushell` global and `Core.getEventBus/byId` in `util/discoveryFiori.js`, legacy bootstrap attribute
spelling in `index.html`, `sap.ui.getCore().byId` in `Main.controller.js` `CREATE_ajaxSuccess` (export 00141),
deprecated `headerDesign` on `tabOrderdetails` in `Main.view.xml` (export IT_ATTRIBUTES 01097) — both export
verbatim (review S2 R-12). Anything else is a real finding — fix it without renaming.

## 2. Against the backend (`npm start`)

Network tab open, filter `AJAXSet`.

| # | Action | Expect |
|---|---|---|
| 1 | open app without `form_guid` | after ~1 s one `GET_DATA` POST; title `New Project Code Request`; region US/LA; dropdowns filled; busy off |
| 2 | open with `?form_guid=<draft>` (FLP: `#…&form_guid=`) | `GET_DATA` with `WA_URL_PARAMETERS.FORM_GUID`; data shown; scrolls to the expanded group |
| 3 | change Company Code | `GET_COSTCENTER` with `AJAX_VALUE: "*"`; cost center cleared |
| 4 | Cost Center VH without company code | message "Company code is required to select Cost Center" |
| 5 | Cost Center search "abc" | `GET_COSTCENTER` with `AJAX_VALUE: "abc"`; list filtered |
| 6 | Save | `SAVE`; toast `txtSaveDraft`; `GET_DATA` reload |
| 7 | add attachment (category + file), Save | row in list; `GT_ATTACHMENTS[0].FILE_DATA` base64 in SAVE |
| 8 | open saved attachment | new tab `ATTACHMENTSet(...)/$value` |
| 9 | delete unsaved / saved attachment | unsaved: local only; saved: `DELETE_ATTACHMENT` |
| 10 | Submit with a required field empty | field red "Entry is required."; no POST |
| 11 | Submit (valid) | `CHECK` → `diaSubmit`; Submit → `SUBMIT` (or `NEW_PROJECT` if RTR group) → toast → back |
| 12 | Reject with empty comment | toast "Comments are Required on Reject" (center) |
| 13 | Reject with comment | `REJECT` → toast `txtRejected` → back |
| 14 | Withdraw | `CLOSE` → toast `txtTranslateWithdrawn` |
| 15 | Resubmit | `diaReSubmit` closes once; busy stays on until the `RESUBMIT` answer; then toast `txtTranslateResubmit` → back (export 00927; P-10 withdrawn) |
| 16 | Change (edit mode, BUDGET_MANAGER) | `CHECK` → `diaChange` → `CHANGE` |
| 17 | Delete draft | `diaDelDraft` → `DELETE` → message `txtDeleteDraft` |
| 18 | Submit with error (RTR) | `NEW_INTENALORDER_WEXP` → nothing happens, busy stays (P-04) |
| 19 | employee popover / agents dialog | `GET_EMPINFO` / `GET_AGENTLIST` (if A6 confirmed) |
| 20 | launchpad: leave with unsaved changes | FLP dirty-state prompt |

## 3. Parity (Neptune vs UI5)

For each row in §2: run the same action in Neptune and UI5 on twin test forms, save both request and
response bodies (DevTools → right-click → Copy response), then:
```zsh
python3 ../../../.claude/skills/nad-project-request-registry/scripts/parity_diff.py neptune_SAVE.json odata_SAVE.json \
  --ignore FORM_GUID STEP_GUID START_TIME LATEST_STARTTIME
```
Also compare visually: field visibility/enablement/required stars per workflow step (requester, FPA, RTR,
BPC, display mode). Differences → fix in the UI or log `P-xx`.
