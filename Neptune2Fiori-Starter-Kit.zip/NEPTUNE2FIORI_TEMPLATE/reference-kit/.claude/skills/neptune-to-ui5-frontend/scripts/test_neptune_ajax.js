#!/usr/bin/env node
/*
 * Offline unit test of the Neptune AJAX emulation (no SAP system, no browser).
 *   node scripts/test_neptune_ajax.js [path/to/webapp]
 * Loads util/*.js with a minimal sap.ui.define stub and checks:
 *   - $metadata parsing
 *   - payload: AJAX_ID/AJAX_VALUE, Send filtering, every GT_* present, ROW_INDEX, unknown fields dropped,
 *     BOOL_TF / BOOL_X / Edm.Decimal / Int / maxLength conversions
 *   - response: results unwrap, __metadata/ROW_INDEX stripped, BOOL_TF / BOOL_X / DATE / DECIMAL conversions,
 *     separate copies per model
 *   - ModelData Find/Add/Delete
 */
"use strict";
const fs = require("fs");
const path = require("path");
const assert = require("assert");

const webapp = path.resolve(process.argv[2] || path.join(__dirname, "..", "assets", "webapp"));
const mods = {};
function load(name) {
    if (mods[name]) return mods[name];
    const src = fs.readFileSync(path.join(webapp, "util", name + ".js"), "utf8");
    let result;
    const sap = { ui: { define: (deps, fn) => {
        const args = deps.map(d => d.startsWith("./") ? load(d.slice(2)) : {});
        result = fn.apply(null, args);
    } } };
    new Function("sap", "window", src)(sap, { location: { search: "" } });
    mods[name] = result;
    return result;
}

class FakeModel {
    constructor(d) { this.d = d; this.refreshed = 0; }
    getData() { return this.d; }
    setData(d) { this.d = d; }
    refresh() { this.refreshed++; }
}

const Ajax = load("AjaxRuntime");
const ModelData = load("ModelData");
const Registry = load("JsonConversionRegistry");

const META = `<?xml version="1.0"?><edmx:Edmx><edmx:DataServices><Schema Namespace="ZDCI_UI_PROJECT_REQUEST_SRV">
<EntityType Name="AJAX"><Key><PropertyRef Name="AJAX_ID"/></Key>
  <Property Name="AJAX_ID" Type="Edm.String" Nullable="false"/><Property Name="AJAX_VALUE" Type="Edm.String"/>
  <Property Name="GS_PROJ_FORM" Type="ZDCI_UI_PROJECT_REQUEST_SRV.GS_PROJ_FORM" Nullable="false"/>
</EntityType>
<ComplexType Name="GS_PROJ_FORM">
  <Property Name="PROJECTNAME" Type="Edm.String" MaxLength="10"/>
  <Property Name="SUBMIT" Type="Edm.String" MaxLength="5"/>
  <Property Name="V_KOSTL" Type="Edm.String" MaxLength="5"/>
  <Property Name="CAN_ATTACH" Type="Edm.String" MaxLength="1"/>
  <Property Name="CAPEX_REQ_AMOUNT" Type="Edm.Decimal" Precision="15" Scale="2"/>
  <Property Name="ORDER_DATE" Type="Edm.String" MaxLength="8"/>
  <Property Name="PROJECT_TYPE" Type="Edm.String" MaxLength="1"/>
</ComplexType>
<ComplexType Name="WA_URL_PARAMETERS"><Property Name="FORM_GUID" Type="Edm.String"/><Property Name="MODE" Type="Edm.String"/></ComplexType>
<EntityType Name="GT_ATTACHMENTS"><Key><PropertyRef Name="ROW_INDEX"/></Key>
  <Property Name="ROW_INDEX" Type="Edm.Int32" Nullable="false"/>
  <Property Name="FILE_NAME" Type="Edm.String"/><Property Name="UUID" Type="Edm.String"/><Property Name="CATEGORY" Type="Edm.String"/>
</EntityType>
<EntityType Name="GT_ATTACHMENTS_REQUIRED"><Key><PropertyRef Name="ROW_INDEX"/></Key>
  <Property Name="ROW_INDEX" Type="Edm.Int32" Nullable="false"/><Property Name="REQUIRED" Type="Edm.String" MaxLength="1"/>
</EntityType>
</Schema></edmx:DataServices></edmx:Edmx>`;

let n = 0;
function t(name, fn) { fn(); n++; console.log("ok - " + name); }

const types = Ajax._parseMetadata(META);
t("metadata parsed", () => {
    assert.strictEqual(types.GS_PROJ_FORM.CAPEX_REQ_AMOUNT.type, "Edm.Decimal");
    assert.strictEqual(types.GS_PROJ_FORM.PROJECTNAME.maxLength, 10);
    assert.strictEqual(types.GT_ATTACHMENTS.ROW_INDEX.type, "Edm.Int32");
});

const models = {
    oPageProj: new FakeModel({ PROJECTNAME: "A very long project name", SUBMIT: true, V_KOSTL: false, CAN_ATTACH: true,
        CAPEX_REQ_AMOUNT: 1500.5, ORDER_DATE: "", PROJECT_TYPE: "2", V_PROJECT_SUBTYPE: true /* UI-only field */ }),
    cntr_formdetails: new FakeModel({}), cntr_stepdetails: new FakeModel({}),
    listAttachments: new FakeModel([{ FILE_NAME: "a.pdf", UUID: "", CATEGORY: "ACCOUNTING", FILE_DATA_UI: "x" }]),
    tabMultiCC: new FakeModel([]), UrlParameters: new FakeModel({ FORM_GUID: "G1", MODE: "" }),
    ProgramState: new FakeModel({}), sysMessage: new FakeModel([]), diaSubmit: new FakeModel({})
};
const fnModel = (s) => models[s];

const body = Ajax._buildPayload("SUBMIT", undefined, fnModel, types);
t("payload envelope keys", () => {
    assert.strictEqual(body.AJAX_ID, "SUBMIT");
    assert.strictEqual(body.AJAX_VALUE, "");
    Registry.TABLES.forEach(tb => assert.ok(Array.isArray(body[tb]), tb + " must be an array"));
    assert.deepStrictEqual(body.WA_URL_PARAMETERS, { FORM_GUID: "G1", MODE: "" }, "in SUBMIT send list (export IT_MODEL)");
    assert.strictEqual(body.WA_CONFIRM_DELETE, undefined, "not in SUBMIT send list");
});
t("payload conversions", () => {
    const f = body.GS_PROJ_FORM;
    assert.strictEqual(f.SUBMIT, "true");
    assert.strictEqual(f.V_KOSTL, "false");
    assert.strictEqual(f.CAN_ATTACH, "X");
    assert.strictEqual(f.CAPEX_REQ_AMOUNT, "1500.5");
    assert.strictEqual(f.PROJECTNAME, "A very lon", "MaxLength cut (ABAP MOVE)");
    assert.strictEqual(f.ORDER_DATE, "");
    assert.ok(!("V_PROJECT_SUBTYPE" in f), "unknown field dropped");
});
t("payload table rows", () => {
    assert.deepStrictEqual(body.GT_ATTACHMENTS, [{ FILE_NAME: "a.pdf", UUID: "", CATEGORY: "ACCOUNTING", ROW_INDEX: 1 }]);
});
t("payload ajax value", () => {
    const b = Ajax._buildPayload("GET_COSTCENTER", "*", fnModel, types);
    assert.strictEqual(b.AJAX_VALUE, "*");
    assert.deepStrictEqual(b.WA_URL_PARAMETERS, { FORM_GUID: "G1", MODE: "" });
});

// response
const m2 = {
    oPageProj: new FakeModel({}), subsectionComments: new FakeModel({}), diaDelDraft: new FakeModel({}),
    AttachmentsRequired: new FakeModel([])
};
const fakeCfgD = {
    GS_PROJ_FORM: { __metadata: {}, SUBMIT: "true", V_KOSTL: "false", CAN_ATTACH: "X", CAPEX_REQ_AMOUNT: "1000.00",
        ORDER_DATE: "00000000", PROJECT_TYPE: "2", PREV_COMMENTS: "c" },
    GT_ATTACHMENTS_REQUIRED: { results: [{ __metadata: {}, ROW_INDEX: 1, REQUIRED: "X" }, { ROW_INDEX: 2, REQUIRED: "" }] }
};
// apply only the receive pairs we have models for: use a tiny custom config through GET_DATA filtered
const Cfg = load("AjaxConfig");
const saved = Cfg.GET_DATA.receive;
Cfg.GET_DATA.receive = [["oPageProj", "GS_PROJ_FORM"], ["subsectionComments", "GS_PROJ_FORM"],
    ["diaDelDraft", "GS_PROJ_FORM"], ["AttachmentsRequired", "GT_ATTACHMENTS_REQUIRED"]];
Ajax._applyResponse("GET_DATA", fakeCfgD, (s) => m2[s], types);
Cfg.GET_DATA.receive = saved;
t("response conversions", () => {
    const d = m2.oPageProj.getData();
    assert.strictEqual(d.SUBMIT, true);
    assert.strictEqual(d.V_KOSTL, false);
    assert.strictEqual(d.CAN_ATTACH, true);
    assert.strictEqual(d.CAPEX_REQ_AMOUNT, 1000);
    assert.strictEqual(d.ORDER_DATE, "");
    assert.strictEqual(d.PROJECT_TYPE, "2");
    assert.ok(!("__metadata" in d));
});
t("response tables", () => {
    assert.deepStrictEqual(m2.AttachmentsRequired.getData(), [{ REQUIRED: true }, { REQUIRED: false }]);
});
t("separate model copies", () => {
    m2.oPageProj.getData().PREV_COMMENTS = "changed";
    assert.strictEqual(m2.subsectionComments.getData().PREV_COMMENTS, "c");
});

// ModelData
t("ModelData Find/Add/Delete", () => {
    const req = new FakeModel([{ PROJECT_TYPE: "2", PROJECT_SUBTYPE: "00", REQUIRED: true, ATT_CATEGORY: "ACCOUNTING" },
                               { PROJECT_TYPE: "2", PROJECT_SUBTYPE: "00", REQUIRED: false, ATT_CATEGORY: "X" }]);
    assert.strictEqual(ModelData.Find(req, ["PROJECT_TYPE", "PROJECT_SUBTYPE", "REQUIRED"], ["2", "00", true], ["EQ", "EQ", "EQ"]).length, 1);
    assert.strictEqual(ModelData.Find(req, "ATT_CATEGORY", "acc", "CP").length, 1);
    ModelData.Add(req, { ATT_CATEGORY: "NEW" });
    assert.strictEqual(req.getData().length, 3);
    ModelData.Delete(req, "ATT_CATEGORY", "NEW", "EQ");
    assert.strictEqual(req.getData().length, 2);
    const ctl = { getId: () => "app---Main--listAttachments", getModel: (n) => n === "listAttachments" ? req : undefined };
    assert.strictEqual(ModelData.Find(ctl, "ATT_CATEGORY", "X", "EQ").length, 1);
});

console.log(`\n${n} tests passed`);
