#!/usr/bin/env node
/*
 * Browser smoke test WITHOUT an SAP system.
 * Serves nothing itself: start the app first (`npx ui5 serve --port 8080` with the OpenUI5 framework in
 * ui5-smoke.yaml), then:   node smoke.js http://localhost:8080/index.html
 * The OData service is mocked with Playwright request interception (mock-data.js).
 * Checks: app boots, every control id / dialog exists, GET_DATA fills the models, booleans convert,
 * Save -> SAVE payload, Submit -> CHECK -> diaSubmit -> SUBMIT, no console errors.
 */
"use strict";
// resolve playwright from the app project (cwd), where `npm install` put it
const { chromium } = require(require.resolve("playwright", { paths: [process.cwd(), __dirname] }));
const mock = require("./mock-data");

const url = process.argv[2] || "http://localhost:8080/index.html";
const SRV = "/sap/opu/odata/sap/ZDCI_UI_PROJECT_REQUEST_SRV/";

(async () => {
    const launch = { headless: true };
    if (process.env.PW_CHROMIUM) launch.executablePath = process.env.PW_CHROMIUM;
    const browser = await chromium.launch(launch);
    const page = await browser.newPage();
    const errors = [];
    const calls = [];
    page.on("console", m => { if (m.type() === "error") errors.push(m.text()); });
    page.on("pageerror", e => errors.push("pageerror: " + e.message));

    await page.route("**" + SRV + "**", async route => {
        const req = route.request();
        const u = req.url();
        if (u.includes("$metadata")) {
            return route.fulfill({ status: 200, contentType: "application/xml", body: mock.metadata() });
        }
        if (req.method() === "GET") {
            return route.fulfill({ status: 200, headers: { "x-csrf-token": "TOKEN" }, contentType: "application/json", body: '{"d":{"EntitySets":["AJAXSet"]}}' });
        }
        if (req.method() === "POST" && u.includes("AJAXSet")) {
            const body = JSON.parse(req.postData());
            calls.push(body);
            return route.fulfill({ status: 201, contentType: "application/json", body: JSON.stringify({ d: mock.respond(body) }) });
        }
        return route.fulfill({ status: 404, body: "" });
    });

    let failed = 0;
    const check = (cond, msg) => { console.log((cond ? "ok - " : "NOT OK - ") + msg); if (!cond) failed++; };
    const waitCall = async (id, ms = 8000) => {
        const t0 = Date.now();
        while (Date.now() - t0 < ms) {
            const c = calls.find(x => x.AJAX_ID === id && !x._seen);
            if (c) { c._seen = true; return c; }
            await page.waitForTimeout(100);
        }
        return null;
    };
    const ui = (fn, arg) => page.evaluate(fn, arg);

    await page.goto(url);
    const get1 = await waitCall("GET_DATA", 20000);
    check(!!get1, "GET_DATA sent on start (Init.txt 1000 ms timer)");
    if (get1) {
        check(Array.isArray(get1.GT_KOSTL) && get1.GT_KOSTL.length === 0, "every navigation property sent ([] when not in Send list)");
        check(get1.WA_URL_PARAMETERS && get1.WA_URL_PARAMETERS.FORM_GUID === "", "UrlParameters sent");
    }
    await page.waitForTimeout(1500);

    const state = await ui(() => {
        const v = sap.ui.getCore().byId("container-zdci_nad_project_request---Main");
        const byId = id => v.byId(id);
        return {
            title: byId("titlePagePCreate").getText(),
            submitVisible: byId("butSubmit").getVisible(),
            saveVisible: byId("butSave").getVisible(),
            rejectVisible: byId("butReject").getVisible(),
            projTypes: byId("oSelectProjType").getItems().length,
            canAttach: v.getModel("oPageProj").getProperty("/CAN_ATTACH"),
            busy: byId("oApp").getBusy(),
            dialogs: ["diaAddMultiCC","diaReSubmit","diaAgents","diaConfirmAttDelete","diaAddAttachment",
                "diaEmployeeInfo","diaReject","diaTimeout","diaCreate","diaChange","diaSubmit","diaSubmitWthErr","diaDelDraft",
                "diaClose","diaMessage","diaSearchAuthBy","diaSearchOnBehalf","diaSearchCostCenter","diaGeography","diaBrand",
                "diaLocation"].filter(id => !byId(id)),
            region: byId("rbgQProcessingRegion").getSelectedIndex(),
            comments: byId("oTextAreaPrevComments").getValue()
        };
    });
    check(state.title === "New Project Code Request", "titlePagePCreate bound to GS_PROJ_FORM-PAGE_HEADER");
    check(state.saveVisible === true && state.submitVisible === true && state.rejectVisible === false, "footer buttons follow 'true'/'false' flags (BOOL_TF)");
    check(state.projTypes === 3, "oSelectProjType items from its own model");
    check(state.canAttach === true, "CAN_ATTACH 'X' -> true (BOOL_X)");
    check(state.busy === false, "busy released by GET_DATA ajaxSuccess");
    check(state.dialogs.length === 0, "all 21 dialogs present " + JSON.stringify(state.dialogs));
    check(state.region === 0, "setprocessingregion(): U -> index 0");
    check(state.comments === "previous comment", "subsectionComments has its own copy of GS_PROJ_FORM");

    // Save
    await ui(() => sap.ui.getCore().byId("container-zdci_nad_project_request---Main--butSave").firePress());
    const save = await waitCall("SAVE");
    check(!!save && save.GS_PROJ_FORM.ITL === "N" && save.GS_PROJ_FORM.SAVE === "true", "SAVE payload: ITL from rbITLYes, booleans back to 'true'");
    const get2 = await waitCall("GET_DATA");
    check(!!get2, "SAVE ajaxSuccess reloads via getOnlineGetDetail()");
    await page.waitForTimeout(1200);

    // Submit -> CHECK -> diaSubmit -> SUBMIT (fill required fields first)
    await ui(() => {
        const v = sap.ui.getCore().byId("container-zdci_nad_project_request---Main");
        v.getModel("oPageProj").setProperty("/PROJECTNAME", "Smoke");
    });
    await ui(() => sap.ui.getCore().byId("container-zdci_nad_project_request---Main--butSubmit").firePress());
    const chk = await waitCall("CHECK");
    check(!!chk, "butSubmit -> validateRequiredAll() -> CHECK");
    await page.waitForTimeout(500);
    const open = await ui(() => sap.ui.getCore().byId("container-zdci_nad_project_request---Main--diaSubmit").isOpen());
    check(open, "CHECK ajaxSuccess opens diaSubmit");
    await ui(() => {
        const v = sap.ui.getCore().byId("container-zdci_nad_project_request---Main");
        v.byId("oTextAreaSubmit").setValue("my comment");
        v.byId("butSubmitSave").firePress();
    });
    const sub = await waitCall("SUBMIT");
    check(!!sub && sub.GS_PROJ_FORM.COMMENTS === "my comment", "SUBMIT carries COMMENTS from oTextAreaSubmit");

    await page.waitForTimeout(800);
    // PARITY P-62: oFormStatusIcon color "Green" (export) is not a CSSColor - UI5 logs it, same as the original
    const relevant = errors.filter(e => !/favicon|Failed to load resource.*404/.test(e)
        && !/"Green" is not of type sap\.ui\.core\.CSSColor/.test(e));
    check(relevant.length === 0, "no console errors" + (relevant.length ? ":\n  " + relevant.join("\n  ") : ""));

    await browser.close();
    console.log(failed ? `\n${failed} check(s) FAILED` : "\nall smoke checks passed");
    process.exit(failed ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
