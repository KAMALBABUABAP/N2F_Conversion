/* Mock OData answers for smoke.js - shaped like the real envelope (registry 02). Values are ABAP-style. */
"use strict";

function metadata() {
    const str = n => `<Property Name="${n}" Type="Edm.String"/>`;
    const projFields = ["PROJECTNAME","PAGE_HEADER","REQUEST_FROM","CAN_ATTACH","PROCESSING_REGION","SAVE","SUBMIT",
        "REJECT","CREATE","CHANGE","DELETE","WITHDRAWN","RESUBMIT","SUBMITWTH_ERR","PROJ_FLGRP_0001","PROJ_FLGRP_0001_MOD",
        "R_PROJECTNAME","V_PROJECTNAME","ITL","COMMENTS","PREV_COMMENTS","PROJECT_TYPE","DISPLAY_OR_EDIT"];
    const vt = name => `<EntityType Name="${name}"><Key><PropertyRef Name="ROW_INDEX"/></Key><Property Name="ROW_INDEX" Type="Edm.Int32" Nullable="false"/>${str("VALUE")}${str("TEXT")}</EntityType>`;
    return `<?xml version="1.0" encoding="utf-8"?><edmx:Edmx Version="1.0" xmlns:edmx="http://schemas.microsoft.com/ado/2007/06/edmx"><edmx:DataServices><Schema Namespace="ZDCI_UI_PROJECT_REQUEST_SRV">
<EntityType Name="AJAX"><Key><PropertyRef Name="AJAX_ID"/></Key>${str("AJAX_ID")}${str("AJAX_VALUE")}</EntityType>
<ComplexType Name="GS_PROJ_FORM">${projFields.map(str).join("")}<Property Name="CAPEX_REQ_AMOUNT" Type="Edm.Decimal" Precision="15" Scale="2"/></ComplexType>
<ComplexType Name="WA_URL_PARAMETERS">${["FORM_GUID","PROJ","MODE","FROM","PROCESSING_REGION","COMPANY_CODE"].map(str).join("")}</ComplexType>
<ComplexType Name="WA_PROGRAM_STATE">${["PROGRAM_STATE","PROGRAM_MESSAGE","INCORRECT_FIELD"].map(str).join("")}</ComplexType>
<ComplexType Name="GS_FORMDETAILS">${["FORM_GUID","APPR_STEP"].map(str).join("")}</ComplexType>
${vt("GT_REQUEST_TYPE")}${vt("GT_CURRENCY")}${vt("GT_KOSTL")}
</Schema></edmx:DataServices></edmx:Edmx>`;
}

function results(rows) { return { results: rows.map((r, i) => Object.assign({ __metadata: { type: "x" }, ROW_INDEX: i + 1 }, r)) }; }

function respond(body) {
    const d = { AJAX_ID: body.AJAX_ID, AJAX_VALUE: body.AJAX_VALUE };
    Object.keys(body).forEach(k => { if (/^GT_/.test(k)) d[k] = results([]); });
    d.GS_PROJ_FORM = { PROJECTNAME: "", PAGE_HEADER: "New Project Code Request", REQUEST_FROM: "N", CAN_ATTACH: "X",
        PROCESSING_REGION: "U", SAVE: "true", SUBMIT: "true", REJECT: "false", CREATE: "false", CHANGE: "false",
        DELETE: "false", WITHDRAWN: "false", RESUBMIT: "false", SUBMITWTH_ERR: "false", PROJ_FLGRP_0001: "true",
        PROJ_FLGRP_0001_MOD: "Expanded", R_PROJECTNAME: "true", V_PROJECTNAME: "true", ITL: "N",
        PREV_COMMENTS: "previous comment", CAPEX_REQ_AMOUNT: "0.00", DISPLAY_OR_EDIT: "EDIT" };
    if (body.GS_PROJ_FORM && body.GS_PROJ_FORM.PROJECTNAME) d.GS_PROJ_FORM.PROJECTNAME = body.GS_PROJ_FORM.PROJECTNAME;
    d.WA_PROGRAM_STATE = { PROGRAM_STATE: "", PROGRAM_MESSAGE: "", INCORRECT_FIELD: "" };
    d.GS_FORMDETAILS = { FORM_GUID: "", APPR_STEP: "REQUESTER" };
    d.GT_REQUEST_TYPE = results([{ VALUE: "1", TEXT: "Capex" }, { VALUE: "2", TEXT: "Capex TI" }, { VALUE: "3", TEXT: "ITL" }]);
    d.GT_CURRENCY = results([{ VALUE: "USD", TEXT: "US Dollar" }]);
    return d;
}

module.exports = { metadata, respond };
