/*
 * AjaxRuntime - the original app AJAX runtime, rebuilt on top of ZDCI_UI_PROJECT_REQUEST_SRV.
 *
 * original app:  getOnlineX(value)  -> POST { Send models }  -> handle_on_ajax( ajax_id, ajax_value )
 *                              <- { Receive models }    -> model<X>.setData(...)  -> ajaxSuccess code
 * Here:     controller.getOnlineX(value) -> AjaxRuntime.call(controller, "<AJAX_ID>", value)
 *           -> one OData V2 deep insert on AJAXSet (the AJAX-mirror envelope, see registry 02)
 *           -> Receive models set -> controller["<AJAX_ID>_ajaxSuccess"]() / ["<AJAX_ID>_ajaxError"](oError)
 *
 * Rules (registry 02 + 07):
 *   - every navigation property (GT_*) is ALWAYS sent ([] when the AJAX does not send it), otherwise the
 *     deep-insert response would not contain that table;
 *   - only properties that exist in $metadata are sent (original app ignored unknown JSON fields too);
 *   - values are converted ABAP <-> JSON exactly like the original app serializer (JsonConversionRegistry);
 *   - plain POST, no $batch (the class does COMMIT WORK).
 */
sap.ui.define([
    "./AjaxConfig",
    "./JsonConversionRegistry"
], function (AjaxConfig, Registry) {
    "use strict";

    var ENTITY_SET = "AJAXSet";
    var _metadataCache = {};   // serviceUrl -> Promise<types>
    var _csrfCache = {};       // serviceUrl -> token

    /* ================================================================ helpers */

    function clone(v) {
        return v === undefined ? undefined : JSON.parse(JSON.stringify(v));
    }

    function isTable(sAttr) {
        return Registry.TABLES.indexOf(sAttr) >= 0;
    }

    function isStructure(sAttr) {
        return Registry.STRUCTURES.indexOf(sAttr) >= 0;
    }

    function inList(oMap, sAttr, sField) {
        var v = oMap && oMap[sAttr];
        return Array.isArray(v) ? v.indexOf(sField) >= 0 : false;
    }

    function isBoolTF(sAttr, sField) {
        var oDef = Registry.BOOL_TF[sAttr];
        if (!oDef) {
            return false;
        }
        if (oDef.fields.indexOf(sField) >= 0) {
            return true;
        }
        return oDef.prefixes.some(function (p) { return sField.indexOf(p) === 0; });
    }

    /* ================================================================ $metadata */

    /**
     * Parse OData V2 $metadata (regex based, so it also runs in node unit tests).
     * @returns {object} { <TypeName>: { <Property>: { type, maxLength, scale } } }
     */
    function parseMetadata(sXml) {
        var oTypes = {};
        var reType = /<(EntityType|ComplexType)\b[^>]*\bName="([^"]+)"[^>]*>([\s\S]*?)<\/\1>/g;
        var reProp = /<Property\b([^>]*)\/?>/g;
        var m;
        while ((m = reType.exec(sXml)) !== null) {
            var oProps = {};
            var p;
            reProp.lastIndex = 0;
            while ((p = reProp.exec(m[3])) !== null) {
                var sAttrs = p[1];
                var sName = (/\bName="([^"]+)"/.exec(sAttrs) || [])[1];
                if (!sName) {
                    continue;
                }
                oProps[sName] = {
                    type: (/\bType="([^"]+)"/.exec(sAttrs) || [])[1] || "Edm.String",
                    maxLength: parseInt((/\bMaxLength="(\d+)"/.exec(sAttrs) || [])[1], 10) || 0,
                    scale: parseInt((/\bScale="(\d+)"/.exec(sAttrs) || [])[1], 10) || 0
                };
            }
            oTypes[m[2]] = oProps;
        }
        return oTypes;
    }

    /* ================================================================ conversions */

    /** JSON (original app JS) -> ABAP/OData value for one field */
    function toAbap(sAttr, sField, vValue, oProp) {
        var v = vValue;
        if (isBoolTF(sAttr, sField) && typeof v === "boolean") {
            v = v ? "true" : "false";
        } else if (inList(Registry.BOOL_X, sAttr, sField) && typeof v === "boolean") {
            v = v ? "X" : "";
        }
        var sType = oProp ? oProp.type : "Edm.String";
        switch (sType) {
            case "Edm.Decimal": {
                var n = Number(v);
                return (v === "" || v === null || v === undefined || isNaN(n)) ? "0" : String(n);
            }
            case "Edm.Int64": return String(parseInt(v, 10) || 0);
            case "Edm.Int32":
            case "Edm.Int16":
            case "Edm.Byte":
            case "Edm.SByte": return parseInt(v, 10) || 0;
            case "Edm.Double":
            case "Edm.Single": return Number(v) || 0;
            case "Edm.Boolean": return v === true || v === "true" || v === "X";
            case "Edm.DateTime":
            case "Edm.DateTimeOffset":
            case "Edm.Time": return (v === "" || v === undefined) ? null : v;
            default: { // Edm.String, Edm.Guid, Edm.Binary
                if (v === null || v === undefined) {
                    v = "";
                } else if (typeof v === "object") {
                    v = JSON.stringify(v);
                } else {
                    v = String(v);
                }
                // ABAP MOVE semantics: a CHAR field silently cuts longer input (original app did the same)
                if (sType === "Edm.String" && oProp && oProp.maxLength > 0 && v.length > oProp.maxLength) {
                    v = v.substring(0, oProp.maxLength);
                }
                return v;
            }
        }
    }

    /** ABAP/OData value -> JSON (what the original app JS expects) for one field */
    function fromAbap(sAttr, sField, vValue, oProp) {
        if (isBoolTF(sAttr, sField)) {
            return vValue === "true" || vValue === true;
        }
        if (inList(Registry.BOOL_X, sAttr, sField)) {
            return vValue === "X" || vValue === true;
        }
        if (inList(Registry.DATE, sAttr, sField)) {
            return (vValue === "00000000" || vValue === null || vValue === undefined) ? "" : vValue;
        }
        if (inList(Registry.TIME, sAttr, sField)) {
            return (vValue === "000000" || vValue === null || vValue === undefined) ? "" : vValue;
        }
        if (inList(Registry.DECIMAL, sAttr, sField)) {
            return Number(vValue) || 0;
        }
        // original app serialised every ABAP number type as a JSON number
        if (oProp && (oProp.type === "Edm.Decimal" || oProp.type === "Edm.Int64" || oProp.type === "Edm.Double")) {
            return (vValue === null || vValue === undefined || vValue === "") ? 0 : Number(vValue);
        }
        return vValue;
    }

    function rowToAbap(sAttr, oRow, oTypeProps, iRowIndex) {
        var oOut = {};
        Object.keys(oTypeProps).forEach(function (sField) {
            if (sField === "ROW_INDEX") {
                return;
            }
            if (oRow && Object.prototype.hasOwnProperty.call(oRow, sField)) {
                oOut[sField] = toAbap(sAttr, sField, oRow[sField], oTypeProps[sField]);
            }
        });
        if (iRowIndex !== undefined) {
            oOut.ROW_INDEX = iRowIndex;
        }
        return oOut;
    }

    function rowFromAbap(sAttr, oRow, oTypeProps) {
        var oOut = {};
        Object.keys(oRow || {}).forEach(function (sField) {
            if (sField === "__metadata" || sField === "__deferred" || sField === "ROW_INDEX") {
                return;
            }
            var v = oRow[sField];
            if (v && typeof v === "object" && v.__deferred) {
                return;
            }
            oOut[sField] = fromAbap(sAttr, sField, v, oTypeProps && oTypeProps[sField]);
        });
        return oOut;
    }

    /* ================================================================ payload / response */

    /**
     * Build the deep-insert body for one AJAX call.
     * @param {string} sAjaxId
     * @param {string} vAjaxValue
     * @param {function(string):object} fnModel  model name -> JSONModel
     * @param {object} oTypes  parsed $metadata
     */
    function buildPayload(sAjaxId, vAjaxValue, fnModel, oTypes) {
        var oCfg = AjaxConfig[sAjaxId];
        if (!oCfg) {
            throw new Error("AjaxRuntime: unknown AJAX_ID " + sAjaxId);
        }
        var oBody = {
            AJAX_ID: sAjaxId,
            AJAX_VALUE: (vAjaxValue === undefined || vAjaxValue === null) ? "" : String(vAjaxValue)
        };
        var oSent = {};
        oCfg.send.forEach(function (aPair) {
            var sModel = aPair[0], sAttr = aPair[1];
            if (oSent[sAttr]) {
                return; // first Send row wins (original app: one JSON key per attribute)
            }
            var oModel = fnModel(sModel);
            if (!oModel) {
                throw new Error("AjaxRuntime: model '" + sModel + "' not found (AJAX " + sAjaxId + ")");
            }
            var oProps = oTypes[sAttr] || {};
            var vData = oModel.getData();
            if (isTable(sAttr)) {
                oBody[sAttr] = (Array.isArray(vData) ? vData : []).map(function (oRow, i) {
                    return rowToAbap(sAttr, oRow, oProps, i + 1);
                });
            } else if (isStructure(sAttr)) {
                oBody[sAttr] = rowToAbap(sAttr, Array.isArray(vData) ? {} : vData, oProps);
            } else {
                throw new Error("AjaxRuntime: attribute " + sAttr + " is not in the envelope registry");
            }
            oSent[sAttr] = true;
        });
        // every navigation property must be present for the response to carry it
        Registry.TABLES.forEach(function (sTable) {
            if (!oBody[sTable]) {
                oBody[sTable] = [];
            }
        });
        return oBody;
    }

    /**
     * Apply the deep-insert response to the Receive models (original app: model<X>.setData(...)).
     */
    function applyResponse(sAjaxId, oD, fnModel, oTypes) {
        var oCfg = AjaxConfig[sAjaxId];
        oCfg.receive.forEach(function (aPair) {
            var sModel = aPair[0], sAttr = aPair[1];
            var oModel = fnModel(sModel);
            if (!oModel) {
                throw new Error("AjaxRuntime: model '" + sModel + "' not found (AJAX " + sAjaxId + ")");
            }
            var vRaw = oD[sAttr];
            var oProps = oTypes[sAttr] || {};
            var vNew;
            if (isTable(sAttr)) {
                var aRows = vRaw && vRaw.results ? vRaw.results : (Array.isArray(vRaw) ? vRaw : []);
                vNew = aRows.map(function (oRow) { return rowFromAbap(sAttr, oRow, oProps); });
            } else {
                vNew = rowFromAbap(sAttr, vRaw || {}, oProps);
            }
            // each original app control had its own model instance -> never share one object between models
            oModel.setData(clone(vNew));
        });
    }

    /* ================================================================ HTTP */

    function withClient(sUrl) {
        var m = /[?&]sap-client=(\d{3})/.exec(window.location.search || "");
        if (!m) {
            return sUrl;
        }
        return sUrl + (sUrl.indexOf("?") >= 0 ? "&" : "?") + "sap-client=" + m[1];
    }

    function serviceUrl(oController) {
        var oComp = oController.getOwnerComponent && oController.getOwnerComponent();
        var sUri = oComp && oComp.getManifestEntry("/sap.app/dataSources/mainService/uri");
        if (!sUri) {
            sUri = "/sap/opu/odata/sap/ZDCI_UI_PROJECT_REQUEST_SRV/";
        }
        if (sUri.charAt(sUri.length - 1) !== "/") {
            sUri += "/";
        }
        if (sUri.charAt(0) !== "/" && !/^https?:/.test(sUri) && oComp && sap.ui.require) {
            sUri = sap.ui.require.toUrl(oComp.getManifestEntry("/sap.app/id").replace(/\./g, "/") + "/" + sUri);
        }
        return sUri;
    }

    function loadMetadata(sService) {
        if (!_metadataCache[sService]) {
            _metadataCache[sService] = fetch(withClient(sService + "$metadata"), {
                credentials: "same-origin",
                headers: { "Accept": "application/xml" }
            }).then(function (oResp) {
                if (!oResp.ok) {
                    throw new Error("$metadata HTTP " + oResp.status);
                }
                return oResp.text();
            }).then(parseMetadata).catch(function (e) {
                delete _metadataCache[sService];
                throw e;
            });
        }
        return _metadataCache[sService];
    }

    function fetchToken(sService) {
        return fetch(withClient(sService), {
            method: "GET",
            credentials: "same-origin",
            headers: { "X-CSRF-Token": "Fetch", "Accept": "application/json" }
        }).then(function (oResp) {
            _csrfCache[sService] = oResp.headers.get("x-csrf-token") || "";
            return _csrfCache[sService];
        });
    }

    function post(sService, oBody, bRetried) {
        var pToken = _csrfCache[sService] ? Promise.resolve(_csrfCache[sService]) : fetchToken(sService);
        return pToken.then(function (sToken) {
            return fetch(withClient(sService + ENTITY_SET), {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "X-CSRF-Token": sToken,
                    "X-Requested-With": "XMLHttpRequest"
                },
                body: JSON.stringify(oBody)
            });
        }).then(function (oResp) {
            if (oResp.status === 403 && !bRetried &&
                String(oResp.headers.get("x-csrf-token") || "").toLowerCase() === "required") {
                delete _csrfCache[sService];
                return post(sService, oBody, true);
            }
            return oResp;
        });
    }

    function errorFrom(oResp, sText) {
        var oErr = new Error("HTTP " + oResp.status);
        oErr.status = oResp.status;
        oErr.responseText = sText;
        try {
            var oJson = JSON.parse(sText);
            oErr.message = (oJson.error && oJson.error.message && oJson.error.message.value) || oErr.message;
        } catch (e) { /* HTML dump page etc. */ }
        return oErr;
    }

    /* ================================================================ public */

    /**
     * Run one original app AJAX: send, receive, then <AJAX_ID>_ajaxSuccess / <AJAX_ID>_ajaxError on the controller.
     * @returns {Promise} resolves after the success/error handler ran (never rejects)
     */
    function call(oController, sAjaxId, vAjaxValue) {
        var sService = serviceUrl(oController);
        var fnModel = function (sName) { return oController.getView().getModel(sName); };
        var oTypes;
        var sSuccess = sAjaxId + "_ajaxSuccess", sError = sAjaxId + "_ajaxError";

        return loadMetadata(sService).then(function (oT) {
            oTypes = oT;
            return post(sService, buildPayload(sAjaxId, vAjaxValue, fnModel, oTypes));
        }).then(function (oResp) {
            return oResp.text().then(function (sText) {
                if (!oResp.ok) {
                    throw errorFrom(oResp, sText);
                }
                var oJson = sText ? JSON.parse(sText) : {};
                return oJson.d || oJson;
            });
        }).then(function (oD) {
            applyResponse(sAjaxId, oD, fnModel, oTypes);
            if (typeof oController[sSuccess] === "function") {
                oController[sSuccess]();
            }
        }).catch(function (oError) {
            /* eslint-disable no-console */
            if (window.console) {
                console.error("AjaxRuntime " + sAjaxId + " failed", oError);
            }
            if (typeof oController[sError] === "function") {
                oController[sError](oError);
            }
        });
    }

    /** URL of an attachment (replaces (original MIME path)) */
    function attachmentUrl(oController, sFormGuid, sAttUuid) {
        var enc = function (s) { return encodeURIComponent(String(s || "").replace(/'/g, "''")); };
        return withClient(serviceUrl(oController) + "ATTACHMENTSet(FORM='" + enc(sFormGuid) + "',ATT='" + enc(sAttUuid) + "')/$value");
    }

    return {
        call: call,
        attachmentUrl: attachmentUrl,
        // exported for unit tests (test/unit/run-node-tests.js)
        _parseMetadata: parseMetadata,
        _buildPayload: buildPayload,
        _applyResponse: applyResponse,
        _toAbap: toAbap,
        _fromAbap: fromAbap
    };
});
