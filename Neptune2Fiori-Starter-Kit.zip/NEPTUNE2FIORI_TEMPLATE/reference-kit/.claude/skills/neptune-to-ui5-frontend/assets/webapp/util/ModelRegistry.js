/*
 * ModelRegistry - every original app control that owns a Model Source becomes ONE named JSONModel on the view,
 * named exactly like the control. Source: nad-project-request-registry/references/registry 03
 *
 * [modelName, ABAP attribute, initial data]
 */
sap.ui.define([], function () {
    "use strict";

    var S = function () { return {}; };
    var T = function () { return []; };

    return [
        ["oPageProj", "GS_PROJ_FORM", S],
        ["subsectionComments", "GS_PROJ_FORM", S],
        ["diaDelDraft", "GS_PROJ_FORM", S],
        ["cntr_formdetails", "GS_FORMDETAILS", S],
        ["cntr_stepdetails", "GS_STEPDETAIL", S],
        ["UrlParameters", "WA_URL_PARAMETERS", function () {
            return { FORM_GUID: "", MODE: "", PROJ: "", FROM: "", PROCESSING_REGION: "", COMPANY_CODE: "" };
        }],
        ["ProgramState", "WA_PROGRAM_STATE", S],
        ["CompanyCodes", "GT_COMP_CODE", T],
        ["AttachmentCategories", "GT_ATTACHMENT_CATEGORIES", T],
        ["AttachmentsRequired", "GT_ATTACHMENTS_REQUIRED", T],
        ["vlAttributesBlock1", "GS_FORMHEADER", S],
        ["vlAttributesBlock2", "GS_FORMHEADER", S],
        ["listAttachments", "GT_ATTACHMENTS", T],
        ["sectionAttachments", "GS_ATTACHMENT", S],
        ["tabMultiCC", "GT_ADDITIONAL_CCODE", T],
        ["tabOrderdetails", "GT_ORDERDETAILS", T],
        ["oTableApprovers", "GT_APPR", T],
        ["oTableINITIA_GRP", "GT_INITI_GROUP", T],
        ["listAgents", "GT_ZCA_AGENT_LIST", T],
        ["oFormEmployeeInfo", "GS_EMPLOYEE_INFO", S],
        ["diaAddMultiCC", "GS_MULTIPLECCODE", S],
        ["diaConfirmAttDelete", "WA_CONFIRM_DELETE", S],
        ["diaCreate", "WA_COMMENTS", S],
        ["diaChange", "WA_COMMENTS", S],
        ["diaSubmit", "WA_COMMENTS", S],
        ["diaSubmitWthErr", "WA_COMMENTS", S],
        ["diaReject", "WA_COMMENTS", S],
        ["diaClose", "WA_COMMENTS", S],
        ["diaReSubmit", "WA_COMMENTS", S],
        ["diaSearchAuthBy", "GT_AUTH_BY_LIST", T],
        ["diaSearchOnBehalf", "GT_AGENT_LIST", T],
        ["diaSearchCostCenter", "GT_KOSTL", T],
        ["diaSearchPrevProj", "GT_PREV_PROJCODE", T],
        ["diaGeography", "GT_GEOGRAPHYLIST", T],
        ["diaBrand", "GT_BRANDS", T],
        ["diaLocation", "GT_LOCATIONS", T],
        ["oSelectProjType", "GT_REQUEST_TYPE", T],
        ["selProjectSubtype", "GT_PROJECT_SUBTYPE", T],
        ["oSelectExecCategory", "GT_EXEC_CATEGORY", T],
        ["oSelectInitPrd_Grp", "GT_INITI_GRP", T],
        ["oSelectAssetClass", "GT_ASSET_CLASS", T],
        ["oSelectITLAssetClass", "GT_ITL_ASSET_CLASS", T],
        ["oSelectCAPCURR", "GT_CURRENCY", T],
        ["oSelectITLCURR", "GT_CURRENCY", T],
        ["oSelectCompCode", "GT_COMP_CODE", T],
        ["oSelectMultiCCode", "GT_ADD_COMP_CCODE", T],
        ["oSelectOrderType", "GT_ORDER_TYPE", T],
        ["oSelectPrevPCode", "GT_PREV_PROJCODE", T],
        ["oSelectUSState", "GT_USSTATE", T],
        ["sysMessage", "GT_SYS_MESSAGE", T]
    ];
});
