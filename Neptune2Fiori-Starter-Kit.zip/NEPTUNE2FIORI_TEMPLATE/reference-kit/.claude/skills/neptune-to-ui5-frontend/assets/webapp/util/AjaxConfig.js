/*
 * AjaxConfig - the original app AJAX objects, one entry per AJAX ID.
 *
 *   fn       original app generated function name getOnline<AjaxName>() (kept verbatim as controller method)
 *   send     [model (original app control), ABAP attribute] pairs ticked "Send" in the original app AJAX object
 *   receive  [model, ABAP attribute] pairs ticked "Receive"
 *   evidence DOC = copied from the original app AJAX parameter table (Ajax/*.md)
 *            INF = inferred from the ABAP class + JS handlers -> MUST be confirmed by capture
 *            CAP = confirmed by capture (update when you confirm a row)
 *
 * Source: nad-project-request-registry/references/04-ajax-dispatch-inventory.md
 */
sap.ui.define([], function () {
    "use strict";

    var FORM_SEND = [
        ["oPageProj", "GS_PROJ_FORM"],
        ["cntr_formdetails", "GS_FORMDETAILS"],
        ["cntr_stepdetails", "GS_STEPDETAIL"],
        ["listAttachments", "GT_ATTACHMENTS"],
        ["tabMultiCC", "GT_ADDITIONAL_CCODE"]
    ];

    return {
        GET_DATA: {
            fn: "getOnlineGetDetail", evidence: "INF",
            send: [["UrlParameters", "WA_URL_PARAMETERS"], ["cntr_formdetails", "GS_FORMDETAILS"]],
            receive: [
                ["oPageProj", "GS_PROJ_FORM"], ["subsectionComments", "GS_PROJ_FORM"], ["diaDelDraft", "GS_PROJ_FORM"],
                ["cntr_formdetails", "GS_FORMDETAILS"], ["cntr_stepdetails", "GS_STEPDETAIL"],
                ["vlAttributesBlock1", "GS_FORMHEADER"], ["vlAttributesBlock2", "GS_FORMHEADER"],
                ["ProgramState", "WA_PROGRAM_STATE"], ["listAttachments", "GT_ATTACHMENTS"],
                ["tabOrderdetails", "GT_ORDERDETAILS"], ["oTableApprovers", "GT_APPR"],
                ["oTableINITIA_GRP", "GT_INITI_GROUP"], ["AttachmentCategories", "GT_ATTACHMENT_CATEGORIES"],
                ["AttachmentsRequired", "GT_ATTACHMENTS_REQUIRED"], ["CompanyCodes", "GT_COMP_CODE"],
                ["oSelectCompCode", "GT_COMP_CODE"], ["oSelectProjType", "GT_REQUEST_TYPE"],
                ["selProjectSubtype", "GT_PROJECT_SUBTYPE"], ["oSelectExecCategory", "GT_EXEC_CATEGORY"],
                ["oSelectInitPrd_Grp", "GT_INITI_GRP"], ["oSelectAssetClass", "GT_ASSET_CLASS"],
                ["oSelectITLAssetClass", "GT_ITL_ASSET_CLASS"], ["oSelectCAPCURR", "GT_CURRENCY"],
                ["oSelectITLCURR", "GT_CURRENCY"], ["oSelectUSState", "GT_USSTATE"],
                ["oSelectOrderType", "GT_ORDER_TYPE"], ["oSelectPrevPCode", "GT_PREV_PROJCODE"],
                ["diaSearchPrevProj", "GT_PREV_PROJCODE"], ["diaSearchCostCenter", "GT_KOSTL"],
                ["diaGeography", "GT_GEOGRAPHYLIST"], ["diaBrand", "GT_BRANDS"], ["diaLocation", "GT_LOCATIONS"],
                ["listAgents", "GT_ZCA_AGENT_LIST"], ["oFormEmployeeInfo", "GS_EMPLOYEE_INFO"],
                ["oSelectMultiCCode", "GT_ADD_COMP_CCODE"]
            ]
        },
        GET_EMPINFO: {
            fn: null, evidence: "INF", // AJAX object name not in the specs - capture it
            send: [["oPageProj", "GS_PROJ_FORM"], ["cntr_formdetails", "GS_FORMDETAILS"]],
            receive: [["oFormEmployeeInfo", "GS_EMPLOYEE_INFO"]]
        },
        GET_AGENTLIST: {
            fn: null, evidence: "INF", // AJAX object name not in the specs - capture it
            send: [["cntr_formdetails", "GS_FORMDETAILS"]],
            receive: [["listAgents", "GT_ZCA_AGENT_LIST"], ["ProgramState", "WA_PROGRAM_STATE"]]
        },
        CREATE: {
            fn: "getOnlineCreate", evidence: "INF",
            send: FORM_SEND,
            receive: [["ProgramState", "WA_PROGRAM_STATE"], ["cntr_formdetails", "GS_FORMDETAILS"],
                ["cntr_stepdetails", "GS_STEPDETAIL"], ["listAttachments", "GT_ATTACHMENTS"]]
        },
        CHECK: {
            fn: "getOnlineCheck", evidence: "INF",
            send: FORM_SEND.concat([["UrlParameters", "WA_URL_PARAMETERS"]]),
            receive: [["ProgramState", "WA_PROGRAM_STATE"]]
        },
        SAVE: {
            fn: "getOnlineSaveAsDraft", evidence: "DOC",
            send: [["cntr_formdetails", "GS_FORMDETAILS"], ["cntr_stepdetails", "GS_STEPDETAIL"],
                ["listAttachments", "GT_ATTACHMENTS"], ["oPageProj", "GS_PROJ_FORM"],
                ["sectionAttachments", "GS_ATTACHMENT"], ["tabMultiCC", "GT_ADDITIONAL_CCODE"]],
            receive: [["cntr_formdetails", "GS_FORMDETAILS"], ["cntr_stepdetails", "GS_STEPDETAIL"],
                ["listAttachments", "GT_ATTACHMENTS"], ["oPageProj", "GS_PROJ_FORM"],
                ["ProgramState", "WA_PROGRAM_STATE"]]
        },
        DELETE: {
            fn: "getOnlineDeleteDraft", evidence: "INF",
            send: [["cntr_formdetails", "GS_FORMDETAILS"], ["listAttachments", "GT_ATTACHMENTS"],
                ["diaConfirmAttDelete", "WA_CONFIRM_DELETE"]],
            receive: [["ProgramState", "WA_PROGRAM_STATE"]]
        },
        REJECT: {
            fn: "getOnlineReject", evidence: "DOC",
            send: [["cntr_formdetails", "GS_FORMDETAILS"], ["cntr_stepdetails", "GS_STEPDETAIL"],
                ["diaReject", "WA_COMMENTS"], ["oPageProj", "GS_PROJ_FORM"], ["tabMultiCC", "GT_ADDITIONAL_CCODE"]],
            receive: [["ProgramState", "WA_PROGRAM_STATE"]]
        },
        SUBMIT: {
            fn: "getOnlineSubmit", evidence: "INF",
            send: FORM_SEND,
            receive: [["ProgramState", "WA_PROGRAM_STATE"], ["sysMessage", "GT_SYS_MESSAGE"]]
        },
        RESUBMIT: {
            fn: "getOnlineResubmit", evidence: "DOC",
            send: [["cntr_formdetails", "GS_FORMDETAILS"], ["cntr_stepdetails", "GS_STEPDETAIL"],
                ["diaReSubmit", "WA_COMMENTS"], ["listAttachments", "GT_ATTACHMENTS"],
                ["oPageProj", "GS_PROJ_FORM"], ["tabMultiCC", "GT_ADDITIONAL_CCODE"]],
            receive: []
        },
        CHANGE: {
            fn: "getOnlineChange", evidence: "INF",
            send: FORM_SEND.concat([["UrlParameters", "WA_URL_PARAMETERS"]]),
            receive: [["ProgramState", "WA_PROGRAM_STATE"]]
        },
        CLOSE: {
            fn: "getOnlineClose", evidence: "INF",
            send: [["oPageProj", "GS_PROJ_FORM"], ["cntr_formdetails", "GS_FORMDETAILS"],
                ["cntr_stepdetails", "GS_STEPDETAIL"], ["listAttachments", "GT_ATTACHMENTS"], ["diaClose", "WA_COMMENTS"]],
            receive: []
        },
        DELETE_ATTACHMENT: {
            fn: "getOnlineDeleteAttachment", evidence: "INF",
            send: [["listAttachments", "GT_ATTACHMENTS"], ["diaConfirmAttDelete", "WA_CONFIRM_DELETE"],
                ["cntr_formdetails", "GS_FORMDETAILS"]],
            receive: [["ProgramState", "WA_PROGRAM_STATE"]]
        },
        BACK: {
            fn: "getOnlineBack", evidence: "DOC",
            send: [["cntr_formdetails", "GS_FORMDETAILS"], ["cntr_stepdetails", "GS_STEPDETAIL"]],
            receive: []
        },
        NEW_PROJECT: {
            fn: "getOnlineNewProject", evidence: "INF",
            send: FORM_SEND,
            receive: [["ProgramState", "WA_PROGRAM_STATE"], ["sysMessage", "GT_SYS_MESSAGE"], ["oPageProj", "GS_PROJ_FORM"]]
        },
        NEW_INTENALORDER_WEXP: {
            // PARITY P-04: the backend WHEN branch is commented out -> no-op
            fn: "getOnlineNewIntOrderWErr", evidence: "INF",
            send: FORM_SEND,
            receive: [["ProgramState", "WA_PROGRAM_STATE"], ["sysMessage", "GT_SYS_MESSAGE"]]
        },
        DEQUEUE_FORM: {
            fn: "getOnlineDequeueForm", evidence: "DOC",
            send: [["cntr_formdetails", "GS_FORMDETAILS"]],
            receive: []
        },
        AGENT_SEARCH: {
            fn: "getOnlineGetOnBehalfPerson", evidence: "INF",
            send: [],
            receive: [["diaSearchOnBehalf", "GT_AGENT_LIST"]]
        },
        AUTH_BY_SEARCH: {
            fn: "getOnlineGetAuthorizedBy", evidence: "INF",
            send: [],
            receive: [["diaSearchAuthBy", "GT_AUTH_BY_LIST"]]
        },
        GET_ONBEHALF_ID: {
            fn: "getOnlineUpdateOnbehalf_ID", evidence: "DOC",
            send: [["cntr_formdetails", "GS_FORMDETAILS"], ["cntr_stepdetails", "GS_STEPDETAIL"], ["oPageProj", "GS_PROJ_FORM"]],
            receive: [["cntr_formdetails", "GS_FORMDETAILS"], ["cntr_stepdetails", "GS_STEPDETAIL"], ["oPageProj", "GS_PROJ_FORM"]]
        },
        GET_AUTHBY_ID: {
            // PARITY P-03: backend no-op
            fn: "getOnlineUpdateAuthorizedBy", evidence: "DOC",
            send: [["cntr_formdetails", "GS_FORMDETAILS"], ["cntr_stepdetails", "GS_STEPDETAIL"],
                ["listAttachments", "GT_ATTACHMENTS"], ["oPageProj", "GS_PROJ_FORM"],
                ["sectionAttachments", "GS_ATTACHMENT"], ["tabMultiCC", "GT_ADDITIONAL_CCODE"]],
            receive: [["cntr_formdetails", "GS_FORMDETAILS"], ["cntr_stepdetails", "GS_STEPDETAIL"],
                ["listAttachments", "GT_ATTACHMENTS"], ["oPageProj", "GS_PROJ_FORM"],
                ["ProgramState", "WA_PROGRAM_STATE"]]
        },
        GET_COSTCENTER: {
            fn: "getOnlineGetCostCenter", evidence: "INF",
            send: [["UrlParameters", "WA_URL_PARAMETERS"]],
            receive: [["diaSearchCostCenter", "GT_KOSTL"]]
        },
        UPDATE_REGION: {
            fn: "getOnlineUpdate_Region", evidence: "INF",
            send: [["UrlParameters", "WA_URL_PARAMETERS"]],
            receive: [["oSelectCompCode", "GT_COMP_CODE"], ["CompanyCodes", "GT_COMP_CODE"],
                ["diaSearchCostCenter", "GT_KOSTL"]]
        }
    };
});
