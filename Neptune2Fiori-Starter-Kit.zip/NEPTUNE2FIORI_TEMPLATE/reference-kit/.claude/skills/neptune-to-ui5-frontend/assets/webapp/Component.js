sap.ui.define([
    "sap/ui/core/UIComponent"
], function (UIComponent) {
    "use strict";

    /*
     * ZDCI_NAD_PROJECT_REQUEST - freestyle SAPUI5 port of the original application of the same name.
     * Component data { child: true } = started as child component by the parent list app (original app
     * "Run initialization if we're not in a subcomponent", Init.txt).
     */
    return UIComponent.extend("zdci_nad_project_request.Component", {
        metadata: {
            manifest: "json"
        },

        init: function () {
            UIComponent.prototype.init.apply(this, arguments);
        }
    });
});
