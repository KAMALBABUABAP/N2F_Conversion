/*
 * JsonConversionRegistry - which ABAP values the original app runtime turned into JSON booleans,
 * empty dates or numbers. Machine copy of
 * nad-project-request-registry/references/json-conversion-registry.json (keep identical;
 * verify_kit.py checks). Confirm every entry with the original app capture before sign-off.
 */
sap.ui.define([], function () {
    "use strict";
    return {
    "BOOL_TF": {
        "GS_PROJ_FORM": {
            "prefixes": [
                "V_",
                "R_",
                "E_"
            ],
            "fields": [
                "PROJ_FLGRP_0001",
                "PROJ_FLGRP_0002",
                "PROJ_FLGRP_0003",
                "PROJ_FLGRP_0004",
                "PROJ_FLGRP_0005",
                "CREATE",
                "CHANGE",
                "SAVE",
                "SUBMITWTH_ERR",
                "DELETE",
                "SUBMIT",
                "REJECT",
                "WITHDRAWN",
                "RESUBMIT",
                "NAVIGATION_VISIBLE",
                "ATTRIBUTES_VISIBLE",
                "MODE_BUTTON_VISIBLE",
                "REPLACE_EXIT_PRJ",
                "FPA_APPROVAL",
                "RTR_APPROVAL",
                "BPC_APPROVAL"
            ]
        },
        "GT_ADDITIONAL_CCODE": {
            "prefixes": [],
            "fields": [
                "DELETABLE",
                "PROJ_FLGRP_0001",
                "PROJ_FLGRP_0002",
                "PROJ_FLGRP_0003",
                "PROJ_FLGRP_0004",
                "PROJ_FLGRP_0005",
                "IS_ERROR"
            ]
        },
        "GS_MULTIPLECCODE": {
            "prefixes": [],
            "fields": [
                "DELETABLE",
                "PROJ_FLGRP_0001",
                "PROJ_FLGRP_0002",
                "PROJ_FLGRP_0003",
                "PROJ_FLGRP_0004",
                "PROJ_FLGRP_0005",
                "IS_ERROR"
            ]
        },
        "GT_ORDERDETAILS": {
            "prefixes": [],
            "fields": [
                "IS_ERROR"
            ]
        }
    },
    "BOOL_X": {
        "GS_PROJ_FORM": [
            "CAN_ATTACH"
        ],
        "GT_ATTACHMENTS_REQUIRED": [
            "REQUIRED"
        ]
    },
    "DATE": {
        "GS_PROJ_FORM": [
            "AUTH_BY_DATE",
            "ORDER_DATE",
            "PROJ_COMPLETION_DATE"
        ],
        "GS_FORMDETAILS": [
            "START_DATE",
            "LATEST_STARTDATE",
            "FIRST_REM_DATE",
            "NEXT_REM_DATE",
            "DEADLINE_DATE"
        ],
        "GS_STEPDETAIL": [
            "COMPLETION_DATE",
            "ON_HOLD_SINCE_DATE"
        ]
    },
    "TIME": {
        "GS_FORMDETAILS": [
            "START_TIME",
            "LATEST_STARTTIME"
        ],
        "GS_STEPDETAIL": [
            "COMPLETION_TIME",
            "ON_HOLD_SINCE_TIME"
        ]
    },
    "DECIMAL": {
        "GS_PROJ_FORM": [
            "CAPEX_REQ_AMOUNT",
            "ITL_REQ_AMOUNT",
            "CAPEX_TI_AMOUNT"
        ]
    },
    "STRUCTURES": [
        "WA_URL_PARAMETERS",
        "WA_PROGRAM_STATE",
        "WA_COMMENTS",
        "WA_CONFIRM_DELETE",
        "GS_PROJ_FORM",
        "GS_FORMDETAILS",
        "GS_STEPDETAIL",
        "GS_FORMHEADER",
        "GS_EMPLOYEE_INFO",
        "GS_ATTACHMENT",
        "GS_MULTIPLECCODE"
    ],
    "TABLES": [
        "GT_APPR",
        "GT_ATTACHMENTS",
        "GT_ZCA_AGENT_LIST",
        "GT_ORDERDETAILS",
        "GT_ADDITIONAL_CCODE",
        "GT_REQUEST_TYPE",
        "GT_PROJECT_SUBTYPE",
        "GT_EXEC_CATEGORY",
        "GT_INITI_GROUP",
        "GT_INITI_GRP",
        "GT_ASSET_CLASS",
        "GT_ITL_ASSET_CLASS",
        "GT_CURRENCY",
        "GT_USSTATE",
        "GT_COMP_CODE",
        "GT_ADD_COMP_CCODE",
        "GT_KOSTL",
        "GT_GEOGRAPHYLIST",
        "GT_BRANDS",
        "GT_LOCATIONS",
        "GT_AGENT_LIST",
        "GT_AUTH_BY_LIST",
        "GT_PREV_PROJCODE",
        "GT_ORDER_TYPE",
        "GT_ATTACHMENT_CATEGORIES",
        "GT_ATTACHMENTS_REQUIRED",
        "GT_SYS_MESSAGE"
    ]
};
});
