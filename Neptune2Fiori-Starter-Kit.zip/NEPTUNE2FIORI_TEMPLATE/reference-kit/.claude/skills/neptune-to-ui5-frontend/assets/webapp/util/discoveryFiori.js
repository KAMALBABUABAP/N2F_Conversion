/*
 * discoveryFiori - shim for the shared original app library
 *   (original MIME path)
 *
 * SHIM-RECONSTRUCTED: the original file is NOT in the repository. The behaviour below is rebuilt from how
 * this app calls it (Init.txt, Utility.txt, form.txt, AJAX handlers, specs). Before go-live:
 *   1. Get the real discoveryFiori.js from the original app MIME folder (see registry 06).
 *   2. Compare every method below with the original and copy its exact behaviour in.
 *   3. Remove the "SHIM-RECONSTRUCTED" marker of each method you confirmed.
 *
 * API used by the app (names unchanged):
 *   new discoveryFiori.ChildComponent(ctx, appName, loadRequestFn)  -> .goBack(), .sendToParent(obj)
 *   new discoveryFiori.DirtyHandler()                               -> .setDirty(b), .isDirty()
 *   new discoveryFiori.FileUploader(listAttachments, oplForm, AttachmentCategories)
 *                                                                   -> .uploadDialog (sap.m.Dialog), .open(category)
 *   discoveryFiori.showMessage(text, valueState)
 *   discoveryFiori.addExpandButtons(oplForm)
 */
sap.ui.define([
    "sap/ui/core/Core",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Text",
    "sap/m/Select",
    "sap/m/Label",
    "sap/m/VBox",
    "sap/ui/core/Item",
    "sap/ui/unified/FileUploader",
    "./ModelData"
], function (Core, Dialog, Button, Text, Select, Label, VBox, Item, FileUploader, ModelData) {
    "use strict";

    var EVENT_CHANNEL = "discoveryFiori";

    function ushell() {
        return (window.sap && sap.ushell && sap.ushell.Container) ? sap.ushell.Container : null;
    }

    /* ------------------------------------------------------------------ ChildComponent
     * original app: the app runs either standalone (FLP tile) or as a child component inside a parent list app
     * (component data { child: true }). The parent passes { detail: { FORM, ID, FROM, PROJREQ } } and gets
     * "form-saved" events back. SHIM-RECONSTRUCTED.
     */
    function ChildComponent(oController, sAppName, fnLoadRequest) {
        this._controller = oController;
        this.appName = sAppName;
        this._load = fnLoadRequest;
        this.isChild = false;
        var oComp = oController && oController.getOwnerComponent && oController.getOwnerComponent();
        var oData = oComp && oComp.getComponentData && oComp.getComponentData();
        if (oData && typeof oData === "object" && oData.child) {
            this.isChild = true;
            Core.getEventBus().subscribe(EVENT_CHANNEL + "." + sAppName, "load", function (sCh, sEv, oEvt) {
                fnLoadRequest(oEvt);
            });
        }
    }
    ChildComponent.prototype.sendToParent = function (oPayload) {
        Core.getEventBus().publish(EVENT_CHANNEL + "." + this.appName, "toParent", oPayload || {});
    };
    ChildComponent.prototype.goBack = function () {
        if (this.isChild) {
            Core.getEventBus().publish(EVENT_CHANNEL + "." + this.appName, "goBack", {});
            return;
        }
        var oContainer = ushell();
        if (oContainer && oContainer.getServiceAsync) {
            oContainer.getServiceAsync("CrossApplicationNavigation").then(function (oNav) {
                oNav.backToPreviousApp();
            });
        } else {
            window.history.go(-1);
        }
    };

    /* ------------------------------------------------------------------ DirtyHandler
     * original app: tells the launchpad that there are unsaved changes. SHIM-RECONSTRUCTED.
     */
    function DirtyHandler() {
        this._dirty = false;
    }
    DirtyHandler.prototype.setDirty = function (bDirty) {
        this._dirty = !!bDirty;
        var oContainer = ushell();
        if (oContainer && oContainer.setDirtyFlag) {
            oContainer.setDirtyFlag(this._dirty);
        }
    };
    DirtyHandler.prototype.isDirty = function () {
        return this._dirty;
    };

    /* ------------------------------------------------------------------ FileUploader
     * original app: builds its own upload dialog (category select + file chooser) and appends the file to the
     * list model as a base64 attachment row. Row shape = ZCA_FORM_ATTACHMENT:
     * ICON, ICON_COLOR, FILE_NAME, EXTENSION, MIME_TYPE, FILE_DATA, UUID, HREF, CATEGORY, CATEGORY_TEXT.
     * SHIM-RECONSTRUCTED (category handling inferred from validateAttachment(), which filters on CATEGORY).
     */
    function NFileUploader(oList, oPageLayout, oCategories) {
        var that = this;
        this.list = oList;
        this.layout = oPageLayout;
        this.categories = oCategories;

        this._select = new Select({ width: "100%", forceSelection: false });
        this._uploader = new FileUploader({
            width: "100%",
            sendXHR: false,
            uploadOnChange: false,
            change: function (oEvent) {
                var aFiles = oEvent.getParameter("files");
                if (aFiles && aFiles[0]) {
                    that._read(aFiles[0]);
                }
            }
        });
        this.uploadDialog = new Dialog({
            title: "Add attachment",
            contentWidth: "400px",
            content: [new VBox({
                items: [new Label({ text: "Category", required: true }), this._select,
                    new Label({ text: "File" }), this._uploader]
            }).addStyleClass("sapUiSmallMargin")],
            endButton: new Button({
                icon: "sap-icon://sys-cancel",
                press: function () { that.uploadDialog.close(); }
            }),
            beforeOpen: function () { that._fillCategories(); }
        });
        if (oList && oList.addDependent) {
            oList.addDependent(this.uploadDialog);
        }
    }
    NFileUploader.prototype._categoryRows = function () {
        try {
            return ModelData.Find(this.categories, "VALUE", "", "NE");
        } catch (e) {
            return [];
        }
    };
    NFileUploader.prototype._fillCategories = function () {
        var sKeep = this._preset || this._select.getSelectedKey();
        this._select.destroyItems();
        this._categoryRows().forEach(function (oCat) {
            this._select.addItem(new Item({ key: oCat.VALUE, text: oCat.TEXT }));
        }, this);
        this._select.setSelectedKey(sKeep || "");
        this._preset = null;
    };
    NFileUploader.prototype.open = function (sCategory) {
        this._preset = sCategory || null;
        this.uploadDialog.open();
    };
    NFileUploader.prototype._read = function (oFile) {
        var that = this;
        var oItem = this._select.getSelectedItem();
        if (!oItem) {
            showMessage("Select a category first.", "Error");
            this._uploader.clear();
            return;
        }
        var oReader = new FileReader();
        oReader.onload = function (oEvt) {
            var sData = oEvt.target.result;
            if (sData.substring(0, 4) === "data") {
                sData = sData.substring(sData.indexOf(",") + 1);
            }
            ModelData.Add(that.list, {
                ICON: "sap-icon://document",
                ICON_COLOR: "",
                FILE_NAME: oFile.name,
                EXTENSION: oFile.name.split(".").pop(),
                MIME_TYPE: oFile.type,
                FILE_DATA: sData,
                UUID: "",
                HREF: "",
                CATEGORY: oItem.getKey(),
                CATEGORY_TEXT: oItem.getText()
            });
            that._uploader.clear();
            that.uploadDialog.close();
            if (that.layout && that.layout.scrollToSection) {
                var oSection = Core.byId(that.layout.getId().replace(/oplForm$/, "sectionAttachments"));
                that.layout.scrollToSection(oSection ? oSection.getId() : "sectionAttachments");
            }
        };
        oReader.readAsDataURL(oFile);
    };

    /* ------------------------------------------------------------------ showMessage
     * Same look as Utility.txt showMessage(): Dialog, title "Attention", state, sys-cancel end button.
     * SHIM-RECONSTRUCTED.
     */
    function showMessage(sMessage, sState) {
        var oDialog = new Dialog({
            state: sState,
            title: "Attention",
            endButton: new Button({
                icon: "sap-icon://sys-cancel",
                press: function () { oDialog.close(); }
            }),
            content: new Text({ text: sMessage }).addStyleClass("sapUiSmallMargin"),
            afterClose: function () { oDialog.destroy(); }
        });
        oDialog.open();
    }

    /* ------------------------------------------------------------------ addExpandButtons
     * original app: adds expand/collapse buttons for sub-sections that have MoreBlock content.
     * UI5's ObjectPageSubSection already renders "Show More/Less" for moreBlocks, so this shim is a no-op.
     * SHIM-RECONSTRUCTED - replace with the original behaviour if the capture shows extra buttons.
     */
    function addExpandButtons(/* oplForm */) {
        return undefined;
    }

    return {
        ChildComponent: ChildComponent,
        DirtyHandler: DirtyHandler,
        FileUploader: NFileUploader,
        showMessage: showMessage,
        addExpandButtons: addExpandButtons,
        EVENT_CHANNEL: EVENT_CHANNEL
    };
});
