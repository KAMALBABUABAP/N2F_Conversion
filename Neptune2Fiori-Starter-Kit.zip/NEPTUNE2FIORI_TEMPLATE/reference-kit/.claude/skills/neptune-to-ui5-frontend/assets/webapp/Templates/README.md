# Templates (download links of subsectionProjAttDownload)

Copy the two files from the original app MIME folder into this folder with the SAME file names
(PARITY P-33):

- `(original MIME path) License Questionnaire.xlsx`
- `(original MIME path) Questionnaire.xlsx`

They are deployed with the BSP `ZUI_PROJREQCODE`; the links `lnkAttCAPEXLicenseDownload` and
`lnkAttAccountingDownload` point to `Templates/<file name>` relative to the app.
