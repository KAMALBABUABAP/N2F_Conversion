/*
 * ZDCI_NAD_PROJECT_REQUEST - Main controller.
 * Apple-to-apple port of the original app JavaScript: Init.txt, Global Script.txt, Utility.txt, form.txt,
 * the AJAX ajaxSuccess/ajaxError code (Ajax/*.md) and the control events (UI and dialog specs).
 *
 * PORT PATTERN (frontend skill/references/js-port-rules.md):
 *   - every original app function keeps its name and becomes a controller method;
 *   - each method starts with LOCAL ALIASES for the original app globals it uses
 *     (controls: this.byId("<id>"), models: this.model("<control>"), functions: bound methods),
 *     then the original app body follows VERBATIM except for the mechanical replacements:
 *       modelX.oData                      -> modelX.getData()
 *       sap.m.MessageToast / sap.ui.core.ValueState / new sap.m.X / sap.ui.model.Filter -> imported modules
 *       jQuery.sap.require(...)           -> removed (module imported)
 *       oEvent.oSource                    -> oEvent.getSource()
 *       ctx.getBindingContext()           -> ctx.getBindingContext("<model of that control>")
 *       control id strings given to UI5   -> full id via getControlName()/this.createId()
 *       txtX.getText() (hidden texts)     -> i18n key "txtX" (alias object with getText())
 *       debugger statements               -> commented out
 *   - markers: PARITY P-xx (behaviour kept on purpose), TODO(SPEC-MISSING) (code inferred - the
 *     original app event code is not in the repo), TODO(CAPTURE) (confirm against the original app capture).
 */
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/core/library",
    "sap/ui/core/Item",
    "sap/m/MessageToast",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Text",
    "sap/m/Input",
    "sap/m/TextArea",
    "sap/m/DatePicker",
    "sap/m/Switch",
    "sap/m/Select",
    "sap/m/MultiComboBox",
    "sap/m/RadioButtonGroup",
    "sap/m/VBox",
    "sap/m/HBox",
    "../util/ModelData",
    "../util/discoveryFiori",
    "../util/AjaxRuntime",
    "../util/ModelRegistry",
    "sap/ui/thirdparty/jquery"
], function (Controller, JSONModel, Filter, coreLibrary, Item, MessageToast, Dialog, Button, Text,
             Input, TextArea, DatePicker, Switch, Select, MultiComboBox, RadioButtonGroup, VBox, HBox,
             ModelData, discoveryFiori, AjaxRuntime, ModelRegistry, jQuery) {
    "use strict";

    var ValueState = coreLibrary.ValueState;

    return Controller.extend("zdci_nad_project_request.controller.Main", {

        /* =============================================================== helpers (not original app) */

        /** original app model<X>  ->  named JSONModel X */
        model: function (sName) {
            return this.getView().getModel(sName);
        },

        /** original app hidden text control txtX -> i18n key txtX */
        i18n: function (sKey) {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(sKey);
        },

        /** alias object so that ported code can keep calling txtX.getText() */
        _txt: function (sKey) {
            var that = this;
            return { getText: function () { return that.i18n(sKey); } };
        },

        /* =============================================================== Global Script.txt + Init.txt */

        onInit: function () {
            var that = this;
            var oView = this.getView();

            // one named JSONModel per original app control that owns a Model Source (util/ModelRegistry.js)
            ModelRegistry.forEach(function (aDef) {
                oView.setModel(new JSONModel(aDef[2]()), aDef[0]);
            });

            // Global Script.txt
            this.listRef = null;
            this.listIndex = null;
            this.dirty = null;
            this.fu = null;
            this.dc = null;
            this.userField = null;
            this.fc = null;
            this.isDirty = false;

            // form.txt (top level): forms[] - NOTE sfBudgetManagerBlock2 is not in the list (original app source)
            this.forms = [];
            this.forms.push(this.byId("sfBudgetManagerBlock1"));
            this.forms.push(this.byId("sfBudgetProj"));
            this.forms.push(this.byId("sfBudgetProj2"));
            this.forms.push(this.byId("sfFPAAppr"));
            this.forms.push(this.byId("sfRTRAppr"));
            this.forms.push(this.byId("sfBPCAppr"));

            // PARITY P-33: template files moved from the original app MIME folder into the BSP (webapp/Templates);
            // resolve them against the app root so the links also work inside the launchpad
            ["lnkAttCAPEXLicenseDownload", "lnkAttAccountingDownload"].forEach(function (sId) {
                var oLink = that.byId(sId);
                oLink.setHref(sap.ui.require.toUrl("zdci_nad_project_request/" + decodeURIComponent(oLink.getHref())).replace(/ /g, "%20"));
            });

            // Init.txt - sap.ui.getCore().attachInit(...)
            var oApp = this.byId("oApp"), listAttachments = this.byId("listAttachments"),
                oplForm = this.byId("oplForm"), AttachmentCategories = this.model("AttachmentCategories");
            // jQuery.getScript(discoveryFiori.js) -> module util/discoveryFiori (SHIM-RECONSTRUCTED)
            this.dc = new discoveryFiori.ChildComponent(this, "ZDCI_NAD_PROJECT_REQUEST", this.loadRequest.bind(this));
            this.dirty = new discoveryFiori.DirtyHandler();
            this.fu = new discoveryFiori.FileUploader(listAttachments, oplForm, AttachmentCategories);

            discoveryFiori.addExpandButtons(oplForm);

            // loadCSS("(original MIME path)") -> manifest sap.ui5/resources/css

            oApp.setBusyIndicatorDelay(0);

            setTimeout(function () {
                that.addDirtyEvents();
            }, 200);

            // Run initialization if we're not in a subcomponent.
            var btnNavBack = this.byId("btnNavBack");
            this.hasParent = true;
            var component = this.getOwnerComponent();
            if (!component
                || typeof component.getComponentData() !== "object"
                || !component.getComponentData().child) {
                this.hasParent = false;
                btnNavBack.setVisible(false);
                setTimeout(function () {
                    that.getUrlParameters();
                    oApp.setBusy(true);
                    that.getOnlineGetDetail();
                }, 1000);
            }
        },

        /* =============================================================== original app AJAX functions getOnline<X>
         * Generated from util/AjaxConfig.js (fn). Same names as the original app generated functions. */

        getOnlineGetDetail: function (v) { return AjaxRuntime.call(this, "GET_DATA", v); },
        getOnlineCreate: function (v) { return AjaxRuntime.call(this, "CREATE", v); },
        getOnlineCheck: function (v) { return AjaxRuntime.call(this, "CHECK", v); },
        getOnlineSaveAsDraft: function (v) { return AjaxRuntime.call(this, "SAVE", v); },
        getOnlineDeleteDraft: function (v) { return AjaxRuntime.call(this, "DELETE", v); },
        getOnlineReject: function (v) { return AjaxRuntime.call(this, "REJECT", v); },
        getOnlineSubmit: function (v) { return AjaxRuntime.call(this, "SUBMIT", v); },
        getOnlineResubmit: function (v) { return AjaxRuntime.call(this, "RESUBMIT", v); },
        getOnlineChange: function (v) { return AjaxRuntime.call(this, "CHANGE", v); },
        getOnlineClose: function (v) { return AjaxRuntime.call(this, "CLOSE", v); },
        getOnlineDeleteAttachment: function (v) { return AjaxRuntime.call(this, "DELETE_ATTACHMENT", v); },
        getOnlineBack: function (v) { return AjaxRuntime.call(this, "BACK", v); },
        getOnlineNewProject: function (v) { return AjaxRuntime.call(this, "NEW_PROJECT", v); },
        getOnlineNewIntOrderWErr: function (v) { return AjaxRuntime.call(this, "NEW_INTENALORDER_WEXP", v); },
        getOnlineDequeueForm: function (v) { return AjaxRuntime.call(this, "DEQUEUE_FORM", v); },
        getOnlineGetOnBehalfPerson: function (v) { return AjaxRuntime.call(this, "AGENT_SEARCH", v); },
        getOnlineGetAuthorizedBy: function (v) { return AjaxRuntime.call(this, "AUTH_BY_SEARCH", v); },
        getOnlineUpdateOnbehalf_ID: function (v) { return AjaxRuntime.call(this, "GET_ONBEHALF_ID", v); },
        getOnlineUpdateAuthorizedBy: function (v) { return AjaxRuntime.call(this, "GET_AUTHBY_ID", v); },
        getOnlineGetCostCenter: function (v) { return AjaxRuntime.call(this, "GET_COSTCENTER", v); },
        getOnlineUpdate_Region: function (v) { return AjaxRuntime.call(this, "UPDATE_REGION", v); },
        /** AJAX IDs whose original app function name is not in the specs (GET_EMPINFO, GET_AGENTLIST) - TODO(CAPTURE) */
        getOnlineAjax: function (sAjaxId, v) { return AjaxRuntime.call(this, sAjaxId, v); },

        /* =============================================================== AJAX ajaxSuccess / ajaxError (Ajax/*.md) */

        // ---- 13_GETDETAIL.md
        GET_DATA_ajaxSuccess: function () {
            var oApp = this.byId("oApp"), oplForm = this.byId("oplForm"), colStatusICON = this.byId("colStatusICON"),
                modeloPageProj = this.model("oPageProj"), modelUrlParameters = this.model("UrlParameters"),
                modelProgramState = this.model("ProgramState"), dirty = this.dirty;
            var setUI = this.setUI.bind(this), resetFields = this.resetFields.bind(this),
                getControlName = this.getControlName.bind(this),
                visible_additional_field = this.visible_additional_field.bind(this),
                set_attachment_visible = this.set_attachment_visible.bind(this),
                set_visibility_amount = this.set_visibility_amount.bind(this),
                setprocessingregion = this.setprocessingregion.bind(this),
                updateinitgrp = this.updateinitgrp.bind(this);

            setUI();
            resetFields();
            // PARITY P-31: oApp.to() receives a model, not a page -> no navigation (page already shown)
            try { oApp.to(modeloPageProj); } catch (e) { /* same no-op as original app */ }
            dirty.setDirty(false);
            discoveryFiori.addExpandButtons(oplForm);
            setTimeout(function () {
                // Scroll to expanded section
                if (modeloPageProj.getData().PROJ_FLGRP_0001_MOD == "Expanded") {
                    oplForm.scrollToSection(getControlName("subsectionRequester"));
                } else if (modeloPageProj.getData().PROJ_FLGRP_0002_MOD == "Expanded") {
                    oplForm.scrollToSection(getControlName("subsectionFPA"));
                } else if (modeloPageProj.getData().PROJ_FLGRP_0003_MOD == "Expanded") {
                    oplForm.scrollToSection(getControlName("subsectionRTR"));
                } else if (modeloPageProj.getData().PROJ_FLGRP_0004_MOD == "Expanded") {
                    oplForm.scrollToSection(getControlName("subsectionBPC"));
                }
                // Status icon visibility
                if (modelUrlParameters.getData().MODE === "" ||
                    (modeloPageProj.getData().REQUEST_FROM === 'N' ||
                     modeloPageProj.getData().REQUEST_FROM === "")) {
                    colStatusICON.setVisible(false);
                } else {
                    colStatusICON.setVisible(true);
                }
                // Program state message
                switch (modelProgramState.getData().PROGRAM_STATE) {
                    case 'E':
                        MessageToast.show(modelProgramState.getData().PROGRAM_MESSAGE);
                        break;
                }
                // Additional helpers
                visible_additional_field();
                set_attachment_visible();
                set_visibility_amount();
                setprocessingregion();
                updateinitgrp();
                oApp.setBusy(false);
            }, 500);
        },
        GET_DATA_ajaxError: function () {
            var oApp = this.byId("oApp");
            oApp.setBusy(false);
        },

        // ---- 01_CREATE_INIT.md
        CREATE_ajaxSuccess: function () {
            var oApp = this.byId("oApp"), oplForm = this.byId("oplForm"), modeloPageProj = this.model("oPageProj");
            var setUI = this.setUI.bind(this), setprocessingregion = this.setprocessingregion.bind(this),
                getControlName = this.getControlName.bind(this);

            setUI();
            // PARITY P-31
            try { oApp.to(modeloPageProj); } catch (e) { /* same no-op as original app */ }
            oApp.setBusy(false);
            setprocessingregion();
            setTimeout(function () {
                oplForm.scrollToSection(getControlName("subsectionRequester"));
            }, 1000);
        },
        CREATE_ajaxError: function () {
            var oApp = this.byId("oApp");
            oApp.setBusy(false);
        },

        // ---- 02_CHECK.md (PARITY P-01: server side no-op)
        CHECK_ajaxSuccess: function () {
            var oApp = this.byId("oApp"), diaChange = this.byId("diaChange"), diaSubmit = this.byId("diaSubmit"),
                modelProgramState = this.model("ProgramState"), modelUrlParameters = this.model("UrlParameters"),
                modelcntr_formdetails = this.model("cntr_formdetails");

            oApp.setBusy(false);
            if (modelProgramState.getData().PROGRAM_STATE &&
                modelProgramState.getData().PROGRAM_STATE.trim() === "E") {
                discoveryFiori.showMessage(
                    modelProgramState.getData().PROGRAM_MESSAGE,
                    ValueState.Error
                );
            } else if (
                modelUrlParameters.getData().MODE === "EDIT" &&
                modelcntr_formdetails.getData().APPR_STEP === "BUDGET_MANAGER"
            ) {
                diaChange.open();
            } else {
                diaSubmit.open();
            }
        },
        CHECK_ajaxError: function () {
            var oApp = this.byId("oApp"), txtConnectionFailure = this._txt("txtConnectionFailure");
            var showMessage = this.showMessage.bind(this);
            oApp.setBusy(false);
            showMessage(txtConnectionFailure.getText(), ValueState.Error);
        },

        // ---- 03_SAVE.md
        SAVE_ajaxSuccess: function () {
            var modeloPageProj = this.model("oPageProj"), dc = this.dc, txtSaveDraft = this._txt("txtSaveDraft");
            var getOnlineGetDetail = this.getOnlineGetDetail.bind(this);

            setTimeout(function () {
                if (modeloPageProj.getData().RESUBMIT) {
                    dc.goBack();
                } else {
                    getOnlineGetDetail();
                }
            }, 200);
            MessageToast.show(txtSaveDraft.getText());
        },
        SAVE_ajaxError: function () {
            var oApp = this.byId("oApp"), dc = this.dc, txtTranslateESaveAsDraft = this._txt("txtTranslateESaveAsDraft");
            var getOnlineDequeueForm = this.getOnlineDequeueForm.bind(this),
                getOnlineoTreeTable = this.getOnlineoTreeTable; // PARITY P-19: exists only in the parent app

            getOnlineDequeueForm();
            setTimeout(function () {
                oApp.setBusy(false);
                // jQuery.sap.require("sap.m.MessageToast"); -> imported
                MessageToast.show(txtTranslateESaveAsDraft.getText());
                if (typeof getOnlineoTreeTable === "function") { getOnlineoTreeTable(); } // P-19
                oApp.back();
            }, 100);
            dc.sendToParent({ event: "form-saved" });
            dc.goBack();
        },

        // ---- 04_DELETE.md
        DELETE_ajaxSuccess: function () {
            var oApp = this.byId("oApp"), modelProgramState = this.model("ProgramState"), dirty = this.dirty, dc = this.dc,
                txtDeleteDraft = this._txt("txtDeleteDraft");

            oApp.setBusy(false);
            if (modelProgramState.getData().PROGRAM_STATE &&
                modelProgramState.getData().PROGRAM_STATE.trim() === "E") {
                discoveryFiori.showMessage(
                    modelProgramState.getData().PROGRAM_MESSAGE,
                    ValueState.Error
                );
            } else {
                discoveryFiori.showMessage(
                    txtDeleteDraft.getText(),
                    ValueState.Success
                );
                dirty.setDirty(false);
                dc.sendToParent({ event: "form-saved" });
                dc.goBack();
            }
        },
        DELETE_ajaxError: function () {
            var oApp = this.byId("oApp"), txtConnectionFailure = this._txt("txtConnectionFailure");
            var showMessage = this.showMessage.bind(this);
            oApp.setBusy(false);
            showMessage(txtConnectionFailure.getText(), ValueState.Error);
        },

        // ---- 05_GET_ONBEHALF_ID.md
        GET_ONBEHALF_ID_ajaxSuccess: function () {
            var oplForm = this.byId("oplForm");
            var getControlName = this.getControlName.bind(this);
            setTimeout(function () {
                oplForm.scrollToSection(getControlName("subsectionRequester"));
            }, 1000);
        },
        GET_ONBEHALF_ID_ajaxError: function () {
            var oApp = this.byId("oApp"), txtConnectionFailure = this._txt("txtConnectionFailure");
            oApp.setBusy(false);
            discoveryFiori.showMessage(
                txtConnectionFailure.getText(),
                ValueState.Error
            );
        },

        // ---- 06_GET_AUTHBY_ID.md (PARITY P-03: copy of SAVE's handlers, server no-op)
        GET_AUTHBY_ID_ajaxSuccess: function () {
            return this.SAVE_ajaxSuccess();
        },
        GET_AUTHBY_ID_ajaxError: function () {
            return this.SAVE_ajaxError();
        },

        // ---- 07_SUBMIT.md
        SUBMIT_ajaxSuccess: function () {
            var oApp = this.byId("oApp"),
                // PARITY P-36: "diaMessages" is not in the control tree; falls back to diaMessage (which holds sysMessage)
                diaMessages = this.byId("diaMessages") || this.byId("diaMessage"),
                modelProgramState = this.model("ProgramState"), modelsysMessage = this.model("sysMessage"),
                modeloPageProj = this.model("oPageProj"), dirty = this.dirty, dc = this.dc,
                txtFinalApproval = this._txt("txtFinalApproval");

            oApp.setBusy(false);
            if (modelProgramState.getData().PROGRAM_STATE &&
                modelProgramState.getData().PROGRAM_STATE.trim() === "E") {
                if (Array.isArray(modelsysMessage.getData()) && modelsysMessage.getData().length) {
                    diaMessages.open();
                } else {
                    discoveryFiori.showMessage(
                        modelProgramState.getData().PROGRAM_MESSAGE,
                        ValueState.Error
                    );
                }
            } else {
                if (!modeloPageProj.getData().PROJ_FLGRP_0004) {
                    MessageToast.show("Project Code Request form approved Successfully");
                } else {
                    MessageToast.show(txtFinalApproval.getText());
                }
            }
            dirty.setDirty(false);
            dc.sendToParent({ event: "form-saved" });
            dc.goBack();
        },
        SUBMIT_ajaxError: function () {
            var oApp = this.byId("oApp"), txtConnectionFailure = this._txt("txtConnectionFailure");
            oApp.setBusy(false);
            discoveryFiori.showMessage(
                txtConnectionFailure.getText(),
                ValueState.Error
            );
        },

        // ---- NEW_PROJECT: no ajaxSuccess/ajaxError documented. PARITY P-27 / TODO(CAPTURE):
        // assumed to share SUBMIT's handlers (same send/receive). Replace with the captured code.
        NEW_PROJECT_ajaxSuccess: function () {
            return this.SUBMIT_ajaxSuccess();
        },
        NEW_PROJECT_ajaxError: function () {
            return this.SUBMIT_ajaxError();
        },

        // ---- NEW_INTENALORDER_WEXP: PARITY P-04 - no handler (backend branch commented out; busy stays on)

        // ---- 08_CHANGE.md
        CHANGE_ajaxSuccess: function () {
            var oApp = this.byId("oApp"), dirty = this.dirty, dc = this.dc, txtTranslateChange = this._txt("txtTranslateChange");
            setTimeout(function () {
                oApp.setBusy(false);
                // jQuery.sap.require("sap.m.MessageToast"); -> imported
                MessageToast.show(txtTranslateChange.getText());
            }, 100);
            dirty.setDirty(false);
            dc.sendToParent({ event: "form-saved" });
            dc.goBack();
        },
        CHANGE_ajaxError: function () {
            // PARITY P-28: no error message
            var oApp = this.byId("oApp"), dc = this.dc;
            var getOnlineBack = this.getOnlineBack.bind(this);
            oApp.setBusy(false);
            getOnlineBack();
            dc.sendToParent({ event: "form-saved" });
            dc.goBack();
        },

        // ---- 09_DEQUEUE_FORM.md / 10_BACK.md: fire and forget (no handlers)

        // ---- 11_REJECT.md
        REJECT_ajaxSuccess: function () {
            var oApp = this.byId("oApp"), modelProgramState = this.model("ProgramState"), dirty = this.dirty, dc = this.dc,
                txtRejected = this._txt("txtRejected");

            // getOnlineDequeueForm(); -- commented out
            oApp.setBusy(false);
            if (modelProgramState.getData().PROGRAM_STATE &&
                modelProgramState.getData().PROGRAM_STATE.trim() === "E") {
                // Output errors
                discoveryFiori.showMessage(
                    modelProgramState.getData().PROGRAM_MESSAGE,
                    ValueState.Error
                );
            } else {
                MessageToast.show(txtRejected.getText());
                dirty.setDirty(false);
                dc.sendToParent({ event: "form-saved" });
                dc.goBack();
            }
        },
        REJECT_ajaxError: function () {
            var oApp = this.byId("oApp"), txtConnectionFailure = this._txt("txtConnectionFailure");
            var showMessage = this.showMessage.bind(this);
            oApp.setBusy(false);
            showMessage(txtConnectionFailure.getText(), ValueState.Error);
        },

        // ---- 12_CLOSE.md
        CLOSE_ajaxSuccess: function () {
            var oApp = this.byId("oApp"), dc = this.dc, txtTranslateWithdrawn = this._txt("txtTranslateWithdrawn");
            setTimeout(function () {
                oApp.setBusy(false);
                // jQuery.sap.require("sap.m.MessageToast"); -> imported
                MessageToast.show(txtTranslateWithdrawn.getText());
            }, 100);
            dc.sendToParent({ event: "form-saved" });
            dc.goBack();
        },
        CLOSE_ajaxError: function () {
            // PARITY P-28: no error message
            var oApp = this.byId("oApp"), dc = this.dc;
            var getOnlineDequeueForm = this.getOnlineDequeueForm.bind(this);
            oApp.setBusy(false);
            getOnlineDequeueForm();
            dc.sendToParent({ event: "form-saved" });
            dc.goBack();
        },

        // ---- 14_RESUBMIT.md
        RESUBMIT_ajaxSuccess: function () {
            var oApp = this.byId("oApp"), dirty = this.dirty, dc = this.dc, txtTranslateResubmit = this._txt("txtTranslateResubmit");
            // Wait a bit for data read above, and then navigate
            setTimeout(function () {
                oApp.setBusy(false);
                // jQuery.sap.require("sap.m.MessageToast"); -> imported
                MessageToast.show(txtTranslateResubmit.getText());
            }, 100);
            // Launch event so that the caller can update their list
            dirty.setDirty(false);
            dc.sendToParent({ event: "form-saved" });
            dc.goBack();
        },
        RESUBMIT_ajaxError: function () {
            // PARITY P-28: no error message
            var oApp = this.byId("oApp"), dc = this.dc;
            var getOnlineBack = this.getOnlineBack.bind(this);
            oApp.setBusy(false);
            getOnlineBack();
            // Launch event so that the caller can update their list
            dc.sendToParent({ event: "form-saved" });
            dc.goBack();
        },

        // ---- AJAX objects WITHOUT documented handlers. PARITY P-37 / TODO(CAPTURE):
        // the callers set oApp busy, so the minimal handler releases it. Replace with the captured code.
        AGENT_SEARCH_ajaxSuccess: function () { this.byId("oApp").setBusy(false); },
        AGENT_SEARCH_ajaxError: function () { this._genericAjaxError(); },
        AUTH_BY_SEARCH_ajaxSuccess: function () { this.byId("oApp").setBusy(false); },
        AUTH_BY_SEARCH_ajaxError: function () { this._genericAjaxError(); },
        GET_COSTCENTER_ajaxSuccess: function () { this.byId("oApp").setBusy(false); },
        GET_COSTCENTER_ajaxError: function () { this._genericAjaxError(); },
        UPDATE_REGION_ajaxSuccess: function () { this.byId("oApp").setBusy(false); },
        UPDATE_REGION_ajaxError: function () { this._genericAjaxError(); },
        GET_EMPINFO_ajaxSuccess: function () { this.byId("oApp").setBusy(false); },
        GET_EMPINFO_ajaxError: function () { this._genericAjaxError(); },
        GET_AGENTLIST_ajaxSuccess: function () { this.byId("oApp").setBusy(false); },
        GET_AGENTLIST_ajaxError: function () { this._genericAjaxError(); },
        DELETE_ATTACHMENT_ajaxSuccess: function () {
            // TODO(CAPTURE): inferred - backend deleted the attachment at DELETE_INDEX
            var oApp = this.byId("oApp"), modelProgramState = this.model("ProgramState"),
                modellistAttachments = this.model("listAttachments"), modeldiaConfirmAttDelete = this.model("diaConfirmAttDelete");
            oApp.setBusy(false);
            if (modelProgramState.getData().PROGRAM_STATE &&
                modelProgramState.getData().PROGRAM_STATE.trim() === "E") {
                discoveryFiori.showMessage(modelProgramState.getData().PROGRAM_MESSAGE, ValueState.Error);
            } else {
                modellistAttachments.getData().splice(Number(modeldiaConfirmAttDelete.getData().DELETE_INDEX), 1);
                modellistAttachments.updateBindings();
            }
        },
        DELETE_ATTACHMENT_ajaxError: function () { this._genericAjaxError(); },
        _genericAjaxError: function () {
            var oApp = this.byId("oApp"), txtConnectionFailure = this._txt("txtConnectionFailure");
            oApp.setBusy(false);
            discoveryFiori.showMessage(txtConnectionFailure.getText(), ValueState.Error);
        },

        /* =============================================================== Utility.txt */

        showMessage: function (message, state) {
            var msgDialog = new Dialog({
                state: state,
                title: "Attention",
                endButton: new Button({
                    icon: "sap-icon://sys-cancel",
                    press: function (evt) {
                        evt.getSource().getParent().close();
                    }
                }),
                content: new Text({
                    text: message
                })
            });
            msgDialog.open();
        },

        loadRequest: function (evt) {
            var btnNavBack = this.byId("btnNavBack"), oApp = this.byId("oApp"), modelUrlParameters = this.model("UrlParameters");
            var getOnlineGetDetail = this.getOnlineGetDetail.bind(this);

            btnNavBack.setVisible(true);
            modelUrlParameters.setProperty("/FORM_GUID", evt.detail.FORM);
            modelUrlParameters.setProperty("/PROJ", evt.detail.ID);
            modelUrlParameters.setProperty("/FROM", evt.detail.FROM);

            if (evt.detail.PROJREQ === 'NEW' || evt.detail.PROJREQ === 'requests' || evt.detail.ID === '') {
                modelUrlParameters.setProperty("/MODE", "");
            } else if (evt.detail.FROM === 'search') {
                modelUrlParameters.setProperty("/MODE", "DISPLAY");
            } else {
                modelUrlParameters.setProperty("/MODE", "CHANGE");
            }

            oApp.setBusy(true);
            getOnlineGetDetail();
        },

        /** original app: prefixes the jsview id when running inside a view. UI5: full id of the control. */
        getControlName: function (cname) {
            return this.createId(cname);
        },

        updateinitgrp: function () {
            var oSelectInitPrd_Grp = this.byId("oSelectInitPrd_Grp"),
                modelcntr_formdetails = this.model("cntr_formdetails"),
                modeloTableINITIA_GRP = this.model("oTableINITIA_GRP"), modeloPageProj = this.model("oPageProj");

            if (modelcntr_formdetails.getData().APPR_STEP === "FPA") {
                oSelectInitPrd_Grp.destroyItems();

                // Empty row
                oSelectInitPrd_Grp.setSelectedKey() == ''; // eslint-disable-line no-unused-expressions
                oSelectInitPrd_Grp.addItem(new Item({
                    key: "",
                    text: ""
                }));

                jQuery.each(modeloTableINITIA_GRP.getData(), function (i, data) {
                    if (modeloPageProj.getData().EXEC_CATEGORY === data.EXEC_CATEGORY_ID) {
                        oSelectInitPrd_Grp.addItem(new Item({
                            key: data.INITIATIVE_GRP_ID,
                            text: data.INITIATIVE_GRP_TXT
                        }));
                    }
                });
            }
        },

        getUrlParameters: function () {
            var modelUrlParameters = this.model("UrlParameters");
            var query = "";
            var form = "";

            if (window.location.href.indexOf("/ui2/flp") >= 0) {
                query = window.location.hash.split("?")[1];
            } else {
                query = window.location.search.split("?")[1];
            }

            if (query) {
                var params = query.split("&");
                params.forEach(function (param) {
                    var keyvalue = param.split("=");
                    switch (keyvalue[0]) {
                        case "form_guid":
                            form = keyvalue[1];
                            break;
                    }
                });
            }

            if (form && form.trim() !== "") {
                modelUrlParameters.setProperty("/FORM_GUID", form);
                //modelUrlParameters.setProperty("/MODE", "CHANGE");
            }
        },

        // loadCSS(filename): not ported - css/app.css is declared in manifest.json (sap.ui5/resources/css)

        fileUploadHandler: function () {
            var oFileUploader = this.byId("oFileUploader"), diaAddAttachment = this.byId("diaAddAttachment"),
                oplForm = this.byId("oplForm"), listAttachments = this.byId("listAttachments");
            var getControlName = this.getControlName.bind(this);

            var fileUpload = document.getElementById(oFileUploader.getDomRef().id + "-fu");
            fileUpload.addEventListener("change", function () {
                var reader = new FileReader();
                reader.onload = function (event) {
                    var newAttachment = {
                        ICON: "sap-icon://document",
                        ICON_COLOR: "",
                        FILE_NAME: fileUpload.files[0].name,
                        EXTENSION: fileUpload.files[0].name.split(".").pop(),
                        MIME_TYPE: fileUpload.files[0].type,
                        FILE_DATA: event.target.result,
                        UUID: ""
                    };
                    if (newAttachment.FILE_DATA.substring(0, 4) === "data") {
                        newAttachment.FILE_DATA = newAttachment.FILE_DATA.substring(newAttachment.FILE_DATA.indexOf(',') + 1);
                    }
                    ModelData.Add(listAttachments, newAttachment);
                    oFileUploader.clear();
                    diaAddAttachment.close();

                    oplForm.scrollToSection(getControlName("sectionAttachments"));
                };
                reader.readAsDataURL(fileUpload.files[0]);
            }, {
                once: true
            });
        },

        displayAttachment: function (attachment) {
            var modelvlAttributesBlock1 = this.model("vlAttributesBlock1");
            if (typeof attachment.FILE_DATA !== "undefined" && attachment.FILE_DATA.length > 0) {
                var byteCharacters = atob(attachment.FILE_DATA);
                var byteNumbers = new Array(byteCharacters.length);
                for (var i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                var blob = new Blob([new Uint8Array(byteNumbers)], {
                    type: attachment.MIME_TYPE
                });
                if (window.navigator &&
                    window.navigator.msSaveOrOpenBlob) {
                    window.navigator.msSaveOrOpenBlob(blob, attachment.FILE_NAME);
                } else {
                    window.open(URL.createObjectURL(blob), "_blank");
                }
            } else {
                // Retrieve data from backend if necessary.
                // PARITY P-34: was (original MIME path)<GUID>,att=<UUID>
                // -> same HANDLE_ON_REQUEST( key = 'ATTACHMENT' ) via the OData media entity ATTACHMENTSet
                var url = AjaxRuntime.attachmentUrl(this, modelvlAttributesBlock1.getData().FORM_GUID, attachment.UUID);
                window.open(url, "_blank");
            }
        },

        setDirty: function (dirty) {
            this.isDirty = dirty;
        },

        visible_additional_field: function () {
            var modeloPageProj = this.model("oPageProj"), AttachmentsRequired = this.model("AttachmentsRequired"),
                vbAttCAPEXLicenses = this.byId("vbAttCAPEXLicenses"), vbAttSoftwareLicense = this.byId("vbAttSoftwareLicense"),
                vbAttAccounting = this.byId("vbAttAccounting"), rbITLYes = this.byId("rbITLYes"),
                oLblTIFundReq = this.byId("oLblTIFundReq"), rbTI_Fund_Yes = this.byId("rbTI_Fund_Yes"),
                rbTI_Fund_No = this.byId("rbTI_Fund_No"), oLblTIAmtReq = this.byId("oLblTIAmtReq"),
                rbTI_Amount_Yes = this.byId("rbTI_Amount_Yes"), rbTI_Amount_No = this.byId("rbTI_Amount_No"),
                inpCAPEX_Amount = this.byId("inpCAPEX_Amount"), oSelectCAPCURR = this.byId("oSelectCAPCURR"),
                vbFPAApprovalAtt = this.byId("vbFPAApprovalAtt");

            modeloPageProj.setProperty("/V_PROJECT_SUBTYPE",
                modeloPageProj.getData().PROJECT_TYPE === "5");
            // debugger (original app source)
            var type = modeloPageProj.getData().PROJECT_TYPE;
            var capexti_val = modeloPageProj.getData().CAPEX_TI;
            var subtype = (typeof modeloPageProj.getData().PROJECT_SUBTYPE === "string" && modeloPageProj.getData().PROJECT_SUBTYPE.trim().length > 0) ?
                modeloPageProj.getData().PROJECT_SUBTYPE : "00";

            var required = ModelData.Find(AttachmentsRequired, ["PROJECT_TYPE", "PROJECT_SUBTYPE", "REQUIRED"],
                [type, subtype, true],
                ["EQ", "EQ", "EQ"]);

            let formVis = [false, false, false];

            for (let i = 0; i < required.length; i++) {
                let cat = required[i];
                switch (cat.ATT_CATEGORY) {
                    case "ACCOUNTING":
                        formVis[2] = true;
                        break;
                    case "CAPEX_LICENSE":
                        formVis[0] = true;
                        break;
                    case "SOFTWARE_LICENSE":
                        formVis[1] = true;
                        break;
                }
            }

            vbAttCAPEXLicenses.setVisible(formVis[0]);
            vbAttSoftwareLicense.setVisible(formVis[1]);
            vbAttAccounting.setVisible(formVis[2]);

            if (type === "3" && !rbITLYes.getSelected()) {
                vbAttAccounting.setVisible(false);
            }

            //ENHC0019081 - Begin TI - Tenant Improvement
            // debugger (original app source)
            if (type === "2") {
                oLblTIFundReq.setVisible(true);
                oLblTIFundReq.setRequired(true);
                rbTI_Fund_Yes.setVisible(true);
                rbTI_Fund_No.setVisible(true);

                if (capexti_val === "Y" || capexti_val === "N") {
                    // Check and update selection TI Fund
                    if (capexti_val === "Y") {
                        rbTI_Fund_Yes.setSelected(true);
                        rbTI_Fund_No.setSelected(false);

                        oLblTIAmtReq.setVisible(true);
                        oLblTIAmtReq.setRequired(true);
                        rbTI_Amount_Yes.setVisible(true);
                        rbTI_Amount_No.setVisible(true);

                    } else if (capexti_val === "N") {
                        rbTI_Fund_No.setSelected(true);
                        rbTI_Fund_Yes.setSelected(false);
                        oLblTIAmtReq.setVisible(false);
                        oLblTIAmtReq.setRequired(false);
                        rbTI_Amount_Yes.setVisible(false);
                        rbTI_Amount_No.setVisible(false);

                    }

                    // Check and update selection TI Amount
                    if (modeloPageProj.getData().CAPEX_TI_AMT_INC === "Y") {
                        rbTI_Amount_Yes.setSelected(true);
                        rbTI_Amount_No.setSelected(false);
                    } else if (modeloPageProj.getData().CAPEX_TI_AMT_INC === "N") {
                        rbTI_Amount_No.setSelected(true);
                        rbTI_Amount_Yes.setSelected(false);
                    }

                } else {
                    oLblTIAmtReq.setVisible(false);
                    oLblTIAmtReq.setRequired(false);
                    rbTI_Amount_Yes.setVisible(false);
                    rbTI_Amount_No.setVisible(false);
                    modeloPageProj.getData().CAPEX_TI = ""; // PARITY: no refresh
                    modeloPageProj.getData().CAPEX_TI_AMT_INC = "";
                }

            } else {
                oLblTIFundReq.setVisible(false);
                oLblTIFundReq.setRequired(false);
                rbTI_Fund_Yes.setVisible(false);
                rbTI_Fund_No.setVisible(false);
                rbTI_Fund_Yes.setSelected(false);
                rbTI_Fund_No.setSelected(false);

                oLblTIAmtReq.setVisible(false);
                oLblTIAmtReq.setRequired(false);
                rbTI_Amount_Yes.setSelected(false);
                rbTI_Amount_No.setSelected(false);
                rbTI_Amount_Yes.setVisible(false);
                rbTI_Amount_No.setVisible(false);

                modeloPageProj.getData().CAPEX_TI = ""; // PARITY: no refresh
                modeloPageProj.getData().CAPEX_TI_AMT_INC = "";
            }

            //ENHC0019081 - End TI - Tenant Improvement

            modeloPageProj.setProperty("/V_ITL", type === "3");
            //modeloPageProj.setProperty("/V_SOFTWARE_REQ",type === "3");

            inpCAPEX_Amount.setVisible(type !== "6");
            oSelectCAPCURR.setVisible(type !== "6");
            vbFPAApprovalAtt.setVisible(type !== "6");
        },

        set_TI_funding_visible: function () {
            var modeloPageProj = this.model("oPageProj"), rbTI_Fund_Yes = this.byId("rbTI_Fund_Yes"),
                oLblTIAmtReq = this.byId("oLblTIAmtReq"), rbTI_Amount_Yes = this.byId("rbTI_Amount_Yes"),
                rbTI_Amount_No = this.byId("rbTI_Amount_No");

            // debugger (original app source)
            var settifundingvisible = "";
            if (modeloPageProj.getData().CAPEX_TI === "Y" || rbTI_Fund_Yes.getSelected()) {
                settifundingvisible = "X";
            } else {
                settifundingvisible = "";
            }

            if (settifundingvisible == "X") {
                oLblTIAmtReq.setVisible(true);
                oLblTIAmtReq.setRequired(true);
                rbTI_Amount_Yes.setVisible(true);
                rbTI_Amount_No.setVisible(true);
                rbTI_Amount_Yes.setSelected(false);
                rbTI_Amount_No.setSelected(false);
            } else {
                oLblTIAmtReq.setVisible(false);
                oLblTIAmtReq.setRequired(false);
                rbTI_Amount_Yes.setSelected(false);
                rbTI_Amount_No.setSelected(false);
            }
        },

        clear_value: function () {
            // Clear Value based on the condition
            // (whole body commented out in original app - returns undefined, so "!clear_value()" is always true)
        },

        set_visibility_amount: function () {
        },

        set_attachment_visible: function () {
        },

        set_projcode_button: function () {
            // NOTE: BtnProjectCode / BtnProjectCodeClear are not in the control tree and this function is never
            // called in the known original app code - ported as is.
            var inpProjCode = this.byId("inpProjCode"), BtnProjectCode = this.byId("BtnProjectCode"),
                BtnProjectCodeClear = this.byId("BtnProjectCodeClear");
            if (inpProjCode.getSelectedKey().length === 0) {
                BtnProjectCode.setEnabled(true);
                BtnProjectCodeClear.setEnabled(false);
            } else {
                BtnProjectCode.setEnabled(false);
                BtnProjectCodeClear.setEnabled(true);
            }
        },

        setprocessingregion: function () {
            var modeloPageProj = this.model("oPageProj"), rbgQProcessingRegion = this.byId("rbgQProcessingRegion");
            switch (modeloPageProj.getData().PROCESSING_REGION) {
                case 'U':
                    rbgQProcessingRegion.setSelectedIndex(0);
                    break;
                case 'E':
                    rbgQProcessingRegion.setSelectedIndex(1);
                    break;
                case 'A':
                    rbgQProcessingRegion.setSelectedIndex(2);
                    break;
                default:
                    modeloPageProj.getData().PROCESSING_REGION = 'U'; // PARITY: no refresh
                    rbgQProcessingRegion.setSelectedIndex(0);
            }
        },

        /* =============================================================== form.txt */

        validateRequiredAll: function () {
            var modeloPageProj = this.model("oPageProj"),
                sfBudgetManagerBlock1 = this.byId("sfBudgetManagerBlock1"), sfBudgetManagerBlock2 = this.byId("sfBudgetManagerBlock2"),
                sfBudgetProj = this.byId("sfBudgetProj"), sfBudgetProj2 = this.byId("sfBudgetProj2"),
                sfFPAAppr = this.byId("sfFPAAppr"), sfRTRAppr = this.byId("sfRTRAppr"), sfBPCAppr = this.byId("sfBPCAppr");
            var validateRequired = this.validateRequired.bind(this);

            var error = false;

            var currform = [];
            // Get Model Data
            if (modeloPageProj.getData().PROJ_FLGRP_0001 || modeloPageProj.getData().PROJ_FLGRP_0005) {
                currform.push(sfBudgetManagerBlock1);
                currform.push(sfBudgetManagerBlock2);
                currform.push(sfBudgetProj);
                currform.push(sfBudgetProj2);

            }
            if (modeloPageProj.getData().PROJ_FLGRP_0002) {
                currform.push(sfFPAAppr);

            }
            if (modeloPageProj.getData().PROJ_FLGRP_0003) {
                currform.push(sfRTRAppr);

            }
            if (modeloPageProj.getData().PROJ_FLGRP_0004) {
                currform.push(sfBPCAppr);
            }

            currform.forEach(function (form) {
                form.getAggregation("form").getAggregation("formContainers")[0].getAggregation("formElements").forEach(function (element) {
                    var field = element.getFields()[0];

                    if (element.getLabel().getRequired()) {
                        if (validateRequired(field, form)) {
                            error = true;
                        }

                    } else if (field._bValid === false) {

                        if (field instanceof DatePicker) {

                            field.setValueState(ValueState.Error);
                            field.setValueStateText("Invalid date.");
                            field.setShowValueStateMessage(true);
                            field.focus();

                            error = true;
                        }

                    }
                });
            });

            return error;
        },

        validateRequired: function (input, form) {
            var oSwitchFPAAppr = this.byId("oSwitchFPAAppr"), oSwitchRTRAppr = this.byId("oSwitchRTRAppr"),
                oSwitchBPCAppr = this.byId("oSwitchBPCAppr");
            var validateRequired = this.validateRequired.bind(this);

            var error = false;
            if (typeof input.setValueState === "function") {
                input.setValueState(ValueState.None);
            }

            if (!input.getVisible()) return false;
            if (typeof input.getEnabled === "function" && !input.getEnabled()) return false;

            if (input instanceof Input || input instanceof TextArea || input instanceof DatePicker) {
                if (input.getValue().length === 0) {
                    // autoExpand(form);
                    input.setValueState(ValueState.Error);
                    input.setValueStateText("Entry is required.");
                    input.setShowValueStateMessage(true);
                    input.focus();
                    error = true;
                }
            } else if (input instanceof Switch) {
                if (!input.getState()) {
                    input.addStyleClass("error-switch");
                    if (input === oSwitchFPAAppr ||
                        input === oSwitchRTRAppr ||
                        input === oSwitchBPCAppr) {
                        discoveryFiori.showMessage("Select 'YES' to acknowledge before you submit the form", ValueState.Error);
                        error = true;
                    }
                }
            } else if (input instanceof Select || input instanceof MultiComboBox) {
                if (input.getSelectedKey().length === 0) {
                    input.setValueState(ValueState.Error);
                    input.setValueStateText("Entry is required.");
                    input.focus();
                    error = true;
                }
            } else if (input instanceof RadioButtonGroup) {

                error = false;
                var selected = false;
                input.getButtons().forEach(function (btn) {
                    if (btn.getSelected()) selected = true;
                });

                if (!selected) {
                    input.setValueState(ValueState.Error);
                    input.focus();
                    error = true;

                }

            } else if (input instanceof VBox || input instanceof HBox) {
                input.getItems().forEach(function (item) {
                    if (validateRequired(item, form)) error = true;
                });
            }

            return error;
        },

        validate_date: function () {
            var dpOrderCompDate = this.byId("dpOrderCompDate"), dporderdate = this.byId("dporderdate");
            var error = false;

            if (dpOrderCompDate.getDateValue() < dporderdate.getDateValue()) {
                dpOrderCompDate.setValueState(ValueState.Error);
                dpOrderCompDate.setValueStateText("The Project Completion Date (estimated) is less than Order Date ");
                dpOrderCompDate.setShowValueStateMessage(true);
                dpOrderCompDate.focus();
                error = true;
            }

            return error;
        },

        validateAttachment: function () {
            var modeloPageProj = this.model("oPageProj"), AttachmentsRequired = this.model("AttachmentsRequired"),
                AttachmentCategories = this.model("AttachmentCategories"), listAttachments = this.byId("listAttachments"),
                rbITLYes = this.byId("rbITLYes");

            var error = false;
            var count = 0;

            var type = modeloPageProj.getData().PROJECT_TYPE;
            var subtype = (typeof modeloPageProj.getData().PROJECT_SUBTYPE === "string" && modeloPageProj.getData().PROJECT_SUBTYPE.trim().length > 0)
                ? modeloPageProj.getData().PROJECT_SUBTYPE : "00";

            var required = ModelData.Find(AttachmentsRequired, ["PROJECT_TYPE", "PROJECT_SUBTYPE", "REQUIRED"],
                [type, subtype, true],
                ["EQ", "EQ", "EQ"]);

            required.forEach(function (category) {
                if (type === "3" && category.ATT_CATEGORY === "ACCOUNTING" && !rbITLYes.getSelected()) {
                    return;
                }

                if (ModelData.Find(listAttachments, "CATEGORY", category.ATT_CATEGORY, "EQ").length === 0) {
                    var cat = ModelData.Find(AttachmentCategories, "VALUE", category.ATT_CATEGORY, "EQ");
                    if (cat.length) {
                        if (type !== "3") {
                            discoveryFiori.showMessage("You must attach " + cat[0].TEXT + " to this form before you submit it for approval.", ValueState.Error);
                        }
                        error = true;
                    }
                } else {
                    // Track how many requirements were satisfied.
                    count++;
                }
            });

            if (type === "3") {
                if (count > 1) {
                    error = false;
                } else {
                    if (rbITLYes.getSelected()) {
                        discoveryFiori.showMessage("You must attach the FP&A Approval Document and either"
                        + " the Accounting Questionnaire or CAPEX Software License"
                        + " to this form before you submit it for approval.", ValueState.Error);
                    } else {
                        discoveryFiori.showMessage("You must attach the FP&A Approval Document and"
                        + " the CAPEX Software License"
                        + " to this form before you submit it for approval.", ValueState.Error);
                    }
                }
            }

            return error;
        },

        validateAmount: function () {
            var modeloPageProj = this.model("oPageProj"), inpCAPEX_Amount = this.byId("inpCAPEX_Amount"),
                inpITL_Amount = this.byId("inpITL_Amount"), oLblCAPEX_AMOUNT = this.byId("oLblCAPEX_AMOUNT"),
                oLblITL_AMOUNT = this.byId("oLblITL_AMOUNT"), oSelectCAPCURR = this.byId("oSelectCAPCURR"),
                oSelectITLCURR = this.byId("oSelectITLCURR");

            var error = false; // eslint-disable-line no-unused-vars

            if (modeloPageProj.getData().PROJECT_TYPE === "6") {
                return;
            }

            var capamount = Number(inpCAPEX_Amount.getValue());
            var itlamount = Number(inpITL_Amount.getValue());

            if ((oLblCAPEX_AMOUNT.getRequired()) && capamount <= 0) {
                inpCAPEX_Amount.setValueState(ValueState.Error);
                inpCAPEX_Amount.setValueStateText("The CAPEX Amount should be greater 0");
                inpCAPEX_Amount.setShowValueStateMessage(true);
                inpCAPEX_Amount.focus();
                return true;
            } else if ((oLblITL_AMOUNT.getRequired()) && itlamount <= 0) {
                inpITL_Amount.setValueState(ValueState.Error);
                inpITL_Amount.setValueStateText("The ITL requested Amount should be greater 0");
                inpITL_Amount.setShowValueStateMessage(true);
                inpITL_Amount.focus();
                return true;
            } else if ((oLblCAPEX_AMOUNT.getRequired()) && oSelectCAPCURR.getSelectedKey().length === 0) {
                oSelectCAPCURR.setValueState(ValueState.Error);
                oSelectCAPCURR.setValueStateText("Currency is required");
                oSelectCAPCURR.focus();
                error = true; // PARITY P-15: not returned -> currency errors never block
            } else if ((oLblITL_AMOUNT.getRequired()) && oSelectITLCURR.getSelectedKey().length === 0) {
                oSelectITLCURR.setValueState(ValueState.Error);
                oSelectITLCURR.setValueStateText("Currency is required");
                oSelectITLCURR.focus();
                error = true; // PARITY P-15
            }
        },

        validate_projname: function () {
            return false; // PARITY P-24 (length check commented out in original app)
        },

        validate_bussjustname: function () {
            var oTxtProjBussJust = this.byId("oTxtProjBussJust"), oTxtProjDesc = this.byId("oTxtProjDesc");
            var error = false;
            if (oTxtProjBussJust.getValue() == oTxtProjDesc.getValue()) {
                oTxtProjBussJust.setValueState(ValueState.Error);
                oTxtProjBussJust.setValueStateText("The Business Justification should not be same as description of project");
                oTxtProjBussJust.setShowValueStateMessage(true);
                oTxtProjBussJust.focus();
                error = true;
            }

            return error;
        },

        validate_additionalCCode: function () {
            var error = false; // eslint-disable-line no-unused-vars
            var table = document.getElementById("tabMultiCC"); // eslint-disable-line no-unused-vars
        },

        resetFields: function () {
            this.forms.forEach(function (form) {
                form.getAggregation("form").getAggregation("formContainers")[0].getAggregation("formElements").forEach(function (element) {
                    var field = element.getFields()[0];
                    if (field instanceof Input || field instanceof Select) {
                        field.setValueState(ValueState.None);
                    } else if (field instanceof Switch) {
                        field.removeStyleClass("error-switch");
                    }
                });
            });
        },

        setUI: function () {
            var btnAddAttachment = this.byId("btnAddAttachment"), modeloPageProj = this.model("oPageProj"),
                rbITLYes = this.byId("rbITLYes"), rbITLNo = this.byId("rbITLNo");

            // Reset form fields.
            this.forms.forEach(function (form) {
                form.getAggregation("form").getAggregation("formContainers")[0].getAggregation("formElements").forEach(function (element) {
                    var field = element.getFields()[0];
                    if (typeof field.setValueState === "function") {
                        field.setValueState(ValueState.None);
                    }
                });
            });

            btnAddAttachment.setVisible(modeloPageProj.getData().CAN_ATTACH);

            rbITLYes.setSelected(modeloPageProj.getData().ITL === "Y");
            rbITLNo.setSelected(modeloPageProj.getData().ITL !== "Y");
        },

        // addDirtyEvents is defined three times (identically) in form.txt - ported once
        addDirtyEvents: function () {
            var dirty = this.dirty;
            this.forms.forEach(function (form) {
                form.getAggregation("form").getAggregation("formContainers")[0].getAggregation("formElements").forEach(function (element) {
                    var field = element.getFields()[0];
                    if (typeof field.attachChange === "function") {
                        field.attachChange(function (evt) {
                            dirty.setDirty(true);
                        });
                    }
                });
            });
        },

        toggleMode: function () {
            var oApp = this.byId("oApp"), modeloPageProj = this.model("oPageProj"), modelUrlParameters = this.model("UrlParameters"),
                modelvlAttributesBlock1 = this.model("vlAttributesBlock1");
            var getOnlineGetDetail = this.getOnlineGetDetail.bind(this);

            var mode = modeloPageProj.getData().DISPLAY_OR_EDIT;
            mode = (mode === "DISPLAY") ? "EDIT" : "DISPLAY";

            modelUrlParameters.setData({
                FORM_GUID: modelvlAttributesBlock1.getData().FORM_GUID,
                MODE: mode,
                PROJ: modelUrlParameters.getData().PROJ,
                FROM: modelUrlParameters.getData().FROM,
                PROCESSING_REGION: modeloPageProj.getData().PROCESSING_REGION,
                COMPANY_CODE: modeloPageProj.getData().COMPANY_CODE
            });
            oApp.setBusy(true);
            getOnlineGetDetail();
        },

        loadProject: function (inc) {
            var oApp = this.byId("oApp"), modelUrlParameters = this.model("UrlParameters");
            var getOnlineGetDetail = this.getOnlineGetDetail.bind(this);

            this.listIndex += inc;
            if (this.listIndex >= 0 && this.listIndex <= this.listRef.length) {
                var projectid = this.listRef[this.listIndex];
                modelUrlParameters.setProperty("/MODE", "DISPLAY");
                modelUrlParameters.setProperty("/FORM_GUID", projectid.FORM_GUID);
                modelUrlParameters.setProperty("/PROJ", projectid.ID);
                oApp.setBusy(true);
                getOnlineGetDetail();
            }

            // PARITY P-32: setNavVisible() is not defined anywhere in the original app (ReferenceError there)
            if (typeof this.setNavVisible === "function") {
                this.setNavVisible();
            }
        },

        /* =============================================================== control events: header */

        btnNavBack_press: function () {
            // TODO(SPEC-MISSING): press code not captured - inferred: back to the parent component
            this.dc.goBack();
        },
        btnPrevOrder_press: function () {
            // TODO(SPEC-MISSING): inferred from form.txt loadProject(inc)
            this.loadProject(-1);
        },
        btnNextOrder_press: function () {
            // TODO(SPEC-MISSING): inferred from form.txt loadProject(inc)
            this.loadProject(1);
        },
        btnToggleEdit_press: function () {
            // TODO(SPEC-MISSING): inferred from form.txt toggleMode()
            this.toggleMode();
        },
        oObjectEmpName_press: function (oEvent) {
            // TODO(SPEC-MISSING): inferred - GET_EMPINFO fills oFormEmployeeInfo, shown in diaEmployeeInfo
            var diaEmployeeInfo = this.byId("diaEmployeeInfo");
            this.getOnlineAjax("GET_EMPINFO");
            diaEmployeeInfo.openBy(oEvent.getSource());
        },
        oObjectAgent_press: function () {
            // TODO(SPEC-MISSING): inferred - GET_AGENTLIST fills listAgents, shown in diaAgents
            var diaAgents = this.byId("diaAgents");
            this.getOnlineAjax("GET_AGENTLIST");
            diaAgents.open();
        },

        /* =============================================================== control events: subsectionRequester
         * TODO(SPEC-MISSING): subsectionRequester_SPEC.md is not in the repo - every handler here is inferred. */

        rbgQProcessingRegion_select: function () {
            var rbgQProcessingRegion = this.byId("rbgQProcessingRegion"), modeloPageProj = this.model("oPageProj"),
                modelUrlParameters = this.model("UrlParameters");
            var region = ["U", "E", "A"][rbgQProcessingRegion.getSelectedIndex()] || "U";
            modeloPageProj.setProperty("/PROCESSING_REGION", region);
            modelUrlParameters.setProperty("/PROCESSING_REGION", region);
            this.getOnlineUpdate_Region();
        },
        inpQReqName_valueHelpRequest: function () {
            // TODO(SPEC-MISSING): no inferable behaviour (requester is set by the backend)
        },
        inpOnBehalfOf_valueHelpRequest: function () {
            var inpOnBehalfOf = this.byId("inpOnBehalfOf"), diaSearchOnBehalf = this.byId("diaSearchOnBehalf");
            this.userField = inpOnBehalfOf; // diaSearchOnBehalf confirm writes into userField (P-26)
            diaSearchOnBehalf.open();
        },
        inpOnBehalfOf_change: function () {
            var inpOnBehalfOf = this.byId("inpOnBehalfOf");
            this.getOnlineUpdateOnbehalf_ID(inpOnBehalfOf.getValue());
        },
        CbtnOnBehalfClr_press: function () {
            var modeloPageProj = this.model("oPageProj");
            modeloPageProj.getData().ONBEHALF_NAME = "";
            modeloPageProj.getData().ONBEHALF_ID = "";
            modeloPageProj.refresh();
        },
        inpAuthBy_valueHelpRequest: function () {
            var diaSearchAuthBy = this.byId("diaSearchAuthBy");
            diaSearchAuthBy.open();
        },

        /* =============================================================== control events: sfBudgetProj
         * TODO(SPEC-MISSING): sfBudgetProj spec not in the repo - handlers inferred from Utility.txt helpers. */

        oSelectProjType_change: function () {
            this.visible_additional_field();
        },
        selProjectSubtype_change: function () {
            this.visible_additional_field();
        },
        rbTIFunds_select: function () {
            var modeloPageProj = this.model("oPageProj"), rbTI_Fund_Yes = this.byId("rbTI_Fund_Yes");
            modeloPageProj.getData().CAPEX_TI = rbTI_Fund_Yes.getSelected() ? "Y" : "N";
            modeloPageProj.refresh();
            this.set_TI_funding_visible();
        },
        rbTIAmount_select: function () {
            var modeloPageProj = this.model("oPageProj"), rbTI_Amount_Yes = this.byId("rbTI_Amount_Yes");
            modeloPageProj.getData().CAPEX_TI_AMT_INC = rbTI_Amount_Yes.getSelected() ? "Y" : "N";
            modeloPageProj.refresh();
        },
        rbITL_select: function () {
            this.visible_additional_field();
        },

        /* =============================================================== control events: sfBudgetProj2 (spec) */

        oSelectCompCode_change: function () {
            var oSelectCompCode = this.byId("oSelectCompCode"), inpCostCenter = this.byId("inpCostCenter"),
                modelUrlParameters = this.model("UrlParameters"), modeloPageProj = this.model("oPageProj");
            var getOnlineGetCostCenter = this.getOnlineGetCostCenter.bind(this);

            var companycode = oSelectCompCode.getSelectedKey();

            if (companycode) {
                modelUrlParameters.setProperty("/COMPANY_CODE", companycode);
                getOnlineGetCostCenter('*');
                // Clear Cost Center if it's selected before
                inpCostCenter.setValue("");
                modeloPageProj.getData().KOSTL = "";
                modeloPageProj.refresh();
                inpCostCenter.fireChange();
            }
        },
        inpCostCenter_valueHelpRequest: function () {
            var oSelectCompCode = this.byId("oSelectCompCode"), diaSearchCostCenter = this.byId("diaSearchCostCenter"),
                modelUrlParameters = this.model("UrlParameters");

            var companycode = oSelectCompCode.getSelectedKey();
            if (companycode) {
                modelUrlParameters.setProperty("/COMPANY_CODE", companycode);
                diaSearchCostCenter.open();
            } else {
                discoveryFiori.showMessage(
                    "Company code is required to select Cost Center",
                    ValueState.Error
                );
            }
        },
        inpLocation_valueHelpRequest: function () {
            this.byId("diaLocation").open();
        },
        inpBrand_valueHelpRequest: function () {
            this.byId("diaBrand").open();
        },
        inpGeography_valueHelpRequest: function () {
            this.byId("diaGeography").open();
        },
        btnFPAApprovalAtt_press: function () {
            // TODO(SPEC-MISSING): anonymous function not captured - inferred: original app upload dialog, category chosen by user
            this.fu.open();
        },

        /* =============================================================== control events: subsectionProjAttDownload */

        btnAttCAPEXLicenseUpload_press: function () {
            // TODO(SPEC-MISSING): anonymous function not captured - inferred category from visible_additional_field()
            this.fu.open("CAPEX_LICENSE");
        },
        btnAttSoftwareLicenseUpload_press: function () {
            // TODO(SPEC-MISSING): see above
            this.fu.open("SOFTWARE_LICENSE");
        },
        btnAttAccountingUpload_press: function () {
            // TODO(SPEC-MISSING): see above
            this.fu.open("ACCOUNTING");
        },

        /* =============================================================== control events: subsectionProjMultiCC (P-22: hidden) */

        btnAddCompCode_press: function () {
            var diaAddMultiCC = this.byId("diaAddMultiCC");
            diaAddMultiCC.open();
        },
        btnDeleteCCode_press: function (oEvent) {
            // TODO(SPEC-MISSING): exact code not captured - inferred: remove the pressed row
            var modeltabMultiCC = this.model("tabMultiCC");
            var iIndex = Number(oEvent.getSource().getBindingContext("tabMultiCC").getPath().split("/").pop());
            modeltabMultiCC.getData().splice(iIndex, 1);
            modeltabMultiCC.refresh(true);
        },

        /* =============================================================== control events: sectionApproval
         * TODO(SPEC-MISSING): FPA spec not in the repo - inferred from updateinitgrp(). */

        oSelectExecCategory_change: function () {
            this.updateinitgrp();
        },

        /* =============================================================== control events: sectionAttachments (spec) */

        listAttachments_delete: function (oEvent) {
            var modeldiaConfirmAttDelete = this.model("diaConfirmAttDelete"), diaConfirmAttDelete = this.byId("diaConfirmAttDelete");
            // Fired when user taps delete icon on a list item
            // (UI5 clone ids end with "-<index>" exactly like the original app's: <template>-<list>-<index>)
            var deleteIndex = Number(
                oEvent.getParameter("listItem").sId.split("-").pop()
            );
            modeldiaConfirmAttDelete.setProperty("/DELETE_INDEX", deleteIndex);
            diaConfirmAttDelete.open();
        },
        btnAddAttachment_press: function () {
            var fu = this.fu;
            fu.uploadDialog.open();
        },
        listItemAttachment_press: function (oEvent) {
            var displayAttachment = this.displayAttachment.bind(this);
            displayAttachment(oEvent.getSource().getBindingContext("listAttachments").getObject());
        },

        /* =============================================================== control events: footer (UI_footerPageCCreate.md) */

        butSave_press: function () {
            var oApp = this.byId("oApp"), rbITLYes = this.byId("rbITLYes"), modeloPageProj = this.model("oPageProj");
            var getOnlineSaveAsDraft = this.getOnlineSaveAsDraft.bind(this);

            // oApp.setBusy(true); -- commented out busy indicator
            oApp.setBusy(true);
            setTimeout(function () {
                if (rbITLYes.getSelected()) {
                    modeloPageProj.getData().ITL = "Y";
                    modeloPageProj.refresh();
                } else {
                    modeloPageProj.getData().ITL = "N";
                    modeloPageProj.refresh();
                }
                getOnlineSaveAsDraft();
            }, 200);
        },
        butDelete_press: function () {
            var oApp = this.byId("oApp"), diaDelDraft = this.byId("diaDelDraft");
            oApp.setBusy(true);
            diaDelDraft.open();
        },
        butCreate_press: function () {
            var diaCreate = this.byId("diaCreate");
            var validateRequiredAll = this.validateRequiredAll.bind(this), clear_value = this.clear_value.bind(this),
                validate_projname = this.validate_projname.bind(this), validate_bussjustname = this.validate_bussjustname.bind(this),
                validate_date = this.validate_date.bind(this), validateAmount = this.validateAmount.bind(this),
                validateAttachment = this.validateAttachment.bind(this);

            if (!validateRequiredAll()) {
                if (!clear_value()) {
                    if (!validate_projname()) {
                        if (!validate_bussjustname()) {
                            if (!validate_date()) {
                                if (!validateAmount()) {
                                    if (!validateAttachment()) {
                                        diaCreate.open();
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        butChange_press: function () {
            var validateRequiredAll = this.validateRequiredAll.bind(this), getOnlineCheck = this.getOnlineCheck.bind(this);
            if (!validateRequiredAll()) {
                getOnlineCheck();
                // diaChange.open(); -- commented out
            }
        },
        butSubmitWthErr_press: function () {
            var diaSubmitWthErr = this.byId("diaSubmitWthErr");
            var validateRequiredAll = this.validateRequiredAll.bind(this);
            if (!validateRequiredAll()) {
                diaSubmitWthErr.open();
            }
        },
        butSubmit_press: function () {
            var validateRequiredAll = this.validateRequiredAll.bind(this), getOnlineCheck = this.getOnlineCheck.bind(this);
            if (!validateRequiredAll()) {
                getOnlineCheck();
            }
        },
        butReject_press: function () {
            this.byId("diaReject").open();
        },
        butClose_press: function () {
            this.byId("diaClose").open();
        },
        butResubmit_press: function () {
            var diaReSubmit = this.byId("diaReSubmit");
            var validateRequiredAll = this.validateRequiredAll.bind(this), validateAmount = this.validateAmount.bind(this),
                validateAttachment = this.validateAttachment.bind(this);
            if (!validateRequiredAll()) {
                if (!validateAmount()) {
                    if (!validateAttachment()) {
                        diaReSubmit.open();
                    }
                }
            }
        },

        /* =============================================================== dialogs: comment dialogs (WA_COMMENTS) */

        // diaCreate - diaCreate_Dialog_Screen.md
        diaCreate_beforeOpen: function () {
            this.byId("oTextAreaCreate").setValue(); // Clear old comments in dialog
        },
        butCreateSave_press: function () {
            var diaCreate = this.byId("diaCreate"), oApp = this.byId("oApp"), oTextAreaCreate = this.byId("oTextAreaCreate"),
                rbITLYes = this.byId("rbITLYes"), modeloPageProj = this.model("oPageProj");
            var clear_value = this.clear_value.bind(this), getOnlineCreate = this.getOnlineCreate.bind(this);

            diaCreate.close();
            oApp.setBusy(true);

            //var newComments = modeldiaCreate.oData.COMMENTS;
            modeloPageProj.getData().COMMENTS = oTextAreaCreate.getValue();
            modeloPageProj.refresh();

            // Update ITL flag from radio button
            if (rbITLYes.getSelected()) {
                modeloPageProj.getData().ITL = "Y";
                modeloPageProj.refresh();
            } else {
                modeloPageProj.getData().ITL = "N";
                modeloPageProj.refresh();
            }

            clear_value();       // Clear Value based on condition
            getOnlineCreate();   // Triggers CREATE AJAX call
        },
        butCreateCancel_press: function () {
            // Close the dialog
            this.byId("diaCreate").close();
        },

        // diaChange - diachange.md
        diaChange_beforeOpen: function () {
            this.byId("oTextAreaChg").setValue();
        },
        butChgSave_press: function () {
            var diaChange = this.byId("diaChange"), oApp = this.byId("oApp"), oTextAreaChg = this.byId("oTextAreaChg"),
                rbITLYes = this.byId("rbITLYes"), modeloPageProj = this.model("oPageProj");
            var clear_value = this.clear_value.bind(this), getOnlineChange = this.getOnlineChange.bind(this);

            diaChange.close();
            oApp.setBusy(true);

            modeloPageProj.getData().COMMENTS = oTextAreaChg.getValue();
            modeloPageProj.refresh();

            if (rbITLYes.getSelected()) {
                modeloPageProj.getData().ITL = "Y";
                modeloPageProj.refresh();
            } else {
                modeloPageProj.getData().ITL = "N";
                modeloPageProj.refresh();
            }

            clear_value();       // Clear Value based on condition
            getOnlineChange();   // Triggers CHANGE AJAX call
        },
        butChgCancel_press: function () {
            this.byId("diaChange").close();
        },

        // diaSubmit - diaSubmit.md
        diaSubmit_beforeOpen: function () {
            this.byId("oTextAreaSubmit").setValue();
        },
        butSubmitSave_press: function () {
            var diaSubmit = this.byId("diaSubmit"), oApp = this.byId("oApp"), oTextAreaSubmit = this.byId("oTextAreaSubmit"),
                modeloPageProj = this.model("oPageProj");
            var clear_value = this.clear_value.bind(this), getOnlineSubmit = this.getOnlineSubmit.bind(this),
                getOnlineNewProject = this.getOnlineNewProject.bind(this);

            diaSubmit.close();
            oApp.setBusy(true);

            //var newComments = modeldiaSubmit.oData.COMMENTS;
            modeloPageProj.getData().COMMENTS = oTextAreaSubmit.getValue();
            modeloPageProj.refresh();

            clear_value(); // Clear Value based on condition

            if (!modeloPageProj.getData().PROJ_FLGRP_0003) {
                getOnlineSubmit();
            } else if (modeloPageProj.getData().PROJ_FLGRP_0003) {
                getOnlineNewProject();
            }
        },
        butSubmitCancel_press: function () {
            var diaSubmit = this.byId("diaSubmit"), oApp = this.byId("oApp");
            diaSubmit.close();
            oApp.setBusy(false);
        },

        // diaSubmitWthErr - diaSubmitWthErr.md
        diaSubmitWthErr_beforeOpen: function () {
            this.byId("oTextAreaSubmitWthErr").setValue();
        },
        butSubWthErrSave_press: function () {
            var diaSubmitWthErr = this.byId("diaSubmitWthErr"), oApp = this.byId("oApp"),
                oTextAreaSubmitWthErr = this.byId("oTextAreaSubmitWthErr"), modeloPageProj = this.model("oPageProj");
            var clear_value = this.clear_value.bind(this), getOnlineNewIntOrderWErr = this.getOnlineNewIntOrderWErr.bind(this);

            diaSubmitWthErr.close();
            oApp.setBusy(true);

            modeloPageProj.getData().COMMENTS = oTextAreaSubmitWthErr.getValue();
            modeloPageProj.refresh();

            clear_value(); // Clear Value based on condition

            if (modeloPageProj.getData().PROJ_FLGRP_0003) {
                getOnlineNewIntOrderWErr(); // PARITY P-04
            }
        },
        butSubWthErrCancel_press: function () {
            var diaSubmitWthErr = this.byId("diaSubmitWthErr"), oApp = this.byId("oApp");
            diaSubmitWthErr.close();
            oApp.setBusy(false);
        },

        // diaReject - diaReject_dialog_box.md
        diaReject_beforeOpen: function () {
            this.byId("oTextAreaReject").setValue(); // Clear old comments in dialog
        },
        butRejectOK_press: function () {
            var oApp = this.byId("oApp"), diaReject = this.byId("diaReject"),
                modeldiaReject = this.model("diaReject"), modeloPageProj = this.model("oPageProj");
            var getOnlineReject = this.getOnlineReject.bind(this);

            var sRejectText = modeldiaReject.getData().COMMENTS;
            modeloPageProj.getData().COMMENTS = sRejectText.trim();
            modeloPageProj.refresh();

            if (sRejectText === '') {
                // jQuery.sap.require("sap.m.MessageToast"); -> imported
                MessageToast.show("Comments are Required on Reject", {
                    at: "center center"
                });
            } else {
                oApp.setBusy(true);
                diaReject.close();
                getOnlineReject();   // Triggers REJECT AJAX call
            }
        },
        butRejectCancel_press: function () {
            this.byId("diaReject").close();
        },

        // diaClose - diaClose.md (PARITY P-11: no beforeOpen)
        butCloseSubmit_press: function () {
            var oApp = this.byId("oApp"), diaClose = this.byId("diaClose"), oTextAreaCancel = this.byId("oTextAreaCancel"),
                modeloPageProj = this.model("oPageProj");
            var getOnlineClose = this.getOnlineClose.bind(this);

            oApp.setBusy(true);
            diaClose.close();

            //var newComments = modeldiaClose.oData.COMMENTS;
            modeloPageProj.getData().COMMENTS = oTextAreaCancel.getValue();
            modeloPageProj.refresh();

            getOnlineClose();
        },
        butCloseCancel_press: function () {
            var diaClose = this.byId("diaClose"), oApp = this.byId("oApp");
            diaClose.close();
            oApp.setBusy(false);
        },

        // diaReSubmit - diaReSubmit.md D3 (PARITY P-10: close() twice, busy released right away)
        diaReSubmit_beforeOpen: function () {
            this.byId("oTextAreaReSubmit").setValue();
        },
        butReSubmitSave_press: function () {
            var diaReSubmit = this.byId("diaReSubmit"), oApp = this.byId("oApp"), oTextAreaReSubmit = this.byId("oTextAreaReSubmit"),
                rbITLYes = this.byId("rbITLYes"), modeloPageProj = this.model("oPageProj");
            var clear_value = this.clear_value.bind(this), getOnlineResubmit = this.getOnlineResubmit.bind(this);

            diaReSubmit.close();
            oApp.setBusy(true);

            modeloPageProj.getData().COMMENTS = oTextAreaReSubmit.getValue();
            modeloPageProj.refresh();

            if (rbITLYes.getSelected()) {
                modeloPageProj.getData().ITL = "Y";
                modeloPageProj.refresh();
            } else {
                modeloPageProj.getData().ITL = "N";
                modeloPageProj.refresh();
            }

            clear_value();          // Clear Value based on condition
            getOnlineResubmit();
            diaReSubmit.close();    // called twice in original app
            oApp.setBusy(false);
        },
        butReSubmitCancel_press: function () {
            var diaReSubmit = this.byId("diaReSubmit"), oApp = this.byId("oApp");
            diaReSubmit.close();
            oApp.setBusy(false);
        },

        /* =============================================================== dialogs: others */

        // diaDelDraft - diaDelDraft.md
        butDDraft_press: function () {
            var diaDelDraft = this.byId("diaDelDraft");
            var getOnlineDeleteDraft = this.getOnlineDeleteDraft.bind(this);
            // Close the dialog
            diaDelDraft.close();
            getOnlineDeleteDraft();
        },
        butDDraftCancel_press: function () {
            // Close the dialog
            this.byId("diaDelDraft").close();
        },

        // diaTimeout
        butTimeoutClose_press: function () {
            var oApp = this.byId("oApp"), diaTimeout = this.byId("diaTimeout");
            oApp.setBusy(false);
            diaTimeout.close();
        },

        // diaMessage
        butMessageClose_press: function () {
            var diaMessage = this.byId("diaMessage"), oApp = this.byId("oApp");
            diaMessage.close();
            oApp.setBusy(false);
        },

        // diaAgents
        btnAgentsClose_press: function () {
            this.byId("diaAgents").close();
        },

        // diaAddAttachment
        diaAddAttachmentClose_press: function () {
            this.byId("diaAddAttachment").close();
        },

        // diaConfirmAttDelete - UI_diaConfirmAttDelete.md
        btnAttDeleteYes_press: function () {
            var diaConfirmAttDelete = this.byId("diaConfirmAttDelete"), modeldiaConfirmAttDelete = this.model("diaConfirmAttDelete"),
                modellistAttachments = this.model("listAttachments");
            var getOnlineDeleteAttachment = this.getOnlineDeleteAttachment.bind(this);

            diaConfirmAttDelete.close();

            // Read the stored index set when delete was triggered from the list
            var deleteIndex = modeldiaConfirmAttDelete.getData().DELETE_INDEX;
            var attachment = modellistAttachments.getData()[deleteIndex];

            if (attachment.UUID && attachment.UUID.trim() !== "") {
                // Attachment already saved in SAP - call backend to delete
                getOnlineDeleteAttachment();
            } else {
                // Not yet saved in SAP - remove from frontend model only
                modellistAttachments.getData().splice(deleteIndex, 1);
                modellistAttachments.updateBindings();
                diaConfirmAttDelete.close();
            }
        },
        btnAttDeleteNo_press: function () {
            this.byId("diaConfirmAttDelete").close();
        },

        // diaAddMultiCC - diaReSubmit.md D2
        btnAddMultiCCOK_press: function () {
            var oSelectMultiCCode = this.byId("oSelectMultiCCode"), inpMultiCostCenter = this.byId("inpMultiCostCenter"),
                diaAddMultiCC = this.byId("diaAddMultiCC"), oApp = this.byId("oApp"),
                modeloPageProj = this.model("oPageProj"), modeltabMultiCC = this.model("tabMultiCC");

            // PARITY P-35: private UI5 APIs kept (public fallback only if a UI5 release removed them)
            var newCompcodes = oSelectMultiCCode.getSelectedKey();
            var newCostCenter = inpMultiCostCenter._getInputValue ? inpMultiCostCenter._getInputValue() : inpMultiCostCenter.getValue();
            var selectedText = function () {
                return oSelectMultiCCode._getSelectedItemText ? oSelectMultiCCode._getSelectedItemText()
                    : (oSelectMultiCCode.getSelectedItem() ? oSelectMultiCCode.getSelectedItem().getText() : "");
            };

            // Determine region label from PROCESSING_REGION
            var region;
            if (modeloPageProj.getData().PROCESSING_REGION === "U") { region = "US/LA"; }
            else if (modeloPageProj.getData().PROCESSING_REGION === "E") { region = "Europe"; }
            else if (modeloPageProj.getData().PROCESSING_REGION === "A") { region = "Asia"; }

            // Validation
            if (newCompcodes.length === 0) {
                discoveryFiori.showMessage(
                    "Select additional company code",
                    ValueState.Error);
                oSelectMultiCCode.focus();

            } else if (newCompcodes.length > 0 && newCostCenter.length === 0) {
                discoveryFiori.showMessage(
                    "Select Cost Center before adding new company code",
                    ValueState.Error);
                inpMultiCostCenter.focus();

            } else {
                // Add new row to table model
                modeltabMultiCC.getData().push({
                    STATUS: 'sap-icon://add-document',
                    REGION: region,
                    COMP_CODE: newCompcodes,
                    COMP_TEXT: selectedText().substring(5,
                        (selectedText().length - 5)),
                    KOSTL_CODE: newCostCenter.substring(0, 10),
                    KOSTL_TEXT: newCostCenter.substring(11, (newCostCenter.length - 10))
                });
                modeltabMultiCC.updateBindings();
                modeltabMultiCC.refresh();
                diaAddMultiCC.close();
                oApp.setBusy(false);
            }
        },
        btnAddMultiCCCancel_press: function () {
            this.byId("diaAddMultiCC").close();
        },
        oSelectMultiCCode_change: function () {
            var oSelectMultiCCode = this.byId("oSelectMultiCCode"), inpMultiCostCenter = this.byId("inpMultiCostCenter"),
                modelUrlParameters = this.model("UrlParameters");
            var getOnlineGetCostCenter = this.getOnlineGetCostCenter.bind(this);

            var companycode = oSelectMultiCCode.getSelectedKey();
            if (companycode) {
                modelUrlParameters.setProperty("/COMPANY_CODE", companycode);
                getOnlineGetCostCenter('*');
                // Clear Cost Center if already selected
                inpMultiCostCenter.setValue("");
                inpMultiCostCenter.fireChange();
            }
        },
        inpMultiCostCenter_valueHelpRequest: function () {
            // TODO(SPEC-MISSING): D2.7.2 code not captured - inferred from inpCostCenter (same COMPANY_CODE gate)
            var oSelectMultiCCode = this.byId("oSelectMultiCCode"), diaSearchCostCenter = this.byId("diaSearchCostCenter"),
                modelUrlParameters = this.model("UrlParameters");
            var companycode = oSelectMultiCCode.getSelectedKey();
            if (companycode) {
                modelUrlParameters.setProperty("/COMPANY_CODE", companycode);
                diaSearchCostCenter.open();
            } else {
                discoveryFiori.showMessage("Company code is required to select Cost Center", ValueState.Error);
            }
        },

        /* =============================================================== dialogs: search SelectDialogs */

        // diaSearchOnBehalf - diaSearchOnBehalf.md
        diaSearchOnBehalf_search: function (oEvent) {
            var oApp = this.byId("oApp"), diaSearchOnBehalf = this.byId("diaSearchOnBehalf");
            var getOnlineGetOnBehalfPerson = this.getOnlineGetOnBehalfPerson.bind(this);

            oApp.setBusy(true);

            var searchTerm = oEvent.getParameter("value");
            var binding = diaSearchOnBehalf.getBinding("items");
            var filter = new Filter("TEXT", "Contains", searchTerm);

            getOnlineGetOnBehalfPerson(filter.oValue1);
            binding.filter([filter]);
        },
        diaSearchOnBehalf_confirm: function (oEvent) {
            var userField = this.userField; // PARITY P-26
            var entry = oEvent.getParameter("selectedItem").getBindingContext("diaSearchOnBehalf").getObject();

            if (userField) {
                userField.setValue(entry.OBJID);
                userField.setDescription(entry.TEXT);
                userField.fireChange();
            }
        },

        // diaSearchAuthBy - diaSearchAuthBy.md
        diaSearchAuthBy_search: function (oEvent) {
            var oApp = this.byId("oApp"), diaSearchAuthBy = this.byId("diaSearchAuthBy");
            var getOnlineGetAuthorizedBy = this.getOnlineGetAuthorizedBy.bind(this);

            oApp.setBusy(true);

            var searchTerm = oEvent.getParameter("value");
            var binding = diaSearchAuthBy.getBinding("items");
            var filter = new Filter("TEXT", "Contains", searchTerm);

            getOnlineGetAuthorizedBy(filter.oValue1);
            binding.filter([filter]);
        },
        diaSearchAuthBy_liveChange: function (oEvent) {
            var diaSearchAuthBy = this.byId("diaSearchAuthBy");
            var searchTerm = oEvent.getParameter("value");
            var binding = diaSearchAuthBy.getBinding("items");
            var filter = new Filter("TEXT", "Contains", searchTerm);
            binding.filter([filter]);
        },
        diaSearchAuthBy_confirm: function (oEvent) {
            var inpAuthBy = this.byId("inpAuthBy"), modeloPageProj = this.model("oPageProj");
            var getOnlineUpdateAuthorizedBy = this.getOnlineUpdateAuthorizedBy.bind(this);

            var entry = oEvent.getParameter("selectedItem").getBindingContext("diaSearchAuthBy").getObject();

            inpAuthBy.setValue(entry.TEXT);
            modeloPageProj.getData().AUTH_BY_ID = entry.OBJID;
            modeloPageProj.refresh();

            getOnlineUpdateAuthorizedBy(entry.OBJID);
            inpAuthBy.fireChange();
        },

        // diaSearchCostCenter - diaSearchCostCenter.md
        diaSearchCostCenter_confirm: function (oEvent) {
            var diaAddMultiCC = this.byId("diaAddMultiCC"), inpCostCenter = this.byId("inpCostCenter"),
                inpMultiCostCenter = this.byId("inpMultiCostCenter"), modeloPageProj = this.model("oPageProj");

            var entry = oEvent.getParameter("selectedItem").getBindingContext("diaSearchCostCenter").getObject();

            if (!diaAddMultiCC.isOpen()) {
                inpCostCenter.setValue(entry.TEXT);
                modeloPageProj.getData().KOSTL = entry.VALUE;
                modeloPageProj.refresh();
                inpCostCenter.fireChange();
            } else {
                inpMultiCostCenter.setValue(entry.TEXT);
                //modelodiaAddMultiCC.oData.KOSTL_CODE = entry.VALUE;
                //modelodiaAddMultiCC.refresh();
                inpMultiCostCenter.fireChange();
            }
        },
        diaSearchCostCenter_liveChange: function (oEvent) {
            var diaSearchCostCenter = this.byId("diaSearchCostCenter");
            var searchTerm = oEvent.getParameter("value");
            var binding = diaSearchCostCenter.getBinding("items");
            var filter = new Filter("TEXT", "Contains", searchTerm);
            binding.filter([filter]);
        },
        diaSearchCostCenter_search: function (oEvent) {
            var oApp = this.byId("oApp"), diaSearchCostCenter = this.byId("diaSearchCostCenter");
            var getOnlineGetCostCenter = this.getOnlineGetCostCenter.bind(this);

            oApp.setBusy(true);

            var searchTerm = oEvent.getParameter("value");

            var binding = diaSearchCostCenter.getBinding("items");
            var filter = new Filter("TEXT", "Contains", searchTerm);

            getOnlineGetCostCenter(filter.oValue1);
            binding.filter([filter]);
        },

        // diaGeography / diaBrand / diaLocation - same original app code, only path/field differ
        _filterValueText: function (oEvent, sKeyPath) {
            var searchTerm = oEvent.getParameter("value");
            var binding = oEvent.getSource().getBinding("items");

            var filter = [];
            if (typeof searchTerm === "string" && searchTerm.trim().length > 0) {
                filter = new Filter({
                    filters: [
                        new Filter({ path: "TEXT", operator: "Contains", value1: searchTerm }),
                        new Filter({ path: sKeyPath, operator: "StartsWith", value1: searchTerm })
                    ]
                });
            }
            binding.filter([filter]);
        },
        diaGeography_confirm: function (oEvent) {
            var modeloPageProj = this.model("oPageProj");
            var entry = oEvent.getParameter("selectedItem").getBindingContext("diaGeography").getObject();
            modeloPageProj.setProperty("/GEOGRAPHY", entry.VALUE);
        },
        diaGeography_liveChange: function (oEvent) { this._filterValueText(oEvent, "VALUE"); },
        diaGeography_search: function (oEvent) { this._filterValueText(oEvent, "VALUE"); },

        diaBrand_confirm: function (oEvent) {
            var modeloPageProj = this.model("oPageProj");
            var entry = oEvent.getParameter("selectedItem").getBindingContext("diaBrand").getObject();
            modeloPageProj.setProperty("/BRAND", entry.VALUE);
        },
        diaBrand_liveChange: function (oEvent) { this._filterValueText(oEvent, "VALUE"); },
        diaBrand_search: function (oEvent) { this._filterValueText(oEvent, "VALUE"); },

        diaLocation_confirm: function (oEvent) {
            var modeloPageProj = this.model("oPageProj");
            var entry = oEvent.getParameter("selectedItem").getBindingContext("diaLocation").getObject();
            modeloPageProj.setProperty("/LOCATION", entry.LOCATION);
        },
        diaLocation_liveChange: function (oEvent) { this._filterValueText(oEvent, "LOCATION"); },
        diaLocation_search: function (oEvent) { this._filterValueText(oEvent, "LOCATION"); },

        // diaSearchPrevProj - TODO(SPEC-MISSING): whole dialog spec missing; inferred like diaGeography
        diaSearchPrevProj_confirm: function (oEvent) {
            var modeloPageProj = this.model("oPageProj");
            var entry = oEvent.getParameter("selectedItem").getBindingContext("diaSearchPrevProj").getObject();
            modeloPageProj.setProperty("/PREV_PROJ_CODE", entry.VALUE);
        },
        diaSearchPrevProj_liveChange: function (oEvent) { this._filterValueText(oEvent, "VALUE"); },
        diaSearchPrevProj_search: function (oEvent) { this._filterValueText(oEvent, "VALUE"); }
    });
});
