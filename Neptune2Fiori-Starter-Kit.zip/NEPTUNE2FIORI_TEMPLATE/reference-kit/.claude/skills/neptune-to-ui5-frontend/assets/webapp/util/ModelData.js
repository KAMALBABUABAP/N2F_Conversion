/*
 * ModelData - shim for the original app runtime helper of the same name.
 *
 * original app JS calls  ModelData.Find(<control>, fields, values, operators)
 *                   ModelData.Add(<control>, object)
 *                   ModelData.Delete(<control>, fields, values, operators)
 *                   ModelData.Update(<control>, fields, values, operators, object)
 * where <control> is the control that owns the Model Source. The ported code keeps those calls verbatim.
 * The first argument may be:
 *   - a sap.ui.model.json.JSONModel                 (data-only containers: AttachmentsRequired, ...)
 *   - a control whose local id is the model name    (listAttachments, tabMultiCC, ...): the named model
 *     "<localId>" is looked up on the control (view models propagate to every child).
 *
 * Operators (original app): EQ NE GT GE LT LE CP (CP = contains, case-insensitive; '*' wildcards allowed).
 * Several fields are combined with AND, exactly like original app.
 */
sap.ui.define([], function () {
    "use strict";

    function resolveModel(oOwner) {
        if (!oOwner) {
            throw new Error("ModelData: no model/control given");
        }
        if (typeof oOwner.getData === "function" && typeof oOwner.setData === "function") {
            return oOwner; // JSONModel
        }
        if (typeof oOwner.getModel === "function" && typeof oOwner.getId === "function") {
            var sLocalId = oOwner.getId().split("--").pop();
            var oModel = oOwner.getModel(sLocalId);
            if (!oModel) {
                throw new Error("ModelData: control '" + sLocalId + "' has no named model '" + sLocalId + "'");
            }
            return oModel;
        }
        throw new Error("ModelData: unsupported argument");
    }

    function toArray(v) {
        return Array.isArray(v) ? v : [v];
    }

    function cpMatch(vActual, vPattern) {
        var sA = String(vActual === undefined || vActual === null ? "" : vActual).toLowerCase();
        var sP = String(vPattern === undefined || vPattern === null ? "" : vPattern).toLowerCase();
        if (sP.indexOf("*") < 0) {
            return sA.indexOf(sP) >= 0;
        }
        var sRe = "^" + sP.split("*").map(function (s) {
            return s.replace(/[.+?^${}()|[\]\\]/g, "\\$&");
        }).join(".*") + "$";
        return new RegExp(sRe).test(sA);
    }

    function test(oRow, aFields, aValues, aOps) {
        for (var i = 0; i < aFields.length; i++) {
            var vA = oRow[aFields[i]];
            var vB = aValues[i];
            var sOp = (aOps[i] || "EQ").toUpperCase();
            var bOk;
            switch (sOp) {
                case "EQ": bOk = vA === vB; break;
                case "NE": bOk = vA !== vB; break;
                case "GT": bOk = vA > vB; break;
                case "GE": bOk = vA >= vB; break;
                case "LT": bOk = vA < vB; break;
                case "LE": bOk = vA <= vB; break;
                case "CP": bOk = cpMatch(vA, vB); break;
                default: throw new Error("ModelData: unknown operator " + sOp);
            }
            if (!bOk) {
                return false;
            }
        }
        return true;
    }

    function rows(oModel) {
        var aData = oModel.getData();
        if (!Array.isArray(aData)) {
            aData = [];
            oModel.setData(aData);
        }
        return aData;
    }

    return {
        Find: function (oOwner, vFields, vValues, vOps) {
            var aFields = toArray(vFields), aValues = toArray(vValues), aOps = toArray(vOps || "EQ");
            return rows(resolveModel(oOwner)).filter(function (oRow) {
                return test(oRow, aFields, aValues, aOps);
            });
        },

        Add: function (oOwner, oObject) {
            var oModel = resolveModel(oOwner);
            rows(oModel).push(oObject);
            oModel.refresh(true);
        },

        Delete: function (oOwner, vFields, vValues, vOps) {
            var oModel = resolveModel(oOwner);
            var aFields = toArray(vFields), aValues = toArray(vValues), aOps = toArray(vOps || "EQ");
            var aData = rows(oModel);
            for (var i = aData.length - 1; i >= 0; i--) {
                if (test(aData[i], aFields, aValues, aOps)) {
                    aData.splice(i, 1);
                }
            }
            oModel.refresh(true);
        },

        Update: function (oOwner, vFields, vValues, vOps, oObject) {
            var oModel = resolveModel(oOwner);
            var aFields = toArray(vFields), aValues = toArray(vValues), aOps = toArray(vOps || "EQ");
            rows(oModel).forEach(function (oRow) {
                if (test(oRow, aFields, aValues, aOps)) {
                    Object.keys(oObject).forEach(function (k) { oRow[k] = oObject[k]; });
                }
            });
            oModel.refresh(true);
        },

        _resolveModel: resolveModel // exposed for unit tests
    };
});
