---
name: neptune-to-ui5-frontend
description: Convert the Neptune UI of ZDCI_NAD_PROJECT_REQUEST into a freestyle SAPUI5 app (XML views, app id zdci_nad_project_request, BSP ZUI_PROJREQCODE) that calls the SEGW service ZDCI_UI_PROJECT_REQUEST_SRV, apple-to-apple (same control IDs, model names, JS function names, texts, behaviour). Use for any SAPUI5 view, controller, binding, dialog, AJAX-client, local run, UI test or BSP deployment task in this project.
---

# Neptune → freestyle SAPUI5 frontend (ZDCI_NAD_PROJECT_REQUEST)

## Before anything

1. Load the registry skill `nad-project-request-registry`. Read `01` (names), `03` (models), `04` (AJAX
   inventory), `05` (parity log), `07` (JSON conversions), `08` (control registry).
2. Owner rules: **no name changes** (control ids, model names, JS function names, i18n keys, texts),
   **parity including bugs**, **freestyle UI5 + SEGW OData V2** (no Fiori elements, no RAP, no CAP).
3. The user works on a **Mac** — every command you give is zsh. Never give Windows/PowerShell commands.
4. Environment facts (Gateway host/port, client, ABAP package, transport, SAPUI5 version 1.102/1.108) are in
   the project `.env` (template `.env.example`). Ask the user only for values that are still empty.
5. Backend first: frontend steps F3+ need the backend skill to have passed **B3** (spike) at least.

## Architecture in one picture

```
Main.view.xml (+ 22 dialog fragments)      every id = Neptune control name
   │ bindings {X>/FIELD}                    X = Neptune control that owns the Model Source
Main.controller.js                          every Neptune function, same name, body verbatim
   │ getOnline<Name>(value)                 Neptune generated AJAX function names
util/AjaxRuntime.js ──POST AJAXSet──▶ ZDCI_UI_PROJECT_REQUEST_SRV ──▶ ZCL_UI_PROJECT_CODE_REQUEST
   │ Send/Receive per util/AjaxConfig.js, ABAP⇄JSON per util/JsonConversionRegistry.js
   └─ then <AJAX_ID>_ajaxSuccess() / <AJAX_ID>_ajaxError() on the controller (Neptune ajaxSuccess code)
util/ModelData.js, util/discoveryFiori.js   shims for the Neptune runtime APIs the code calls
```

## Assets (ready to use)

| File | What |
|---|---|
| `assets/webapp/manifest.json`, `Component.js`, `index.html` | App id `zdci_nad_project_request`, dataSource `/sap/opu/odata/sap/ZDCI_UI_PROJECT_REQUEST_SRV/` |
| `assets/webapp/view/Main.view.xml` | Full control tree in Neptune render order, all ids, all known bindings |
| `assets/webapp/view/fragments/*.fragment.xml` | 22 dialogs of `oPageDialogs`, ids unchanged, declared as page dependents |
| `assets/webapp/controller/Main.controller.js` | Port of Init/Global/Utility/form JS, all AJAX handlers, all control events |
| `assets/webapp/util/AjaxRuntime.js` | The Neptune AJAX runtime on OData (CSRF, $metadata-driven filtering/typing, deep insert) |
| `assets/webapp/util/AjaxConfig.js` | Per AJAX ID: function name, Send list, Receive list, evidence (DOC/INF/CAP) |
| `assets/webapp/util/JsonConversionRegistry.js` | Machine copy of registry `07` (keep in sync — `verify_kit.py`) |
| `assets/webapp/util/ModelRegistry.js` | Every named JSONModel (= registry `03`) with its initial data |
| `assets/webapp/util/ModelData.js`, `discoveryFiori.js` | Shims: Neptune `ModelData.*` and the shared library (SHIM-RECONSTRUCTED) |
| `assets/webapp/i18n/i18n.properties`, `css/app.css`, `Templates/` | Neptune text controls as i18n keys, Neptune CSS classes, template downloads (values to capture) |
| `assets/project/` (working copy: `src/ui5/zdci_nad_project_request/`) | `package.json`, `ui5.yaml` (proxy to SAP), `ui5-smoke.yaml` (offline), `ui5-deploy.yaml` (BSP), `.gitignore` |
| `scripts/test_neptune_ajax.js` | Offline unit test of payload/response conversion and ModelData (node, no SAP) |
| `scripts/smoke/smoke.js` + `mock-data.js` | Headless browser smoke test with a mocked OData service (no SAP) |

The kit was verified offline: all JS passes `node --check`, all XML parses, the unit test passes, and the
smoke test boots the app on OpenUI5 1.108 with a mocked service and runs GET_DATA → Save → Submit (CHECK →
diaSubmit → SUBMIT) with no console errors. It has **not** run against your Gateway yet — that is F3.

## Procedure

Track these as tasks.

### F0 — Set up the app folder on the Mac
The working copy of the app already exists at `src/ui5/zdci_nad_project_request/` (the skill's
`assets/webapp` + `assets/project` stay as the pristine reference — diff against them to see your changes).
```zsh
cd ~/<sap-dev>/projects/NEPTUNE2FIORI_PROJREQ/src/ui5/zdci_nad_project_request
node --version                           # need Node 20 LTS or newer: brew install node@20
npm install
npx playwright install chromium          # once, for the smoke test
cp ../../../.env.example ../../../.env 2>/dev/null; open -e ../../../.env   # fill host/client/package/transport
```
The folder name is the app id; it is not an SAP object. Copy the host, client, package and transport from the
project `.env` into the `<...>` placeholders of `ui5.yaml` and `ui5-deploy.yaml` (UI5 YAML cannot read `.env`).

### F1 — Offline checks (no SAP needed)
```zsh
npm run test:unit                        # conversion + ModelData tests
npm run start-smoke &                    # OpenUI5 1.108 from npm on http://localhost:8080
sleep 15 && npm run test:smoke           # mocked OData; must end with "all smoke checks passed"
kill %1
npm run lint                             # see references/test-plan.md §Lint for the expected findings
```
Run F1 again after every change you make to the webapp.

### F2 — Close the spec gaps (needs the Neptune designer / capture)
Search the code for `TODO(SPEC-MISSING)` and `TODO(CAPTURE)`:
```zsh
grep -rn "TODO(SPEC-MISSING)\|TODO(CAPTURE)\|SHIM-RECONSTRUCTED" webapp | wc -l
```
Work through `references/spec-gaps.md` with the capture from registry `06`. For every gap: copy the
Neptune attribute/binding/event code verbatim using `references/binding-rules.md` and
`references/js-port-rules.md`, remove the marker, update the registry (`03`, `04`, `08`) in the same change.
Change `evidence: "INF"` to `"CAP"` in `AjaxConfig.js` for each AJAX row the HAR report confirms.

### F3 — Run against the real backend
Fill `ui5.yaml` (host, port, client, `ui5.version` = system version), then `npm start`. Log on, then:
new request → the page title shows `New Project Code Request` (same pass criteria as backend B3), the
dropdowns are filled, Save works. Problems: `references/ajax-client.md` §Troubleshooting.

### F4 — Parity test against Neptune
Run `references/test-plan.md` side by side with the Neptune app (same user, same test form). For each AJAX
call compare payloads with `parity_diff.py` (registry skill). Every difference is fixed in the UI
(not in ABAP logic) or logged as a new `P-xx` in `05-parity-log.md` and marked `PARITY P-xx` in code.

### F5 — Deploy to BSP `ZUI_PROJREQCODE` and wire the launchpad
`references/deployment.md`: fill `ui5-deploy.yaml`, `npm run deploy`, then point the **existing** Neptune
launchpad tile/target mapping to the UI5 app (same semantic object/action — no new tile names).

### F6 — Handover
Record in the registry: confirmed rows, closed gaps, new parity items, final i18n texts. Transport: BSP
`ZUI_PROJREQCODE` (from deploy), launchpad customizing, role changes for `S_SERVICE` of the OData service.

## Guardrails

- Never rename a control id, model, JS function or i18n key. Never "clean up" Neptune code into new
  helper names (the repo specs' "Fiori migration" snippets do exactly that — ignore them, see registry `09`).
- Keep the Neptune function body verbatim; only the mechanical replacements in `js-port-rules.md` are allowed.
- Never use an `ODataModel` with `$batch` for the AJAX calls; `AjaxRuntime` posts plain JSON (the class
  commits). Do not bind controls to OData directly — Neptune had JSON models only.
- Send/Receive lists live only in `AjaxConfig.js`; the backend sends everything back on purpose.
- Every navigation property (`GT_*`) is sent on every call (empty `[]`) — `AjaxRuntime` does this; keep it.
- Behaviour that looks wrong is a parity item, not a bug fix (owner decides after go-live).
- Do not edit `JsonConversionRegistry.js` without editing registry `07` and its JSON copy the same way.

## References

- `references/binding-rules.md` — Neptune binding → UI5 binding, Selects, tables, dialogs, special cases
- `references/js-port-rules.md` — how a Neptune function becomes a controller method (with examples)
- `references/ajax-client.md` — AjaxRuntime internals, config format, conversions, troubleshooting
- `references/spec-gaps.md` — every inferred element and how to close it
- `references/test-plan.md` — offline checks, lint expectations, parity test script
- `references/deployment.md` — Mac commands for BSP deploy and launchpad wiring
