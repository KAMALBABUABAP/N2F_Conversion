#!/usr/bin/env python3
"""Compare one Neptune AJAX response with the OData envelope response for the same action.

Both sides are normalised to "what the JavaScript sees":
  - OData side: unwrap d/results, drop __metadata/__deferred/ROW_INDEX, apply the JSON conversion
    registry (booleans, initial dates/times -> "", decimals -> numbers).
  - Neptune side: taken as-is. Top-level keys may be ABAP attribute names (GS_PROJ_FORM) or Neptune
    model names (oPageProj); model names are mapped back to attributes with --owners.

Usage (macOS, zsh):
    python3 parity_diff.py neptune_SAVE.json odata_SAVE.json [--ignore FIELD ...]

Exit code 0 = identical after normalisation, 1 = differences (listed), 2 = usage error.
Volatile values (GUIDs, timestamps, user-specific data) can be skipped with --ignore.
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REG = json.load(open(os.path.join(HERE, "..", "references", "json-conversion-registry.json"), encoding="utf-8"))

# Neptune model (control) name -> ABAP attribute, for Neptune payloads keyed by model name.
OWNERS = {
    "UrlParameters": "WA_URL_PARAMETERS", "ProgramState": "WA_PROGRAM_STATE",
    "diaCreate": "WA_COMMENTS", "diaChange": "WA_COMMENTS", "diaSubmit": "WA_COMMENTS",
    "diaSubmitWthErr": "WA_COMMENTS", "diaReject": "WA_COMMENTS", "diaClose": "WA_COMMENTS",
    "diaReSubmit": "WA_COMMENTS", "diaConfirmAttDelete": "WA_CONFIRM_DELETE",
    "oPageProj": "GS_PROJ_FORM", "diaDelDraft": "GS_PROJ_FORM", "subsectionComments": "GS_PROJ_FORM",
    "cntr_formdetails": "GS_FORMDETAILS", "cntr_stepdetails": "GS_STEPDETAIL",
    "vlAttributesBlock1": "GS_FORMHEADER", "vlAttributesBlock2": "GS_FORMHEADER",
    "oFormEmployeeInfo": "GS_EMPLOYEE_INFO", "sectionAttachments": "GS_ATTACHMENT",
    "diaAddMultiCC": "GS_MULTIPLECCODE", "oTableApprovers": "GT_APPR", "listAttachments": "GT_ATTACHMENTS",
    "listAgents": "GT_ZCA_AGENT_LIST", "tabOrderdetails": "GT_ORDERDETAILS", "tabMultiCC": "GT_ADDITIONAL_CCODE",
    "oSelectProjType": "GT_REQUEST_TYPE", "selProjectSubtype": "GT_PROJECT_SUBTYPE",
    "oSelectExecCategory": "GT_EXEC_CATEGORY", "oTableINITIA_GRP": "GT_INITI_GROUP",
    "oSelectInitPrd_Grp": "GT_INITI_GRP", "oSelectAssetClass": "GT_ASSET_CLASS",
    "oSelectITLAssetClass": "GT_ITL_ASSET_CLASS", "oSelectCAPCURR": "GT_CURRENCY", "oSelectITLCURR": "GT_CURRENCY",
    "oSelectUSState": "GT_USSTATE", "CompanyCodes": "GT_COMP_CODE", "oSelectCompCode": "GT_COMP_CODE",
    "oSelectMultiCCode": "GT_ADD_COMP_CCODE", "diaSearchCostCenter": "GT_KOSTL",
    "diaGeography": "GT_GEOGRAPHYLIST", "diaBrand": "GT_BRANDS", "diaLocation": "GT_LOCATIONS",
    "diaSearchOnBehalf": "GT_AGENT_LIST", "diaSearchAuthBy": "GT_AUTH_BY_LIST",
    "oSelectPrevPCode": "GT_PREV_PROJCODE", "diaSearchPrevProj": "GT_PREV_PROJCODE",
    "oSelectOrderType": "GT_ORDER_TYPE", "AttachmentCategories": "GT_ATTACHMENT_CATEGORIES",
    "AttachmentsRequired": "GT_ATTACHMENTS_REQUIRED", "sysMessage": "GT_SYS_MESSAGE",
}


def is_tf(attr, field):
    spec = REG["BOOL_TF"].get(attr)
    return bool(spec) and (field in spec["fields"] or any(field.startswith(p) for p in spec["prefixes"]))


def convert_row(attr, row):
    out = {}
    for k, v in row.items():
        if k in ("__metadata", "__deferred", "ROW_INDEX"):
            continue
        if is_tf(attr, k):
            v = (v == "true")
        elif k in REG["BOOL_X"].get(attr, []):
            v = (v == "X")
        elif k in REG["DATE"].get(attr, []) and v == "00000000":
            v = ""
        elif k in REG["TIME"].get(attr, []) and v == "000000":
            v = ""
        elif k in REG["DECIMAL"].get(attr, []):
            try:
                v = float(v)
            except (TypeError, ValueError):
                v = 0.0
        out[k] = v
    return out


def normalise_odata(doc):
    d = doc.get("d", doc)
    out = {}
    for attr in REG["STRUCTURES"]:
        if attr in d:
            out[attr] = convert_row(attr, d[attr] or {})
    for attr in REG["TABLES"]:
        if attr in d:
            rows = d[attr]
            rows = rows.get("results", []) if isinstance(rows, dict) else (rows or [])
            out[attr] = [convert_row(attr, r) for r in rows]
    return out


def normalise_neptune(doc):
    out = {}
    for k, v in doc.items():
        attr = OWNERS.get(k, k)
        out.setdefault(attr, v)
    return out


def diff(a, b, path, ignore, problems):
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            if k in ignore:
                continue
            if k not in a:
                problems.append(f"{path}.{k}: only in OData")
            elif k not in b:
                problems.append(f"{path}.{k}: only in Neptune")
            else:
                diff(a[k], b[k], f"{path}.{k}", ignore, problems)
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            problems.append(f"{path}: Neptune {len(a)} rows, OData {len(b)} rows")
        for i, (x, y) in enumerate(zip(a, b)):
            diff(x, y, f"{path}[{i}]", ignore, problems)
    else:
        if isinstance(a, (int, float)) and isinstance(b, (int, float)) and float(a) == float(b):
            return
        if a != b:
            problems.append(f"{path}: Neptune {json.dumps(a)[:60]} ({type(a).__name__}) "
                            f"vs OData {json.dumps(b)[:60]} ({type(b).__name__})")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("neptune_json")
    ap.add_argument("odata_json")
    ap.add_argument("--ignore", nargs="*", default=[])
    args = ap.parse_args()
    nep = normalise_neptune(json.load(open(args.neptune_json, encoding="utf-8")))
    odt = normalise_odata(json.load(open(args.odata_json, encoding="utf-8")))
    shared = {k: nep[k] for k in nep if k in odt}
    problems = []
    diff(shared, {k: odt[k] for k in shared}, "", set(args.ignore), problems)
    print(f"Compared attributes: {', '.join(sorted(shared)) or 'none'}")
    missing = sorted(set(nep) - set(odt))
    if missing:
        print(f"In Neptune response but not in OData response: {', '.join(missing)}")
    if problems:
        print(f"\n{len(problems)} difference(s):")
        for p in problems:
            print(" - " + p)
        sys.exit(1)
    print("No differences after normalisation.")


if __name__ == "__main__":
    main()
