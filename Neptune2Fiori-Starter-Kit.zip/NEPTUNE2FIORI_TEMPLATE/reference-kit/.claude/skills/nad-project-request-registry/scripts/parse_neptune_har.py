#!/usr/bin/env python3
"""Turn a browser HAR recording of the running Neptune app into a Send/Receive capture report.

Why: several AJAX parameter lists exist only as screenshots. The live traffic is the ground truth for
(a) which models each AJAX ID sends and receives, (b) the JSON type Neptune used for every field
(boolean vs "true" string vs "X", numbers, dates).

Usage (macOS, zsh):
    python3 parse_neptune_har.py ~/Downloads/neptune.har > capture-report.md

The script never prints cookies, headers or full field values - only names, JSON types and short samples.
It works with any HAR; it looks for requests that carry an `ajax_id` (query string or JSON body).
"""
import json
import re
import sys
from collections import OrderedDict
from urllib.parse import parse_qs, urlparse

MAX_SAMPLE = 24


def jtype(v):
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, (int, float)):
        return "number"
    if isinstance(v, str):
        if v in ("true", "false"):
            return "str-tf"
        if v == "X":
            return "str-X"
        if re.fullmatch(r"\d{8}", v):
            return "str-8digits"
        return "str"
    if isinstance(v, list):
        return "array"
    if isinstance(v, dict):
        return "object"
    return "null"


def sample(v):
    s = json.dumps(v)[:MAX_SAMPLE]
    return s.replace("|", "\\|")


def find_ajax_id(entry, body_json):
    url = entry["request"]["url"]
    qs = parse_qs(urlparse(url).query)
    for k in ("ajax_id", "AJAX_ID", "ajaxid"):
        if k in qs:
            return qs[k][0]
    if isinstance(body_json, dict):
        for k in ("ajax_id", "AJAX_ID"):
            if k in body_json:
                return str(body_json[k])
    return None


def load_json(text):
    if not text:
        return None
    try:
        return json.loads(text)
    except (ValueError, TypeError):
        return None


def describe(obj, prefix=""):
    """Yield (path, type, sample) for top-level keys and one level of nested fields."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            t = jtype(v)
            if t == "object":
                yield (prefix + k, "object", "")
                for k2, v2 in v.items():
                    yield (prefix + k + "." + k2, jtype(v2), sample(v2))
            elif t == "array":
                yield (prefix + k, f"array[{len(v)}]", "")
                if v and isinstance(v[0], dict):
                    for k2, v2 in v[0].items():
                        yield (prefix + k + "[0]." + k2, jtype(v2), sample(v2))
            else:
                yield (prefix + k, t, sample(v))


def main():
    har = json.load(open(sys.argv[1], encoding="utf-8"))
    calls = OrderedDict()
    for e in har.get("log", {}).get("entries", []):
        req = e.get("request", {})
        body = (req.get("postData") or {}).get("text", "")
        body_json = load_json(body)
        ajax_id = find_ajax_id(e, body_json)
        if not ajax_id:
            continue
        resp_json = load_json(((e.get("response") or {}).get("content") or {}).get("text", ""))
        calls.setdefault(ajax_id, []).append((body_json, resp_json, e["response"].get("status")))

    print("# Neptune capture report\n")
    print(f"AJAX IDs observed: {', '.join(calls) or 'none'}\n")
    for ajax_id, items in calls.items():
        body_json, resp_json, status = items[-1]
        print(f"## {ajax_id}  (calls: {len(items)}, last HTTP {status})\n")
        print("### Sent (request body)\n\n| Path | JSON type | Sample |\n|---|---|---|")
        for p, t, s in describe(body_json or {}):
            print(f"| `{p}` | {t} | {s} |")
        print("\n### Received (response body)\n\n| Path | JSON type | Sample |\n|---|---|---|")
        for p, t, s in describe(resp_json or {}):
            print(f"| `{p}` | {t} | {s} |")
        print()
    print("\n> Fields typed `bool` confirm a boolean conversion (07-json-conversion-registry.md).")
    print("> `str-8digits` on a date field means Neptune sent yyyyMMdd strings; check initial dates.")


if __name__ == "__main__":
    main()
