# AJAX-Mirror Envelope — OData V2 model for ZDCI_UI_PROJECT_REQUEST_SRV

## Why an envelope

Neptune runs the app as stateless AJAX calls. For every call the browser sends a set of class attributes
(**Send**), the server creates a fresh instance of the class, moves the sent JSON into those attributes,
runs `handle_on_ajax( ajax_id, ajax_value )`, and sends a set of attributes back (**Receive**).

The envelope reproduces that exactly with one OData V2 deep insert:

```
POST /sap/opu/odata/sap/ZDCI_UI_PROJECT_REQUEST_SRV/AJAXSet
{ "AJAX_ID": "SAVE", "AJAX_VALUE": "",
  "GS_PROJ_FORM": {...}, "GS_FORMDETAILS": {...}, ...        <- structures = complex properties
  "GT_ATTACHMENTS": [ {...}, ... ], "GT_KOSTL": [], ... }    <- tables = navigation properties
```

DPC_EXT does exactly what Neptune did: new `ZCL_UI_PROJECT_CODE_REQUEST` → move every envelope component
into the public attribute with the same name → `handle_on_ajax( )` → move every attribute back → return.
The Send/Receive filtering happens in the UI (`04-ajax-dispatch-inventory.md`), just as it did in Neptune,
where it was a property of the AJAX object, not of the class.

**The UI must send every navigation property on every call (empty `[]` for the ones it is not sending).**
The deep-insert response is serialised along the navigation tree of the request, so sending every
navigation property is what makes every table receivable. The backend skill's spike test (step B3)
proves this on your Gateway before anything else is built.

## Naming rule

Every OData name is the ABAP name. Complex types and table entity types are named after the **ABAP
attribute** they carry (not the ABAP row type), so two attributes of the same ABAP type never collide.

| OData artifact | Name |
|---|---|
| Root entity type / set | `AJAX` / `AJAXSet`, key `AJAX_ID`, plus `AJAX_VALUE` |
| Complex type for structure attribute `X` | `X` (e.g. `GS_PROJ_FORM`) |
| Complex property on `AJAX` | `X` |
| Entity type for table attribute `T` | `T` (e.g. `GT_KOSTL`), key `ROW_INDEX` (Edm.Int32) + the row's components |
| Entity set | `TSet` |
| Association / association set | `AJAX_T` / `AJAX_TSet` (cardinality 1 : M) |
| Navigation property on `AJAX` | `T` |
| Property names | ABAP component names, uppercase, unchanged (all ≤ 40 chars — the V2 limit) |
| Media entity | `ATTACHMENT` / `ATTACHMENTSet`, keys `FORM`, `ATT`; props `MIME_TYPE`, `FILE_NAME` |

## Envelope components (38) — the attributes Neptune binds, sends or receives

Kind **S** = structure → complex property. Kind **T** = table → navigation property.
"Neptune model owner(s)" = the Neptune control(s) whose Model Source is that attribute; those are the
JSON model names in the UI (see `03-neptune-model-registry.md`).

| # | Attribute (= OData name) | Kind | ABAP type (in `ZCL_UI_PROJECT_CODE_REQUEST`) | Neptune model owner(s) |
|---|---|---|---|---|
| 1 | `WA_URL_PARAMETERS` | S | anonymous: `FORM_GUID, PROJ, MODE, FROM, PROCESSING_REGION, COMPANY_CODE` (all STRING) | `UrlParameters` |
| 2 | `WA_PROGRAM_STATE` | S | anonymous: `PROGRAM_STATE, PROGRAM_MESSAGE, INCORRECT_FIELD` (STRING) | `ProgramState` |
| 3 | `WA_COMMENTS` | S | anonymous: `COMMENTS` (STRING) | `diaCreate, diaChange, diaSubmit, diaSubmitWthErr, diaReject, diaClose, diaReSubmit` |
| 4 | `WA_CONFIRM_DELETE` | S | anonymous: `DELETE_INDEX` (STRING) | `diaConfirmAttDelete` |
| 5 | `GS_PROJ_FORM` | S | `TY_PROJ_FORM` = `ZMDG_PROJ_FORM` + `ZMDG_S_PROJ_FLGRP_VISI` + `ZMDG_S_PROJ_FLGRP_EXPAND` + `ZMDG_PROJ_FORM_S_READ_ONLY` + `ZMDG_PROJ_FORM_S_VISIBLE` + `ZMDG_S_NAD_ORDER_BUTTONS` + `ZMDG_PROJ_FORM_S_EDITABLE` + `KOSTL_TEXT, IS_DIRTY, REQUESTER_TITLE, REQUESTER_EMAIL, PREV_COMMENTS, NAVIGATION_VISIBLE, DISPLAY_OR_EDIT, PAGE_HEADER, ATTRIBUTES_VISIBLE, MODE_BUTTON_VISIBLE, MODE_BUTTON_ICON, CAN_ATTACH, PROJECT_ID_OUT` | `oPageProj, diaDelDraft, subsectionComments` |
| 6 | `GS_FORMDETAILS` | S | `ZCA_FORMDETAIL` | `cntr_formdetails` |
| 7 | `GS_STEPDETAIL` | S | `ZCA_STEPDETAIL` | `cntr_stepdetails` |
| 8 | `GS_FORMHEADER` | S | `ZCA_S_NAD_GL_PAGEHEADER` | `vlAttributesBlock1, vlAttributesBlock2` |
| 9 | `GS_EMPLOYEE_INFO` | S | `ZHCM_S_EMPLOYEE_INFO` | `oFormEmployeeInfo` |
| 10 | `GS_ATTACHMENT` | S | `ZCA_FORM_ATTACHMENT` | `sectionAttachments` |
| 11 | `GS_MULTIPLECCODE` | S | `TY_ADDITIONAL_CCODE` | `diaAddMultiCC` |
| 12 | `GT_APPR` | T | `TY_WI_APPR` | `oTableApprovers` |
| 13 | `GT_ATTACHMENTS` | T | `ZCA_FORM_ATTACHMENT` (`ZCA_FORM_ATTACHMENT_T`) | `listAttachments` |
| 14 | `GT_ZCA_AGENT_LIST` | T | `ZCA_S_NAD_GL_AGENT` (`ZCA_T_NAD_GL_AGENT`) | `listAgents` |
| 15 | `GT_ORDERDETAILS` | T | `TY_ORDERDETAILS` | `tabOrderdetails` |
| 16 | `GT_ADDITIONAL_CCODE` | T | `TY_ADDITIONAL_CCODE` | `tabMultiCC` |
| 17 | `GT_REQUEST_TYPE` | T | `TY_VALUE_TEXT` | `oSelectProjType` |
| 18 | `GT_PROJECT_SUBTYPE` | T | `TY_VALUE_TEXT` | `selProjectSubtype` |
| 19 | `GT_EXEC_CATEGORY` | T | `TY_VALUE_TEXT` | `oSelectExecCategory` |
| 20 | `GT_INITI_GROUP` | T | `ZZMDG_INITIA_GRP` | `oTableINITIA_GRP` |
| 21 | `GT_INITI_GRP` | T | `ZZMDG_INITIA_GRP` | `oSelectInitPrd_Grp` |
| 22 | `GT_ASSET_CLASS` | T | `TY_VALUE_TEXT` | `oSelectAssetClass` |
| 23 | `GT_ITL_ASSET_CLASS` | T | `TY_VALUE_TEXT` | `oSelectITLAssetClass` |
| 24 | `GT_CURRENCY` | T | `TY_VALUE_TEXT` | `oSelectCAPCURR, oSelectITLCURR` |
| 25 | `GT_USSTATE` | T | `TY_VALUE_TEXT` | `oSelectUSState` |
| 26 | `GT_COMP_CODE` | T | `TY_VALUE_TEXT` | `CompanyCodes, oSelectCompCode` |
| 27 | `GT_ADD_COMP_CCODE` | T | `TY_VALUE_TEXT` | `oSelectMultiCCode` |
| 28 | `GT_KOSTL` | T | `TY_VALUE_TEXT` | `diaSearchCostCenter` |
| 29 | `GT_GEOGRAPHYLIST` | T | `TY_VALUE_TEXT` | `diaGeography` |
| 30 | `GT_BRANDS` | T | `TY_VALUE_TEXT` | `diaBrand` |
| 31 | `GT_LOCATIONS` | T | `TY_LOCATION` (`PLANT, LOCATION, TEXT`) | `diaLocation` |
| 32 | `GT_AGENT_LIST` | T | `TY_AGENT_LIST` (`OTYPE, OBJID, TEXT`) | `diaSearchOnBehalf` |
| 33 | `GT_AUTH_BY_LIST` | T | `TY_AGENT_LIST` | `diaSearchAuthBy` |
| 34 | `GT_PREV_PROJCODE` | T | `S_VALUE_TEXT` | `oSelectPrevPCode, diaSearchPrevProj` |
| 35 | `GT_ORDER_TYPE` | T | `S_VALUE_TEXT` | `oSelectOrderType` |
| 36 | `GT_ATTACHMENT_CATEGORIES` | T | `S_VALUE_TEXT_REQ` (`VALUE, TEXT, REQUIRED, PROJECT_TYPE, PROJECT_SUBTYPE`) | `AttachmentCategories` |
| 37 | `GT_ATTACHMENTS_REQUIRED` | T | `ZMDG_ATT_REQ` | `AttachmentsRequired` |
| 38 | `GT_SYS_MESSAGE` | T | `TY_MESSAGE` (components of `/NEPTUNE/MESSAGE`) | `sysMessage` (Neptune built-in) |

Owner list source: the full parameter table of AJAX `GET_AUTHBY_ID` (Neptune lists every model-bound control
there) plus `sysMessage` from `07_SUBMIT.md`.

### Class attributes deliberately NOT in the envelope

No Neptune control binds them, so Neptune never transferred them. If a captured Neptune payload
(`06-capture-neptune-payloads.md`) shows one of them, add it — same naming rule.

`GV_WI_ID, GT_ZCA_FORM, GT_ZCA_FORM_FLDGRP, GT_ZCA_FLDGRP_FLDS, GT_ZCA_APPRVR_LIST, GT_ZCA_APPRVR_ATTR,
GT_ZCA_FORMDETAIL, GT_ZCA_STEPDETAIL, GT_FIELDGROUP, GT_QUADRANT, GT_FUNCTION, GT_PRIORITY,
GT_PREV_ITL_PROJCODE, GT_PREV_IMO_PROJCODE, GT_ALL_COMP_CODE, GT_EXCLUDE_CCODE, GS_APPR, GS_FIELDGROUP,
GS_ERROR_MSG, GS_REQUEST_TYPE, GS_EXEC_CATEGORY, GS_QUADRANT, GS_INITI_GROUP, GS_FUNCTION, GS_ASSET_CLASS,
GS_PRIORITY, GS_GEOGRAPHY, GS_KOSTL, GS_CURRENCY, GS_USSTATE, GS_ORDERTYPE, GS_ORDERDETAILS, GS_EMAIL_VALUE,
GS_COMP_CODE, GC_*` (all `GC_*` are instance DATA used as constants; `GC_FORM_VER` is mutated per region).

## ABAP → Edm type mapping (done by RTTI in MPC_EXT, so it always matches the live DDIC)

| ABAP kind | Edm type | Notes |
|---|---|---|
| C, N | Edm.String, MaxLength = length | NUMC stays a string (`'0001'`) |
| D | Edm.String, MaxLength 8 | Neptune sends `yyyyMMdd` strings; DatePickers use `valueFormat="yyyyMMdd"` |
| T | Edm.String, MaxLength 6 | |
| STRING | Edm.String | |
| P | Edm.Decimal, Precision = 2·len−1, Scale = decimals | Gateway API: `set_maxlength` = precision, `set_precison` = scale |
| I / INT2 / INT1 / INT8 | Edm.Int32 / Int16 / Byte / Int64 | |
| F | Edm.Double | |
| X / XSTRING | Edm.Binary | none expected in the envelope |

`bind_structure( iv_bind_conversions = abap_false )` — Neptune did **not** apply conversion exits
(cost centers arrive as internal `0000012345`; the UI even slices `KOSTL_CODE` with `substring(0, 10)`).

Booleans: the OData layer carries ABAP values unchanged (`'true'`, `'false'`, `'X'`, `''`). The UI client
converts them to/from JSON booleans exactly as the Neptune runtime did — see `07-json-conversion-registry.md`.

## Request / response shape

Request (UI → Gateway): all 11 complex properties as objects, all 27 navigation properties as arrays.
Rows carry `ROW_INDEX` (1..n). Values for non-Send attributes are empty (`{}` fields blank / `[]`).

Response: standard V2 JSON `{ "d": { "AJAX_ID": ..., "GS_PROJ_FORM": {...}, "GT_KOSTL": { "results": [...] } } }`.
The client unwraps `results`, strips `ROW_INDEX` and `__metadata`, applies the JSON conversion registry,
and writes only the **Receive** attributes into their owner models.

## Attachment download (replaces `handle_on_request`)

```
GET /sap/opu/odata/sap/ZDCI_UI_PROJECT_REQUEST_SRV/ATTACHMENTSet(FORM='<form guid>',ATT='<uuid>')/$value
```
DPC_EXT `GET_STREAM` calls `ZCL_UI_PROJECT_CODE_REQUEST->handle_on_request( key = 'ATTACHMENT'
key_id = 'FORM=<guid>,ATT=<uuid>' )` — the same key/key_id string Neptune built in `displayAttachment()`.
