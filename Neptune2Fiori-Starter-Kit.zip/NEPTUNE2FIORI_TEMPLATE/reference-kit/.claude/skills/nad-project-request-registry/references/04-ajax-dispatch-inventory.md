# AJAX Dispatch Inventory — all 23 server entry points

Derived line-by-line from `docs/neptune-source/Backend Class/ProjectRequest App.txt` (`handle_on_ajax` + `handle_on_request`)
and cross-checked with the `Ajax/*.md` specs, the UI specs and (S2c, 2026-10-17) the Neptune XML export
(`docs/capture/export-extract/ajax.json` = IT_CONTENT AJAX objects + IT_MODEL + IT_EVENT_SCRIPT).

**Evidence levels** for Send/Receive:
- **CAP** — confirmed by capture or by the Neptune XML export IT_MODEL table (authoritative). All rows are CAP since S2c.
- **DOC** — taken from the Neptune AJAX parameter table in `Ajax/*.md`.
- **INF** — inferred from what the backend method reads/writes and what the JS handler touches.

Model names in Send/Receive are Neptune control names (= Fiori model names, see `03-neptune-model-registry.md`).
The exact pair lists `[model, ABAP attribute]` are in `webapp/util/AjaxConfig.js` (export IT_MODEL order).
Handlers (`<AJAX_ID>_ajaxSuccess` / `_ajaxError`) are ported verbatim from the export IT_EVENT_SCRIPT.

## Summary

| # | AJAX ID | Export AJAX object (FIELD_ID) → JS caller | Class method chain | Backend behaviour | Send/Receive evidence |
|---|---|---|---|---|---|
| 1 | `GET_DATA` | GetDetail (00139) → `getOnlineGetDetail()` | `get_data` → `create_form_wref_orderid` / `create_init` / (`get_approvers`, `load_form`, `set_header`, `set_field_*`, `set_fldgrp_visibility`, `set_button_visibility`, `reset_value`) → `populate_f4_help` | Loads/initialises the whole form | **CAP** |
| 2 | `GET_EMPINFO` | GetEmplInfo (00799) → `getOnlineGetEmplInfo()` (caller `oObjectEmpName` press — S2b) | `get_userdetail` | Fills `GS_EMPLOYEE_INFO` | **CAP** |
| 3 | `GET_AGENTLIST` | GetAgent (00666) → `getOnlineGetAgent()` (caller `oObjectAgent` press — S2b) | `get_agents` | Fills `GT_ZCA_AGENT_LIST` | **CAP** |
| 4 | `CREATE` | Create (00141) → `getOnlineCreate()` (`butCreateSave`) | `create_form` | Starts workflow, writes `ZMDG_PROJ_FORM` ×2, saves attachments, dequeues | **CAP** |
| 5 | `CHECK` | Check (00144) → `getOnlineCheck()` (`butChange`, `butSubmit`) | `check_error` | **No-op** — whole body commented out | **CAP** |
| 6 | `SAVE` | SaveAsDraft (00142) → `getOnlineSaveAsDraft()` (`butSave`) | `save_form` | `save_draft`, `MODIFY zmdg_proj_form` (implicit commit), attachments | **CAP** |
| 7 | `DELETE` | DeleteDraft (00145) → `getOnlineDeleteDraft()` (`butDDraft`) | `delete_form` (→ `delete_attachment`) | Deletes form + ONE attachment | **CAP** |
| 8 | `REJECT` | Reject (00143) → `getOnlineReject()` (`butRejectOK`) | `reject_form` | Workflow reject | **CAP** |
| 9 | `SUBMIT` | Submit (00885) → `getOnlineSubmit()` (`butSubmitSave` when `!PROJ_FLGRP_0003`) | `submit_form` | Workflow approve | **CAP** |
| 10 | `RESUBMIT` | Resubmit (01187) → `getOnlineResubmit()` (`butReSubmitSave`) | `resubmit_form` | Workflow resubmit | **CAP** |
| 11 | `CHANGE` | Change (00928) → `getOnlineChange()` (`butChgSave`) | `change_form` (→ `create_form` if no GUID) | Workflow change | **CAP** |
| 12 | `CLOSE` | Close (00146) → `getOnlineClose()` (`butCloseSubmit`) | `close_form` | Workflow withdraw | **CAP** |
| 13 | `DELETE_ATTACHMENT` | DeleteAttachment (00931) → `getOnlineDeleteAttachment()` (`btnAttDeleteYes`) | `delete_attachment` | Deletes attachment at `DELETE_INDEX + 1` | **CAP** |
| 14 | `BACK` | Back (00930) → `getOnlineBack()` (CHANGE/RESUBMIT error) | `check_dirty` | **Only sets `IS_DIRTY = 'X'`** — does not dequeue | **CAP** |
| 15 | `NEW_PROJECT` | NewProject (01237) → `getOnlineNewProject()` (`butSubmitSave` when `PROJ_FLGRP_0003`) | `create_project` → `cc_all_approvers` → `submit_form` | Creates PS project (`Z_PS_COPY_TEMPLATE`), then approves | **CAP** |
| 16 | `DEQUEUE_FORM` | DequeueForm (00853) → `getOnlineDequeueForm()` | `check_dirty` + `zcl_nd_ca_utilities=>dequeue_form` | Releases lock | **CAP** |
| 17 | `AGENT_SEARCH` | GetOnBehalfPerson (01197) → `getOnlineGetOnBehalfPerson(term)` (`diaSearchOnBehalf` search) | `agent_search( ajax_value )` | Fills `GT_AGENT_LIST` | **CAP** |
| 18 | `AUTH_BY_SEARCH` | GetAuthorizedBy (01036) → `getOnlineGetAuthorizedBy(term)` (`diaSearchAuthBy` search) | `auth_by_search( ajax_value )` | Fills `GT_AUTH_BY_LIST` | **CAP** |
| 19 | `GET_ONBEHALF_ID` | UpdateOnbehalf_ID (01196) → `getOnlineUpdateOnbehalf_ID(id)` | `get_on_behalf_data( ajax_value )` | Sets `REQUESTER_TITLE/EMAIL` from that user | **CAP** |
| 20 | `GET_AUTHBY_ID` | UpdateAuthorizedBy (01031) → `getOnlineUpdateAuthorizedBy(id)` (`diaSearchAuthBy` confirm) | `get_authorized_by_data` | **No-op** — body commented out | **CAP** |
| 21 | `GET_COSTCENTER` | GetCostCenter (01075) → `getOnlineGetCostCenter(filter)` | `get_costcenter( ajax_value )` | Fills `GT_KOSTL` for `WA_URL_PARAMETERS-COMPANY_CODE` | **CAP** |
| 22 | `UPDATE_REGION` | Update_Region (01079) → `getOnlineUpdate_Region()` (`rbgQProcessingRegion` select) | `update_process_region` | Sets region + form version, refreshes `GT_COMP_CODE`, clears `GT_KOSTL` | **CAP** |
| 23 | *(request)* `ATTACHMENT` | `displayAttachment()` → URL `?key=attachment&key_id=form=…,att=…` | `handle_on_request` → `zcl_nd_ca_utilities=>get_attachment_data` / `redirect_error` | Streams the file | n/a → OData `ATTACHMENTSet(...)/$value` |

**Called by the UI but NOT handled by the backend (no `WHEN` branch):**

| JS function | Intended AJAX | Effect today | Parity action |
|---|---|---|---|
| `getOnlineNewIntOrderWErr()` (`butSubWthErrSave`) | `NEW_INTENALORDER_WEXP` = export NewIntOrderWErr (01176), `WHEN` commented out in class | Server falls through `CASE` and returns normally → ajaxSuccess shows "Multiple internal orders … created in SAP with Error." and goes back | Replicate (config CAP + handlers ported). P-04 |
| `getOnlineoTreeTable()` (SAVE error path) | belongs to the parent list app | Only works when embedded in the parent | Call only if defined. P-19 |

**AJAX objects in the export that are dead (no caller, no active `WHEN`) — not ported (P-39):**

| Export AJAX object (FIELD_ID) | AJAX ID | fn | Class |
|---|---|---|---|
| Create_INIT (00322) | `CREATE_INIT` | `getOnlineCreate_INIT` | no `WHEN` |
| GetProjectCode (01063) | `GET_PROJCODE` | `getOnlineGetProjectCode` | no `WHEN` |
| NewInternalOrder (01078) | `NEW_INTENALORDER` | `getOnlineNewInternalOrder` | `WHEN` commented (`ProjectRequest App.txt:606`) |

`Ajax/01_CREATE_INIT.md` describes the dead `Create_INIT` object; its `ajaxSuccess` code was used for `CREATE` by the kit
until S2c — `CREATE` now has its own export code.

**IT_MODEL rows without ABAP attribute (not in `AjaxConfig.js`, P-40):** `DEQUEUE_FORM` → `oplForm` (Send),
`BACK` → `sectionGL` (Send+Receive).

**Runtime message channel (P-42):** `[sysMessage, GT_SYS_MESSAGE]` is not an IT_MODEL row; it replaces
`server->api_message_create` (R-06). Active calls only in `WHEN 'NEW_PROJECT'` (lines 703/708/714/719) → received by
`NEW_PROJECT` only.

---

## Per-call detail

Format: **Reads** = attributes the backend reads. **Writes** = attributes it changes. **Send/Receive** = export IT_MODEL
(CAP). DB/side effects listed for test design.

### 1. GET_DATA — `getOnlineGetDetail()`
- Reads: `WA_URL_PARAMETERS` (`FORM_GUID` incl. `"<guid>/create"` suffix, `MODE`, `PROJ`, `FROM`),
  `GS_FORMDETAILS` (`FORM_STATUS`, `FORM_GUID` — re-open of a draft), `GS_STEPDETAIL`.
- Writes: `GS_PROJ_FORM`, `GS_FORMDETAILS`, `GS_STEPDETAIL`, `GS_FORMHEADER`, `GS_EMPLOYEE_INFO`, `GT_APPR`,
  `GT_ZCA_AGENT_LIST`, `GT_ATTACHMENTS`, `GT_ORDERDETAILS`, `WA_PROGRAM_STATE`, and every value list.
- Send (CAP): `UrlParameters, cntr_formdetails, cntr_stepdetails`. **`oPageProj` is not sent** (P-25 closed).
- Receive (CAP): `diaCreate, diaSubmit, diaDelDraft, oTableApprovers, oPageProj, UrlParameters, vlAttributesBlock1,
  vlAttributesBlock2, oFormEmployeeInfo, diaReject, cntr_formdetails, cntr_stepdetails, sectionAttachments,
  listAttachments, listAgents, subsectionComments, ProgramState, CompanyCodes, oSelectProjType, oSelectExecCategory,
  oSelectAssetClass, oSelectCompCode, diaSearchOnBehalf, AttachmentCategories, oSelectCAPCURR, oSelectITLCURR,
  oSelectUSState, oSelectOrderType, oSelectPrevPCode, tabOrderdetails, oSelectITLAssetClass, oTableINITIA_GRP,
  tabMultiCC, oSelectMultiCCode, oSelectInitPrd_Grp, selProjectSubtype, diaGeography, diaBrand, diaLocation,
  AttachmentsRequired`. Not received: `diaSearchCostCenter`, `diaSearchPrevProj`.
- Handlers: export 00139 (setUI, resetFields, oApp.to, dirty false, addExpandButtons, scroll, `colStatusICON`,
  PROGRAM_STATE toast, helpers, busy off). ajaxError: `oApp.setBusy(false)`.

### 2. GET_EMPINFO — `getOnlineGetEmplInfo()`
- Reads `GS_PROJ_FORM-REQUESTER_ID`, `GS_FORMDETAILS-INITIATED_BY`. Writes `GS_EMPLOYEE_INFO`.
- Send (CAP): `cntr_formdetails`. Receive (CAP): `oFormEmployeeInfo`. (`oPageProj` is not sent → `REQUESTER_ID` initial on the server.)
- Handlers: success `oApp.setBusy(false); diaEmployeeInfo.openBy(oObjectEmpName);` error `oApp.setBusy(false);`.

### 3. GET_AGENTLIST — `getOnlineGetAgent()`
- Reads `GS_FORMDETAILS` (`FORM_GUID, AGENT_ID_LIST, WORKCENTER_ID`). Writes `GT_ZCA_AGENT_LIST`;
  `WA_PROGRAM_STATE` on `ZCX_CA_FORM_EXCEPTIONS` (not received).
- Send (CAP): `cntr_formdetails, cntr_stepdetails`. Receive (CAP): `listAgents`.
- Handlers: success `oApp.setBusy(false); diaAgents.open();` error `oApp.setBusy(false);`.

### 4. CREATE — `getOnlineCreate()`
- Reads `GS_PROJ_FORM`, `GS_FORMDETAILS-FORM_GUID`, `GS_STEPDETAIL-STEP_GUID`, `GT_ATTACHMENTS`.
  DB: `ZMDG_PROJ_FORM`, `ZMDGATTACH`; workflow; emails; dequeue.
- Send (CAP): `diaCreate, oPageProj, UrlParameters, cntr_formdetails, cntr_stepdetails, listAttachments, tabMultiCC`.
  Receive (CAP): `UrlParameters, cntr_formdetails, cntr_stepdetails, ProgramState`.
- Handlers: export 00141 — PROGRAM_STATE E → `INCORRECT_FIELD` value state or `discoveryFiori.showMessage`; else
  toast `txtTranslateCreate`, dirty false, `form-saved`, `goBack`. Error: `showMessage(txtConnectionFailure)`.

### 5. CHECK — `getOnlineCheck()`
- Backend: nothing (method body commented). Returns initial `WA_PROGRAM_STATE`.
- Send (CAP): `UrlParameters, cntr_formdetails, tabMultiCC`. Receive (CAP): `UrlParameters, vlAttributesBlock1,
  vlAttributesBlock2, cntr_formdetails, ProgramState`.
- ajaxSuccess: E → message; else `MODE == "EDIT" && APPR_STEP == "BUDGET_MANAGER"` → `diaChange.open()`; else
  `diaSubmit.open()`. ajaxError: **none** in the export (P-41).

### 6. SAVE — `getOnlineSaveAsDraft()`
- Send (CAP): `oPageProj, cntr_formdetails, cntr_stepdetails, sectionAttachments, listAttachments, tabMultiCC`.
- Receive (CAP): `oPageProj, cntr_formdetails, cntr_stepdetails, listAttachments, ProgramState`.
- Backend: region → form version; `save_draft` (exceptions swallowed); `MODIFY zmdg_proj_form` without `COMMIT WORK`.

### 7. DELETE — `getOnlineDeleteDraft()`
- Reads `GS_FORMDETAILS-FORM_GUID`, `GT_ATTACHMENTS`, `WA_CONFIRM_DELETE-DELETE_INDEX` (not sent → initial, P-07).
- Send (CAP): `oPageProj, UrlParameters, cntr_formdetails, cntr_stepdetails, listAttachments, ProgramState, tabMultiCC`.
  Receive (CAP): `ProgramState`.

### 8. REJECT — `getOnlineReject()`
- Send (CAP): `oPageProj, diaReject, cntr_formdetails, cntr_stepdetails, tabMultiCC`. Receive (CAP): `ProgramState`.

### 9. SUBMIT — `getOnlineSubmit()`
- Send (CAP): `diaSubmit, oPageProj, UrlParameters, cntr_formdetails, cntr_stepdetails, listAttachments,
  ProgramState, tabMultiCC`.
- Receive (CAP): `diaSubmit, oPageProj, UrlParameters, cntr_stepdetails, listAttachments, ProgramState,
  tabOrderdetails, tabMultiCC`. No `sysMessage` (P-42).
- Handlers: export 00885 (`diaMessages` guarded, P-36).

### 10. RESUBMIT — `getOnlineResubmit()`
- Send (CAP): `oPageProj, cntr_formdetails, cntr_stepdetails, listAttachments, diaReSubmit, tabMultiCC`. Receive: none.

### 11. CHANGE — `getOnlineChange()`
- Send (CAP): `oPageProj, UrlParameters, cntr_formdetails, cntr_stepdetails, listAttachments, tabMultiCC, diaChange`.
  Receive (CAP): `UrlParameters`.

### 12. CLOSE — `getOnlineClose()`
- Send (CAP): `diaClose, oPageProj, UrlParameters, cntr_formdetails, cntr_stepdetails, listAttachments, ProgramState`.
  Receive (CAP): `UrlParameters, ProgramState`.

### 13. DELETE_ATTACHMENT — `getOnlineDeleteAttachment()`
- Reads `GT_ATTACHMENTS`, `WA_CONFIRM_DELETE-DELETE_INDEX`, `GS_FORMDETAILS-FORM_GUID`. Writes `WA_PROGRAM_STATE` on error.
- Send (CAP): `cntr_formdetails, cntr_stepdetails, sectionAttachments, listAttachments, diaConfirmAttDelete`.
  Receive (CAP): `ProgramState`.
- Handlers: export 00931 — busy off, `diaConfirmAttDelete.close()`, E → MessageToast + return; else splice row
  `DELETE_INDEX`, `updateBindings`, close again. Error: `txtConnectionFailure` message.

### 14. BACK — `getOnlineBack()`
- Send (CAP): `cntr_formdetails, cntr_stepdetails` (+ `sectionGL`, no attribute, P-40). Receive: none.
  Handlers: export code fully commented out.

### 15. NEW_PROJECT — `getOnlineNewProject()`
- Reads from `GS_PROJ_FORM` the project fields + everything `submit_form` reads.
- Writes `GS_PROJ_FORM-PROJECT_ID`, `PROJECT_ID_OUT`, `GT_SYS_MESSAGE` (errors), DB, emails.
- Send (CAP): `diaSubmit, oPageProj, cntr_formdetails, cntr_stepdetails, listAttachments`.
  Receive (CAP): `oPageProj` + `sysMessage` (runtime channel, P-42).
- Handlers: export 01237 (P-27 closed).

### 16. DEQUEUE_FORM — `getOnlineDequeueForm()`
- Send (CAP): `cntr_formdetails` (+ `oplForm`, no attribute, P-40). Receive (CAP): `ProgramState`.
  Handlers: export code fully commented out.

### 17. AGENT_SEARCH — `getOnlineGetOnBehalfPerson(term)`
- `ajax_value` = search term. Writes `GT_AGENT_LIST` (first row empty).
- Send (CAP): `oPageProj, cntr_stepdetails`. Receive (CAP): `oPageProj, cntr_stepdetails, diaSearchOnBehalf`.
- Handlers: busy off; error message commented out (P-37).

### 18. AUTH_BY_SEARCH — `getOnlineGetAuthorizedBy(term)`
- As 17, writes `GT_AUTH_BY_LIST`. Send (CAP): `oPageProj, cntr_stepdetails`.
  Receive (CAP): `oPageProj, cntr_stepdetails, diaSearchAuthBy`.

### 19. GET_ONBEHALF_ID — `getOnlineUpdateOnbehalf_ID(userId)`
- Send/Receive (CAP): `oPageProj, cntr_formdetails, cntr_stepdetails`.
- Backend: empty `ajax_value` → uses `sy-uname` and clears `ONBEHALF_NAME/ID`; sets `REQUESTER_TITLE/EMAIL`.
- Handlers: export 01196 (busy off + scroll).

### 20. GET_AUTHBY_ID — `getOnlineUpdateAuthorizedBy(userId)`
- Send/Receive (CAP): `oPageProj, cntr_formdetails, cntr_stepdetails`.
- Backend: no-op. Handlers: export 01031 (busy off + scroll; error message) — P-03 corrected.

### 21. GET_COSTCENTER — `getOnlineGetCostCenter(filter)`
- Reads `WA_URL_PARAMETERS-COMPANY_CODE`, `ajax_value`. Writes `GT_KOSTL` (first row empty).
- Send (CAP): `UrlParameters, cntr_formdetails, cntr_stepdetails`.
  Receive (CAP): `cntr_formdetails, cntr_stepdetails, diaSearchCostCenter`.

### 22. UPDATE_REGION — `getOnlineUpdate_Region()`
- Reads `WA_URL_PARAMETERS-PROCESSING_REGION`. Writes `GS_PROJ_FORM-PROCESSING_REGION`, `GC_FORM_VER`,
  `GT_COMP_CODE`, `GT_KOSTL` (cleared).
- Send (CAP): `oPageProj, UrlParameters, cntr_formdetails, cntr_stepdetails` (`oPageProj` round-trips, so the form is
  not wiped). Receive (CAP): `oPageProj, CompanyCodes, oSelectCompCode, oSelectMultiCCode` (not `diaSearchCostCenter`).

### 23. Attachment download
- Neptune: `/neptune/zdci_nad_project_request.html?key=attachment&key_id=form=<FORM_GUID>,att=<UUID>` opened in a
  new tab (`FORM_GUID` from `vlAttributesBlock1`).
- Fiori: `<service>/ATTACHMENTSet(FORM='<FORM_GUID>',ATT='<UUID>')/$value` in a new tab.
  Errors return the MIME page `/neptune/public/application/zdci_nad_customer_form/pages/attacherror.html`
  (HTML) exactly as Neptune did — if Neptune is uninstalled that MIME file is gone (parity log P-20).
