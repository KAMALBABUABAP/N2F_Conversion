# Capturing the live Neptune behaviour (ground truth for every "INF" row)

Several AJAX parameter lists exist only as screenshots, and a few specs are missing. Before the UI is
signed off, capture the running Neptune app once. This takes about 30 minutes and removes every guess.

## A. Network capture (Chrome or Edge on the Mac)

1. Open the Neptune app `ZDCI_NAD_PROJECT_REQUEST` in the browser as a normal user.
2. Open DevTools (Cmd+Option+I) → **Network** tab → tick **Preserve log**.
3. Run through every action once, on a test form:
   new request (GET_DATA create), Save, open again (GET_DATA existing), On-behalf search + select,
   Authorized-by search + select, change Processing Region, Company Code → Cost Center search,
   add + delete an attachment, open an attachment, Submit (CHECK → SUBMIT), Reject, Resubmit,
   Change (edit mode), Withdraw, Delete draft, employee-info popover, agents dialog, Back.
4. Right-click the request list → **Save all as HAR with content** → `~/Downloads/neptune.har`.
5. Produce the report (no cookies or headers are printed):
   ```zsh
   python3 .claude/skills/nad-project-request-registry/scripts/parse_neptune_har.py ~/Downloads/neptune.har > docs/capture-report.md
   ```
6. Do not commit the `.har` file — it contains session cookies. Delete it after the report is made.

## B. Neptune designer (Cockpit) — what the HAR cannot show

For each AJAX object, open its parameter dialog and copy the table
`Model | Field Type | Binding | Send | Receive` into `docs/ajax-params/<AJAX_ID>.md`.
Also copy:
- the `ajaxSuccess` / `ajaxError` code of `CREATE`, `NEW_PROJECT`, `DELETE_ATTACHMENT`, `GET_EMPINFO`,
  `GET_AGENTLIST`, `UPDATE_REGION`, `GET_COSTCENTER`, `AGENT_SEARCH`, `AUTH_BY_SEARCH`
  (no spec file exists for them);
- the AJAX object **names** (they define the `getOnline<Name>()` function names);
- the text of every hidden text control (`txtSaveDraft`, `txtConnectionFailure`, … see `03`);
- the missing UI specs: `subsectionRequester`, `subsectionProjdetail` → `sfBudgetProj`,
  `subsectionFPA`, `subsectionRTR`, `subsectionBPC`, `hcAttributes`, `diaSearchPrevProj`,
  plus the press handlers of `oObjectEmpName`, `oObjectAgent`, `btnPrevOrder`, `btnNextOrder`,
  `btnToggleEdit`, `btnNavBack`, `rbgQProcessingRegion`;
- the source of the shared library `/neptune/public/application/zdci_nad_shared/js/discoveryFiori.js`
  (ChildComponent, DirtyHandler, FileUploader, showMessage, addExpandButtons) and
  `/neptune/public/application/ZDCI_NAD_PROJECT_REQUEST/css/app.css`;
- the two template files under `/neptune/public/application/ZDCI_NAD_PROJECT_REQUEST/Templates/`.

## C. Updating the registries

For every INF row in `04-ajax-dispatch-inventory.md` that the capture confirms or corrects:
change the evidence to **CAP** (captured) and fix the Send/Receive list. For every field whose JSON type
differs from `07-json-conversion-registry.md`, fix the registry. Record any new quirk in `05-parity-log.md`.
