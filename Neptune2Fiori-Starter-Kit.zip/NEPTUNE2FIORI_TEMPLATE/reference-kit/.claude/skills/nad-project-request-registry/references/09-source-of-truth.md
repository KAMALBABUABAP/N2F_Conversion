# Source-of-Truth Order and Known Spec Errors

The Neptune2Fiori repo mixes real source (ABAP, JS) with specs re-typed from PDF screenshots. When two
sources disagree, the higher one wins. Never "average" two sources; never guess silently.

## Order (highest first)

1. **Live Neptune capture** — HAR report and Neptune designer copies (`06-capture-neptune-payloads.md`).
2. **ABAP class source** — `docs/neptune-source/Backend Class/ProjectRequest App.txt` (what the server really does).
3. **DDIC in the target system** (SE11) — newer than the printouts in `DB Model/`.
4. **JavaScript source** — `Init.txt`, `Global Script.txt`, `Utility.txt`, `form.txt`, and code blocks quoted
   inside specs (copied from the designer, reliable).
5. **`DB Model/` printouts** — the `ZMDG_PROJ_FORM` printout is Rel. 750 and lacks fields the code uses.
6. **`Ajax/*.md`** parameter tables (reliable where present; several are screenshot placeholders).
7. **UI/dialog specs** (`*_SPEC.md`, `dia*.md`, `UI_*.md`, `Master_Control_Tree.md`) — PDF-derived; tables of
   attributes are reliable, inferred notes and "Fiori migration" code inside them are **not** (they rename
   functions and models, which this project forbids).
8. Anything else → it is an assumption: write it down, mark it `ASSUMPTION`, and ask.

## Known errors in the repo specs (do not copy them)

| Spec says | Correct value | Evidence |
|---|---|---|
| `DS_PROJ_FORM-…` (`*_SPEC.md`) | `GS_PROJ_FORM-…` | OCR of `GS_`; no `DS_PROJ_FORM` attribute exists in the class |
| `DT_ADDITIONAL_CCODE-…` | `GT_ADDITIONAL_CCODE-…` | OCR of `GT_` |
| `REGIN` (tabMultiCC region) | `REGION` | `TY_ADDITIONAL_CCODE-REGION` |
| `ISULTRUE` (delete button enabled) | `DELETABLE` | `TY_ADDITIONAL_CCODE-DELETABLE`, set in `set_multi_ccode` |
| `R_CAPD` (Cap Number required) | `R_CAPID` — **confirmed S4M S3-B0** | `ZMDG_PROJ_FORM_S_READ_ONLY-R_CAPID`, `ZMDG_PROJ_FORM-CAPID` |
| `SUBMITWITH_ERR` (butSubmitWthErr visible) | `SUBMITWTH_ERR` | `ZMDG_S_NAD_ORDER_BUTTONS` |
| `ProgramState` has `DISPLAY_OR_EDIT, CAN_ATTACH, CAN_SUBMIT, …` | `PROGRAM_STATE, PROGRAM_MESSAGE, INCORRECT_FIELD` | `WA_PROGRAM_STATE` in the class |
| `GS_EMPLOYEE_INFO` has `NAME, DEPARTMENT, KOSTL, COMP_CODE, ORG_UNIT` | `PERNR, ENAME, EMAIL_TEXT, EMAIL, ORGUNIT_TXT, POSITION_TXT, CELL_TEXT, CELL, PHONE_TEXT, PHONE, OTHER_TYPE, OTHER` | `DB Model/Structure/ZHCM_S_EMPLOYEE_INFO.txt` |
| `cntr_formdetails` has `STATUS` | `FORM_STATUS` | `ZCA_FORMDETAIL` |
| `BACK` "releases the lock" | it only sets `IS_DIRTY` | `check_dirty` (P-02) |
| Search dialogs call AJAX `GET_ONBEHALF_ID` / `GET_AUTHBY_ID` on **search** | search = `AGENT_SEARCH` / `AUTH_BY_SEARCH`; `GET_*_ID` run on **confirm** | dispatcher + `agent_search` / `get_on_behalf_data` |
| `GET_COST_CENTER` AJAX object | `GET_COSTCENTER` | dispatcher |
| `NEW_INT_ORDER_W_ERR` AJAX object | `NEW_INTENALORDER_WEXP` (commented out) | dispatcher (P-04) |
| `AJAX 01_CREATE_INIT` | branch of `GET_DATA` | dispatcher has no `CREATE_INIT` |
| `06_GET_AUTHBY_ID.md` AJAX Name `SaveAsDraft` | name copied from SAVE in the spec; confirm in designer | duplicate of `03_SAVE.md` header |
| `ZMDG_ATT_REQ` has no `PROJECT_TYPE/PROJECT_SUBTYPE` (Rel. 750 printout) | both exist as **key** fields — **confirmed S4M S3-B0** | `visible_additional_field`, `validateAttachment`; live DDIC below |
| `ZMDG_PROJ_FORM` printout lacks `BRAND, LOCATION, CAPID, PROJECT_ID, PROJECT_SUBTYPE` | they exist, plus `RESP_LEAD_NAME` — **confirmed S4M S3-B0** | `create_project`, `populate_field_email`; live DDIC below |
| Spec "Fiori migration" code renames models (`pageProj`, `additionalCCode`, `oAppModel`) and functions (`_validateDate`, `_clearValue`) | keep Neptune names (`oPageProj`, `tabMultiCC`, `validate_date`, `clear_value`) | owner rule: no name changes |
| `MASTER_SCAFFOLD_SPEC.md` controller `zdci.nad.project.request.controller.Main` | `zdci_nad_project_request.controller.Main` | naming registry |

## Live DDIC in the target system — confirmed S3-B0 (S4M/100, 2026-10-18)

S4M = S/4HANA 2022: `SAP_BASIS` 757 SP02, `SAP_GWFND` 757 SP02, `SAP_UI` 757 SP03, `S4CORE` 107 SP02 (no separate `IW_BEP`).
Read via ADT MCP (`GetTable`/`GetStructure`/`GetDataElement`, DD03L/DD04L/DD40L). Only differences to `DB Model/` are listed; every
other printout (`ZCA_FORMDETAIL`, `ZCA_STEPDETAIL`, `ZCA_FORM*`, `ZCA_FLDGRP_FLDS`, `ZCA_APPRVR_*`, `ZMDGATTACH`, `ZMDGATTCATEGORY`,
`ZMDG_PRJ_CCODE`, `ZPS_*`, `ZTBRAND_T`, `ZTGEOGRAPHY_T`, `ZTRR_CC_*`, `ZZMDG_*`, `ZHCM_S_EMPLOYEE_INFO`, `ZMDG_S_PROJ_FLGRP_*`,
`ZMDG_S_NAD_ORDER_BUTTONS`, `ZCA_S_NAD_GL_*`, `ZCA_FORM_ATTACHMENT`) matches the live field list.

| Object | Field | Printout | Live (S4M) | Consequence |
|---|---|---|---|---|
| `ZMDG_PROJ_FORM` | `PROJECT_SUBTYPE` | — | `ZMDG_PROJ_SUBTYPE` NUMC 2 | new; RTTI picks it up; OData string with leading zero (`"01"`), same in `ZMDG_ATT_REQ` → JS filter compares like with like |
| `ZMDG_PROJ_FORM` | `BRAND` | — | `ZZBRAND` CHAR 5 | new; RTTI |
| `ZMDG_PROJ_FORM` | `CAPID` | — | `ZDE_CAPID` CHAR 25 | new; RTTI |
| `ZMDG_PROJ_FORM` | `LOCATION` | — | `STORT_T499S` CHAR 10 | new; RTTI |
| `ZMDG_PROJ_FORM` | `PROJECT_ID` | — | `PS_PSPID` CHAR 24 | new; RTTI |
| `ZMDG_PROJ_FORM` | `RESP_LEAD_NAME` | — | `TEXT100` CHAR 100 | new; not referenced by the class; RTTI |
| `ZMDG_PROJ_FORM` | `CAPEX_TI_AMOUNT` | `PROERLPLAN` CURR 15 | **does not exist** | not used by the class (0 refs). Stale entry in `07` DECIMAL list, `json-conversion-registry.json`, `JsonConversionRegistry.js`, `check_metadata.py` `DECIMALS` — harmless (absent field is skipped) — clean up in a later session (out of B0 scope) |
| `ZMDG_PROJ_FORM` | `PROJECTNAME` | `CHAR25` CHAR 25 | `TEXT40` CHAR 40 | matches UI `inpProjectName maxLength="40"` |
| `ZMDG_PROJ_FORM` | `PROJ_DESC`, `BUSS_JUSTIFY` | `CHAR1024` CHAR 1024 | `STRING` | Edm.String without MaxLength |
| `ZMDG_PROJ_FORM_S_READ_ONLY` | `R_IS_SOFTWARE_REQ, R_PROJECT_SUBTYPE, R_BRAND, R_CAPID, R_LOCATION, R_PERSON_RESPONSIBLE` | — | STRING | new; BOOL_TF by prefix rule in `07` (no change needed) |
| `ZMDG_PROJ_FORM_S_VISIBLE` | `V_INTERNAL_NO, V_IS_SOFTWARE_REQ, V_PROJECT_SUBTYPE, V_BRAND, V_CAPID, V_LOCATION, V_PERSON_RESPONSIBLE` | — | STRING | same |
| `ZMDG_PROJ_FORM_S_EDITABLE` | `E_INTERNAL_NO, E_IS_SOFTWARE_REQ, E_PROJECT_SUBTYPE, E_BRAND, E_CAPID, E_LOCATION, E_PERSON_RESPONSIBLE` | — | STRING | same. `*_PERSON_RESPONSIBLE` has no table field of that name (class fills `ZPS_PROJECT_UPDATE-PERSON_RESPONSIBLE` from `RESP_LEAD`) |
| `ZMDG_ATT_REQ` | `PROJECT_TYPE`, `PROJECT_SUBTYPE` | — | key, `ZMDG_PROJ_TYPE` CHAR 1 / `ZMDG_PROJ_SUBTYPE` NUMC 2 | new key fields; class does `SELECT *` → RTTI |
| `ZMDG_ATT_REQ` | `REQUIRED` | `ZMDGATTREQ` CHAR 1 | `DDBOOL_D` CHAR 1 | values still `'X'`/`''` → BOOL_X in `07` unchanged |
| `ZZDCI_PROJ` | `ZZPROJECT` (`ZZDEPROJECT`) | CHAR 10 | CHAR 24 | type via RTTI; no name change |
| FM `Z_MDG_CREATE_INTERNALORDER` | — | called 6× | **does not exist in S4M** | calls are only in `CREATE_INTERNAL_ORDER` / `CREATE_MULTI_INTERNAL_ORDER`, unreachable (callers commented out). ASSUMPTION: B1 activation gives at most a warning; runtime dump only if the path were reached |
| Shared `ZCL_ND_CA_UTILITIES` | `DEQUEUE_FORM` / `ENQUEUE_FORM` | — | uses `/NEPTUNE/` lock framework | licence blocker, see register R-32/R-33 |
