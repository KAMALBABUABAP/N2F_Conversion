# Neptune Model Registry — every client-side model, with its Fiori equivalent

## How Neptune models work (and how we mirror them)

In Neptune, every control that has a **Model Source** gets its own JSON model, exposed in JavaScript as
`model<ControlName>` (e.g. `modeloPageProj`, `modelcntr_formdetails`, `modeltabMultiCC`). Two controls with the
same Model Source (e.g. `diaReject` and `diaCreate`, both `WA_COMMENTS`) have **separate** model instances.
An AJAX parameter row is `Model (control) | Binding (ABAP attribute) | Send | Receive`.

Fiori mirror (exact, no renames):

| Neptune | Fiori freestyle |
|---|---|
| model of control `X` (JS `modelX`) | named `sap.ui.model.json.JSONModel` set on the view with name **`X`** |
| `modelX.oData.F` (read) | `this.model("X").getProperty("/F")` |
| `modelX.oData.F = v; modelX.refresh();` | `this.model("X").setProperty("/F", v)` |
| `modelX.oData.F = v;` **without** refresh | `this.model("X").getData().F = v;` + `// PARITY: no refresh` |
| `modelX.setData(d)` / `setProperty` / `updateBindings()` | same call on `this.model("X")` |
| binding `{ATTR-FIELD}` on a control | `{X>/FIELD}` where **X = nearest ancestor-or-self whose Model Source is ATTR** |
| table/list template binding `{GT_ATTR-FIELD}` | list `items="{X>/}"`, cell `{X>FIELD}` (X = the list/table control) |
| `ModelData.Find(X, ...)` / `Add` / `Delete` | `ModelData.Find(this.model("X"), ...)` via the `util/ModelData.js` shim (same API) |

`this.model(sName)` is a one-line helper in the controller: `return this.getView().getModel(sName);`

## Registry (from the AJAX `GET_AUTHBY_ID` parameter table + specs)

| Neptune control (= Fiori model name) | Control type | Model Source (ABAP attribute) | Initial data | Notes |
|---|---|---|---|---|
| `oPageProj` | sap.m.Page | `GS_PROJ_FORM` | `{}` | Main form model. JS: `modeloPageProj` |
| `subsectionComments` | ObjectPageSubSection | `GS_PROJ_FORM` | `{}` | Separate instance; binds `PREV_COMMENTS` |
| `diaDelDraft` | sap.m.Dialog | `GS_PROJ_FORM` | `{}` | Separate instance |
| `cntr_formdetails` | sap.m.FlexBox (data) | `GS_FORMDETAILS` | `{}` | "Do not add to view" data container |
| `cntr_stepdetails` | sap.m.FlexBox (data) | `GS_STEPDETAIL` | `{}` | data container |
| `UrlParameters` | sap.m.FlexBox (data) | `WA_URL_PARAMETERS` | `{FORM_GUID:"",MODE:"",PROJ:"",FROM:"",PROCESSING_REGION:"",COMPANY_CODE:""}` | JS: `modelUrlParameters` |
| `ProgramState` | sap.m.FlexBox (data) | `WA_PROGRAM_STATE` | `{}` | Real fields: `PROGRAM_STATE, PROGRAM_MESSAGE, INCORRECT_FIELD` (the `CAN_*` fields in `data_Structure_to_hold.md` are wrong guesses) |
| `CompanyCodes` | sap.m.List (data) | `GT_COMP_CODE` | `[]` | data container |
| `AttachmentCategories` | neptune.model.array | `GT_ATTACHMENT_CATEGORIES` | `[]` | used by FileUploader category select + `validateAttachment` |
| `AttachmentsRequired` | neptune.model.array | `GT_ATTACHMENTS_REQUIRED` | `[]` | used by `visible_additional_field`, `validateAttachment` |
| `vlAttributesBlock1` | VerticalLayout | `GS_FORMHEADER` | `{}` | header attrs; `FORM_GUID` used by `displayAttachment`, `toggleMode` |
| `vlAttributesBlock2` | VerticalLayout | `GS_FORMHEADER` | `{}` | header attrs |
| `listAttachments` | sap.m.List | `GT_ATTACHMENTS` | `[]` | |
| `sectionAttachments` | ObjectPageSection | `GS_ATTACHMENT` | `{}` | |
| `tabMultiCC` | sap.m.Table | `GT_ADDITIONAL_CCODE` | `[]` | spec files call it `DT_ADDITIONAL_CCODE` (OCR error) |
| `tabOrderdetails` | sap.m.Table | `GT_ORDERDETAILS` | `[]` | |
| `oTableApprovers` | sap.m.Table | `GT_APPR` | `[]` | |
| `oTableINITIA_GRP` | sap.m.Table (hidden data) | `GT_INITI_GROUP` | `[]` | read by `updateinitgrp()` |
| `listAgents` | sap.m.List | `GT_ZCA_AGENT_LIST` | `[]` | in `diaAgents` |
| `oFormEmployeeInfo` | SimpleForm | `GS_EMPLOYEE_INFO` | `{}` | in `diaEmployeeInfo` |
| `diaAddMultiCC` | sap.m.Dialog | `GS_MULTIPLECCODE` | `{}` | |
| `diaConfirmAttDelete` | sap.m.Dialog | `WA_CONFIRM_DELETE` | `{}` | `DELETE_INDEX` |
| `diaCreate` | sap.m.Dialog | `WA_COMMENTS` | `{}` | |
| `diaChange` | sap.m.Dialog | `WA_COMMENTS` | `{}` | |
| `diaSubmit` | sap.m.Dialog | `WA_COMMENTS` | `{}` | |
| `diaSubmitWthErr` | sap.m.Dialog | `WA_COMMENTS` | `{}` | |
| `diaReject` | sap.m.Dialog | `WA_COMMENTS` | `{}` | JS reads `modeldiaReject.oData.COMMENTS` |
| `diaClose` | sap.m.Dialog | `WA_COMMENTS` | `{}` | |
| `diaReSubmit` | sap.m.Dialog | `WA_COMMENTS` | `{}` | |
| `diaSearchAuthBy` | SelectDialog | `GT_AUTH_BY_LIST` | `[]` | |
| `diaSearchOnBehalf` | SelectDialog | `GT_AGENT_LIST` | `[]` | |
| `diaSearchCostCenter` | SelectDialog | `GT_KOSTL` | `[]` | |
| `diaSearchPrevProj` | SelectDialog | `GT_PREV_PROJCODE` | `[]` | spec missing |
| `diaGeography` | SelectDialog | `GT_GEOGRAPHYLIST` | `[]` | |
| `diaBrand` | SelectDialog | `GT_BRANDS` | `[]` | |
| `diaLocation` | SelectDialog | `GT_LOCATIONS` | `[]` | key field `LOCATION` |
| `oSelectProjType` | Select | `GT_REQUEST_TYPE` | `[]` | items key `VALUE`, text `TEXT` |
| `selProjectSubtype` | Select | `GT_PROJECT_SUBTYPE` | `[]` | |
| `oSelectExecCategory` | Select | `GT_EXEC_CATEGORY` | `[]` | |
| `oSelectInitPrd_Grp` | Select | `GT_INITI_GRP` | `[]` | items rebuilt in code by `updateinitgrp()` |
| `oSelectAssetClass` | Select | `GT_ASSET_CLASS` | `[]` | |
| `oSelectITLAssetClass` | Select | `GT_ITL_ASSET_CLASS` | `[]` | |
| `oSelectCAPCURR` | Select | `GT_CURRENCY` | `[]` | |
| `oSelectITLCURR` | Select | `GT_CURRENCY` | `[]` | |
| `oSelectCompCode` | Select | `GT_COMP_CODE` | `[]` | Value field `VALUE`, label `TEXT`, cached |
| `oSelectMultiCCode` | Select | `GT_ADD_COMP_CCODE` | `[]` | |
| `oSelectOrderType` | Select | `GT_ORDER_TYPE` | `[]` | |
| `oSelectPrevPCode` | Select | `GT_PREV_PROJCODE` | `[]` | |
| `oSelectUSState` | Select | `GT_USSTATE` | `[]` | |
| `sysMessage` | Neptune built-in | `GT_SYS_MESSAGE` | `[]` | filled by `api_message_create`; JS `modelsysMessage`; shown by `diaMessages` |

### Select controls with a Model Source

The Select's own model feeds only its **items** (`items="{oSelectCompCode>/}"`, `key="{oSelectCompCode>VALUE}"`,
`text="{oSelectCompCode>TEXT}"`). Its `selectedKey` binds to the form model by the attribute rule
(e.g. `selectedKey="{oPageProj>/COMPANY_CODE}"`).

## Neptune text controls → i18n (same names)

Neptune keeps translatable strings in hidden `sap.m.Text` controls and reads them with `txtX.getText()`.
In Fiori they become i18n keys with **identical names**: `txtX.getText()` → `this.i18n("txtX")`.

| Key | Used by | Value (export Translate folder, S2a) |
|---|---|---|
| `txtSaveDraft` | SAVE, GET_AUTHBY_ID success | Your new Project Code Request was saved as a draft |
| `txtTranslateESaveAsDraft` | SAVE, GET_AUTHBY_ID error | Error in Save as Draft |
| `txtDeleteDraft` | DELETE success | Your Project Code Request draft was deleted |
| `txtConnectionFailure` | many ajaxError handlers | Unable to connect to SAP. Please check your network connection, and contact your IT department if the problem persists. |
| `txtFinalApproval` | SUBMIT success (when `PROJ_FLGRP_0004`) | Project Code Request form is complete |
| `txtTranslateChange` | CHANGE success | Project code request - Changes submitted Successfully |
| `txtRejected` | REJECT success | Project Code Request - Rejected and sent back to Budget Manager |
| `txtTranslateWithdrawn` | CLOSE success | New Project code request is withdrawn successfully |
| `txtTranslateResubmit` | RESUBMIT success | Project code request - Resubmited Successfully (typo kept) |
| `txtTranslateCreate` | CREATE success | Project code request - Created Successfully |
| `txtSubmit` | — (not used) | The new project code request was submitted successfully |
| `txtTranslateHeader` | — (not used) | Create new project code request |
| `txtTranslateTxtEdit` | — (not used) | Edit |
| `txtTranslateUpdated` | — (not used) | Data updated |
| `txtTranslateButCreate` | — (not used) | Create |
| `txtTranslateButSave` | — (not used) | Save |
| `txtTranslateMsgErrorUpdate` | — (not used) | Error retrieving data from server. Please try again |
| `txtTranslateMsgErrorCreate` | — (not used) | Error Creating new Dimension Request (wording from another app, kept) |
| `txtTranslateMsgConnError` | — (not used) | Connection Error |

Literal (non-i18n) strings in Neptune code stay literal — e.g. `"Project Code Request form approved Successfully"`,
`"Comments are Required on Reject"`, `"Select 'YES' to acknowledge before you submit the form"`. Copy them verbatim.

## Global JS variables (from `Global Script.txt` / `Init.txt`)

| Neptune global | Fiori |
|---|---|
| `dc` (`discoveryFiori.ChildComponent`) | `this.dc` (shim) |
| `dirty` (`discoveryFiori.DirtyHandler`) | `this.dirty` (shim) |
| `fu` (`discoveryFiori.FileUploader`) | `this.fu` (shim) |
| `listRef`, `listIndex` | `this.listRef`, `this.listIndex` (set by the parent list app; see parity log) |
| `userField` | `this.userField` |
| `isDirty`, `hasParent`, `fc` | `this.isDirty`, `this.hasParent`, `this.fc` |
| control globals (`oApp`, `oplForm`, `rbITLYes`, …) | `this.byId("oApp")`, … (same IDs) |
