# JSON Conversion Registry — emulating the Neptune serializer in the UI client

The OData layer carries ABAP values unchanged (`'true'`, `'false'`, `'X'`, `''`, `'20250101'`, decimals as
strings). Neptune's runtime converted some of them to JSON types before the JavaScript saw them — the JS
code proves it:

| Evidence in Neptune JS | Conclusion |
|---|---|
| `if (modeloPageProj.oData.PROJ_FLGRP_0003)` / `if (!...PROJ_FLGRP_0004)` / `if (modeloPageProj.oData.RESUBMIT)` | `'true'/'false'` strings arrived as JSON booleans (a `"false"` string would be truthy) |
| `btnAddAttachment.setVisible(modeloPageProj.oData.CAN_ATTACH)` | `CAN_ATTACH` (`'X'`/`''`, DDBOOL_D) arrived as a boolean |
| `ModelData.Find(AttachmentsRequired, [...,"REQUIRED"], [...,true])` | `ZMDG_ATT_REQ-REQUIRED` (`'X'`) arrived as `true` |
| `visible="{GS_PROJ_FORM-V_KOSTL}"`, `required="{...R_*}"`, `enabled="{...PROJ_FLGRP_0001}"` | flag strings bound to boolean properties |
| `DatePicker valueFormat="yyyyMMdd"` | dates arrived as `yyyyMMdd` strings |

The UI client (`AjaxRuntime.js`) applies this registry on **receive** (ABAP → JSON) and reverses it on
**send** (JSON → ABAP). Machine-readable copy: `neptune-to-ui5-frontend/assets/webapp/util/JsonConversionRegistry.js`
— keep both in sync. Every entry below is **INF** until confirmed by the capture report (`06`).

## BOOL_TF — ABAP `'true'` / `'false'` ⇄ JSON `true` / `false`

| Attribute | Fields |
|---|---|
| `GS_PROJ_FORM` | every field starting `V_`, `R_`, `E_`; `PROJ_FLGRP_0001`…`PROJ_FLGRP_0005`; buttons `CREATE, CHANGE, SAVE, SUBMITWTH_ERR, DELETE, SUBMIT, REJECT, WITHDRAWN, RESUBMIT`; `NAVIGATION_VISIBLE, ATTRIBUTES_VISIBLE, MODE_BUTTON_VISIBLE`; `REPLACE_EXIT_PRJ, FPA_APPROVAL, RTR_APPROVAL, BPC_APPROVAL` |
| `GT_ADDITIONAL_CCODE`, `GS_MULTIPLECCODE` | `DELETABLE`, `PROJ_FLGRP_0001`…`PROJ_FLGRP_0005`, `IS_ERROR` |
| `GT_ORDERDETAILS` | `IS_ERROR` |

Receive: `'true'` → `true`; anything else (`'false'`, `''`) → `false`. Send: `true` → `'true'`, `false` → `'false'`.

## BOOL_X — ABAP `'X'` / `''` ⇄ JSON `true` / `false`

| Attribute | Fields |
|---|---|
| `GS_PROJ_FORM` | `CAN_ATTACH` |
| `GT_ATTACHMENTS_REQUIRED` | `REQUIRED` |

Receive: `'X'` → `true`, else `false`. Send: `true` → `'X'`, `false` → `''`.

**Not converted** (stay strings): `PROJ_FLGRP_000x_MOD` (`'Expanded'`/`'Collapsed'`), `IS_DIRTY` (`'X'` in a
STRING, never read by JS), `ITL`/`CLS`/`CAPEX_TI`/`CAPEX_TI_AMT_INC`/`IS_SOFTWARE_REQ` (`'Y'`/`'N'`),
`REQUEST_FROM`, `DISPLAY_OR_EDIT`, `STATUS` icons, all `WA_PROGRAM_STATE` fields.

## DATE / TIME — initial value ⇄ empty string

| Attribute | DATS fields (`'00000000'` → `""`) | TIMS fields (`'000000'` → `""`) |
|---|---|---|
| `GS_PROJ_FORM` | `AUTH_BY_DATE, ORDER_DATE, PROJ_COMPLETION_DATE` | — |
| `GS_FORMDETAILS` | `START_DATE, LATEST_STARTDATE, FIRST_REM_DATE, NEXT_REM_DATE, DEADLINE_DATE` | `START_TIME, LATEST_STARTTIME` |
| `GS_STEPDETAIL` | `COMPLETION_DATE, ON_HOLD_SINCE_DATE` | `COMPLETION_TIME, ON_HOLD_SINCE_TIME` |

Send: `""` stays `""` (ABAP moves it to the initial value). Non-initial values pass through unchanged.

## DECIMAL — OData string ⇄ JSON number

| Attribute | Fields |
|---|---|
| `GS_PROJ_FORM` | `CAPEX_REQ_AMOUNT, ITL_REQ_AMOUNT, CAPEX_TI_AMOUNT` |

Receive: `"1000.00"` → `1000`. Send: number or numeric string → `String(Number(v) || 0)` (Edm.Decimal must be a
JSON string in OData V2).

## Always

- Receive: unwrap `{ results: [...] }`, delete `__metadata`, `__deferred` and `ROW_INDEX`.
- Send: every row gets `ROW_INDEX` = 1..n; every complex property is an object with **all** its fields
  (start from the last received copy so no field is lost); every navigation property is an array.
