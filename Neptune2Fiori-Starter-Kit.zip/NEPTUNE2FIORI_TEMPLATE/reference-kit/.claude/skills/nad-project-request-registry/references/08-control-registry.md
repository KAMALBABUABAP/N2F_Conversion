# Control Registry — every Neptune control ID (reuse verbatim as Fiori `id`)

Order = Neptune render order (`Master_Control_Tree.md`). "Spec" = where the full attribute/event detail lives.
**MISSING** = control is known by ID but its attributes/bindings/events must be captured (see `06`).

## Shell and page

| ID | Type | Spec |
|---|---|---|
| `oShell` | sap.m.Shell (`appWidthLimited=false`) | export 00003 — omit in FLP (launchpad provides the shell); standalone `index.html` only |
| `oApp` | sap.m.App | export 00282 — no properties; `setBusyIndicatorDelay(0)` in `onInit` (Init script) |
| `oBusyIndicator` | BusyIndicator (`text="Saving As Draft..."`, `visible=false`) | export 00880 — not rendered: `oApp.setBusy()` (binding-rules §7); only a commented line references it |
| `oPageProj` | sap.m.Page (model `oPageProj`) | export 00505 — no properties (default `showHeader`/`enableScrolling`) |
| `headerPageProj` | sap.m.Bar (customHeader) | export 00506 |
| `btnNavBack` | sap.m.Button `icon=sap-icon://nav-back` | export 00716 — visibility set in code (`onInit` / `loadRequest`) |
| `titlePagePCreate` | sap.m.Text | export 00633 — `text={GS_PROJ_FORM-PAGE_HEADER}` |
| `oplForm` | sap.uxap.ObjectPageLayout | export 00507 (`alwaysShowContentHeader`, `styleClass="opl-two-column"`, `subSectionLayout="TitleOnLeft"`, `useTwoColumnsForLargeScreen`) |
| `ophProj` | sap.uxap.ObjectPageHeader | export 00762 (`objectTitle={GS_PROJ_FORM-PROJECTNAME}`, `objectImageShape=Circle`, `objectImageURI=sap-icon://dimension`, `isObjectIconAlwaysVisible`) |
| `btnPrevOrder`, `btnToggleEdit`, `btnNextOrder` | ObjectPageHeaderActionButton | export 01179/01181/01180 — all `visible={GS_PROJ_FORM-NAVIGATION_VISIBLE}`; texts `Previous Order` / `Edit` / none |
| `hcAttributes` | aggregation node, no runtime control | export 00776 — the designer's `headerContent` node of `oplForm`; its children sit directly in `<uxap:headerContent>` |
| `vlAttributesBlock1` (`oObjectEmpName`, `attrStartDate`) | VerticalLayout / ObjectAttribute, ObjectStatus (model `vlAttributesBlock1`) | export 00777 — `Budget Manager` = `INITIATED_BY`; `Requested at` = `START_DATE,START_TIME` + formatter `attrStartDate_text` |
| `vlAttributesBlock2` (`attrCurrentStep`, `oObjectAgent`) | VerticalLayout / ObjectStatus, ObjectAttribute (model `vlAttributesBlock2`) | export 00780 — `Current step` = `CURRENT_STEP`; `Current Agent` = `CURRENT_AGENT` |

## sectionProj — "Project Details" (`styleClass="sfactor-block"`)

**Layout parity 2026-10-20 (`docs/layout-parity.md` L-01…L-04):** `RequesterBlock`, `ProjDetailBlock`, `ProjMultiCCode`,
`oObjectPageSubSectionFPA`, `oObjectPageSubSectionRTR`, `oObjectPageSubSectionBPC`, `attachBlock1`, `approvalBlock1`, `CommentsBlock`
are export `UM5_OPSUBC` with `position=MoreBlock` = no runtime control (like `hcAttributes`); their forms/lists go directly into
`uxap:moreBlocks` (one block each → two columns). Ids kept as one-line comments in the view.

| ID | Type | Spec |
|---|---|---|
| `subsectionRequester` → `RequesterBlock` (`moreBlocks`) | SubSection | export 00729/00730 |
| `sfBudgetManagerBlock1`: `lblQProcessingRegion`, `rbgQProcessingRegion` (`rbUsLa`, `rbEurope`, `rbAsia`, `groupName=rbgProc`), `lblQReqName`, `inpQReqName`, `lblOnBehalf`, `oHBoxOnBehalf` (`inpOnBehalfOf`, `CbtnOnBehalfClr`) | SimpleForm | export 00932–01028 — edit group `PROJ_FLGRP_0005` (region, on-behalf, clear); `inpOnBehalfOf` value `ONBEHALF_ID` + description `ONBEHALF_NAME`; `lblQProcessingRegion.required` P-55 |
| `sfBudgetManagerBlock2`: `lblPersonResponsible`, `inpPersonResponsible`, `oHBoxAuthBy` (`inpAuthBy`, `CbtnAuthbyClr` DISABLED → not rendered, P-56), `lblAuthDate`, `dpAuthDate` | SimpleForm | export 01024–01200 — `inpPersonResponsible` `PROJ_FLGRP_0005`, description `RESP_LEAD_NAME`; `oHBoxAuthBy.visible = V_AUTH_BY_ID`; `dpAuthDate.displayFormat` P-57 |
| `subsectionProjdetail` "Project Details" → `ProjDetailBlock` (`moreBlocks`) | SubSection | export 00946/00947 |
| `sfBudgetProj`: `lblQProjName`, `inpProjectName`, `lblProjDesc`, `oTxtProjDesc`, `lblBussJust`, `oTxtProjBussJust`, `lblProjectType`, `oSelectProjType`, `oLblTIFundReq`, `rbTIFunds` (`rbTI_Fund_Yes`, `rbTI_Fund_No`), `oLblTIAmtReq`, `rbTIAmount` (`rbTI_Amount_Yes`, `rbTI_Amount_No`), `lblProjectSubtype`, `selProjectSubtype`, `oLblSoftwareReq`, `rbSoftwareReq` (`rbSoftwareYes`, `rbSoftwareNo`), `oLblITL`, `rbITL` (`rbITLYes`, `rbITLNo`), `oLblCLS`, `rbCLS` (`rbCLSYes`, `rbCLSNo`), `lblPrvProjCode`, `oSelectPrevPCode`, `oLblCAPEX_AMOUNT`, `inpCAPEX_Amount`, `oLblCAPEX_CURR`, `oSelectCAPCURR`, `oLblITL_AMOUNT`, `inpITL_Amount`, `oLblITL_CURR`, `oSelectITLCURR` | SimpleForm | export 00948–01051 — radio buttons `editable = PROJ_FLGRP_0001` (only `rbITL` group has `enabled`); `oTxtProjDesc` uses `editable`; `oSelectPrevPCode`, `inpITL_Amount`, `oSelectITLCURR` `visible=false`; `V_IS_SOFTWARE_REQ`; P-58, P-59 |
| `sfBudgetProj2` (only `editable=true`, default layout): `lblCompanyCode`, `oSelectCompCode`, `lblCostCenter`, `inpCostCenter`, `lblLocation`, `inpLocation`, `oSelectUSState` (DISABLED → not rendered, P-56), `lblBrand`, `inpBrand`, `lblGeography`, `inpGeography`, `lblCapNumber` "Planning ID", `inpCapNumber`, `lblWorkOrderDate`, `dporderdate`, `lblCompletionDt`, `dpOrderCompDate`, `lblFPAApprovalAtt`, `vbFPAApprovalAtt` (`btnFPAApprovalAtt`) | SimpleForm | export 01023–01243 — dates P-57 |
| `subsectionProjAttDownload` → `sfProjAttDownload`: `lblAttCAPEXLicenses`, `vbAttCAPEXLicenses` (`lnkAttCAPEXLicenseDownload`, `btnAttCAPEXLicenseUpload`), `lblAttSoftwareLicense`, `vbAttSoftwareLicense` (`btnAttSoftwareLicenseUpload`), `lblAttAccounting`, `vbAttAccounting` (`lnkAttAccountingDownload`, `btnAttAccountingUpload`) | SubSection | export 01222–01235 — hrefs `Templates/CAPEX%20Licenses%20Questionnaire.xlsx`, `Templates/Accounting%20Questionnaire.xlsx` (R-23/R-24, P-33) |
| `subsectionProjMultiCC` (`mode = PROJ_FLGRP_0005_MOD`) → `ProjMultiCCode` → `sfBudgetCCode` → `tabMultiCC` (`boxy-border`; `tbTabMultiCCData`, `tbSpacerCCode`, `btnAddCompCode` P-23; columns `colStatusICON, colCRegion, colCCompCode, colCCompCode_Text, colCostCenterCode, colCostCenterText, colCDelete`; item `listItemMultiCCode`: `oFormStatusIcon, txtCMultiCRegion, txtCMultiCCode` (`COMP_CODE`), `txtCMultiCCode_Text, txtCMultiCostCenter, txtCMultiCCenter_Text, btnDeleteCCode`) | SubSection | export 01132–01161 |

## sectionApproval — "Workflow"

| ID | Type | Spec |
|---|---|---|
| `subsectionFPA` → `oObjectPageSubSectionFPA` (`moreBlocks`) → `sfFPAAppr` (default layout): `lblExec_Category` "Executive Category", `oSelectExecCategory`, `lblInit_Group` "Initiative/Product", `oSelectInitPrd_Grp`, `oSelectInit_Group` (DISABLED → not rendered, P-56), `oLblFPAAppr`, `oSwitchFPAAppr` | SubSection | export 00964–01203 |
| `subsectionRTR` → `oObjectPageSubSectionRTR` (`moreBlocks`) → `sfRTRAppr` (`labelSpanM=4`): `lblOrderType`, `oSelectOrderType`, `lblAssetClass`, `oSelectAssetClass`, `lblITLAssetClass`, `oSelectITLAssetClass` (three selects `visible=false`, P-60), `oLblRTRAppr`, `oSwitchRTRAppr`; `sfRTROrderTbl`: `lblProjectID`, `txtProjectID` (formatter `txtProjectID_text`), `tabOrderdetails` (`visible=false`, P-60; columns `colCompanyCode, colCostCenterCode1, colCProjCode, colCInternalCode, colCErrorDesc`; item `listItems`; cells `txtCompCode, txtCostCenterCode, txtCProjCode, txtCInternalID, txtCProjName`) | SubSection | export 00991–01239 |
| `subsectionBPC` (`visible=false`, P-60) → `oObjectPageSubSectionBPC` (`moreBlocks`) → `sfBPCAppr`: `oLblBPCAppr`, `oSwitchBPCAppr`; `oLblProjCode`, `inpProjCode`, `oLblInternalOrder`, `inpOnInternalNo` DISABLED → not rendered (P-56) | SubSection | export 01055–01096 |

## sectionAttachments, sectionApprovals, sectionComments

| ID | Type | Spec |
|---|---|---|
| `sectionAttachments` (model `sectionAttachments`; no `titleUppercase`) → `subsectionAttachments` "Attachments" → `attachBlock1` (`moreBlocks`) → `listAttachments` (`tbListAttachments`, `tbSpacerAttachments`, `btnAddAttachment`, item `listItemAttachment`) | Section | export 00814–00821 |
| `sectionApprovals` → `subsectionApprovals` ("Approvals", `Expanded`) → `approvalBlock1` (`moreBlocks`) → `oTableApprovers` (columns `coloDTableApproversSTEPS` "Approval Steps", `coloDTableApproversSTATUS_ICON` "Status", `coloTableApproversSTEP_STATUS` "Text", `coloDTableApproversSTATUS_DATE` "Date", `coloDTableApproversAPPRNAME` "Approver Name"; item `colItemDTableApprovers`; cells `txtDTableApproversSTEPS, oDIconStatus, txtoTableApproversSTEP_STATUS, txtDTableApproversSTATUS_DATE` (formatter `txtDTableApproversSTATUS_DATE_text`), `txtDTableApproversAPPROVERNAME`) | Section | export 00541–00476 — column ids in export spelling; `Master_Control_Tree.md` has the old `colD…`/`coloDTableApproversSTEP_STATUS` spelling (export wins, registry 09) |
| `sectionComments` → `subsectionComments` (model `subsectionComments`) → `CommentsBlock` → `oTextAreaPrevComments` | Section | `UI_sectionComments.md` |

## Footer and data containers

| ID | Type | Spec |
|---|---|---|
| `footerPageCCreate`: `butSave, butDelete, butCreate, butChange, butSubmitWthErr, butSubmit, butReject, butClose, butResubmit` | sap.m.Bar | export 00634–00923 — `butDelete` "Delete", `butCreate` icon `sap-icon://create`, `butReject` `type=Reject`; `butSubmitWthErr.visible` is `SUBMITWTH_ERR` (spec typo `SUBMITWITH_ERR`) |
| `cntr_formdetails`, `cntr_stepdetails`, `UrlParameters`, `ProgramState`, `CompanyCodes`, `AttachmentCategories`, `AttachmentsRequired`, `oTableINITIA_GRP` | data-only | JSON models only — not rendered |
| hidden text controls `txtSaveDraft` … | sap.m.Text | i18n keys (`03`) |

## Dialogs (`oPageDialogs`) — declare as XML fragments, IDs unchanged

| Dialog | Children | Spec |
|---|---|---|
| `diaAddMultiCC` | `sfAddMultiCCodes` (`columnsL=1`), `lblMultiCCode`, `oSelectMultiCCode`, `lblMultiCostCenter`, `inpMultiCostCenter`; **begin = `btnAddMultiCCCancel`, end = `btnAddMultiCCOK`** | export 01144–01157 — `contentWidth=500px`, edit flag `PROJ_FLGRP_0005`; `inpMultiCostCenter.visible` P-55 |
| `diaSearchPrevProj` | `listPrev_ProjCode` | export 01042 — **DISABLED → not rendered** (fragment removed, P-56); model `diaSearchPrevProj` kept |
| `diaReSubmit` | `oTextAreaReSubmit` (`rows=8 cols=100`), `butReSubmitSave`, `butReSubmitCancel` | export 00924–00927 |
| `diaAgents` ("Possible Agents", `class=false`) | `listAgents` (`noDataText`), `listItemAgent`, `btnAgentsClose`; `butAgentOK` is `oPageDialogs` content without association (in `<dependents>`, never shown, P-46) | export 00844–00847, 00668 |
| `diaConfirmAttDelete` ("Delete Confirmation") | `txtConfirmAttDelete`, `btnAttDeleteYes`, `btnAttDeleteNo` | export 00825–00828 |
| `diaAddAttachment` | `oFileUploader` (no properties), `diaAddAttachmentClose` (+ category select from `discoveryFiori.FileUploader`) | export 00822–00824 |
| `diaEmployeeInfo` (ResponsivePopover) | `oFormEmployeeInfo`; labels `lbloFormEmployeeInfo<FIELD>` (literal texts `Personnel Number`, `Name`, `Email ID`, `Cell No`, `Phone No`, `Other`) / texts `txtoFormEmployeeInfo<FIELD>` for `PERNR, ENAME, EMAIL, CELL, OTHER`; `oEmpPhone` Link `text=PHONE_TEXT`, `href=PHONE` (P-49) | export 00785–00861 |
| `diaReject` | `oTextAreaReject` (`rows=8 cols=100`), `butRejectOK` (`type=Reject`), `butRejectCancel` | export 00802–00805 |
| `diaTimeout` | `oTextAreaTimeout` ("Your Session has Timed Out. …"), `butTimeoutClose` | export 00114/00115/00132 |
| `diaCreate` ("Confirmation to create new project request") | `oTextAreaCreate`, `butCreateSave` (Accept), `butCreateCancel` | export 00116–00118, 00813 — all comment dialogs: 500×200px, draggable, no vertical scrolling, TextArea `rows=8 cols=100` |
| `diaChange` ("Confirmation to change existing order") | `oTextAreaChg`, `butChgSave` (Accept), `butChgCancel` | export 01183–01186 |
| `diaSubmit` ("Submit Confirmation") | `oTextAreaSubmit`, `butSubmitSave` (Accept), `butSubmitCancel` (Transparent) | export 00119–00121, 00848 |
| `diaSubmitWthErr` ("Submit Confirmation") | `oTextAreaSubmitWthErr`, `butSubWthErrSave` (Accept), `butSubWthErrCancel` (Transparent) | export 01172–01175 |
| `diaDelDraft` ("Confirm Deletion", 150×50px) | **`oDDraftText`** (export spelling; kit `sDDraftText` renamed S2a), `butDDraft`, `butDDraftCancel` | export 00123–00126 |
| `diaClose` ("Confirm Withdraw") | `oTextAreaCancel`, `butCloseSubmit`, `butCloseCancel` | export 00127–00134 (P-11) |
| `diaMessage` ("System Message") | `sysMessage` (`UM5_MESSAG` → List, P-61), `butMessageClose` ("Close"); `btnMessageClose` is `oPageDialogs` content without association (in `<dependents>`, never shown, P-46) | export 00130/00131/00135, 01082 |
| `diaMessages` | — | **not a control** (export has only `diaMessage`); referenced by the SUBMIT handler — call guarded, P-36 |
| `diaSearchAuthBy` ("Authorized By(require VP or above authorization)") | `listAuthBy_Person` (title P-55) | export 01191/01192 — reachable only from DISABLED `inpAuthBy` (P-56) |
| `diaSearchOnBehalf` ("Search for an Employee") | **`listOnBehalf_Person`** (export spelling; kit `lstOnBehalf_Person` renamed S2a) | export 01029/01030 |
| `diaSearchCostCenter` ("Cost Center Selection") | `listCostCenter` | export 01119/01120 |
| `diaGeography` ("Geography", `growing=false`) | `listItemGeography` (`title=TEXT`, `info=VALUE`) | export 01215/01218 |
| `diaBrand` ("Brands", `growing=false`) | `listItemBrand` (`title=TEXT`, `info=VALUE`) | export 01216/01219 |
| `diaLocation` ("Locations", `growing=false`) | `listItemLocation` (`title=TEXT`, `info=LOCATION`) | export 01217/01220 |

ID conflicts resolved S2a from the export (registry 09): `oDDraftText` (not `sDDraftText`), `oSelectMultiCCode` (not `oSelectMultiCCCode`), `diaMessage` (`diaMessages` is not a control, P-36), `listOnBehalf_Person`, approvals columns `coloDTableApproversSTEPS`, `coloDTableApproversSTATUS_ICON`, `coloTableApproversSTEP_STATUS`.
