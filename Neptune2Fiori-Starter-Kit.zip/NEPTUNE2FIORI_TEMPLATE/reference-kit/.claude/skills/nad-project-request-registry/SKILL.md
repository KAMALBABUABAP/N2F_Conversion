---
name: nad-project-request-registry
description: Authoritative names, AJAX inventory, model/control registries and parity log for converting the Neptune app ZDCI_NAD_PROJECT_REQUEST to SEGW + freestyle SAPUI5. Load before any backend or frontend conversion step, any naming decision, or any question about what the Neptune app does.
---

# ZDCI_NAD_PROJECT_REQUEST — conversion registry

Shared reference data for the two working skills:
- `neptune-to-segw-backend` — ABAP class copy, SEGW model, MPC_EXT/DPC_EXT.
- `neptune-to-ui5-frontend` — freestyle SAPUI5 app in BSP `ZUI_PROJREQCODE`.

## The three rules that override everything

1. **No name changes.** Every Neptune name (ABAP members, AJAX IDs, DDIC, control IDs, model names, JS
   function names, texts) is reused exactly. The only new names are listed in
   `references/01-naming-registry.md`. Anything else new → stop and ask the user.
2. **Parity first.** Behaviour must match Neptune, including its bugs. Known quirks are in
   `references/05-parity-log.md`; mark each in code with `PARITY P-xx`.
3. **Evidence before code.** Use the source order in `references/09-source-of-truth.md`. Rows marked
   **INF** in `references/04-ajax-dispatch-inventory.md` must be confirmed by a capture
   (`references/06-capture-neptune-payloads.md`) before the UI is signed off.

## What to read for which task

| Task | Read |
|---|---|
| Naming anything | `01-naming-registry.md` |
| OData model, envelope, Edm types | `02-envelope-and-odata-names.md` |
| UI models, bindings, texts, globals | `03-neptune-model-registry.md` |
| What each AJAX call sends, receives, does | `04-ajax-dispatch-inventory.md` |
| A behaviour that looks like a bug | `05-parity-log.md` |
| Confirming INF rows / missing specs | `06-capture-neptune-payloads.md` + `scripts/parse_neptune_har.py` |
| Booleans, dates, decimals between ABAP and JS | `07-json-conversion-registry.md` |
| Control IDs and which spec covers them | `08-control-registry.md` |
| Two documents disagree | `09-source-of-truth.md` |

## Neptune source files (copied to `docs/neptune-source/` in this project folder)

- `docs/neptune-source/Backend Class/ProjectRequest App.txt` — class `ZCL_NAD_PROJECT_CODE_REQUEST` (6,012 lines)
- `docs/neptune-source/Ajax/*.md` — AJAX objects; `DB Model/` — DDIC printouts
- `docs/neptune-source/` `Init.txt`, `Global Script.txt`, `Utility.txt`, `form.txt` — Neptune JavaScript
- `MASTER_SCAFFOLD_SPEC.md`, `Master_Control_Tree.md`, `data_Structure_to_hold.md`, `UI_*.md`, `dia*.md`,
  `subsection*_SPEC.md` — UI specs (PDF-derived; see known errors in `09`)

When a registry entry is confirmed or corrected, update the registry file in the same change and say so
in the commit message. Registries are the project's memory; keep them true.
