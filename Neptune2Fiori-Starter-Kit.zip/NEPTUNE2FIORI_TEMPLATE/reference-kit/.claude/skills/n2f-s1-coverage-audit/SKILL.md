---
name: n2f-s1-coverage-audit
description: S1 — compare the Neptune XML export with the kit and write docs/coverage-report.md (read-only)
argument-hint: File name of the Neptune XML export in docs/neptune-export/
disable-model-invocation: true
---

Work as the custom agent `neptune-parity-reviewer` (`.claude/agents/neptune-parity-reviewer.md`; best: start this session with `claude --agent neptune-parity-reviewer`): follow its rules.

Session S1 (coverage audit). Use the registry skill. Do not change code in this session; the only file you write is `docs/coverage-report.md`.

1. Write a small Python script (in `docs/capture/parse_export.py`) that parses the Neptune XML export `docs/neptune-export/<exportFile, taken from the text after the command>` — do not read the whole XML by hand. First print the XML's top-level structure so we agree how controls, attributes, events, AJAX objects and scripts are stored.
2. Extract: every control (id, type, parent, Model Source, attributes with bindings), every event script (control, event, code), every AJAX object (name, ID, send/receive parameter table, ajaxSuccess/ajaxError code), every global/init/utility script function, every text control.
3. Compare with the kit and write `docs/coverage-report.md` with one table per area: Neptune item | kit item | status (`same` / `different` / `missing in kit` / `extra in kit`) | evidence:
   - control ids vs `src/ui5/zdci_nad_project_request/webapp/view/**`
   - attributes/bindings vs the view
   - event scripts vs controller methods (`<controlId>_<event>`)
   - AJAX objects vs `webapp/util/AjaxConfig.js` (send/receive/fn name) and registry `04`
   - script functions vs controller methods
   - text controls vs `i18n/i18n.properties`
4. Add a section "Answers to open items": for every `TODO(SPEC-MISSING)`, `TODO(CAPTURE)`, `INF` row and `SHIM-RECONSTRUCTED` marker, quote what the XML says (or "not in export").
5. End with counts per status and the top 10 blockers.

**Replacement log (licence removal):** names that start with or contain `NEPTUNE` (or use `/NEPTUNE/`) must not appear in anything the new solution uses in SAP. Log every one you find in `docs/replacements/S1-replacements.txt` (format and rules: `docs/replacements/framework-replacement-register.md`; write `RESULT: none found` if none) and add rows to the register. Read-only session: propose replacements, do not apply them.
