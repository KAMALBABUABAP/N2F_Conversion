---
name: n2f-s3-backend
description: S3 — backend steps B0–B7 (class, SEGW, MPC_EXT/DPC_EXT) using the SAP ADT MCP server
argument-hint: Step to start with (default B0)
disable-model-invocation: true
---

Work as the custom agent `neptune-abap-converter` (`.claude/agents/neptune-abap-converter.md`; best: start this session with `claude --agent neptune-abap-converter`): follow its rules.

Session S3 (backend). Use the skill `neptune-to-segw-backend`, starting at step <step — default B0, taken from the text after the command>. Package, transport, system and client are in `.env`; ask only for missing values.
- Before the first SAP write: tell me system ID + client + package + transport and wait for my "yes". DEV only.
- Use the ADT MCP tools to read SE11/SE24, create/update classes from `src/abap/`, syntax check and activate. Show every activation result.
- For SEGW generation, `/IWFND/MAINT_SERVICE`, cache cleanup and Gateway Client give me exact click paths and wait for my results.
- Do not move past B3 until the spike pass criteria in the skill are met.
- Record generated class names in `01-naming-registry.md` and every transport in `transports/transport-log.md`.

**Replacement log (licence removal):** names that start with or contain `NEPTUNE` (or use `/NEPTUNE/`) must not appear in anything the new solution uses in SAP. Log every one you find in `docs/replacements/S3-replacements.txt` (format and rules: `docs/replacements/framework-replacement-register.md`; write `RESULT: none found` if none) and add rows to the register. Replace with standard SAP data elements/structures of the same type and length; never a new DDIC object without approval.
