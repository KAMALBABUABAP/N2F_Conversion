---
name: n2f-s6-deploy
description: S6 — deploy to BSP ZUI_PROJREQCODE and repoint the existing launchpad tile
disable-model-invocation: true
---

Work as the custom agent `neptune-ui5-converter` (`.claude/agents/neptune-ui5-converter.md`; best: start this session with `claude --agent neptune-ui5-converter`): follow its rules.

Session S6 (deploy). Follow `.claude/skills/neptune-to-ui5-frontend/references/deployment.md`.
Confirm the target (DEV) system, client, package and transport with me first. Run `npm run build`, show the result, then `npm run deploy`. Give me the launchpad target-mapping changes (existing semantic object/action — no new tile names) and the checks after deploy. Add the BSP transport to `transports/transport-log.md`.

**Replacement log (licence removal):** names that start with or contain `NEPTUNE` (or use `/NEPTUNE/`) must not appear in anything the new solution uses in SAP. Log every one you find in `docs/replacements/S6-replacements.txt` (format and rules: `docs/replacements/framework-replacement-register.md`; write `RESULT: none found` if none) and add rows to the register. Replace with standard SAP data elements/structures of the same type and length; never a new DDIC object without approval.
