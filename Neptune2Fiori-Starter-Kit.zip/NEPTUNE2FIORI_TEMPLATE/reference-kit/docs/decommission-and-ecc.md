# Decommissioning Neptune and running on ECC

## 1. Deleting `ZCL_NAD_PROJECT_CODE_REQUEST`

The new solution does not use it: `ZCL_UI_PROJECT_CODE_REQUEST` is a full copy (it mentions the old name only
in its header comment), and `MPC_EXT` / `DPC_EXT` call only `ZCL_UI_PROJECT_CODE_REQUEST`. The UI calls only
`ZDCI_UI_PROJECT_REQUEST_SRV`.

Delete it only when **all** of these are true:

| # | Check | How |
|---|---|---|
| 1 | Parity signed off (S5) and the new app is live in PRD | sign-off in `05-parity-log.md` |
| 2 | Where-used list of the class is empty, or lists only Neptune objects that are deleted as well | SE24 → Where-used list (all object types), or ADT "Where-used" |
| 3 | No other object uses its **types** (`ZCL_NAD_PROJECT_CODE_REQUEST=>TY_*`) — check especially `ZCL_ND_CA_MDG_WORKFLOW`, `ZCL_ND_CA_UTILITIES`, `ZCL_ND_PROJECT_UTILITY`, workflow tasks, reports | where-used on each type, or code search for `ZCL_NAD_PROJECT_CODE_REQUEST` (SAP: report `RS_ABAP_SOURCE_SCAN`) |
| 4 | Other Neptune apps (for example the parent list app) are also replaced or retired | Neptune cockpit app list |
| 5 | Deletion goes through a transport (DEV → QA → PRD), not a direct delete in PRD | `transports/transport-log.md` |

Neptune's own objects (`/NEPTUNE/*`) and the Neptune ICF nodes are removed by the Basis team when the licence
ends; nothing in this project depends on them (register `docs/replacements/framework-replacement-register.md`,
check 9 of `verify_kit.py`).

## 2. Lift and shift to a new ECC system

| Area | Requirement | If not met |
|---|---|---|
| ABAP release | SAP_BASIS **7.40 SP05 or higher** (ECC 6.0 EHP7/EHP8). The code parses at v740sp05, v740sp08, v750, v757; it fails at 7.02 (inline declarations in `MPC_EXT`). | rewrite the inline declarations — decision for the owner |
| Gateway | SAP_GWFND (7.40+) in the ECC, or a separate Gateway hub with a system alias to the ECC | install/activate Gateway; register the service on the hub |
| SAPUI5 | Kit is built for SAPUI5 1.102/1.108. SAP_UI 7.50 can ship 1.38–1.71 depending on SP. | see 2.1 |
| Deploy | `/UI5/ABAP_REPOSITORY_SRV` for `npm run deploy` | upload with report `/UI5/UI5_REPOSITORY_LOAD` |
| Custom objects | All Z tables (with data), `ZCL_ND_*` classes, `Z_BAPI_BC_USER_GETLIST`, `Z_MDG_CREATE_INTERNALORDER`, `Z_PS_COPY_TEMPLATE`, workflow customizing, number ranges, roles | transport them before S3-B1 |
| Standard objects | Used tables CSKS, CSKT, USR21, ADRP, USR02, TAPRFT, TCURT, T499S, T093C, T005U, T001 and classes `CL_ABAP_CHAR_UTILITIES`, `CL_ABAP_STRUCTDESCR`, `CL_MIME_REPOSITORY_API` exist in ECC | — |
| SAP ADT MCP | ADT needs the ECC on 7.40+ with the ADT ICF services active | Basis activates `/sap/bc/adt` |

### 2.1 If the ECC SAPUI5 version is lower than 1.108

1. Set `minUI5Version` in `manifest.json` and `framework.version` in `ui5-smoke.yaml` to the ECC version.
2. Theme: `sap_horizon` exists from 1.102 only — use `sap_belize` (or `sap_fiori_3` from 1.65).
3. `sap.ui.require.toUrl` needs 1.58+; below that use `jQuery.sap.getModulePath`.
4. Re-run the smoke test with OpenUI5 at that version; log every change as a parity item, not as a fix.
