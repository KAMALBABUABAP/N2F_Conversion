# Layout parity — Neptune vs UI5 (session "S4 layout parity", 2026-10-20)

Status: **STEP 5 done (2026-10-20).** Decided: L-01…L-04 yes (all 9 wrappers, no re-indent), T-01 (a) → P-64, F-01…F-06 no action,
binding-rules §6 + coverage-report + registry 08 + `verify_kit.py` exception line yes. Result per row: last section. New P-65 proposed (owner "yes" pending).

## Inputs

| Source | Content |
|---|---|
| `docs/Neptune_Screenshot.docx` → `docs/capture/layout/neptune/01_image1.png` (1292×1071), `02_image2.png` (1268×811) | Neptune reference: header, tabs, Requester, Project Details / Important Forms, Workflow (FP&A, RTR collapsed), Attachments, footer |
| `docs/localhost_screenshot_v1.docx` → `docs/capture/layout/localhost/01_image1.png` (2510×1149), `02_image2.png` (2535×846) | UI5 kit (`npm start`, SAPUI5 1.108.48, real S4M data): header, tabs, Requester, Project Details, Important Forms, Workflow, Attachments — **no footer** |
| `docs/neptune-export/zdci_nad_project_request.xml` (parsed: `docs/capture/export-extract/controls.json`, `attributes.json`, `css.json`, `header.json`) | source of truth for every attribute (registry 09) |

Not in any screenshot: Approvals, Comments, footer (UI5 side), dialogs. They are compared by attributes only (row X-01).

## How the comparison was made

1. Container level first: for every ObjectPage subsection, the outer control(s) and their layout attributes were taken from the export
   (`IT_CONTENT` tree + `IT_ATTRIBUTES`) and compared with `webapp/view/Main.view.xml`.
2. Automatic attribute check over **all** controls of the export against `Main.view.xml` + 21 fragments for every layout-relevant
   property (`layout`, `labelSpan*`, `emptySpan*`, `columns*`, `adjustLabelSpan`, `singleContainerFullSize`, `width`, `contentWidth`,
   `contentHeight`, `textAlign`, `styleClass`, `fieldWidth`, `rows`, `cols`, `wrapping`, `subSectionLayout`, `useTwoColumnsForLargeScreen`,
   `titleUppercase`, `upperCaseAnchorBar`, `mode`, `type`, `icon`, `displayFormat`, …), both directions (missing in kit / extra in kit).
   **Result: every value is identical**, except binding syntax (expected, binding-rules §2) and `displayFormat` (P-57, owner decision).
3. UI5 runtime rule that decides the columns (SAPUI5 1.108 source, `sap/uxap/ObjectPageSubSection.js` `_calculateLayoutConfiguration`,
   `ObjectPageSectionBase.js` `_assignLayoutData`):
   - every **block** of a subsection gets its own `GridData`; the block grid uses `containerQuery: true` (width of the block area =
     75 % − 2rem of the subsection with `TitleOnLeft`), not the window width;
   - columns per size with `subSectionLayout=TitleOnLeft` + `useTwoColumnsForLargeScreen=true`: **M = 2, L = 1, XL = 3**;
   - two blocks at M → `M6` + `M6` = two equal columns side by side; **one block → always full width**.

   Consequence: the side-by-side layout in Neptune exists only because each SimpleForm is a separate block.

## Main finding (root cause)

The export node type `UM5_OPSUBC` (`RequesterBlock`, `ProjDetailBlock`, `oObjectPageSubSectionRTR`, …) has **no properties**, only the
Parent attribute `position = MoreBlock`. It is the designer's **aggregation node** (same as `UM5_BARCON` `Left`/`Middle`/`Right` → Bar
`contentLeft`/… and `UM5_OPCONT` `hcAttributes` → `headerContent`, already treated as "no runtime control" in S2a, registry 08). Its
children are the blocks. The kit (binding-rules §6) wraps the children in **one `VBox` with the node id** → the subsection has one
block → the two forms are stacked in full width, so everything below sits in one column and `sfBudgetProj2` (default layout =
ResponsiveLayout) has room to put its labels on the left. `parse_export.py` maps `UM5_OPSUBC` to "no rendered control" too.
No JS (controller, utils, Neptune scripts, smoke test) references any of the nine node ids; `validateRequiredAll` reads the forms by id.

## Viewport note (affects Step 5)

The Neptune image is about 1 300 CSS px wide (block area ≈ 900 px → size **M** → 2 columns). The localhost image is about 2 500 px
(block area ≈ 1 800 px → size **XL**). With the fix, the same UI5 rules give: block area < 1 024 px → `M6`+`M6` = 2 equal columns (as
Neptune); 1 024–1 439 px → `L12` = 1 column (stacked); ≥ 1 440 px → XL 2/3 + 1/3. **Measured (Step 5):** window 1292 → block area 445+445 px,
`M6`/`M6`, two columns; window **1440 → block area 1016 px, `L12`, stacked** (my Step 3 estimate "1440 = 2 columns" was wrong). The export
CSS `.opl-two-column .sapUiRespGridSpanXL9/XL3 { width: calc(50% - 1rem) }` does not match the 1.108 spans (XL8/XL4) — same UI5 version in
Neptune, so it is parity, not a difference.

## Table — cause classes: A = attribute/structure vs export (view XML), C = CSS/theme, D = data/start context, V = UI5 runtime (new P-xx)

### 1. Container level

| # | Section | Control id | What differs | Neptune export value (attribute + ref) | Current kit value (file:line) | Class | Proposed action | Decision |
|---|---|---|---|---|---|---|---|---|
| L-01 | Requester | `RequesterBlock` → `sfBudgetManagerBlock1`, `sfBudgetManagerBlock2` | column / order: Neptune = 2 columns (left Processing region / Requested By / On Behalf Of + Clear; right Authorized By / Authorized Date). Kit = 1 column, Authorized By + Authorized Date below On Behalf Of, Authorized By input full width | `RequesterBlock` `UM5_OPSUBC`, Parent `position=MoreBlock`, no properties (IT_CONTENT/IT_ATTRIBUTES 00730); 2 children 00932, 01024 | `VBox id="RequesterBlock"` wraps both forms — `webapp/view/Main.view.xml:83`–`123` | A | remove the `VBox`; both `SimpleForm`s directly in `<uxap:moreBlocks>`; one-line comment `<!-- RequesterBlock = moreBlocks aggregation node of the original designer, no runtime control -->` | open |
| L-02 | Project Details | `ProjDetailBlock` → `sfBudgetProj`, `sfBudgetProj2` | column / label position: Neptune = 2 columns (left Project Name … CAPEX Currency; right Company Code … FP&A Approval Document), labels above in both. Kit = `sfBudgetProj` full width, `sfBudgetProj2` below it with labels **left**, right-aligned | `ProjDetailBlock` `UM5_OPSUBC`, `position=MoreBlock` (00947); children 00948, 01023. `sfBudgetProj2` has only `editable=true` (01023) → UI5 default layout — the kit is identical | `VBox id="ProjDetailBlock"` — `Main.view.xml:129`–`263`; `sfBudgetProj2` `:223` (same attributes as export) | A | same as L-01. No attribute is added to `sfBudgetProj2` (export has none): labels-above is expected from the half-width block — verify in Step 5; if labels stay left → new P-xx (V), not a fix | open |
| L-03 | Workflow / RTR | `oObjectPageSubSectionRTR` → `sfRTRAppr`, `sfRTROrderTbl` | column (subsection collapsed in both screenshots): Neptune 2 blocks side by side, kit stacked | `UM5_OPSUBC`, `position=MoreBlock` (00992); children 01065, 01110 | `VBox` — `Main.view.xml:376`–`429` | A | same as L-01 | open |
| L-04 | FP&A, BPC, Additional Company Code, Attachments, Approvals, Comments | `oObjectPageSubSectionFPA`, `oObjectPageSubSectionBPC`, `ProjMultiCCode`, `attachBlock1`, `approvalBlock1`, `CommentsBlock` | none visible (one child → one block = full width either way); only an extra `VBox` in the DOM | `UM5_OPSUBC`, `position=MoreBlock` (00987, 01056, 01133, 00816, 00543, 00864) | `VBox` — `Main.view.xml:350`, `436`, `300`, `455`, `480`, `513` | A (consistency) | same treatment as L-01 so that all 9 `UM5_OPSUBC` nodes follow one rule (recommended); or leave as is | open |
| L-05 | all forms | `sfBudgetManagerBlock1/2`, `sfBudgetProj`, `sfProjAttDownload`, `sfRTRAppr`, `sfBPCAppr`, `sfBudgetProj2`, `sfFPAAppr`, `sfBudgetCCode`, `sfRTROrderTbl` | **no difference**: RGL `labelSpanL=12 labelSpanM=12` (+ `labelSpanXL=12` on `sfProjAttDownload`), RGL `labelSpanM=4` on RTR/BPC, default layout on the others; no `emptySpan*`, `columns*`, `adjustLabelSpan`, `singleContainerFullSize` anywhere | 00932, 01024, 00948, 01224, 01065, 01086, 01023, 00988, 01134, 01110 | identical — `Main.view.xml:84`, `108`, `130`, `270`, `377`, `437`, `223`, `351`, `301`, `399` | — | none | — |
| L-06 | page | `oplForm` | **no difference**: `alwaysShowContentHeader=true`, `styleClass=opl-two-column`, `subSectionLayout=TitleOnLeft`, `useTwoColumnsForLargeScreen=true` | 00507 | `Main.view.xml:39`–`43` | — | none | — |
| L-07 | Project Details | `sectionProj` | **no difference**: `styleClass=sfactor-block`, `titleUppercase=false` (CSS `.sfactor-block > div .sapUiRespGrid { background-color:#f4f4f4 }`) | 00539 | `Main.view.xml:78` | — | none | — |

### 2. Header, tabs, theme, CSS

| # | Section | Control id | What differs | Neptune export value (attribute + ref) | Current kit value (file:line) | Class | Proposed action | Decision |
|---|---|---|---|---|---|---|---|---|
| H-01 | header | `btnNavBack` | visibility: Neptune shows the back button, localhost not | `icon=sap-icon://nav-back` (00716); Init script hides it when the app is **not** a child component (`script_00314_Init.js:33`), `loadRequest` shows it (`script_00768_Utility.js:24`) | same logic — `Main.controller.js:137`, `:878`; view `Main.view.xml:30` | D | none — Neptune was opened from the parent list app, localhost standalone. Compare with the same start context | open |
| H-02 | header | `titlePagePCreate`, `headerPageProj` | position the same (left, after back button); font size/weight follow the theme | `text={GS_PROJ_FORM-PAGE_HEADER}` in Bar `contentMiddle` (00633, 00632) | `Main.view.xml:28`–`35` | C | follows T-01 | open |
| H-03 | tabs | `oplForm` anchor bar | case: Neptune `PROJECT DETAILS, WORKFLOW, …` (upper), localhost `Project Details, Workflow, …` | `upperCaseAnchorBar` **not set** in the export → default `true` (UI5 1.108 `ObjectPageLayout.js:166`) — same in kit; it is **not** an attribute difference | not set — `Main.view.xml:39` | C | follows T-01. Do **not** add `upperCaseAnchorBar` (not in export) | open |
| H-04 | header, sections | `ophProj`, subsection titles, buttons, inputs | look: Neptune = solid blue circle icon, blue-bordered buttons (`Clear`, expand), full-border inputs, regular-weight subsection titles; localhost = light circle icon, grey rounded buttons, bold titles, white card behind `sfBudgetProj2`, white strips above the forms | `ophProj` `objectImageShape=Circle`, `objectImageURI=sap-icon://dimension`, `isObjectIconAlwaysVisible=true` (00762) — identical | `Main.view.xml:46`–`50` | C | follows T-01 | open |
| T-01 | all | theme | Neptune screenshot looks like **sap_fiori_3 (Quartz Light)** — upper-case anchor bar, blue-outlined Default/Accept buttons, full-border inputs, solid avatar. **ASSUMPTION** (visual); confirm in the Neptune app: Chrome DevTools console `sap.ui.getCore().getConfiguration().getTheme()` | export: theme plugin `sap_horizon` (IT_PLUGIN, `header.json` `THEME_PLUGINS`), `SAPUI5_VERSION 1.108` — the app sets no theme itself, so the Neptune launchpad decided | `index.html:11` `data-sap-ui-theme="sap_horizon"`; `manifest.json` no theme; in the FLP the user's launchpad theme decides (index.html is standalone only) | C / V | **(a) recommended:** keep `sap_horizon` (= export value), log new **P-64** "Neptune runtime rendered with launchpad theme sap_fiori_3; UI5 app follows the FLP theme" — the FLP theme is a launchpad setting, not app code. **(b)** standalone parity: `index.html` → `sap_fiori_3` and `ui5-smoke.yaml` + `themelib_sap_fiori_3` — both files are **outside** the files allowed for this session, needs your explicit OK | **(a) — owner 2026-10-20:** keep `sap_horizon`, log P-64 "theme to confirm in S5" (Neptune theme not confirmed; visually sap_fiori_3). H-02, H-03, H-04 follow → P-64 |
| T-02 | all | content density | **no difference**: both compact (Neptune input height 26 px = 1.625rem) | — | `index.html:17` `sapUiSizeCompact` | — | none | — |
| T-03 | all | `app.css` | **no difference**: loaded via `manifest.json:71`–`73` (`css/app.css`); content byte-identical to export `IT_CSS_DESKTOP` (kit file adds only the 4-line Neptune MIME header comment, = `docs/neptune-export/app.css`) | `css.json` `it_css_desktop` | `webapp/css/app.css` | — | none | — |

### 3. Field level (after L-01…L-04 most width/position differences disappear; re-check in Step 5)

| # | Section | Control id | What differs | Neptune export value (attribute + ref) | Current kit value (file:line) | Class | Proposed action | Decision |
|---|---|---|---|---|---|---|---|---|
| F-01 | Requester | `rbgQProcessingRegion`, `inpOnBehalfOf`, `CbtnOnBehalfClr` | enabled: Neptune enabled, localhost disabled (greyed) | `enabled={GS_PROJ_FORM-PROJ_FLGRP_0005}` (00934, 01027, 01028) | same binding — `Main.view.xml:88`, `:101`, `:104` | D | none in the view. Different user/form (Neptune "AI AWS", localhost "Kamalbabu Kamatchi"). If the **same** user + form gives a different `PROJ_FLGRP_0005` in the `GET_DATA` response → backend/conversion parity item (separate session) | open |
| F-02 | Project Details | `lblProjectType` | required star: Neptune yes, localhost no | `required={GS_PROJ_FORM-PROJ_FLGRP_0005}` (00999, P-58) | same — `Main.view.xml:141` | D | as F-01 (same flag) | open |
| F-03 | Requester | `lblAuthDate` | required star: Neptune yes, localhost no | `required={GS_PROJ_FORM-R_AUTH_BY_DATE}` (01199) | same — `Main.view.xml:117` | D | none (data `R_AUTH_BY_DATE`) | open |
| F-04 | Requester, Project Details | `inpOnBehalfOf`, `inpPersonResponsible`, `inpCostCenter`, `inpLocation`, `inpBrand`, `inpGeography` | value-help icon: shown in Neptune, missing in localhost | `showValueHelp=true` (01027, 01236, 01117, 01221, 01212, 01213) | `showValueHelp="true"` — `Main.view.xml:101`, `:113`, `:231`, `:234`, `:238`, `:241`; no code changes it | D? | verify in Step 5 (mock data, fields enabled). If still missing with `enabled=true` → new P-xx (V) | open |
| F-05 | Requester, Project Details | `dpAuthDate`, `dporderdate`, `dpOrderCompDate` | placeholder `e.g. 20261231` in Neptune, none in localhost | `displayFormat` formatter `date:SAPUserDefault` (01200, 01072, 01074) | not set — `Main.view.xml:119`, `:249`, `:254` (PARITY P-57, owner 2026-10-18: unset) | V (P-57) | none — existing owner decision P-57; add the placeholder difference to the P-57 row as evidence | open |
| F-06 | Requester | `inpOnBehalfOf` + `CbtnOnBehalfClr` | width: Neptune input ≈ 190 px + Clear, localhost ≈ 130 px | `oHBoxOnBehalf width=100%` (01026); `inpOnBehalfOf styleClass=one-line-form-field` | identical — `Main.view.xml:99`–`105` | C / D | none — follows L-01 (block width), F-01 (enabled → VH icon) and T-01 | open |
| F-07 | Important Forms | `subsectionProjAttDownload` | **no difference**: title + expand button only in both | `blocks` (no `UM5_OPSUBC`), 01222/01224 | `<uxap:blocks>` — `Main.view.xml:268`–`295` | — | none | — |
| F-08 | Attachments | `listAttachments` | **no difference** in position (toolbar right, list in the block area); `noDataText` visible only in localhost because the Neptune image is cut | 00817 | `Main.view.xml:456` | — | none | — |
| X-01 | footer, Approvals, Comments, dialogs | `footerPageCCreate`, `oTableApprovers`, `oTextAreaPrevComments`, 21 dialog fragments | not in the localhost screenshots; attribute check: **no layout difference** | export 00634–00923, 00465, 00872, dialog rows | `Main.view.xml:526`–`540`, `:481`, `:514`, `webapp/view/fragments/*.fragment.xml` | — | compare visually in Step 5 (`pw_after_footer.png`, …) | — |

Not a difference: the dotted rectangles in the Neptune image are the keyboard-focus outline; the dashed border on `oTxtProjDesc` in the
localhost image is the Horizon focus outline.

## Impact of L-01…L-04 if approved

- Files: `webapp/view/Main.view.xml` only (9 `VBox` wrappers removed, 9 one-line comments). No fragment and no CSS change.
- Ids: the 9 node names stay documented (comment in the view, registry 08). No other id/model/function/text changes.
- Registry 08 rows for `RequesterBlock`, `ProjDetailBlock`, `ProjMultiCCode`, `oObjectPageSubSectionFPA/RTR/BPC`, `attachBlock1`,
  `approvalBlock1`, `CommentsBlock`: "aggregation node `moreBlocks`, no runtime control (export `UM5_OPSUBC`)".
- Also needed (outside the allowed list, needs your OK): `neptune-to-ui5-frontend/references/binding-rules.md` §6 still says
  "become a VBox with the same id"; `docs/coverage-report.md` rows 128/149/… describe the VBox. Otherwise the next session re-adds the VBoxes.
- Registry 03: no change (none of the 9 nodes has a Model Source).
- Registry 05: P-64 only if T-01 (a) is chosen; P-57 evidence line (F-05).

## Result per row (Step 5)

Run: offline smoke server (`ui5 serve --config ui5-smoke.yaml`, OpenUI5 1.108.54, `sap_horizon`, mocked OData = `smoke/mock-data.js`) on
port 8081 (8080 was the owner's running `npm start`), headless Chromium, viewport 1292×900 and 1440×900. Screenshots
`docs/capture/layout/localhost/pw_after_<section>_<width>.png` (header, requester, projectdetails, workflow, attachments, approvals,
comments, footer). Geometry read from the DOM (block rect + grid span class, label rect vs field rect, value-help icon element);
`subsectionRTR` set to Expanded in the browser only for the RTR measurement.

| # | Result | Evidence |
|---|---|---|
| L-01 | **fixed** at 1292 | `sfBudgetManagerBlock1` x339 w445 `M6`, `sfBudgetManagerBlock2` x800 w445 `M6`; Processing region / Requested By / On Behalf Of + Clear left, Authorized By / Authorized Date right, labels ABOVE — `pw_after_requester_1292.png`. At 1440 stacked → P-65 |
| L-02 | **fixed** at 1292 | `sfBudgetProj` x339 w445 `M6`, `sfBudgetProj2` x800 w445 `M6`; labels ABOVE for `lblCompanyCode`, `lblCostCenter`, `lblCompletionDt`, `lblFPAApprovalAtt` — `pw_after_projectdetails_1292.png`. At 1440 stacked and `sfBudgetProj2` labels LEFT (ResponsiveLayout at 1016 px) → P-65 |
| L-03 | **fixed** at 1292 | `sfRTRAppr` x339 `M6`, `sfRTROrderTbl` x800 `M6` (RTR expanded for the measurement; collapsed on screen as in Neptune) |
| L-04 | **done** (no visible change, as expected) | FP&A/RTR collapsed, Attachments list, Approvals table, Comments text area unchanged — `pw_after_workflow_1292.png`, `pw_after_comments_1292.png` |
| L-05…L-07 | unchanged (were equal) | — |
| H-01 | data/start context (D) | back button hidden standalone (Init script), shown when opened from the parent list app |
| H-02, H-04 | P-64 | Horizon look (light avatar, grey rounded buttons, bold titles, white card behind `sfBudgetProj2`) |
| H-03 | P-64 — **new observation** | anchor bar is **UPPER CASE** in this run (`upperCaseAnchorBar=true`, computed `text-transform: uppercase`, `pw_after_header_1292.png`) but was mixed case in the owner's `npm start` screenshot (`localhost/01_image1.png`, SAPUI5 1.108.48 via proxy). Not caused by the app (no attribute, no CSS). To confirm in S5 together with the theme (P-64) on the real system |
| T-01 | P-64 (owner: keep `sap_horizon`) | `index.html` `<!-- PARITY P-64 -->` |
| T-02, T-03 | unchanged (were equal) | — |
| F-01, F-02, F-03 | data (D) | mock: Processing region / Clear enabled; real-data difference stays a data question |
| F-04 | data (D) — **closed** | with fields enabled, all 6 value-help icons render (`enabled=true, editable=true, showValueHelp=true, icon element present`) at both widths; the missing icons in `localhost/01_image1.png`/`02_image2.png` came from the data |
| F-05 | P-57 | placeholder now `e.g. Dec 31, 2026` (UI5 medium style, `displayFormat` unset) vs Neptune `e.g. 20261231` (user format) |
| F-06 | fixed with L-01 | `inpOnBehalfOf` + Clear in the half-width block |
| X-01 | no difference | footer Save/Submit right-aligned (mock flags), Approvals columns, Comments text area — `pw_after_footer_*.png`, `pw_after_approvals_*.png`, `pw_after_comments_*.png` |

Checks after the change (real output in the session): `npm run test:unit` 9 tests passed; smoke (`smoke.js` against port 8081) "all
smoke checks passed"; `npm run lint` 26 findings (23 errors, 3 warnings) = all EXPECTED per `test-plan.md` §Lint; `verify_kit.py --source
neptune-source` **KIT OK incl. check 8 "all 252 master-tree ids present"** (before the TREE_EXCEPTIONS line it failed on exactly the 9
wrapper ids). Console during screenshots: resource 404s + `"Green"` (P-62) — both filtered as known by `smoke.js`.

Proposed **P-65** (V, owner "yes" pending): UI5 1.108 `ObjectPageSubSection` with `TitleOnLeft` + `useTwoColumnsForLargeScreen` gives
L = 1 block column → with a block area of 1 024–1 439 px (window ≈ 1 430–1 920 px, estimated from the 1292/1440 measurements) the two forms stack and `sfBudgetProj2` (default
ResponsiveLayout) puts labels left. Same UI5 version + same attributes + now same block structure as the original → expected identical in
Neptune; confirm in S5 with the Neptune app at 1440 px.

---
Created using Anthropic Claude — internal working document; keep it on internal versions until a human has reviewed and verified the content.
