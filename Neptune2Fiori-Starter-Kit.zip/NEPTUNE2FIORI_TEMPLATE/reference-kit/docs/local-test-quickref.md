# Local test – quick reference

App `zdci_nad_project_request` against `ZDCI_UI_PROJECT_REQUEST_SRV` on DEV (S4M / client 100).
Never put user, password or cookies in any file. Never save a HAR.

## 0. Go to the app folder

```zsh
cd ~/Documents/NeptuneToFiori/sap-dev/projects/NEPTUNE2FIORI_PROJREQ/src/ui5/zdci_nad_project_request
```

## 1. Start with real DEV data (VPN or office network)

```zsh
export FIORI_TOOLS_USER='KKAMATCH'
read -s "FIORI_TOOLS_PASSWORD?SAP password: "; export FIORI_TOOLS_PASSWORD
npm start
```

`read -s` keeps the password hidden and out of the shell history.
If F3 documented different variable names, use those.

## 2. Start with mock data only (no backend, no VPN)

```zsh
npm run start-smoke
```

## 3. Open in the browser

| Test | URL |
|---|---|
| New request | `http://localhost:8080/index.html?sap-client=100` |
| Existing form (display) | `http://localhost:8080/index.html?sap-client=100&form_guid=<guid>` (names lowercase: `getUrlParameters`) |
| Existing form (change) | `http://localhost:8080/index.html?sap-client=100&form_guid=<guid>&mode=change` |
| B4 test form (change) | `http://localhost:8080/index.html?sap-client=100&form_guid=021E8810B7451FD1B2F74C04852DC000&mode=change` |
| Service check (direct) | `http://saps4m1.discovery.com:8000/sap/opu/odata/sap/ZDCI_UI_PROJECT_REQUEST_SRV/$metadata?sap-client=100` |

## 4. Watch and save the AJAX calls

1. Chrome DevTools (`Cmd+Option+I`) → **Network** → filter `AJAXSet`.
2. Click the POST → **Payload** tab = request, **Response** tab = reply.
3. Copy the body, then save it:

```zsh
pbpaste > ~/Documents/NeptuneToFiori/sap-dev/projects/NEPTUNE2FIORI_PROJREQ/docs/capture/f3/<row>_<AJAX_ID>_res.json
```

## 5. Stop and clean up

```zsh
# Ctrl+C in the server terminal, then:
unset FIORI_TOOLS_USER FIORI_TOOLS_PASSWORD
```

## 6. Checks after a code change

```zsh
npm run test:unit                              # all tests pass
npm run start-smoke                            # terminal 1
npm run test:smoke                             # terminal 2 → "all smoke checks passed"
npm run lint                                   # 26 EXPECTED findings is normal (test-plan.md §Lint)
python3 ../../../.claude/scripts/verify_kit.py # must print KIT OK
```

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| Port 8080 already in use | `lsof -ti :8080 \| xargs kill` |
| 401 / login pop-up loops | Wrong password or user locked → re-export the variables, check SU01 |
| 404 on AJAXSet | Service not active → `/IWFND/MAINT_SERVICE` |
| 500 on AJAXSet | `/IWFND/ERROR_LOG`, `/IWBEP/ERROR_LOG`, ST22 |
| Old model or data after a backend change | `/IWFND/CACHE_CLEANUP` + `/IWBEP/CACHE_CLEANUP`, then hard reload `Cmd+Shift+R` |
| Proxy timeout / host not found | VPN off → `ping saps4m1.discovery.com` |
| Smoke test can't find the browser | `npx playwright install chromium` |
| Tables come back as `__deferred` | The request didn't send that GT_* nav property (see F3 item a) |
