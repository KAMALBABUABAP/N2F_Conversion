# Claude Code session prompts — NEPTUNE2FIORI_PROJREQ

Ready-to-paste prompts for every Claude Code session of the Neptune `ZDCI_NAD_PROJECT_REQUEST` → SEGW +
freestyle SAPUI5 conversion. One prompt = one new Claude Code session.

**How to use**
1. In the macOS terminal (or the VS Code integrated terminal, for diffs in the editor):
   `cd ~/<sap-dev>/projects/NEPTUNE2FIORI_PROJREQ` and run the **Start with** command from the header, e.g.
   `claude --agent neptune-abap-converter`. Starting *as* the agent matters: the agent can then ask for your
   "yes" before SAP writes (a subagent cannot ask questions).
2. Check `/mcp` shows `sap-adt` connected (sessions that touch SAP). The first time, choose **Authenticate** there and
   sign in with your BTP user in the browser. Every SAP call uses `system` S4M and `client` 100 from `.env`.
3. Paste the prompt. Replace `<...>` values. Read the first answer before you say "yes" to any SAP write.
4. End the session: commit, then `/exit` (or `/clear` before the next prompt). The next session picks up from
   the files, not from the conversation.

**Without the terminal (VS Code Claude Code panel):** open `projects/NEPTUNE2FIORI_PROJREQ` as the folder of a
second VS Code window, click **New session** for each prompt, and replace `claude --agent <name>` with this first
line: *Read `.claude/agents/<name>.md` and follow it as your rules for this whole session.* Then paste the prompt.

**CRUD actions**: every prompt says exactly what the agent may do:

| Action | Meaning in this project |
|---|---|
| **C**reate | new files in the repo, new ABAP objects in DEV, new BSP, new registry rows |
| **R**ead | repo files, Neptune sources/export, SAP via read-only ADT tools, SQL read |
| **U**pdate | change existing repo files, ABAP source in DEV, registries, logs |
| **D**elete | remove files, objects, markers. Allowed only where a prompt names it |

Anything a prompt does not list is not allowed. The agent must stop and ask.

**Licence removal:** every prompt also tells the agent to log names that start with or contain `NEPTUNE` in `docs/replacements/<session>-replacements.txt` and the register `docs/replacements/framework-replacement-register.md`. Build sessions replace them with standard SAP data elements or structures. Read-only sessions only propose replacements.

---

## Contents

| # | Session | Start with | CRUD |
|---|---|---|---|
| 1 | S0 Setup check | `claude` | R · C (log only) |
| 2 | S1 Coverage audit vs Neptune XML export | `claude --agent neptune-parity-reviewer` | R · C (report only) |
| 3 | S2a Close gaps — view bindings and attributes | `claude --agent neptune-ui5-converter` | R · U |
| 4 | S2b Close gaps — event handlers and AJAX handlers | `claude --agent neptune-ui5-converter` | R · U |
| 5 | S2c Confirm AJAX send/receive (INF → CAP) | `claude --agent neptune-ui5-converter` | R · U |
| 6 | S2d Replace the discoveryFiori shim with the original | `claude --agent neptune-ui5-converter` | R · U |
| 7 | S3-B0 DDIC check + licence scan | `claude --agent neptune-abap-converter` | R · U (registry) · C (log) |
| 8 | S3-B1 Create ZCL_UI_PROJECT_CODE_REQUEST | `claude --agent neptune-abap-converter` | R · C · U |
| 9 | S3-B2 SEGW project (guided) | `claude --agent neptune-abap-converter` | R · U (registry) |
| 10 | S3-B3 MPC_EXT / DPC_EXT + spike | `claude --agent neptune-abap-converter` | R · U |
| 11 | S3-B4 Test every AJAX ID | `claude --agent neptune-abap-converter` | R · C (results) |
| 12 | S3-B5–B7 Backend parity, attachment, hand-off | `claude --agent neptune-abap-converter` | R · U |
| 13 | S4-F0/F1 Frontend offline checks | `claude --agent neptune-ui5-converter` | R · C (local only) |
| 14 | S4-F3 Frontend against the real service | `claude --agent neptune-ui5-converter` | R · U |
| 15 | S5 Parity test Neptune vs UI5 | `claude` | R · C · U |
| 16 | S6 Deploy to BSP + launchpad | `claude --agent neptune-ui5-converter` | R · C · U |
| 17 | Review before sign-off | `claude --agent neptune-parity-reviewer` | R · C (log only) |
| 18 | Q&A | `claude --agent neptune-parity-reviewer` | R |
| 19 | Rollback / decommission plan | `claude` | R · C (plan only) |

---

## 1 · S0 Setup check · CRUD: R · C (log only)

Start with: `claude`

```text
Run session S0 (setup check) for project NEPTUNE2FIORI_PROJREQ. Read CLAUDE.md and README.md in this folder first.

Follow the rules in CLAUDE.md. Use the skill n2f-s0-setup-check.

Actions: Read only. Run python3 .claude/scripts/verify_kit.py and, in src/ui5/zdci_nad_project_request, npm run test:unit (npm install first if node_modules is missing). Call ListSapSystems and confirm S4M is listed. On every SAP tool call pass system=S4M and client=100 (from .env); never omit system, the server default is S4D. Call one read-only SAP ADT MCP tool (read the standard class CL_ABAP_CHAR_UTILITIES; the original class ZCL_NAD_PROJECT_CODE_REQUEST may already be deleted or not exist on the target system) and tell me the system ID and client you are connected to. Also report the target system's release: SAP_BASIS, SAP_UI (SAPUI5 version), SAP_GWFND / IW_BEP, and whether it is S/4HANA or ECC. Write it into .env (SAP_SYSTEM_TYPE, SAP_BASIS_RELEASE, SAPUI5_VERSION). Create: only docs/replacements/S0-replacements.txt. Update: nothing. Delete: nothing.

Scope: kit check, unit test, list of skills and agents you can see, full list of SAP ADT MCP tools grouped as read / write / activate / test / transport / other, and which .env values are still empty (do not print secrets).

Out of scope: any SAP write, any file change, installing global tools.

Replacement log (licence removal): list every name you find that starts with or contains NEPTUNE (namespace /NEPTUNE/, data element, structure, class, interface, variable, MIME/ICF path, literal) in what you read. Do not replace anything in this session. Propose the standard SAP data element/structure of the same type and length for each. Write docs/replacements/S0-replacements.txt in the format of docs/replacements/framework-replacement-register.md (write "RESULT: none found" if none) and add proposed rows to the register.

When done: show the last lines of both checks, the tool list as a markdown table I can paste into ../../common/mcp/README.md §2, and tell me which session to run next.
```

---

## 2 · S1 Coverage audit vs Neptune XML export · CRUD: R · C (report only)

Start with: `claude --agent neptune-parity-reviewer`

```text
Run session S1 (coverage audit) for ZDCI_NAD_PROJECT_REQUEST. Read CLAUDE.md, .claude/skills/nad-project-request-registry/SKILL.md and references 03, 04, 08 first.

You run as the neptune-parity-reviewer agent; follow its rules. Use the skill n2f-s1-coverage-audit with the export file docs/neptune-export/<export-file>.xml.

Actions: Read the XML export, docs/neptune-source/ and src/ui5/zdci_nad_project_request/webapp/. Create only docs/capture/parse_export.py, docs/coverage-report.md and docs/replacements/S1-replacements.txt. Update: nothing. Delete: nothing.

Scope: parse the export with the script (do not read the XML by hand). First print its top-level structure so we agree where controls, attributes, events, AJAX objects and scripts sit. Then compare control ids, attributes and bindings, event scripts, AJAX objects (name, send/receive, ajaxSuccess/ajaxError), script functions and text controls with the kit. Add "Answers to open items" for every TODO(SPEC-MISSING), TODO(CAPTURE), INF row and SHIM-RECONSTRUCTED marker.

Out of scope: fixing anything, changing registries, SAP access, the backend class.

Replacement log (licence removal): list every name you find that starts with or contains NEPTUNE (namespace /NEPTUNE/, data element, structure, class, interface, variable, MIME/ICF path, literal) in what you read. Do not replace anything in this session. Propose the standard SAP data element/structure of the same type and length for each. Write docs/replacements/S1-replacements.txt in the format of docs/replacements/framework-replacement-register.md (write "RESULT: none found" if none) and add proposed rows to the register.

When done: report the counts per status (same / different / missing in kit / extra in kit) and the top 10 blockers, then tell me which S2 prompt to run first. Commit message: "S1 coverage report".
```

---

## 3 · S2a Close gaps — view bindings and attributes · CRUD: R · U

Start with: `claude --agent neptune-ui5-converter`

```text
Close the view gaps listed in docs/coverage-report.md (areas "control ids" and "attributes/bindings") for ZDCI_NAD_PROJECT_REQUEST. Read docs/coverage-report.md and .claude/skills/neptune-to-ui5-frontend/references/binding-rules.md first.

Follow CLAUDE.md and the neptune-ui5-converter agent. Use the skill n2f-s2-close-gaps, then run python3 .claude/scripts/verify_kit.py and npm run test:unit before you finish.

Actions: Read the coverage report and the export. Update only src/ui5/zdci_nad_project_request/webapp/view/Main.view.xml, view/fragments/*.fragment.xml, i18n/i18n.properties, and registry files 03 and 08. Create: nothing. Delete: only TODO(SPEC-MISSING) markers you have replaced with the Neptune value.

Scope: copy every Neptune attribute and binding verbatim using the binding rules: {ATTR-FIELD} → {X>/FIELD} with the owning control's model. Fix id spellings only where the export proves the kit wrong. Do one section at a time: header, Requester, Project detail, FPA/RTR/BPC, attachments/approvals/comments, footer, dialogs. Show me the plan for each section before you edit it.

Out of scope: controller code, AJAX config, CSS, renaming anything not proven by the export, "improving" Neptune behaviour.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S2a-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: list the closed items per section and the items still open, show the verify_kit and unit-test output, and update spec-gaps.md. Commit message: "S2a view gaps from Neptune export".
```

---

## 4 · S2b Close gaps — event handlers and AJAX handlers · CRUD: R · U

Start with: `claude --agent neptune-ui5-converter`

```text
Close the controller gaps in docs/coverage-report.md (areas "event scripts" and "script functions", plus ajaxSuccess/ajaxError code) for ZDCI_NAD_PROJECT_REQUEST. Read docs/coverage-report.md and .claude/skills/neptune-to-ui5-frontend/references/js-port-rules.md first.

Follow CLAUDE.md and the neptune-ui5-converter agent. Use the skill n2f-s2-close-gaps, then run verify_kit.py and npm run test:unit before you finish.

Actions: Read the export and the coverage report. Update only src/ui5/zdci_nad_project_request/webapp/controller/Main.controller.js, registry 05 (new P-xx items) and spec-gaps.md. Create: new controller methods only where Neptune has an event or function the kit lacks, named <controlId>_<event> or the Neptune function name. Delete: only TODO(SPEC-MISSING)/TODO(CAPTURE) markers you have replaced with real Neptune code.

Scope: port each Neptune body verbatim. Local aliases at the top; only the mechanical replacements from js-port-rules.md. Replace the inferred handlers (header buttons, Requester, sfBudgetProj, upload buttons, P-37 AJAX handlers, NEW_PROJECT) with the captured code. A behaviour that looks wrong stays and becomes a new P-xx item.

Out of scope: view XML, AjaxRuntime.js internals, backend, refactoring, merging duplicate Neptune functions differently than the kit does.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S2b-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: list every handler replaced (old inferred → Neptune source location), new P-xx items, and the test output. Commit message: "S2b controller gaps from Neptune export".
```

---

## 5 · S2c Confirm AJAX send/receive (INF → CAP) · CRUD: R · U

Start with: `claude --agent neptune-ui5-converter`

```text
Confirm every AJAX object's send and receive lists for ZDCI_NAD_PROJECT_REQUEST and mark them CAP. Read registry 04-ajax-dispatch-inventory.md, docs/coverage-report.md (AJAX area) and docs/capture/capture-report.md (if present) first.

Follow CLAUDE.md and the neptune-ui5-converter agent. Use the skill neptune-to-ui5-frontend (references/ajax-client.md), then run verify_kit.py and npm run test:unit.

Actions: Read the export, the capture report and the config. Update only src/ui5/zdci_nad_project_request/webapp/util/AjaxConfig.js, registry 04, and the getOnline<Name> methods in the controller (for GET_EMPINFO / GET_AGENTLIST once their Neptune names are known). Create: nothing else. Delete: nothing.

Scope: for each AJAX ID, set the send and receive pairs ([model, ATTR]) exactly as in the Neptune AJAX object, set fn to the Neptune function name, and set evidence to "CAP" with a comment naming the source (export path or capture call). Pairs that are in the kit but not in Neptune are removed from the list. That is the only removal allowed.

Out of scope: backend envelope, adding attributes that are not in registry 02, any SAP access.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S2c-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: table AJAX ID | old evidence | new evidence | changes. Show test output. Commit message: "S2c AJAX config confirmed".
```

---

## 6 · S2d Replace the discoveryFiori shim with the original · CRUD: R · U

Start with: `claude --agent neptune-ui5-converter`

```text
Align util/discoveryFiori.js with the original Neptune library for ZDCI_NAD_PROJECT_REQUEST. Read docs/neptune-export/discoveryFiori.js and src/ui5/zdci_nad_project_request/webapp/util/discoveryFiori.js first.

Follow CLAUDE.md and the neptune-ui5-converter agent. Use references/spec-gaps.md §C of the frontend skill, then run npm run test:unit and the smoke test (npm run start-smoke, then npm run test:smoke).

Actions: Read both files. Update only webapp/util/discoveryFiori.js and spec-gaps.md. Create: nothing. Delete: the SHIM-RECONSTRUCTED marker of each method you aligned.

Scope: for ChildComponent, DirtyHandler, FileUploader, showMessage and addExpandButtons, copy the original behaviour into the UI5 module form (sap.ui.define, imported controls, no globals). Keep the method names and the API the controller uses. Where the original relies on Neptune-only runtime, keep the shim behaviour and log a P-xx item.

Out of scope: controller and view changes, new features, parent-app changes.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S2d-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: method-by-method table (original behaviour | ported | parity note), plus the test and smoke output. Commit message: "S2d discoveryFiori aligned with original".
```

---

## 7 · S3-B0 DDIC check · CRUD: R · U (registry)

Start with: `claude --agent neptune-abap-converter`

```text
Run backend step B0 (DDIC check) for ZDCI_NAD_PROJECT_REQUEST. Read CLAUDE.md, the skill neptune-to-segw-backend (B0) and registry 09-source-of-truth.md first.

Follow the neptune-abap-converter agent and the skill abap-adt-workflow (read-only part). Use the skill n2f-s3-backend with step B0.

Actions: Read via ADT MCP the DDIC definitions of ZMDG_PROJ_FORM, ZMDG_PROJ_FORM_S_READ_ONLY, ZMDG_PROJ_FORM_S_VISIBLE, ZMDG_PROJ_FORM_S_EDITABLE, ZMDG_ATT_REQ, ZCA_FORMDETAIL, ZCA_STEPDETAIL, ZHCM_S_EMPLOYEE_INFO, and the existence of the shared classes/FMs listed in B0. Update only registry 09 (confirmed DDIC differences), 07 if a boolean/date field is new, and the replacement register. Create: nothing. Delete: nothing.

Scope: compare live DDIC with docs/neptune-source/DB Model/. Confirm in particular CAPID / R_CAPID, PROJECT_TYPE and PROJECT_SUBTYPE in ZMDG_ATT_REQ, BRAND, LOCATION and PROJECT_SUBTYPE. Licence scan (register rows R-17, R-18): check every DDIC object the class uses, and the shared classes/FMs (ZCL_ND_CA_MDG_WORKFLOW, ZCL_ND_CA_UTILITIES, ZCL_ND_PROJECT_UTILITY, ZMDG_SEND_EMAIL, Z_MDG_CREATE_INTERNALORDER, Z_PS_COPY_TEMPLATE, Z_BAPI_BC_USER_GETLIST, ZCX_CA_FORM_EXCEPTIONS, ZCX_PROJECT_CODE_REQUEST), for components, parameters or code that use /NEPTUNE/ objects. Any hit blocks go-live; propose the standard replacement.

Out of scope: any SAP write, class creation, SEGW.

Replacement log (licence removal): list every name you find that starts with or contains NEPTUNE (namespace /NEPTUNE/, data element, structure, class, interface, variable, MIME/ICF path, literal) in what you read. Do not replace anything in this session. Propose the standard SAP data element/structure of the same type and length for each. Write docs/replacements/S3-B0-replacements.txt in the format of docs/replacements/framework-replacement-register.md (write "RESULT: none found" if none) and add proposed rows to the register.

When done: table object | field | printout | live | consequence, and the licence-scan result per object. Then the standard ABAP response block. Commit message: "S3 B0 DDIC confirmed".
```

---

## 8 · S3-B1 Create ZCL_UI_PROJECT_CODE_REQUEST · CRUD: R · C · U

Start with: `claude --agent neptune-abap-converter`

```text
Run backend step B1: create the Neptune-free class ZCL_UI_PROJECT_CODE_REQUEST in DEV. Read the skill neptune-to-segw-backend (B1), references/class-conversion-changes.md and .env first.

Follow the neptune-abap-converter agent and the skill abap-adt-workflow (confirm target before any write). Use the skill n2f-s3-backend with step B1.

Actions: Read docs/neptune-source/Backend Class/ProjectRequest App.txt. That repo copy is the source; the original class ZCL_NAD_PROJECT_CODE_REQUEST is not needed in SAP and may already be deleted. Run assets/convert_class.py with the workbench transport from .env as 4th argument (it turns <TR> in the conversion comments into the transport number) and diff its output with src/abap/ZCL_UI_PROJECT_CODE_REQUEST.clas.abap: only <TR> may differ; then save the output there. Create the class ZCL_UI_PROJECT_CODE_REQUEST in package <PACKAGE> on transport <TRANSPORT>, and only that class. Update its source from src/abap/, run the syntax check, activate. Update transports/transport-log.md. Delete: nothing.

Scope: the class as generated: 27 counted change groups, nothing else. If activation needs a TYPE-POOLS line, add exactly that line with the one-line comment " <transport> activation" and log it. Keep every original comment; new comments are one short line starting with the transport number.

Out of scope: logic changes, Clean ABAP refactoring, ABAP Unit test classes, SEGW, MPC/DPC, any other object, QA/PRD, releasing the transport. Target release: if .env says ECC / SAP_BASIS below 7.50, run the abaplint check from references/offline-checks.md with that release first and report syntax the release does not support. Do not rewrite code without my decision.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S3-B1-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: method list compared with Neptune (plus HANDLE_ON_AJAX and HANDLE_ON_REQUEST, minus the six /NEPTUNE/IF_NAD_SERVER methods), the activation result, then the standard ABAP response block. Stop before the first write and wait for my "yes". Commit message: "S3 B1 ZCL_UI_PROJECT_CODE_REQUEST activated".
```

---

## 9 · S3-B2 SEGW project (guided) · CRUD: R · U (registry)

Start with: `claude --agent neptune-abap-converter`

```text
Run backend step B2: guide me through creating the SEGW project ZDCI_UI_PROJECT_REQUEST and generating its runtime objects. Read the skill neptune-to-segw-backend (B2) and references/segw-steps.md first.

Follow the neptune-abap-converter agent. Use the skill n2f-s3-backend with step B2.

Actions: Read: after I report back, read the four generated classes via ADT MCP to confirm they exist. Update only registry 01-naming-registry.md (generated class names) and transports/transport-log.md. Create: nothing yourself. I create the SEGW project in SAP GUI. Delete: nothing.

Scope: exact click path for SEGW (no entity types modelled; the model is code-based), project ZDCI_UI_PROJECT_REQUEST, service ZDCI_UI_PROJECT_REQUEST_SRV, package and transport from .env. Wait for my result, then record the generated MPC, MPC_EXT, DPC and DPC_EXT names.

Out of scope: writing MPC_EXT/DPC_EXT (that is B3), service registration, any rename of generated names.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S3-B2-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: the standard ABAP response block with the four names. Commit message: "S3 B2 SEGW project generated".
```

---

## 10 · S3-B3 MPC_EXT / DPC_EXT + spike · CRUD: R · U

Start with: `claude --agent neptune-abap-converter`

```text
Run backend step B3: write MPC_EXT and DPC_EXT and prove the AJAX envelope with the spike. Read the skill neptune-to-segw-backend (B3), references/gateway-api-checklist.md, troubleshooting.md and registry 02 first.

Follow the neptune-abap-converter agent and the skill abap-adt-workflow. Use the skill n2f-s3-backend with step B3. In MPC_EXT/DPC_EXT replace <TR> in comments with the workbench transport from .env; new comments are one short line starting with the transport number.

Actions: Read the generated classes. Confirm src/abap/ZCL_ZDCI_UI_PROJECT_RE_MPC_EXT.clas.abap and _DPC_EXT.clas.abap carry the generated names (set in B2, registry 01), then update both classes in DEV (source, syntax check, activate). Update transports/transport-log.md. Create: nothing new in SAP. I register the service. Delete: nothing.

Scope: give me the click paths for /IWFND/MAINT_SERVICE and both cache cleanups. Run check_metadata.py on the $metadata I paste. Read the Gateway Client response of assets/gateway-client/00_spike_GET_DATA_new.json and check the pass criteria: HTTP 201, PAGE_HEADER, REQUEST_FROM, CAN_ATTACH, PROCESSING_REGION, GT_CURRENCY and GT_REQUEST_TYPE non-empty, ROW_INDEX 1..n.

Out of scope: changing ZCL_UI_PROJECT_CODE_REQUEST, adding COMMIT WORK, renaming OData artifacts, moving on to B4 if the spike fails.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S3-B3-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: pass/fail per criterion and the standard ABAP response block. If any criterion fails, stop and use troubleshooting.md. Commit message: "S3 B3 spike passed".
```

---

## 11 · S3-B4 Test every AJAX ID · CRUD: R · C (results)

Start with: `claude --agent neptune-abap-converter`

```text
Run backend step B4: test every AJAX ID of ZDCI_UI_PROJECT_REQUEST_SRV through the Gateway Client. Read registry 04-ajax-dispatch-inventory.md and the gateway-client assets first.

Follow the neptune-abap-converter agent. Use the skill n2f-s3-backend with step B4.

Actions: Read the responses I paste and the DB effects with queries/*.sql (read-only via ADT MCP or I run them). Create only docs/backend-ajax-results.md. Update registry 04 only if a result contradicts it (with evidence). Delete: nothing.

Scope: for each AJAX ID give me the request body (from assets or derived from the last GET_DATA response), the expected result and DB effect. Parity behaviour (P-01 CHECK no-op, P-04 NEW_INTENALORDER_WEXP no-op) counts as a pass. Use a test form; tell me before any state-changing call.

Out of scope: code changes, fixing parity items, frontend.

Replacement log (licence removal): list every name you find that starts with or contains NEPTUNE (namespace /NEPTUNE/, data element, structure, class, interface, variable, MIME/ICF path, literal) in what you read. Do not replace anything in this session. Propose the standard SAP data element/structure of the same type and length for each. Write docs/replacements/S3-B4-replacements.txt in the format of docs/replacements/framework-replacement-register.md (write "RESULT: none found" if none) and add proposed rows to the register.

When done: results table AJAX ID | HTTP | key fields | DB effect | pass/fail, then the standard ABAP response block. Commit message: "S3 B4 AJAX IDs tested".
```

---

## 12 · S3-B5–B7 Backend parity, attachment stream, hand-off · CRUD: R · U

Start with: `claude --agent neptune-abap-converter`

```text
Run backend steps B5, B6 and B7 for ZDCI_NAD_PROJECT_REQUEST. Read registry 05-parity-log.md, 06-capture-neptune-payloads.md and the skill neptune-to-segw-backend (B5–B7) first.

Follow the neptune-abap-converter agent. Use the skill n2f-s3-backend, starting with B5.

Actions: Read the Neptune and OData response pairs in docs/capture/ and run parity_diff.py. Update only MPC_EXT/DPC_EXT (if a difference is in the transport layer), registries 02, 04, 05, 07 and transports/transport-log.md. Create: the hand-off section in docs/backend-ajax-results.md. Delete: nothing.

Scope: B5: every difference is fixed in MPC_EXT/DPC_EXT or the registry, or logged as a new P-xx. B6: check ATTACHMENTSet(FORM='…',ATT='…')/$value for an existing and a wrong attachment. B7: hand-off with service URL, generated names, changed registry rows and new P-xx items.

Out of scope: changing business logic in ZCL_UI_PROJECT_CODE_REQUEST, releasing transports, frontend changes.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S3-B5-B7-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: difference table, B6 result, hand-off text, then the standard ABAP response block. Commit message: "S3 B5-B7 backend parity and hand-off".
```

---

## 13 · S4-F0/F1 Frontend offline checks · CRUD: R · C (local only)

Start with: `claude --agent neptune-ui5-converter`

```text
Run frontend steps F0 and F1 for the app zdci_nad_project_request. Read the skill neptune-to-ui5-frontend (F0, F1) and references/test-plan.md §1 first.

Follow the neptune-ui5-converter agent. Use the skill n2f-s4-frontend with scope F0-F1.

Actions: Read the app folder src/ui5/zdci_nad_project_request. Create only local, uncommitted artefacts: node_modules and the Playwright browser. Update: nothing in webapp unless a check fails and the fix is a mechanical one from js-port-rules.md. Ask first. Delete: nothing.

Scope: npm install, npm run test:unit, smoke test (npm run start-smoke in a second terminal, then npm run test:smoke), npm run lint. Explain each lint finding using test-plan.md §Lint (expected vs real).

Out of scope: backend calls, ui5.yaml backend settings, deployment, feature changes.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S4-F0F1-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: real output of each check (last lines), lint findings classified, and a yes/no on "ready for F3". Commit message only if a file changed: "S4 F1 offline checks".
```

---

## 14 · S4-F3 Frontend against the real service · CRUD: R · U

Start with: `claude --agent neptune-ui5-converter`

```text
Run frontend step F3: run zdci_nad_project_request against ZDCI_UI_PROJECT_REQUEST_SRV on DEV. Read references/ajax-client.md, test-plan.md §2 rows 1–6, and the B7 hand-off in docs/backend-ajax-results.md first.

Follow the neptune-ui5-converter agent. Use the skill n2f-s4-frontend with scope F3.

Actions: Read the network results I paste from the browser. Update only ui5.yaml (host, client, UI5 version from .env), and webapp files when a defect is proven against Neptune behaviour. Registries for confirmed facts. Create: nothing. Delete: nothing.

Scope: npm start, then test-plan §2 rows 1–6 (new request, existing draft, company code → cost center, cost center guard, search, save). For each failure use ajax-client.md §Troubleshooting and fix in the UI only.

Out of scope: backend changes (report them for the ABAP agent), deployment, rows 7–20 (S5).

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S4-F3-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: row-by-row result table, fixes made (file + reason), open issues for the backend. Commit message: "S4 F3 frontend on DEV".
```

---

## 15 · S5 Parity test Neptune vs UI5 · CRUD: R · C · U

Start with: `claude`

```text
Run session S5 (parity test) for ZDCI_NAD_PROJECT_REQUEST: Neptune vs UI5, side by side. Read references/test-plan.md §2–3 and registry 05-parity-log.md first.

Follow CLAUDE.md. Use the skill n2f-s5-parity-test, one test-plan row at a time.

Actions: Read the request/response bodies I save in docs/capture/ and the DB state via queries/*.sql (read-only). Create docs/parity-results.md. Update webapp files only for proven UI differences (verbatim rules), and registry 05 for new P-xx items. Delete: nothing.

Scope: rows 1–20 of test-plan §2 on twin test forms, for each role (requester, budget manager, FPA, RTR, BPC, display). Run parity_diff.py with --ignore FORM_GUID STEP_GUID START_TIME LATEST_STARTTIME. Also compare visibility, enabled and required per step.

Out of scope: backend logic changes, "fixing" Neptune bugs, deployment.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S5-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: parity-results.md with row | role | result | difference | action (fixed / P-xx), plus a summary of open items for the owner. Commit message: "S5 parity results".
```

---

## 16 · S6 Deploy to BSP + launchpad · CRUD: R · C · U

Start with: `claude --agent neptune-ui5-converter`

```text
Run session S6: deploy zdci_nad_project_request to BSP ZUI_PROJREQCODE on DEV and repoint the existing launchpad tile. Read references/deployment.md, ../../common/standards/transport-management.md and docs/parity-results.md first.

Follow the neptune-ui5-converter agent. Use the skill n2f-s6-deploy.

Actions: Read the current launchpad target mapping I describe. Create the BSP ZUI_PROJREQCODE through npm run deploy, on transport <TRANSPORT>, after my "yes". Update ui5-deploy.yaml (from .env) and transports/transport-log.md. I update the existing target mapping in SAP GUI. Delete: nothing (no undeploy).

Scope: confirm system, client, package and transport, then npm run build (show dist/ contents) and npm run deploy. Give me the target-mapping change (same semantic object/action, SAPUI5 app, URL /sap/bc/ui5_ui5/sap/zui_projreqcode, ID zdci_nad_project_request) and the checks after deploy (SE80, SICF, /UI5/APP_INDEX_CALCULATE, open the tile).

Out of scope: new tiles or catalogs, QA/PRD, transport release, removing the Neptune app.

Replacement log (licence removal): no object you create or change may start with or contain NEPTUNE or use /NEPTUNE/. Replace each one you find with a standard SAP data element/structure of the same type and length, or a local type built from standard data elements. Never create a new DDIC object without my approval. Follow docs/replacements/framework-replacement-register.md. Write docs/replacements/S6-replacements.txt (write "RESULT: none found" if none) and add rows to the register.

When done: deploy log summary, post-deploy check results, transport log updated. Commit message: "S6 deployed to ZUI_PROJREQCODE (DEV)".
```

---

## 17 · Review before sign-off · CRUD: R · C (log only)

Start with: `claude --agent neptune-parity-reviewer`

```text
Review the current state of the ZDCI_NAD_PROJECT_REQUEST conversion before sign-off. Read CLAUDE.md, registry 01, 05 and 08, and ../../common/standards/code-review-checklist.md first.

Follow the neptune-parity-reviewer agent (read-only).

Actions: Read the whole project, re-run assets/convert_class.py and diff with src/abap/, run verify_kit.py and npm run test:unit, read SAP objects with read-only ADT tools. Create: only docs/replacements/review-replacements.txt. Update: nothing. Delete: nothing.

Scope: names, ported function bodies vs Neptune, backend change groups, DPC_EXT without logic/COMMIT, registry consistency, open INF / TODO markers, overrides of the workspace standards respected.

Out of scope: fixing findings (list them for the right agent), SAP writes.

Replacement log (licence removal): list every name you find that starts with or contains NEPTUNE (namespace /NEPTUNE/, data element, structure, class, interface, variable, MIME/ICF path, literal) in what you read. Do not replace anything in this session. Propose the standard SAP data element/structure of the same type and length for each. Write docs/replacements/review-replacements.txt in the format of docs/replacements/framework-replacement-register.md (write "RESULT: none found" if none) and add proposed rows to the register.

When done: findings table severity | finding | evidence | suggested action | owner agent, then the list of checks that passed.
```

---

## 18 · Q&A · CRUD: R

Start with: `claude --agent neptune-parity-reviewer`

```text
Answer my question about the Neptune app ZDCI_NAD_PROJECT_REQUEST or its conversion. Read the registry skill references, CLAUDE.md and docs/neptune-source/ as needed.

Use the skill n2f-qa.

Actions: Read only. Create, Update, Delete: nothing, in the repo and in SAP.

Scope: answer with file citations (path and line where useful). If the answer is not in the files, say so and mark it as an assumption.

Out of scope: any change, any SAP access beyond read.

Replacement log: none for Q&A. If the answer involves an object whose name starts with or contains NEPTUNE, say so and point to docs/replacements/framework-replacement-register.md.

Question: <your question>
```

---

## 19 · Rollback / decommission plan · CRUD: R · C (plan only)

Start with: `claude`

```text
Prepare the rollback and later decommission plan for the Neptune app ZDCI_NAD_PROJECT_REQUEST after the UI5 go-live. Read ../../common/standards/transport-management.md §6, references/deployment.md §5 and transports/transport-log.md first.

Follow CLAUDE.md.

Actions: Read the transport log, deployment guide and the list of Neptune objects (app, class ZCL_NAD_PROJECT_CODE_REQUEST, shared library usage). Create only docs/rollback-decommission-plan.md. Update: nothing. Delete: nothing. This is a plan, nothing is executed.

Scope: rollback steps during hypercare (repoint the target mapping to Neptune; who, how long, checks); decommission candidates after sign-off, with dependencies (parent list app, shared ZDCI_NAD_SHARED library, other users of ZCL_NAD_PROJECT_CODE_REQUEST); the separate transport and approval each step needs.

Out of scope: deleting or deactivating anything, transport actions, changes to the new app.

Replacement log (licence removal): list every name you find that starts with or contains NEPTUNE (namespace /NEPTUNE/, data element, structure, class, interface, variable, MIME/ICF path, literal) in what you read. Do not replace anything in this session. Propose the standard SAP data element/structure of the same type and length for each. Write docs/replacements/rollback-replacements.txt in the format of docs/replacements/framework-replacement-register.md (write "RESULT: none found" if none) and add proposed rows to the register.

When done: the plan file with a checklist per phase and the open decisions for the owner. Commit message: "Rollback and decommission plan".
```
