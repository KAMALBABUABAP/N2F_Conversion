#!/usr/bin/env python3
"""Parse the original-app XML export of ZDCI_NAD_PROJECT_REQUEST and compare it with the kit (session S1, read-only).

Usage (run from the project folder, Python >= 3.9):
  python3 -I docs/capture/parse_export.py <export.xml> --structure [depth]   # top-level structure
  python3 -I docs/capture/parse_export.py <export.xml> --summary             # value distributions
  python3 -I docs/capture/parse_export.py <export.xml> --extract [outdir]    # JSON files for S2
  python3 -I docs/capture/parse_export.py <export.xml> --compare [outdir]    # extract + kit comparison

Export layout (agreed in S1): values/PROJECT/
  IT_CONTENT       controls (FIELD_ID, FIELD_NAME, FIELD_TYPE, FIELD_PARENT, FIELD_POS, DISABLED, EVENT_ID ...)
  IT_ATTRIBUTES    attributes per FIELD_ID (GROUPING Properties/Events/Associations/Model/Parent/Formatter)
  IT_BINDING       Model Source per control (BINDING = ABAP attribute)
  IT_EVENT_SCRIPT  event code, one line per row (FIELD_ID + EVENT, ordered by SEQNR)
  IT_MODEL         AJAX parameter table (AJAX FIELD_ID, MODEL = control, SEND, RECEIVE)
  IT_SCRIPT        script code per FIELD_ID (00000 global, Init, Utility, Form, oPageDialogs)
  IT_TABLE_FIELDS  column metadata per control;  IT_CSS_DESKTOP  inline CSS;  IT_PLUGIN  theme
"""
import difflib
import json
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import Counter, OrderedDict, defaultdict

KIT = 'src/ui5/zdci_nad_project_request'
WEBAPP = KIT + '/webapp'
REG = '.claude/skills/nad-project-request-registry/references'
CLASS_SRC = 'docs/neptune-source/Backend Class/ProjectRequest App.txt'
SRC_SCRIPTS = {'Init': 'docs/neptune-source/Init.txt', 'Utility': 'docs/neptune-source/Utility.txt',
               'Form': 'docs/neptune-source/form.txt', 'GLOBAL': 'docs/neptune-source/Global Script.txt'}

# original control type -> UI5 class (local name); None = no rendered control expected in the kit
TYPE_MAP = {
    'UM5_LABEL': 'Label', 'UM5_BUTTON': 'Button', 'UM5_TEXT': 'Text', 'UM5_COLUMN': 'Column',
    'UM5_INPUT': 'Input', 'UM5_SELECT': 'Select', 'UM5_DIALOG': 'Dialog', 'UM5_RADIO': 'RadioButton',
    'UM5_SFORM': 'SimpleForm', 'UM5_TEXTAR': 'TextArea', 'UM5_OPSUBS': 'ObjectPageSubSection',
    'UM5_STDITM': 'StandardListItem', 'UM5_SELDIA': 'SelectDialog', 'UM5_RADIOG': 'RadioButtonGroup',
    'UM5_OPSECT': 'ObjectPageSection', 'UM5_VBOX': 'VBox', 'UM5_HBOX': 'HBox',
    'UM5_OPBUTT': 'ObjectPageHeaderActionButton', 'UM5_DATE': 'DatePicker', 'UM5_LINK': 'Link',
    'UM5_TABLE': 'Table', 'UM5_COLITM': 'ColumnListItem', 'UM5_SWITCH': 'Switch', 'UM5_LIST': 'List',
    'UM5_PAGE': 'Page', 'UM5_BAR': 'Bar', 'UI5_VLAYOU': 'VerticalLayout', 'UM5_OBJATT': 'ObjectAttribute',
    'UM5_OBJSTA': 'ObjectStatus', 'UM5_TOOLBA': 'Toolbar', 'UM5_TOOLSE': 'ToolbarSpacer', 'UM5_ICON': 'Icon',
    'UM5_SHELL': 'Shell', 'UM5_APP': 'App', 'UM5_BUSYI': 'BusyIndicator', 'UM5_OPLAYO': 'ObjectPageLayout',
    'UM5_OPHEAD': 'ObjectPageHeader', 'UM5_OPCONT': 'ObjectPageHeaderContent', 'UM5_OBJITM': 'ObjectListItem',
    'UI5_FILEUP': 'FileUploader', 'UM5_POPOVR': 'ResponsivePopover', 'UI5_TABLE': 'Table',
    'UM5_FBOX': 'FlexBox', 'UM5_OPSUBC': None, 'UM5_BARCON': None, 'UM5_RESFOL': None, 'UM5_DBARR': None,
    'UM5_MESSAG': None, 'UM5_AJAX': None, 'SCRIPT': None, 'RESOURCES': None, 'HTML5 DOC': None,
}
# designer-only nodes: not controls in UI5 (aggregation placeholders, folders, scripts)
PSEUDO_TYPES = {'UM5_BARCON', 'UM5_RESFOL', 'SCRIPT', 'RESOURCES', 'HTML5 DOC', 'UM5_AJAX'}
# data-only types: become a named JSONModel, not a rendered control (registry 03/08)
DATA_TYPES = {'UM5_DBARR', 'UM5_MESSAG', 'UM5_FBOX'}
ASSOC_MAP = {'leftButton': 'beginButton', 'rightButton': 'endButton'}


# ------------------------------------------------------------------ generic XML helpers

def local(tag):
    return tag.split('}', 1)[-1] if isinstance(tag, str) else str(tag)


def project_node(root):
    return next(c for v in root if local(v.tag) == 'values' for c in v if local(c.tag) == 'PROJECT')


def rows(root, table):
    """Rows of an IT_* table as dicts (tag -> text)."""
    node = next((c for c in project_node(root) if local(c.tag) == table), None)
    if node is None:
        return []
    return [{local(f.tag): (f.text or '') for f in r} for r in node]


def section(root, name):
    node = next((c for c in project_node(root) if local(c.tag) == name), None)
    return {local(f.tag): (f.text or '') for f in node} if node is not None else {}


def print_structure(root, max_depth=4):
    print(f"ROOT <{local(root.tag)}> attrs={sorted(root.attrib)} children={len(root)}")

    def walk(node, depth, path):
        if depth > max_depth:
            return
        kids = Counter(local(c.tag) for c in node)
        seen = OrderedDict()
        for c in node:
            seen.setdefault(local(c.tag), c)
        for tag, sample in seen.items():
            text = (sample.text or '').strip().replace('\n', ' ')
            info = f" text[{len(text)}]='{text[:60]}'" if text and len(sample) == 0 else ''
            print(f"{'  ' * depth}{path}/{tag}  x{kids[tag]}  children={len(sample)}"
                  f" attrs={sorted(sample.attrib)[:8]}{info}")
            walk(sample, depth + 1, f"{path}/{tag}")

    walk(root, 1, '')


def print_summary(root):
    content = rows(root, 'IT_CONTENT')
    print(f"IT_CONTENT rows={len(content)}")
    print('  FIELD_TYPE:', Counter(r['FIELD_TYPE'] for r in content).most_common())
    for table, keys in [('IT_ATTRIBUTES', ['GROUPING']), ('IT_EVENT_SCRIPT', ['EVENT']),
                        ('IT_BINDING', ['BIND_TYPE']), ('IT_TABLE_FIELDS', ['TABNAME'])]:
        data = rows(root, table)
        print(f"{table} rows={len(data)}")
        for k in keys:
            print(f"  {k}:", Counter(r.get(k, '') for r in data).most_common(25))
    for table in ['IT_SCRIPT', 'IT_MODEL', 'IT_BINDING', 'IT_PLUGIN', 'IT_TABLE_FIELDS', 'IT_CSS_DESKTOP']:
        print(f"{table} sample:", rows(root, table)[:2])
    print('IT_SCRIPT FIELD_IDs:', Counter(r['FIELD_ID'] for r in rows(root, 'IT_SCRIPT')).most_common())


# ------------------------------------------------------------------ extraction

FUNC_RE = re.compile(r'^\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(|^\s*(?:var\s+)?([A-Za-z_$][\w$]*)\s*=\s*function\s*\(')


def script_functions(code):
    out = []
    for i, line in enumerate(code.split('\n'), 1):
        m = FUNC_RE.match(line)
        if m:
            out.append({'name': m.group(1) or m.group(2), 'line': i})
    return out


def function_bodies(code):
    """name -> source of each top-level function (brace matching, strings/comments ignored roughly)."""
    bodies = {}
    lines = code.split('\n')
    for f in script_functions(code):
        start = f['line'] - 1
        depth, started, buf = 0, False, []
        for line in lines[start:]:
            buf.append(line)
            clean = re.sub(r'//.*$|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'', '', line)
            depth += clean.count('{') - clean.count('}')
            started = started or '{' in clean
            if started and depth <= 0:
                break
        src = '\n'.join(buf)
        # inner body only (header "function x(a) {" and the closing brace removed)
        bodies[f['name']] = src[src.find('{') + 1:src.rfind('}')] if '{' in src else src
    return bodies


def extract(root):
    content = rows(root, 'IT_CONTENT')
    by_id = {c['FIELD_ID']: c for c in content}
    name_of = lambda fid: by_id.get(fid, {}).get('FIELD_NAME', '')
    bind = {b['FIELD_ID']: b for b in rows(root, 'IT_BINDING')}

    controls = []
    for c in sorted(content, key=lambda x: (int(x['FIELD_POS'] or 0), x['FIELD_ID'])):
        b = bind.get(c['FIELD_ID'], {})
        controls.append({
            'field_id': c['FIELD_ID'], 'name': c['FIELD_NAME'], 'type': c['FIELD_TYPE'],
            'ui5_type': TYPE_MAP.get(c['FIELD_TYPE']), 'parent_id': c['FIELD_PARENT'],
            'parent': name_of(c['FIELD_PARENT']), 'pos': int(c['FIELD_POS'] or 0),
            'descr': c['DESCR'], 'disabled': c['DISABLED'] == 'X', 'is_container': c['IS_CONTAINER'] == 'X',
            'event_id': c['EVENT_ID'], 'model_source': b.get('BINDING', ''), 'bind_type': b.get('BIND_TYPE', ''),
            'combo_tech': c['COMBO_TECH'], 'sh': c['SH'], 'sh_key': c['SH_KEY'],
        })

    attributes = [{'field_id': a['FIELD_ID'], 'control': name_of(a['FIELD_ID']), 'grouping': a['GROUPING'],
                   'attribute': a['ATTRIBUTE'], 'value': a['VALUE']} for a in rows(root, 'IT_ATTRIBUTES')]

    bindings = [{'field_id': b['FIELD_ID'], 'control': name_of(b['FIELD_ID']), 'abap_attribute': b['BINDING'],
                 'bind_type': b['BIND_TYPE'], 'bind_object': b['BIND_OBJECT']} for b in rows(root, 'IT_BINDING')]

    ev_lines = defaultdict(list)
    for e in rows(root, 'IT_EVENT_SCRIPT'):
        ev_lines[(e['FIELD_ID'], e['EVENT'])].append((int(e['SEQNR']), e['TEXT']))
    ev_attr = {(a['field_id'], a['attribute']): a['value'] for a in attributes
               if a['grouping'] == 'Events' or (a['grouping'] == 'Formatter' and a['value'] == 'Anonymous Function')}
    events = []
    for key in sorted(set(ev_lines) | {k for k in ev_attr if ev_attr[k] == 'Anonymous Function' or k[1] in
                                       {e for (_, e) in ev_lines}}):
        fid, ev = key
        code = '\n'.join(t for _, t in sorted(ev_lines.get(key, [])))
        attr_val = ev_attr.get(key, '')
        if not code and attr_val and attr_val != 'Anonymous Function':
            code = attr_val
        events.append({'field_id': fid, 'control': name_of(fid), 'type': by_id.get(fid, {}).get('FIELD_TYPE', ''),
                       'event': ev, 'attribute_value': attr_val, 'code': code})
    # Events-group attributes whose value is inline code / a call and have no event-script rows
    for (fid, ev), val in ev_attr.items():
        if (fid, ev) not in ev_lines and val != 'Anonymous Function' and not any(
                e['field_id'] == fid and e['event'] == ev for e in events):
            events.append({'field_id': fid, 'control': name_of(fid), 'type': by_id.get(fid, {}).get('FIELD_TYPE', ''),
                           'event': ev, 'attribute_value': val, 'code': val})

    model_src = {b['field_id']: b['abap_attribute'] for b in bindings}
    ctrl_by_name = {c['name']: c for c in controls}
    models = defaultdict(list)
    for m in rows(root, 'IT_MODEL'):
        ctrl = ctrl_by_name.get(m['MODEL'])
        models[m['FIELD_ID']].append({
            'model': m['MODEL'], 'abap_attribute': model_src.get(ctrl['field_id'], '') if ctrl else '',
            'send': m['SEND'] == 'X', 'receive': m['RECEIVE'] == 'X', 'model_id': m['MODEL_ID'],
            'resolved': bool(ctrl and model_src.get(ctrl['field_id']))})
    ajax = []
    for c in controls:
        if c['type'] != 'UM5_AJAX':
            continue
        code = {e['event']: e['code'] for e in events if e['field_id'] == c['field_id']}
        ajax.append({'field_id': c['field_id'], 'name': c['name'], 'ajax_id': c['event_id'],
                     'fn': 'getOnline' + c['name'], 'pos': c['pos'],
                     'models': sorted(models.get(c['field_id'], []), key=lambda x: x['model_id']),
                     'ajaxSuccess': code.get('ajaxSuccess', ''), 'ajaxError': code.get('ajaxError', '')})

    sc_lines = defaultdict(list)
    for s in rows(root, 'IT_SCRIPT'):
        sc_lines[s['FIELD_ID']].append((int(s['SEQNR']), s['TEXT']))
    scripts = []
    for fid, lines in sorted(sc_lines.items()):
        code = '\n'.join(t for _, t in sorted(lines))
        scripts.append({'field_id': fid, 'name': name_of(fid) or 'GLOBAL', 'code': code,
                        'functions': script_functions(code)})

    tf = defaultdict(list)
    for t in rows(root, 'IT_TABLE_FIELDS'):
        tf[t['FIELD_ID']].append({k.lower(): v for k, v in t.items() if k not in ('APPLID', 'VERSION')})
    table_fields = [{'field_id': fid, 'control': name_of(fid) or None, 'fields': v} for fid, v in sorted(tf.items())]

    css = '\n'.join(t for _, t in sorted((int(r['SEQNR']), r['TEXT']) for r in rows(root, 'IT_CSS_DESKTOP')))
    app = section(root, 'APPLICATION')
    header = {k: app.get(k, '') for k in ('APPLID', 'VERSION', 'CLSNAME', 'TITLE', 'DESCR', 'SAPUI5_VERSION',
                                           'TR_ORDER', 'UPDDAT', 'UPDNAM', 'DEVCLASS', 'UI5_LANGUAGE', 'LIBRARY')}
    header['THEME_PLUGINS'] = rows(root, 'IT_PLUGIN')
    return {'header': header, 'controls': controls, 'attributes': attributes, 'bindings': bindings,
            'events': events, 'ajax': ajax, 'scripts': scripts, 'table_fields': table_fields, 'css': css}


def neptune_hits(root, data):
    """Every occurrence of 'neptune' in names, values, code lines (case-insensitive)."""
    hits = []
    tables = Counter(local(r.tag) for t in project_node(root) for r in t if 'NEPTUNE' in local(r.tag).upper())
    for tag, n in sorted(tables.items()):
        hits.append({'where': f'XML row tag values/PROJECT/*/{tag}', 'text': f'{tag} x{n}', 'kind': 'export container'})
    for c in data['controls']:
        for k in ('name', 'descr', 'model_source', 'event_id', 'combo_tech', 'sh', 'sh_key'):
            if 'neptune' in (c[k] or '').lower():
                hits.append({'where': f"IT_CONTENT {c['field_id']} {c['name']}.{k}", 'text': c[k], 'kind': 'name'})
    for a in data['attributes']:
        if 'neptune' in a['value'].lower() or 'neptune' in a['attribute'].lower():
            hits.append({'where': f"IT_ATTRIBUTES {a['control']}.{a['attribute']}", 'text': a['value'], 'kind': 'value'})
    for e in data['events']:
        for i, line in enumerate(e['code'].split('\n'), 1):
            if 'neptune' in line.lower():
                hits.append({'where': f"IT_EVENT_SCRIPT {e['control']}.{e['event']} line {i}", 'text': line.strip(),
                             'kind': 'script'})
    for s in data['scripts']:
        for i, line in enumerate(s['code'].split('\n'), 1):
            if 'neptune' in line.lower():
                hits.append({'where': f"IT_SCRIPT {s['name']} line {i}", 'text': line.strip(), 'kind': 'script'})
    for i, line in enumerate(data['css'].split('\n'), 1):
        if 'neptune' in line.lower():
            hits.append({'where': f'IT_CSS_DESKTOP line {i}', 'text': line.strip(), 'kind': 'css'})
    for k, v in data['header'].items():
        if 'neptune' in str(v).lower():
            hits.append({'where': f'APPLICATION.{k}', 'text': str(v), 'kind': 'header'})
    return hits


def write_extract(data, hits, outdir):
    os.makedirs(outdir, exist_ok=True)
    for key in ('header', 'controls', 'attributes', 'bindings', 'events', 'ajax', 'scripts', 'table_fields'):
        with open(os.path.join(outdir, key + '.json'), 'w') as f:
            json.dump(data[key], f, indent=1, ensure_ascii=False)
    with open(os.path.join(outdir, 'css.json'), 'w') as f:
        json.dump({'it_css_desktop': data['css']}, f, indent=1, ensure_ascii=False)
    with open(os.path.join(outdir, 'neptune_hits.json'), 'w') as f:
        json.dump(hits, f, indent=1, ensure_ascii=False)
    for s in data['scripts']:
        with open(os.path.join(outdir, f"script_{s['field_id']}_{s['name']}.js"), 'w') as f:
            f.write(s['code'] + '\n')


# ------------------------------------------------------------------ kit side

class KitNode:
    def __init__(self, el, tag, file, aggregation, parent, order):
        self.el, self.tag, self.file, self.aggregation, self.parent, self.order = el, tag, file, aggregation, parent, order
        self.id = el.attrib.get('id')
        self.attrs = {k: v for k, v in el.attrib.items() if k != 'id'}


def find_line(path, needle):
    with open(path) as f:
        for i, line in enumerate(f, 1):
            if needle in line:
                return i
    return 0


def load_kit_views():
    """All id'd elements of Main.view.xml with fragments inlined at their core:Fragment position."""
    nodes, order = {}, [0]
    frag_dir = WEBAPP + '/view/fragments'

    def walk(el, file, id_parent, aggregation):
        tag = local(el.tag)
        if tag == 'Fragment' and 'fragmentName' in el.attrib:
            fname = el.attrib['fragmentName'].split('.')[-1]
            fpath = f'{frag_dir}/{fname}.fragment.xml'
            froot = ET.parse(fpath).getroot()
            for child in froot:
                walk(child, fpath, id_parent, aggregation)
            return
        is_aggr = tag[:1].islower() and not el.attrib  # aggregation element like <content>, <beginButton>
        if is_aggr:
            for child in el:
                walk(child, file, id_parent, tag)
            return
        node_parent = id_parent
        if 'id' in el.attrib:
            order[0] += 1
            n = KitNode(el, tag, file, aggregation, id_parent, order[0])
            nodes[n.id] = n
            node_parent = n
        for child in el:
            walk(child, file, node_parent, aggregation if 'id' not in el.attrib else None)

    walk(ET.parse(WEBAPP + '/view/Main.view.xml').getroot(), WEBAPP + '/view/Main.view.xml', None, None)
    return nodes


def load_controller():
    path = WEBAPP + '/controller/Main.controller.js'
    src = open(path).read()
    lines = src.split('\n')
    methods = OrderedDict()
    starts = [(i, m.group(1)) for i, l in enumerate(lines) for m in [re.match(r'^ {8}([A-Za-z_$][\w$]*)\s*:\s*function', l)] if m]
    for k, (i, name) in enumerate(starts):
        end = starts[k + 1][0] if k + 1 < len(starts) else len(lines)
        methods[name] = {'line': i + 1, 'body': '\n'.join(lines[i:end])}
    return path, methods


def load_ajax_config():
    js = ("global.sap={ui:{define:function(d,f){process.stdout.write(JSON.stringify(f()))}}};"
          f"require(process.cwd()+'/{WEBAPP}/util/AjaxConfig.js');")
    out = subprocess.run(['node', '-e', js], capture_output=True, text=True, check=True).stdout
    return json.loads(out)


def load_model_registry():
    src = open(WEBAPP + '/util/ModelRegistry.js').read()
    return {m.group(1): m.group(2) for m in re.finditer(r'\["([\w$]+)",\s*"([\w$]*)"', src)}


def load_i18n():
    path = WEBAPP + '/i18n/i18n.properties'
    out = {}
    for i, line in enumerate(open(path), 1):
        if '=' in line and not line.lstrip().startswith('#'):
            k, v = line.rstrip('\n').split('=', 1)
            out[k.strip()] = {'value': v, 'line': i}
    return path, out


def load_dispatcher():
    lines = open(CLASS_SRC, encoding='utf-8', errors='replace').read().split('\n')
    ids, in_case = {}, False
    for i, l in enumerate(lines, 1):
        if re.match(r'\s*CASE ajax_id\.', l, re.I):
            in_case = True
        elif in_case and re.match(r'\s*ENDCASE\.', l, re.I) and len(l) - len(l.lstrip()) <= 4:
            in_case = False
        if in_case:
            m = re.match(r"\s{6}WHEN '([A-Z_0-9]+)'", l)
            if m:
                ids[m.group(1)] = i
    # commented-out WHEN branches (e.g. NEW_INTENALORDER*)
    commented = {m.group(1): i for i, l in enumerate(lines, 1)
                 for m in [re.match(r"^\*\s*WHEN '([A-Z_0-9]+)'", l)] if m}
    return ids, commented


def load_registry04():
    path = REG + '/04-ajax-dispatch-inventory.md'
    ids = {}
    for i, l in enumerate(open(path), 1):
        m = re.match(r'\| (\d+) \| `([A-Z_0-9]+)` \|', l)
        if m:
            ids[m.group(2)] = i
    return path, ids


# ------------------------------------------------------------------ comparison helpers

def norm_code(code):
    """Token list after the mechanical replacements of js-port-rules.md (applied to both sides)."""
    code = re.sub(r'/\*.*?\*/', ' ', code, flags=re.S)
    code = re.sub(r'//[^\n]*', ' ', code)
    code = re.sub(r'jQuery\.sap\.require\([^)]*\)\s*;?', ' ', code)
    code = re.sub(r'\bdebugger\s*;?', ' ', code)
    code = code.replace('.getData()', '.oData').replace('oEvent.getSource()', 'oEvent.oSource')
    code = re.sub(r'\bsap\.ui\.core\.(ValueState|Item)\b', r'\1', code)
    code = re.sub(r'\bsap\.ui\.model\.(Filter)\b', r'\1', code)
    code = re.sub(r'\bsap\.m\.(\w+)\b', r'\1', code)
    code = re.sub(r'(?<![\w.])\$\.each\b', 'jQuery.each', code)
    # inline aliases of the port pattern: this.byId("X") == X, this.model("X") == modelX, this._txt("X") == X
    code = re.sub(r'this\.(?:byId|_txt)\("([\w$]+)"\)', r'\1', code)
    code = re.sub(r'this\.model\("([\w$]+)"\)', r'model\1', code)
    code = re.sub(r'\bthis\.', '', code)
    return re.findall(r'[\w$]+|[^\s\w]', code)


ALIAS_PIECE = re.compile(r'^\s*[\w$]+\s*=\s*(this\.(byId|model|_txt)\([^()]*\)|this\.[\w$]+(\.bind\(this\))?|this)\s*;?\s*$')


def kit_body(method_src):
    """Drop the controller wrapper and the pure local-alias lines the port pattern adds."""
    all_lines = method_src.split('\n')
    head = all_lines[0]
    inline = head[head.find('{') + 1:] if '{' in head else ''
    if inline.strip():  # one-line method: "x: function () { body },"
        return re.sub(r'\}\s*,?\s*$', '', inline)
    lines = all_lines[1:]
    # cut after the method's closing brace (8-space indent), dropping comments of the next method
    last = max((i for i, l in enumerate(lines) if re.match(r'^ {8}\},?\s*$', l)), default=len(lines))
    out = []
    for l in lines[:last]:
        code = re.sub(r'//.*$', '', l).strip()
        if code:
            pieces = re.sub(r'^var\s+', '', code).rstrip(';,').split(',')
            if all(ALIAS_PIECE.match(p) for p in pieces):
                continue
        out.append(l)
    return '\n'.join(out)


def similarity(nep, kit):
    a, b = norm_code(nep), norm_code(kit)
    if not a and not b:
        return 1.0
    return difflib.SequenceMatcher(None, a, b, autojunk=False).ratio()


BIND_RE = re.compile(r'\{([A-Z0-9_]+)-([A-Z0-9_/]+)\}')


def expected_binding(value, control, ancestors, model_src):
    """Original {ATTR-FIELD} -> expected kit {X>/FIELD} or {X>FIELD} (table templates)."""
    def repl(m):
        attr, field = m.group(1), m.group(2)
        for anc in [control] + ancestors:
            if model_src.get(anc) == attr:
                return '{%s>%s%s}' % (anc, '' if attr.startswith('GT_') else '/', field)
        return '{?%s>/%s}' % (attr, field)
    return BIND_RE.sub(repl, value)


def esc(s, n=120):
    s = (s or '').replace('|', '\\|').replace('\n', ' ⏎ ')
    return s if len(s) <= n else s[:n - 1] + '…'


def rel(path):
    return path


# ------------------------------------------------------------------ compare

def compare(data, outdir):
    ctrls = {c['name']: c for c in data['controls']}
    by_fid = {c['field_id']: c for c in data['controls']}
    kit = load_kit_views()
    ctl_path, methods = load_controller()
    ajax_cfg = load_ajax_config()
    model_reg = load_model_registry()
    i18n_path, i18n = load_i18n()
    dispatcher, commented_when = load_dispatcher()
    reg04_path, reg04 = load_registry04()
    model_src = {c['name']: c['model_source'] for c in data['controls'] if c['model_source']}

    def ancestors(name):
        out, c = [], ctrls.get(name)
        while c and c['parent_id'] in by_fid:
            c = by_fid[c['parent_id']]
            out.append(c['name'])
        return out

    def kloc(node):
        line = find_line(node.file, 'id="%s"' % node.id)
        return node.file.replace(WEBAPP + '/', '') + ':' + str(line)

    def mloc(name):
        return f"controller/Main.controller.js:{methods[name]['line']}" if name in methods else ''

    res = OrderedDict()

    # ---------- 1. control ids
    rows_ = []
    for c in data['controls']:
        if c['type'] in PSEUDO_TYPES:
            continue
        n = kit.get(c['name'])
        xml = f"IT_CONTENT {c['field_id']} ({c['type']}{', DISABLED' if c['disabled'] else ''})"
        if n:
            exp = c['ui5_type']
            st = 'same' if (exp is None or exp == n.tag) else 'different'
            note = '' if st == 'same' else f'type {c["type"]}→{exp} vs kit {n.tag}'
            if c['disabled']:
                st, note = 'different', (note + '; ' if note else '') + 'DISABLED in original (not rendered) but present in kit'
            rows_.append([c['name'], f"{n.tag} #{c['name']}", st, f"{xml}; {kloc(n)} {note}".strip()])
        elif c['parent'] == 'Translate':
            st = 'same' if c['name'] in i18n else 'missing in kit'
            rows_.append([c['name'], f"i18n key {c['name']}" if st == 'same' else '—', st,
                          f"{xml}; hidden text in Translate folder → i18n key (see texts table)"])
        elif c['type'] in DATA_TYPES or c['name'] in model_reg:
            st = 'same' if c['name'] in model_reg else 'missing in kit'
            rows_.append([c['name'], 'JSONModel only' if st == 'same' else '—', st,
                          f"{xml}; data-only, util/ModelRegistry.js {'has' if st == 'same' else 'lacks'} '{c['name']}'"])
        elif c['disabled']:
            rows_.append([c['name'], '—', 'same', f"{xml}; DISABLED in original → not rendered; kit omits it"])
        else:
            rows_.append([c['name'], '—', 'missing in kit', xml])
    for kid, n in kit.items():
        if kid not in ctrls:
            rows_.append(['—', f'{n.tag} #{kid}', 'extra in kit', kloc(n)])
    res['controls'] = rows_

    # ---------- 2. attributes (Properties, Formatter, Parent, Model, Associations)
    rows_ = []
    for a in data['attributes']:
        if a['grouping'] == 'Events':
            continue
        c = ctrls.get(a['control'])
        if not c or c['type'] in PSEUDO_TYPES:
            continue
        n = kit.get(a['control'])
        item = f"{a['control']}.{a['attribute']} [{a['grouping']}] = {esc(a['value'], 70)}"
        ev = f"IT_ATTRIBUTES {a['field_id']}"
        if not n:
            if c['disabled'] or c['type'] in DATA_TYPES:
                continue
            rows_.append([item, '—', 'missing in kit', ev + '; control not in kit'])
            continue
        if a['grouping'] == 'Parent':
            agg = n.aggregation or ''
            want = a['value'][3:] if a['value'][:3] in ('set', 'add') else a['value']
            want = want[:1].lower() + want[1:]
            st = 'same' if agg and (agg.lower().startswith(want.lower().rstrip('s')) or want.lower().startswith(agg.lower().rstrip('s'))) else 'different'
            rows_.append([item, f"aggregation <{agg or '(default)'}>", st, f"{ev}; {kloc(n)}"])
            continue
        if a['grouping'] == 'Associations':
            target = kit.get(a['value'])
            want = ASSOC_MAP.get(a['attribute'], a['attribute'])
            got = target.aggregation if target and target.parent is n else None
            if got is None and a['attribute'] in n.attrs:
                got = a['attribute']
            st = 'same' if got == want or (got and got == a['attribute']) else ('missing in kit' if got is None else 'different')
            rows_.append([item, f"{a['value']} in <{got}>" if got else '—', st,
                          f"{ev}; {kloc(n)}; mapping {a['attribute']}→{want}"])
            continue
        if a['grouping'] == 'Model':
            rows_.append([item, '—', 'missing in kit',
                          f"{ev}; original model cache setting, no kit equivalent (ModelRegistry/AjaxRuntime)"])
            continue
        if a['grouping'] == 'Formatter':
            kv = n.attrs.get(a['attribute'], '')
            if a['value'] == 'Anonymous Function':
                st = 'same' if 'formatter' in kv else ('missing in kit' if not kv else 'different')
            else:
                st = 'same' if a['value'] in kv else ('missing in kit' if not kv else 'different')
            rows_.append([item, f"{a['attribute']}=\"{esc(kv, 60)}\"" if kv else '—', st, f"{ev}; {kloc(n)}"])
            continue
        attr = a['attribute']
        kv = n.attrs.get(attr)
        if attr == 'styleClass':
            kv = n.attrs.get('class')
        exp = expected_binding(a['value'], a['control'], ancestors(a['control']), model_src) if '{' in a['value'] else a['value']
        if kv is None:
            st = 'missing in kit'
        elif kv.replace(' ', '') == exp.replace(' ', ''):
            st = 'same'
        elif '{' in exp and re.sub(r"[{}\s]|path:|'", '', kv).startswith(re.sub(r'[{}\s]', '', exp)):
            st = 'same'
        else:
            st = 'different'
        rows_.append([item, f"{'class' if attr == 'styleClass' else attr}=\"{esc(kv, 60)}\"" if kv is not None else '—', st,
                      f"{ev}; {kloc(n)}" + (f"; expected `{esc(exp, 60)}`" if st == 'different' and exp != a['value'] else '')])
    # kit attributes not in the export (only for controls that exist in both)
    nep_attrs = defaultdict(set)
    for a in data['attributes']:
        nep_attrs[a['control']].add(a['attribute'])
    skip = {'press', 'change', 'select', 'search', 'liveChange', 'confirm', 'beforeOpen', 'valueHelpRequest',
            'delete', 'items', 'class', 'beginButton', 'endButton'}
    for kid, n in kit.items():
        if kid in ctrls and ctrls[kid]['type'] not in PSEUDO_TYPES:
            for k, v in n.attrs.items():
                if k not in nep_attrs[kid] and k not in skip and not (k == 'class' and 'styleClass' in nep_attrs[kid]):
                    rows_.append([f'{kid}.{k} (not set in original)', f'{k}="{esc(v, 60)}"', 'extra in kit', kloc(n)])
    res['attributes'] = rows_

    # ---------- 3. hierarchy (differences only)
    # agreed equivalences: oPageDialogs (detail page holding the dialogs) == kit <dependents> of oPageProj;
    # a control referenced by leftButton/rightButton/... belongs to the control that references it
    assoc_owner = {a['value']: a['control'] for a in data['attributes'] if a['grouping'] == 'Associations'}
    alias = {'oPageDialogs': 'oPageProj'}

    def nep_parent(name):
        if name in assoc_owner:
            return assoc_owner[name]
        for a in ancestors(name):
            a = alias.get(a, a)
            if a in kit:
                return a
        return None

    rows_ = []
    common = [c for c in data['controls'] if c['name'] in kit and c['type'] not in PSEUDO_TYPES]
    for c in common:
        nep_par = nep_parent(c['name'])
        k = kit[c['name']].parent
        kit_par = k.id if k else None
        if nep_par != kit_par:
            rows_.append([c['name'], f"original parent {nep_par} (direct {c['parent']})", f"kit parent {kit_par}",
                          f"IT_CONTENT {c['field_id']} FIELD_PARENT {c['parent_id']}; {kloc(kit[c['name']])}"])
    # sibling order within the same kit aggregation (dependents and association targets excluded: no visual order)
    groups = defaultdict(list)
    for c in common:
        n = kit[c['name']]
        if n.aggregation == 'dependents' or c['name'] in assoc_owner:
            continue
        groups[(n.parent.id if n.parent else None, n.aggregation)].append(c)
    for (par, agg), kids in groups.items():
        nep_order = [c['name'] for c in sorted(kids, key=lambda x: x['pos'])]
        kit_order = [c['name'] for c in sorted(kids, key=lambda x: kit[x['name']].order)]
        if nep_order != kit_order:
            rows_.append([f'children of {par} <{agg or "default"}>', 'original order: ' + ', '.join(nep_order),
                          'kit order: ' + ', '.join(kit_order), 'FIELD_POS vs document order'])
    res['hierarchy'] = rows_

    # ---------- 4. events
    rows_ = []
    for e in data['events']:
        if e['type'] == 'UM5_AJAX':
            continue
        c = ctrls.get(e['control'])
        if e['event'] == 'text':  # formatter code
            meth = None
        n = kit.get(e['control'])
        mname = f"{e['control']}_{e['event']}"
        item = f"{e['control']}.{e['event']}"
        ev = f"IT_EVENT_SCRIPT {e['field_id']}/{e['event']} ({len(e['code'].splitlines())} lines)"
        if e['event'] == 'text':
            kv = n.attrs.get('text', '') if n else ''
            st = 'same' if 'formatter' in kv else ('missing in kit' if not n or not kv else 'different')
            rows_.append([item + ' (formatter)', f'text="{esc(kv, 50)}"' if kv else '—', st, ev + (f'; {kloc(n)}' if n else '')])
            continue
        if c and c['disabled'] and not n:
            rows_.append([item, '—', 'same', ev + '; control DISABLED in original, not in kit'])
            continue
        wired = n.attrs.get(e['event'], '') if n else ''
        has_m = mname in methods
        if not has_m and not wired:
            rows_.append([item, '—', 'missing in kit', ev + ('' if n else '; control not in kit')])
            continue
        body = methods.get(mname, {}).get('body', '')
        ratio = similarity(e['code'], kit_body(body)) if has_m else 0
        inferred = 'TODO(SPEC-MISSING)' in body
        st = 'same' if has_m and wired.lstrip('.') == mname and ratio >= 0.85 and not inferred else 'different'
        notes = []
        if wired.lstrip('.') != mname:
            notes.append(f'view wires {e["event"]}="{wired}"' if wired else 'event not wired in view')
        if inferred:
            notes.append('kit body marked TODO(SPEC-MISSING)')
        rows_.append([item, f'{mname}()' if has_m else '—', st,
                      f"{ev}; {mloc(mname) or (kloc(n) if n else '')}; similarity {ratio:.2f}" + ('; ' + '; '.join(notes) if notes else '')])
    nep_ev = {f"{e['control']}_{e['event']}" for e in data['events']}
    for m in methods:
        mm = re.match(r'^(\w+?)_(press|change|select|search|liveChange|confirm|beforeOpen|valueHelpRequest|delete)$', m)
        if mm and m not in nep_ev:
            rows_.append(['—', f'{m}()', 'extra in kit', mloc(m)])
    res['events'] = rows_

    # ---------- 5. AJAX objects
    ajax_rows, pair_rows = [], []
    nep_ids = {}
    for a in data['ajax']:
        aid = a['ajax_id']
        nep_ids.setdefault(aid, []).append(a['name'])
        cfg = ajax_cfg.get(aid)
        disp = dispatcher.get(aid)
        r4 = reg04.get(aid)
        ev = (f"IT_CONTENT {a['field_id']} EVENT_ID={aid or '(none)'}; class "
              f"{'WHEN line ' + str(disp) if disp else ('commented WHEN line ' + str(commented_when[aid]) if aid in commented_when else 'no WHEN')}"
              f"; registry 04 {'line ' + str(r4) if r4 else 'absent'}")
        if not cfg:
            ajax_rows.append([f"{a['name']} ({aid})", '—', 'missing in kit', ev])
        else:
            st = 'same' if cfg.get('fn') == a['fn'] else 'different'
            ajax_rows.append([f"{a['name']} ({aid}) fn {a['fn']}", f"AjaxConfig.{aid} fn {cfg.get('fn')} [{cfg.get('evidence')}]", st, ev])
        # send / receive pairs
        nep_s = {(m['model'], m['abap_attribute']) for m in a['models'] if m['send']}
        nep_r = {(m['model'], m['abap_attribute']) for m in a['models'] if m['receive']}
        unresolved = [m['model'] for m in a['models'] if not m['resolved']]
        kit_s = {tuple(p) for p in (cfg or {}).get('send', [])}
        kit_r = {tuple(p) for p in (cfg or {}).get('receive', [])}
        for pair in sorted(nep_s | nep_r | kit_s | kit_r):
            ns, nr, ks, kr = pair in nep_s, pair in nep_r, pair in kit_s, pair in kit_r
            nf = ('S' if ns else '-') + ('R' if nr else '-')
            kf = ('S' if ks else '-') + ('R' if kr else '-')
            if not cfg:
                st = 'missing in kit'
            elif nf == kf:
                st = 'same'
            elif nf == '--':
                st = 'extra in kit'
            elif kf == '--':
                st = 'missing in kit'
            else:
                st = 'different'
            pair_rows.append([aid or a['name'], f'[{pair[0]}, {pair[1] or "?unresolved"}]', nf, kf, st])
        a['unresolved_models'] = unresolved
    for aid, cfg in ajax_cfg.items():
        if aid not in nep_ids:
            ajax_rows.append(['—', f"AjaxConfig.{aid} fn {cfg.get('fn')} [{cfg.get('evidence')}]", 'extra in kit',
                              f"class {'WHEN line ' + str(dispatcher[aid]) if aid in dispatcher else 'no WHEN'}"])
            for p in cfg.get('send', []) + cfg.get('receive', []):
                pass
    res['ajax'] = ajax_rows
    res['ajax_pairs'] = pair_rows
    res['ajax_checks'] = {
        'no_event_id': [a['name'] for a in data['ajax'] if not a['ajax_id']],
        'export_not_in_dispatcher': sorted(i for i in nep_ids if i and i not in dispatcher),
        'dispatcher_not_in_export': sorted(i for i in dispatcher if i not in nep_ids and i != 'ATTACHMENT'),
        'export_not_in_reg04': sorted(i for i in nep_ids if i and i not in reg04),
        'reg04_not_in_export': sorted(i for i in reg04 if i not in nep_ids),
        'dup_event_ids': {k: v for k, v in nep_ids.items() if len(v) > 1},
        'dispatcher_lines': dispatcher, 'commented_when': commented_when, 'reg04_lines': reg04,
        'unresolved_models': {a['ajax_id']: a['unresolved_models'] for a in data['ajax'] if a['unresolved_models']},
    }
    # ajaxSuccess / ajaxError
    rows_ = []
    for a in data['ajax']:
        for evn in ('ajaxSuccess', 'ajaxError'):
            mname = f"{a['ajax_id']}_{evn}"
            code = a[evn]
            has = mname in methods
            if not code and not has:
                continue
            if not has:
                rows_.append([f"{a['name']}.{evn}", '—', 'missing in kit', f"IT_EVENT_SCRIPT {a['field_id']}/{evn} ({len(code.splitlines())} lines)"])
                continue
            body = methods[mname]['body']
            if not code:
                rows_.append([f"{a['name']}.{evn}", f'{mname}()', 'extra in kit', mloc(mname) + '; no code in export'])
                continue
            ratio = similarity(code, kit_body(body))
            todo = 'TODO(CAPTURE)' in body or 'TODO(SPEC-MISSING)' in body
            st = 'same' if ratio >= 0.85 and not todo else 'different'
            rows_.append([f"{a['name']}.{evn}", f'{mname}()', st,
                          f"IT_EVENT_SCRIPT {a['field_id']}/{evn} ({len(code.splitlines())} lines); {mloc(mname)}; similarity {ratio:.2f}"
                          + ('; kit body has TODO marker' if todo else '')])
    res['ajax_handlers'] = rows_

    # ---------- 6. script functions
    rows_, src_diff = [], []
    nep_funcs = {}
    for s in data['scripts']:
        bodies = function_bodies(s['code'])
        for f in s['functions']:
            nep_funcs[f['name']] = (s, f, bodies.get(f['name'], ''))
    for name, (s, f, body) in nep_funcs.items():
        item = f"{name}() [{s['name']}:{f['line']}]"
        if name not in methods:
            rows_.append([item, '—', 'missing in kit', f"IT_SCRIPT {s['field_id']} line {f['line']}"])
            continue
        ratio = similarity(body, kit_body(methods[name]['body']))
        st = 'same' if ratio >= 0.85 else 'different'
        rows_.append([item, f'{name}()', st, f"IT_SCRIPT {s['field_id']} line {f['line']}; {mloc(name)}; similarity {ratio:.2f}"])
    handler_like = re.compile(r'_(ajaxSuccess|ajaxError|press|change|select|search|liveChange|confirm|beforeOpen|valueHelpRequest|delete)$|^getOnline')
    for m in methods:
        if m not in nep_funcs and not handler_like.search(m) and m not in ('model', 'i18n', '_txt', 'onInit'):
            rows_.append(['—', f'{m}()', 'extra in kit', mloc(m)])
    for s in data['scripts']:
        key = {'00000': 'GLOBAL'}.get(s['field_id'], s['name'])
        p = SRC_SCRIPTS.get(key)
        if p and os.path.exists(p):
            src = open(p, encoding='utf-8', errors='replace').read()
            r = difflib.SequenceMatcher(None, [l.strip() for l in src.split('\n') if l.strip()],
                                        [l.strip() for l in s['code'].split('\n') if l.strip()], autojunk=False).ratio()
            src_diff.append([s['name'], p, f'{r:.3f}', len(s['code'].splitlines()), len(src.splitlines())])
        else:
            src_diff.append([s['name'], p or '(no repo copy)', '—', len(s['code'].splitlines()), 0])
    res['functions'] = rows_
    res['script_vs_repo'] = src_diff

    # ---------- 7. text controls (Translate folder + all text-bearing controls referenced by getText) vs i18n
    rows_ = []
    translate = [c for c in data['controls'] if c['parent'] == 'Translate']
    attr_of = defaultdict(dict)
    for a in data['attributes']:
        attr_of[a['control']][a['attribute']] = a['value']
    all_code = '\n'.join([s['code'] for s in data['scripts']] + [e['code'] for e in data['events']])
    referenced = set(re.findall(r'\b(\w+)\.getText\(\)', all_code))
    for c in translate + [ctrls[r] for r in sorted(referenced) if r in ctrls and ctrls[r]['parent'] != 'Translate'
                          and ctrls[r]['type'] == 'UM5_TEXT' and ctrls[r]['name'] not in kit]:
        txt = attr_of[c['name']].get('text', '')
        k = i18n.get(c['name'])
        ev = f"IT_CONTENT {c['field_id']} (parent {c['parent']}); used in code: {'yes' if c['name'] in referenced else 'no'}"
        if not k:
            rows_.append([f"{c['name']} = \"{esc(txt, 70)}\"", '—', 'missing in kit', ev])
        else:
            st = 'same' if k['value'] == txt else 'different'
            rows_.append([f"{c['name']} = \"{esc(txt, 70)}\"", f"{c['name']}={esc(k['value'], 60)}", st,
                          f"{ev}; i18n/i18n.properties:{k['line']}"])
    tnames = {c['name'] for c in translate}
    for k, v in i18n.items():
        if k not in tnames and k not in ('appTitle', 'appDescription'):
            rows_.append(['—', f"{k}={esc(v['value'], 60)}", 'extra in kit', f"i18n/i18n.properties:{v['line']}"])
    res['texts'] = rows_
    res['texts_referenced_missing'] = sorted(r for r in referenced if r not in ctrls)

    # ---------- 8. table fields
    rows_ = []
    for t in data['table_fields']:
        cname = t['control']
        if not cname:
            rows_.append([f"FIELD_ID {t['field_id']} (no control)", ', '.join(f['keyfield'] for f in t['fields']), '—',
                          'orphan IT_TABLE_FIELDS rows (control deleted in designer)'])
            continue
        n = kit.get(cname)
        keys = [f['keyfield'] for f in t['fields']]
        if not n:
            rows_.append([cname, ', '.join(keys), 'missing in kit', f"IT_TABLE_FIELDS {t['field_id']}"])
            continue
        frag = ' '.join(v for el in n.el.iter() for v in el.attrib.values())
        used = set(re.findall(r'\{%s>/?(\w+)\}' % re.escape(cname), frag))
        miss = [k for k in keys if k not in used]
        extra = sorted(used - set(keys))
        st = 'same' if not miss and not extra else 'different'
        rows_.append([f"{cname}: {', '.join(keys)}", 'bound: ' + (', '.join(sorted(used)) or '—'), st,
                      f"IT_TABLE_FIELDS {t['field_id']}; {kloc(n)}" + (f"; not bound in kit: {', '.join(miss)}" if miss else '')
                      + (f"; kit-only: {', '.join(extra)}" if extra else '')])
    res['table_fields'] = rows_

    # ---------- 9. models: original Model Source vs ModelRegistry
    rows_ = []
    for c in data['controls']:
        if c['model_source']:
            k = model_reg.get(c['name'])
            st = 'same' if k == c['model_source'] else ('missing in kit' if k is None else 'different')
            rows_.append([f"{c['name']} → {c['model_source']} ({c['bind_type']})", f"{c['name']} → {k}" if k else '—', st,
                          f"IT_BINDING {c['field_id']}; util/ModelRegistry.js"])
    for k, v in model_reg.items():
        if k not in model_src:
            rows_.append(['—', f'{k} → {v}', 'extra in kit', 'util/ModelRegistry.js'])
    res['models'] = rows_

    # ---------- 10. header / CSS
    man = json.load(open(WEBAPP + '/manifest.json'))
    idx = open(WEBAPP + '/index.html').read()
    theme = re.search(r'data-sap-ui-theme="([^"]+)"', idx)
    res['header'] = {
        'export': data['header'],
        'kit_minUI5Version': man['sap.ui5']['dependencies'].get('minUI5Version'),
        'kit_theme_index_html': theme.group(1) if theme else None,
        'kit_ui5_yaml': [l.strip() for f in os.listdir(KIT) if f.startswith('ui5') and f.endswith('.yaml')
                         for l in open(os.path.join(KIT, f)) if re.search(r'version|theme', l)],
    }
    kit_css = open(WEBAPP + '/css/app.css').read()
    mime_css = open('docs/neptune-export/app.css').read() if os.path.exists('docs/neptune-export/app.css') else ''
    cls = lambda s: sorted(set(re.findall(r'\.([A-Za-z][\w-]*)\s*[{,:\s]', re.sub(r'/\*.*?\*/', '', s, flags=re.S))))
    res['css'] = {'it_css_desktop_classes': cls(data['css']), 'mime_app_css_classes': cls(mime_css),
                  'kit_app_css_classes': cls(kit_css), 'it_css_desktop_lines': len(data['css'].splitlines()),
                  'mime_lines': len(mime_css.splitlines()), 'kit_lines': len(kit_css.splitlines())}

    # ---------- counts
    counts = Counter()
    for key in ('controls', 'attributes', 'events', 'ajax', 'ajax_handlers', 'functions', 'texts', 'table_fields', 'models'):
        for r in res[key]:
            counts[(key, r[2])] += 1
    for r in res['ajax_pairs']:
        counts[('ajax_pairs', r[4])] += 1
    res['counts'] = {f'{k}|{s}': n for (k, s), n in sorted(counts.items())}

    with open(os.path.join(outdir, 'comparison.json'), 'w') as f:
        json.dump(res, f, indent=1, ensure_ascii=False, default=str)
    return res


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    root = ET.parse(sys.argv[1]).getroot()
    mode = sys.argv[2]
    outdir = sys.argv[3] if len(sys.argv) > 3 else 'docs/capture/export-extract'
    if mode == '--structure':
        print_structure(root, int(sys.argv[3]) if len(sys.argv) > 3 else 4)
    elif mode == '--summary':
        print_summary(root)
    elif mode in ('--extract', '--compare'):
        data = extract(root)
        hits = neptune_hits(root, data)
        write_extract(data, hits, outdir)
        print(f"extract: {len(data['controls'])} controls, {len(data['attributes'])} attributes, "
              f"{len(data['events'])} event scripts, {len(data['ajax'])} AJAX objects, {len(data['scripts'])} scripts, "
              f"{len(hits)} 'neptune' hits -> {outdir}")
        if mode == '--compare':
            res = compare(data, outdir)
            for k, v in res['counts'].items():
                print(f'  {k}: {v}')
    else:
        print(__doc__)
        sys.exit(2)


if __name__ == '__main__':
    main()
