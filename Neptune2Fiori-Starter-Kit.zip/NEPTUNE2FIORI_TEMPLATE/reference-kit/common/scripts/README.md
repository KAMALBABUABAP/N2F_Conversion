# Shared scripts

> **Change log** (latest first — add a row for every change)
>
> | Date | Change | Why | By |
> |---|---|---|---|
> | 2026-10-17 | First version, draft for team review | Shared standards for the sap-dev workspace (set up with the NEPTUNE2FIORI_PROJREQ project) | KB |

- `abaplint.json` — offline ABAP parser check for files under a project's `src/abap/`:
  ```zsh
  mkdir -p ~/n2f-lint/src && cd ~/n2f-lint && npm init -y >/dev/null && npm i @abaplint/cli
  cp <project>/src/abap/*.abap ~/n2f-lint/src/ && cp ~/<sap-dev>/common/scripts/abaplint.json ~/n2f-lint/
  for f in ~/n2f-lint/src/*.abap; do mv "$f" "$(echo $f | tr '[:upper:]' '[:lower:]')"; done
  npx abaplint
  ```
- Project-specific scripts stay in the project (`.claude/scripts/`, skill `scripts/`).
