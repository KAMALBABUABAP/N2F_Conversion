# Project <PROJECT> — <one-line goal>

> **Change log** (latest first — add a row for every change)
>
> | Date | Change | Why | By |
> |---|---|---|---|
> | 2026-10-17 | First version, draft for team review | Shared standards for the sap-dev workspace (set up with the NEPTUNE2FIORI_PROJREQ project) | KB |

Read by Claude Code (start `claude` in the project folder). Workspace standards in
`../../common/standards/` apply except where **Overrides** says otherwise.

## Decisions
| Topic | Decision |
|---|---|
| Scope | |
| Backend pattern | |
| Frontend pattern | |
| New object names | listed in `<naming registry file>` — nothing else new |

## Overrides of the workspace standards
| Standard | Applies? / deviation and reason |
|---|---|
| naming-conventions.md | |
| clean-abap.md | |
| testing-abap-unit.md | |
| transport-management.md | |
| code-review-checklist.md | |

## SAP access
SAP ADT MCP rules: `../../common/mcp/README.md`. DEV only; confirm system + client before writes.

## How to work
- Skills: `.claude/skills/...`  ·  Agents: `.claude/agents/...` (`claude --agent <name>`)  ·  Session skills: `/...`
- Hand work between chat sessions through files (`docs/`, registries, `transports/`).

## Layout
| Path | Content |
|---|---|
| `docs/` | specs, exports, reports |
| `src/` | ABAP / UI5 working copies |
| `queries/` | read-only SQL for checks |
| `transports/transport-log.md` | transports |

## Checks after every change
```zsh
# project-specific commands
```
