# Transport log — <PROJECT>

> **Change log** (latest first — add a row for every change)
>
> | Date | Change | Why | By |
> |---|---|---|---|
> | 2026-10-17 | First version, draft for team review | Shared standards for the sap-dev workspace (set up with the NEPTUNE2FIORI_PROJREQ project) | KB |

Rules: `../../common/standards/transport-management.md`. One row per object; update when created, released, imported.

| Transport | Type | Object(s) | Created (date/who) | Released | QA import | PRD import | Notes |
|---|---|---|---|---|---|---|---|
| | Workbench | `ZCL_UI_PROJECT_CODE_REQUEST` | | | | | |
| | Workbench | SEGW `ZDCI_NAD_PROJECT_REQUEST` + generated MPC/DPC(_EXT) | | | | | |
| | Customizing (hub) | Service registration `ZDCI_NAD_PROJECT_REQUEST_SRV` (`/IWFND/MAINT_SERVICE`) | | | | | |
| | Workbench | BSP `ZUI_PROJREQCODE` (`npm run deploy`) | | | | | |
| | Customizing | Launchpad target mapping (existing tile repointed) | | | | | |
| | Workbench | Role / `S_SERVICE` authorization for the service | | | | | |
