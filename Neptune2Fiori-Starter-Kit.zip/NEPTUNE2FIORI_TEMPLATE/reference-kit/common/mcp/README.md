# SAP ADT MCP server — how agents may use it

> **Change log** (latest first — add a row for every change)
>
> | Date | Change | Why | By |
> |---|---|---|---|
> | 2026-10-17 | First version, draft for team review | Shared standards for the sap-dev workspace (set up with the NEPTUNE2FIORI_PROJREQ project) | KB |

> DRAFT for team review. Server: the SAP **ADT MCP server** that comes with *ABAP Development Tools for
> Visual Studio Code* (referred to in the workspace `CLAUDE.md` as `sap-abap-adt`).

## 1. Rules for every agent (Claude Code, any MCP client)

1. **Confirm the target first.** Before the first write in a session, state *system ID, client, user,
   package, transport* and wait for the developer's explicit "yes".
2. **DEV only.** Never write to QA or PRD. Read-only access to QA is allowed only if the developer asks.
3. **Never release or import transports**, never change transport owners, never delete objects without an
   explicit instruction naming the object.
4. **Show results.** After create/write/activate/test, show the tool's result (activation log, syntax
   errors, ATC/unit results). Never claim success that was not returned by a tool.
5. **Smallest change.** Write only the objects the task names; no "while I'm here" edits.
6. **No secrets in chat or files.** Logon data stays in the ADT/VS Code connection, never in prompts,
   `.env` committed files or logs.

## 2. Tool inventory (fill in from your installation)

Ask the agent in a new session: *"List every SAP ADT MCP tool you have, with a one-line description, grouped
as read / write / activate / test / transport / other."* Paste the answer here and keep it current — skills
refer to capabilities, not tool names.

| Group | Tool name | What it does | Allowed for agents |
|---|---|---|---|
| read | | e.g. read class/interface/program source, DDIC definitions, where-used | yes |
| read | | e.g. run SQL/data preview (read-only) | yes, DEV/QA |
| write | | e.g. create object, write source | DEV, after confirmation |
| activate | | e.g. syntax check, activate | DEV |
| test | | e.g. ABAP Unit, ATC | DEV |
| transport | | e.g. list/assign transport | assign only, never release |
| other | | | |

## 3. What usually still needs SAP GUI

SEGW project generation, `/IWFND/MAINT_SERVICE` service registration, `/IWFND/CACHE_CLEANUP`,
`/IWBEP/CACHE_CLEANUP`, `/IWFND/GW_CLIENT`, launchpad customizing, PFCG roles. Agents give exact click paths
and wait for the developer's results. Update this list when the MCP server gains a capability.

## 4. Claude Code setup (company server `mcp-abap-adt-btp`)

The company runs one MCP server on BTP Cloud Foundry that reaches the on-premise systems through BTP Destinations
and the Cloud Connector. Sign-in is OAuth with your BTP user; no SAP password is stored anywhere.

`.mcp.json` in the project folder:
```json
{
  "mcpServers": {
    "sap-adt": {
      "type": "http",
      "url": "https://mcp-abap-adt.cfapps.us10.hana.ondemand.com/mcp/stream/http"
    }
  }
}
```
Same thing from the terminal: `claude mcp add --transport http --scope project sap-adt <url>`.

1. Start `claude` in the project folder, approve the project server, then `/mcp` → `sap-adt` → **Authenticate**
   → sign in with your BTP user in the browser.
2. Call `ListSapSystems`. The project's system must be listed; if not, ask the BTP admin to add it to the
   server's `systems.json` (destination to the Cloud Connector).
3. Every tool call passes `system` (and `client`) from the project `.env`. **Never omit `system`** — the server
   then uses its default (S4D), which is not necessarily your project's system.
4. Health check if something fails: open `https://mcp-abap-adt.cfapps.us10.hana.ondemand.com/mcp/health`.
5. One session per task; run sessions that write to SAP as the main agent (`claude --agent <name>`), because
   subagents cannot ask you for confirmation.
