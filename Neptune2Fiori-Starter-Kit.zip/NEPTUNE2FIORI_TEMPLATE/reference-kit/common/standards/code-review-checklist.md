# Code review checklist

> **Change log** (latest first — add a row for every change)
>
> | Date | Change | Why | By |
> |---|---|---|---|
> | 2026-10-17 | First version, draft for team review | Shared standards for the sap-dev workspace (set up with the NEPTUNE2FIORI_PROJREQ project) | KB |

> DRAFT for team review. Use for every transport before release. Agents use it for self-review and the
> project's reviewer agent for independent review. Tick each line or note "n/a" with a reason.

## A. Scope and traceability
- [ ] Change matches the ticket/requirement; nothing unrelated changed.
- [ ] Names follow `naming-conventions.md` (or the project registry for migrations).
- [ ] Transport description and object descriptions are meaningful.

## B. ABAP
- [ ] Clean ABAP rules (`clean-abap.md`) for new/changed code; migrated copies untouched except documented changes.
- [ ] Syntax check, activation and ATC clean (priority 1/2 = 0).
- [ ] No `SELECT` in loops, no `SELECT *` in productive code, `FOR ALL ENTRIES` with empty check.
- [ ] No `COMMIT WORK` in reusable code / Gateway change sets; locks released on all paths.
- [ ] Exceptions are class-based and handled; no empty `CATCH`; messages from message class.
- [ ] `AUTHORITY-CHECK` for business actions; no hard-coded users, clients, systems or secrets.
- [ ] No dynamic SQL from user input without escaping.

## C. OData / Gateway
- [ ] `$metadata` as designed; property names/types/lengths correct; keys stable.
- [ ] Business errors returned with `/IWBEP/CX_MGW_BUSI_EXCEPTION` and readable messages.
- [ ] No business logic in DPC_EXT beyond mapping/orchestration (logic lives in classes).
- [ ] `$batch`/change-set behaviour understood (no commit inside change sets).
- [ ] Service registered with correct system alias; `S_SERVICE` added to the role.

## D. SAPUI5
- [ ] `ui5lint` clean for the target version (or documented exceptions).
- [ ] No global variables, no private UI5 APIs in new code (migrated code: documented).
- [ ] Texts in i18n; no hard-coded user-facing strings in new code.
- [ ] Busy state released on every success and error path; errors shown to the user.
- [ ] Works in the launchpad (navigation, dirty flag, theme) and standalone.

## E. Tests and evidence (`testing-abap-unit.md`)
- [ ] ABAP Unit passes, coverage meets target for new logic.
- [ ] Gateway Client tests and UI smoke test pass; manual role tests done on DEV.
- [ ] Evidence attached to the ticket/transport log.

## F. Migration / parity projects
- [ ] Behaviour compared with the old app; differences fixed or logged as parity items with owner decision.
- [ ] Old names reused exactly; new objects only from the project naming registry.
- [ ] Rollback path documented (launchpad repoint).

## G. AI-assisted changes
- [ ] Every agent-generated change was read by a human before activation/commit.
- [ ] No claims of tests/activations without evidence; SAP writes happened in DEV only.
- [ ] Prompts/sessions did not expose credentials or personal data.
