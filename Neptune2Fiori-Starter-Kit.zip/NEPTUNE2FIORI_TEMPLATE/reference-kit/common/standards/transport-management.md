# Transport management

> **Change log** (latest first — add a row for every change)
>
> | Date | Change | Why | By |
> |---|---|---|---|
> | 2026-10-17 | First version, draft for team review | Shared standards for the sap-dev workspace (set up with the NEPTUNE2FIORI_PROJREQ project) | KB |

> DRAFT for team review. Landscape assumed: DEV → QA → PRD, central Gateway hub or embedded deployment.

## 1. Golden rules

- Develop and customize **only in DEV**. Agents/tools never write to QA or PRD and never release transports.
- Every change is on a transport owned by a named developer; description per `naming-conventions.md` §5:
  `<PROJECT/TICKET> <short text>`.
- Release only after: activation clean, ATC clean, tests passed (`testing-abap-unit.md`), review done
  (`code-review-checklist.md`).
- Each project keeps `transports/transport-log.md` (template in `common/templates/`).

## 2. What goes on which transport

| Object | Transport type | Notes |
|---|---|---|
| Classes, DDIC, function groups, messages | Workbench (backend) | |
| SEGW project + generated MPC/DPC(_EXT) | Workbench (backend) | together with the classes they call |
| Service registration (`/IWFND/MAINT_SERVICE`), system alias | Customizing (Gateway hub) | separate, imported after the backend transport |
| BSP / UI5 repository app | Workbench (frontend/hub) | created by `fiori deploy` / `/UI5/UI5_REPOSITORY_LOAD` |
| Launchpad catalogs, target mappings, spaces/pages | Customizing (cross-client or client, per setup) | |
| Roles (PFCG) incl. `S_SERVICE` | Workbench / role transport | |
| ICF nodes (`SICF`) activation | done per system or via transport per basis rules | |

## 3. Import order

1. DDIC + backend classes → 2. SEGW/MPC/DPC → 3. service registration (hub) → 4. BSP → 5. launchpad
content → 6. roles. Note dependencies in the transport log; basis imports in this order.

## 4. After import (QA/PRD)

- Gateway: `/IWFND/CACHE_CLEANUP`, `/IWBEP/CACHE_CLEANUP`; check `$metadata`.
- UI5: run `/UI5/APP_INDEX_CALCULATE` for the BSP; clear browser cache; open the tile.
- Smoke test per the project test plan; record result in the transport log.

## 5. Hotfixes

Hotfix transport from DEV only, minimal scope, same review/test gates, imported to QA then PRD. Never
"repair" in QA/PRD.

## 6. Parallel run and rollback (migrations)

Keep the old app running until sign-off. Rollback = repoint the launchpad target mapping back; no object
deletion during hypercare. Decommission old objects in a separate, later transport.
