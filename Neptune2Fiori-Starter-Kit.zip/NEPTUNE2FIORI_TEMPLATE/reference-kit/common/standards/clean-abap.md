# Clean ABAP — team rules (S/4HANA, ABAP 7.57)

> **Change log** (latest first — add a row for every change)
>
> | Date | Change | Why | By |
> |---|---|---|---|
> | 2026-10-17 | First version, draft for team review | Shared standards for the sap-dev workspace (set up with the NEPTUNE2FIORI_PROJREQ project) | KB |

> DRAFT for team review. Based on the SAP Clean ABAP style guide, narrowed to what we enforce.
> Applies to **new and changed code**. **Exception:** copied or migrated logic (e.g. a 1:1 copy of a Neptune
> or legacy class) is not refactored — the project `CLAUDE.md` names those objects.

## 1. Language level

- Modern syntax: inline declarations (`DATA(...)`, `FIELD-SYMBOL(...)`), constructor expressions
  (`VALUE`, `NEW`, `CORRESPONDING`, `COND`, `SWITCH`, `REDUCE`, `FILTER`), string templates `|...|`,
  table expressions with `line_exists( )` / `TRY ... CATCH cx_sy_itab_line_not_found`.
- No obsolete statements: `MOVE`, `COMPUTE`, `CALL METHOD` (static form), `REFRESH`, `DESCRIBE TABLE ... LINES`,
  header lines, `FORM`/`PERFORM` in new code, `TABLES` parameters, `OCCURS`.
- Prefer classes and methods over function modules for new logic; wrap required FMs/BAPIs in a class.

## 2. Names (see `naming-conventions.md`)

- Descriptive names over comments. Methods are verbs (`read_approvers`), booleans read as questions
  (`is_locked`, `has_errors`). Use `abap_true`/`abap_false`, `xsdbool( )`.

## 3. Methods

- One method, one job; aim for ≤ 50 statements and ≤ 3 nesting levels.
- Few importing parameters (≤ 3 preferred); return results via `RETURNING` where possible.
- No boolean "mode" parameters that switch behaviour — split the method.
- Fail fast: validate input at the top; use `RAISE EXCEPTION NEW zcx_...( )` (class-based exceptions);
  never `MESSAGE ... TYPE 'E'` inside a reusable class.

## 4. Classes

- `FINAL` unless designed for inheritance; `CREATE PRIVATE` + factory when instances must be controlled.
- Program against interfaces for dependencies (DB access, BAPIs, time, user) so they can be mocked.
- Keep constants in the class or an interface; no "global constants" god-interfaces.

## 5. Database access

- Open SQL with new syntax (`@`-escaped host variables, comma-separated field lists, `INTO TABLE @DATA(...)`).
- Select only needed fields; no `SELECT *` in productive code (reading for analysis is fine); no
  `SELECT` inside loops — use `FOR ALL ENTRIES` (with non-empty check) or joins/CDS.
- No `COMMIT WORK` in reusable classes or inside Gateway change sets — the caller / framework commits.
- Lock with enqueue FMs; release on every exit path.

## 6. Error handling and messages

- Exception classes per area (`ZCX_<AREA>_...`) with message class texts (`IF_T100_MESSAGE` /
  `IF_T100_DYN_MSG`). Catch narrowly; never empty `CATCH`.
- Log with BAL (application log) for batch/background; Gateway returns business errors via
  `/IWBEP/CX_MGW_BUSI_EXCEPTION` with the message container.

## 7. Formatting and comments

- Pretty printer: keywords upper case, identifiers lower case (team setting in ADT/VS Code).
- Comments explain *why*, not *what*. No commented-out code in new code (Git/version history keeps it).
- `" N2F:`-style tags only where a project asks for change markers.

## 8. Security and authorization

- `AUTHORITY-CHECK` for every business action; never hard-code user names.
- No dynamic SQL/`GENERATE` from user input; escape with `cl_abap_dyn_prg`.
- No secrets in code; RFC destinations/communication arrangements only.

## 9. Static checks before release

- ATC with the team check variant: no priority 1/2 findings; exemptions approved and documented.
- abaplint (offline, optional) with `common/scripts/abaplint.json` for files under `src/`.
- Syntax check and activation clean; no unused variables/methods in new code.
