# Testing — ABAP Unit, OData and UI5

> **Change log** (latest first — add a row for every change)
>
> | Date | Change | Why | By |
> |---|---|---|---|
> | 2026-10-17 | First version, draft for team review | Shared standards for the sap-dev workspace (set up with the NEPTUNE2FIORI_PROJREQ project) | KB |

> DRAFT for team review. What must be tested before a transport is released.

## 1. ABAP Unit

**Required for:** new classes with business logic, bug fixes (a test that reproduces the bug first),
utility classes. **Not required for:** generated code (MPC/DPC base classes), thin wrappers without logic,
1:1 copies of migrated logic (covered by parity tests instead — see the project `CLAUDE.md`).

Rules:
- Local test classes in the class's test include: `CLASS ltc_<topic> DEFINITION FOR TESTING
  RISK LEVEL HARMLESS DURATION SHORT FINAL.`
- Given/When/Then structure; one behaviour per test method; method names describe the behaviour
  (`rejects_empty_comment`).
- No real DB writes, no commits, no RFC/HTTP in unit tests. Isolate dependencies:
  - DB: `cl_osql_test_environment` (Open SQL test double framework) or an injected reader interface;
  - CDS: `cl_cds_test_environment`;
  - Function modules: `cl_function_test_environment` (where available) or a wrapper interface;
  - Classes: interface + test double (`cl_abap_testdouble`) or local fake.
- Assertions with `cl_abap_unit_assert`; check messages/exceptions explicitly.
- Coverage target for new logic: **≥ 70 % statement coverage** (ADT coverage run); critical calculations 100 %.
- Run all tests of the package before release; zero failures.

## 2. OData V2 (SEGW) services

- `$metadata` loads after `/IWFND/CACHE_CLEANUP` + `/IWBEP/CACHE_CLEANUP`; property names/types as designed.
- Gateway Client (`/IWFND/GW_CLIENT`) test case per operation (GET/POST/deep insert/stream), saved in the
  project (`src/gateway-tests/` or the skill's `gateway-client/` folder) with expected status and key fields.
- Negative tests: missing authorization (403), business error (400 with message), wrong key (404).
- Errors visible in `/IWFND/ERROR_LOG` / `/IWBEP/ERROR_LOG` are investigated before release.

## 3. SAPUI5

- Lint clean for the target UI5 version (`ui5lint`; documented exceptions per project).
- Unit tests (QUnit or node tests) for formatters, helpers and client logic.
- Smoke/integration test (OPA5 or Playwright) for the main flow with a mock server — runs without SAP.
- Manual test script per role (requester, approver, display) on DEV with real data; screenshots for sign-off.

## 4. Migration / parity projects

- Every action of the old app is executed side by side with the new one on test data; request/response
  and DB effects are compared (project parity tooling). Every difference is fixed or logged as a parity item
  with an owner decision.

## 5. Evidence

Attach to the transport/ticket: ABAP Unit result (pass + coverage), ATC result, Gateway test results,
UI test results. Agents report only results they actually saw.
