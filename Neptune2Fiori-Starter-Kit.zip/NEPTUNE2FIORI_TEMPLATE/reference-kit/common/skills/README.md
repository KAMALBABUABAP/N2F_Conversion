# Shared skills

> **Change log** (latest first — add a row for every change)
>
> | Date | Change | Why | By |
> |---|---|---|---|
> | 2026-10-17 | First version, draft for team review | Shared standards for the sap-dev workspace (set up with the NEPTUNE2FIORI_PROJREQ project) | KB |

Skills used by more than one project live here, one folder per skill (`<skill-name>/SKILL.md`).

**Discovery:** Claude Code discovers skills in the project's `.claude/skills/` (and your `~/.claude/skills/`)
— not in `common/skills/`. Make a shared
skill visible to a project with a symlink (macOS):
```zsh
cd ~/<sap-dev>/projects/<PROJECT>/.claude/skills
ln -s ../../../../common/skills/<skill-name> <skill-name>
```
Candidates to move here once a second project needs them: "SEGW service from a class", "UI5 freestyle
deploy to BSP", "SAP ADT MCP usage". Project-specific skills (e.g. the Neptune conversion) stay in the project.
