# Project NEPTUNE2FIORI_PROJREQ — Neptune ZDCI_NAD_PROJECT_REQUEST → SEGW OData V2 + freestyle SAPUI5

Apple-to-apple conversion of the Neptune DXP app `ZDCI_NAD_PROJECT_REQUEST`: same names, same behaviour,
no Neptune at runtime. Target: S/4HANA 2022 **or** a new ECC 6.0 system (lift and shift) — see the row
"Target system" below and `docs/decommission-and-ecc.md`.

This file is read by Claude Code (start `claude` in this folder; the workspace `../../CLAUDE.md` is loaded
too). The workspace standards in `../../common/standards/` apply, except where the **Overrides** section below says
otherwise — project rules take precedence (workspace `CLAUDE.md`).

## Fixed decisions (project owner, 2026-10-12) — do not reopen without the owner

| Topic | Decision |
|---|---|
| Backend | SEGW OData V2 project `ZDCI_UI_PROJECT_REQUEST`, service `ZDCI_UI_PROJECT_REQUEST_SRV`, model `ZDCI_UI_PROJECT_REQUEST_MDL`. No RAP, no CAP, no Fiori elements. **Owner-approved name change 2026-10-18:** project was `ZDCI_NAD_PROJECT_REQUEST`; "NAD" → "UI" to match `ZCL_UI_PROJECT_CODE_REQUEST` (registry 01) |
| Logic | Neptune-free copy of `ZCL_NAD_PROJECT_CODE_REQUEST` named `ZCL_UI_PROJECT_CODE_REQUEST`, every member name unchanged |
| OData shape | "AJAX-mirror envelope": one deep-insert POST to `AJAXSet` per Neptune AJAX call; every OData name = ABAP name |
| Quirks | Replicate Neptune behaviour exactly, including bugs; mark `PARITY P-xx`, log in `05-parity-log.md` |
| Frontend | Freestyle SAPUI5 XML views, app id `zdci_nad_project_request`, BSP `ZUI_PROJREQCODE`; every control id, model name, JS function name, i18n key and text kept |
| Names | **No new or changed object names** except those in `.claude/skills/nad-project-request-registry/references/01-naming-registry.md` |
| Commands | The developer works on macOS — terminal commands in zsh only, never Windows/PowerShell |
| Original class | `ZCL_NAD_PROJECT_CODE_REQUEST` (Neptune) is **not used at runtime** by the new solution and will be deleted after go-live. Never read it from SAP, never reference it in code; the source is `docs/neptune-source/Backend Class/ProjectRequest App.txt`. Deletion only after the where-used check in `docs/decommission-and-ecc.md`. |
| Target system | S/4HANA or ECC 6.0 — minimum SAP_BASIS 7.40 SP05 (abaplint-verified). Before S3: record SAP_BASIS, SAP_UI, SAP_GWFND/IW_BEP in `.env`; if SAPUI5 < 1.108 apply the ECC checks in `docs/decommission-and-ecc.md`. |
| SEGW data model | **Owner requirement 2026-10-18:** the final SEGW project shows the full model in its **Data Model** folder — entity types, entity sets, all properties, complex types, associations/navigation properties and the `ATTACHMENT` media entity. B2 creates the project empty (no hand-modelled entities); B3 proves the envelope with the code-built (RTTI) `MPC_EXT` + spike; **B3b** imports the proven `$metadata` (Data Model → Import → Data Model from File), regenerates, and reduces `MPC_EXT` to what SEGW cannot express (the deep structure for the deep insert). Names and types stay identical to the proven model. |
| Framework licence | The Neptune licence is removed from S/4: **no SAP object, type, data element, structure, variable, path or literal used by the new solution may start with or contain `NEPTUNE`** or use `/NEPTUNE/`. Replace with standard SAP objects; log every case in `docs/replacements/` (register + one `<session>-replacements.txt` per chat). The only accepted reason to change an original name. |

## Overrides of the workspace standards (`common/standards/`)

| Standard | Applies here? |
|---|---|
| `naming-conventions.md` | **Not** to anything that exists in Neptune (class members, AJAX IDs, DDIC, control IDs, models, JS functions). Only the new objects in `01-naming-registry.md` follow it, and they are already decided. |
| `clean-abap.md` | **Not** to `ZCL_UI_PROJECT_CODE_REQUEST` — it is a 1:1 copy; no refactoring, renaming, reformatting or "modernising". Applies to new code in `MPC_EXT` / `DPC_EXT`. |
| `testing-abap-unit.md` | No test class is added to `ZCL_UI_PROJECT_CODE_REQUEST`. ABAP Unit for `DPC_EXT` helpers is allowed. Parity tests (Gateway Client, `parity_diff.py`, UI test plan) are mandatory. |
| `transport-management.md` | Applies fully. Transport list in `transports/transport-log.md`. |
| `code-review-checklist.md` | Applies, plus: review against **Neptune behaviour**, not best practice. A behaviour difference is a parity item, never a silent fix. |

## Code comments

**Comments (owner decision 2026-10-17):** keep every original comment of the Neptune class as it is. Every new conversion comment is **one short line**: the transport number, then a few words — e.g. `" S4MK900123 SERVER removed` or `* S4MK900123 Local message type`. No multi-line explanations in code; details go in the registries/docs. The converter writes `<TR>`; B1 runs it with the workbench transport from `.env` so `<TR>` becomes the real number. The only original lines touched are old commented-out lines that used the variable `ls_neptune_message` (renamed `ls_message`, licence rule).

## Standards by file type

- Editing `*.abap`: new/changed code in `MPC_EXT`/`DPC_EXT` follows `../../common/standards/clean-abap.md` and
  `naming-conventions.md`; `ZCL_UI_PROJECT_CODE_REQUEST` is never refactored.
- Editing `webapp/**`: SAPUI5 section of `../../common/standards/code-review-checklist.md` and the UI5 part of
  `testing-abap-unit.md`; ids, model names, function names and texts stay as in Neptune.

## Evidence

Never claim an activation, test or deployment result you did not see. Mark guesses `TODO(SPEC-MISSING)` /
`ASSUMPTION`. Never commit `.env`, `*.har` or anything with cookies or passwords; never `git push` without asking.

## SAP access (SAP ADT MCP server)

Server: company wrapper `mcp-abap-adt-btp` (BTP Cloud Foundry → Destination → Cloud Connector), configured in
`.mcp.json` as `sap-adt`; sign-in is BTP/XSUAA OAuth (`/mcp` → authenticate) — never put SAP user or password in
any file. **Every SAP tool call must pass `system` = `SAP_SYSTEM_ID` from `.env` (S4M) and `client` = `SAP_CLIENT`
(100).** Never omit `system`: the server default is a different system (S4D). Start each session with
`ListSapSystems` and confirm S4M is listed. Rules in `../../common/mcp/README.md`. In short: confirm system ID + client before the first write of a
session; write to **DEV only**; never QA/PRD; never release transports; show activation results. What the
MCP server cannot do (SEGW generation, `/IWFND/MAINT_SERVICE`, cache cleanup, Gateway Client, launchpad
customizing) the developer does in SAP GUI and reports back. Never claim an activation or a test you did not see.

## How to work

- Load the skill that fits before acting (`.claude/skills/`):
  - `nad-project-request-registry` — names, AJAX inventory, models, controls, parity log, source-of-truth order
  - `neptune-to-segw-backend` — ABAP class, SEGW, MPC_EXT/DPC_EXT, Gateway tests (steps B0–B7)
  - `neptune-to-ui5-frontend` — UI5 app, AjaxRuntime client, tests, BSP deploy (steps F0–F6)
  - `abap-adt-workflow` (shared, `common/skills/`) — every SAP write via ADT MCP + the standard ABAP response format
- Agents (`.claude/agents/`): `neptune-abap-converter`, `neptune-ui5-converter`,
  `neptune-parity-reviewer` (read-only audit before any sign-off). Start a session **as** an agent with
  `claude --agent <name>` — then it can ask for confirmation. As a subagent it cannot ask questions, so never
  delegate SAP writes to a subagent.
- Session skills (type `/` in Claude Code; only run when invoked): `/n2f-s0-setup-check`, `/n2f-s1-coverage-audit`,
  `/n2f-s2-close-gaps`, `/n2f-s3-backend`, `/n2f-s4-frontend`, `/n2f-s5-parity-test`, `/n2f-s6-deploy`, `/n2f-qa`.
- Order: backend B0–B3 (spike) → frontend F0–F3 → close gaps with the Neptune XML export / capture →
  parity tests → deploy.
- Sources disagree → `09-source-of-truth.md` (Neptune XML export / live capture > ABAP source > SE11 > JS >
  specs). Never copy the "Fiori migration" snippets inside the specs; they rename things.
- Sessions do not share memory (use `/clear` or a new `claude` between sessions). Hand work over through files: registries, `docs/`, `transports/`.
  When you confirm or correct something, update the registry file in the same change.
- Edits from the VS Code Claude Code extension must follow the same rules: a Neptune function body is ported
  verbatim except the mechanical replacements in `neptune-to-ui5-frontend/references/js-port-rules.md`.

## Folder layout

| Path | Content |
|---|---|
| `docs/neptune-source/` | Neptune repo: `Backend Class/ProjectRequest App.txt`, `Ajax/`, `DB Model/`, `Init.txt`, `Utility.txt`, `form.txt`, specs |
| `docs/neptune-export/` | Neptune XML export, `discoveryFiori.js`, `app.css`, template `.xlsx` (you add them) |
| `docs/capture/`, `docs/ajax-params/` | HAR report (never the `.har`), designer copies |
| `docs/coverage-report.md` | Output of session S1 |
| `src/abap/` | Working copies of `ZCL_UI_PROJECT_CODE_REQUEST`, `MPC_EXT`, `DPC_EXT` (+ `abaplint.json`) |
| `src/ui5/zdci_nad_project_request/` | The UI5 app (`webapp/`, `package.json`, `ui5*.yaml`) |
| `queries/` | Parity-check SQL (ADT SQL console / SE16) |
| `docs/replacements/` | Licence-removal register + one replacement log per chat session |
| `transports/transport-log.md` | Every transport of this project |
| `.claude/skills/` | The three skills (pristine reference code in their `assets/`) |
| `.claude/agents/` | The three agents |
| `.claude/settings.json` | Team permissions (allow checks, deny pushes and secret files) |
| `.mcp.json` (from `.mcp.json.example`) | The SAP ADT MCP server for Claude Code |
| `.env` (not committed) / `.env.example` | System, client, package, transport, UI5 version |

## Checks after every change

```zsh
python3 .claude/scripts/verify_kit.py                        # must print KIT OK
cd src/ui5/zdci_nad_project_request && npm run test:unit      # conversion tests
```
Smoke test and lint: `neptune-to-ui5-frontend/references/test-plan.md`.
