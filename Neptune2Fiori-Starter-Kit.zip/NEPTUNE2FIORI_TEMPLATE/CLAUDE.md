# Project NEPTUNE2FIORI_<SHORTNAME> — Neptune <NEPTUNE_APP> → SEGW OData V2 + freestyle SAPUI5

**Status: bootstrap. The project kit is not built yet → run the K0 prompt in `KICKOFF-PROMPT.md`.**
K0 replaces this file with the full version (built from `reference-kit/CLAUDE.md` + `docs/app-facts.md`); every rule
below stays.

Apple-to-apple conversion of the Neptune app `<NEPTUNE_APP>`: same names, same behaviour, no Neptune at runtime.
Method and lessons: `playbook/`. Facts and decisions for this app: `docs/app-facts.md`.

## Fixed decisions (owner <OWNER>, <DATE>)

| Topic | Decision |
|---|---|
| Method | SEGW OData V2 "AJAX-mirror envelope", freestyle SAPUI5, no RAP/CAP/Fiori elements; every OData name = ABAP name |
| Names | No new or changed names except the naming registry; new ABAP/SEGW objects as agreed in K0 (`docs/app-facts.md` §2) |
| Quirks | Replicate Neptune behaviour exactly, including bugs; mark `PARITY P-xx`, log in the parity log |
| Target | <SYSTEM>, client <CLIENT> (DEV), package `<PACKAGE>`, workbench `<TR_WB>`, customizing `<TR_CU>` |
| Licence | No SAP object, type, data element, structure, variable, path, literal, description or comment used by the new solution may start with or contain `NEPTUNE` or use `/NEPTUNE/`; log every case in `docs/replacements/` |
| Comments | Keep every original comment; every new conversion comment is one short line: transport number + a few words (no "framework", no "neptune") |
| Commands | macOS zsh only |

## Boundaries

- **Read-only:** `reference-kit/` (copy of the first project's kit) — adapt copies, never edit it.
- **SAP:** ADT MCP, DEV only, `system` and `client` on every call, `ListSapSystems` first, owner "yes" before the first
  write, never release transports. SAP writes only in a main session started as the agent, never a subagent.
  K0 and K1 make no SAP calls.
- **Evidence:** never claim an activation, test or deployment result you did not see. Mark guesses
  `TODO(SPEC-MISSING)` / `ASSUMPTION`. Never commit `.env`, `*.har` or anything with cookies or passwords; never push.
- **Documents** end with "Created using Anthropic Claude" and the internal-review note.
