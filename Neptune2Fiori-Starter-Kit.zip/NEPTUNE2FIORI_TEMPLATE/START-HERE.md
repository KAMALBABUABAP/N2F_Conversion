# Neptune → Fiori starter kit — start here

Converts one Neptune DXP app into a **SEGW OData V2 service + freestyle SAPUI5 app**, apple-to-apple (same names,
same behaviour, Neptune bugs kept as logged parity items), with Claude Code and the SAP ADT MCP server.
Built from the first conversion (`ZDCI_NAD_PROJECT_REQUEST`, 2026-10).

## What is in this zip

| Path | What |
|---|---|
| `START-HERE.md` | This page |
| `KICKOFF-PROMPT.md` | The first two Claude Code prompts (K0 kickoff, K1 backend assets) — fill the `<…>` values |
| `CLAUDE.md` | Starter project rules (K0 writes the full version) — fill the `<…>` values |
| `docs/app-facts.md` | Your app's facts and decisions — fill before K0 |
| `playbook/` | The method, lessons learned, all session prompts (template), reuse map — read `playbook/README.md` |
| `reference-kit/` | **Read-only** copy of the first project's Claude Code kit (agents, skills, scripts, prompts, workspace standards in `reference-kit/common/`). K0 adapts it for your app. Wherever the playbook says `projects/NEPTUNE2FIORI_PROJREQ/`, use `reference-kit/` |
| `docs/…`, `src/…`, `queries/`, `transports/` | Empty project skeleton |

## Steps

1. **Prerequisites (Mac):** Claude Code (terminal or VS Code extension), Node.js 20+, Python 3, git; access to the
   SAP ADT MCP server (BTP sign-in through `/mcp`); a DEV package and a workbench + customizing transport.
2. **Unzip** into your workspace, e.g. `sap-dev/projects/`, and rename the folder to `NEPTUNE2FIORI_<SHORTNAME>`.
3. **Drop the inputs:**
   - Neptune backend class source (SE24 → source-based view → copy all) → `docs/neptune-source/Backend Class/<name>.txt`
   - Neptune XML export of the app + the MIME files it loads (`app.css`, shared JS such as `discoveryFiori.js`,
     templates) → `docs/neptune-export/`
   - Neptune screenshots, window width in the file name (e.g. `01_main_1292.png`) → `docs/capture/layout/neptune/`
4. **Fill** `docs/app-facts.md` §1–§2 and replace the `<…>` values in `CLAUDE.md` and `KICKOFF-PROMPT.md`.
5. **K0:**
   ```zsh
   cd ~/<workspace>/projects/NEPTUNE2FIORI_<SHORTNAME>
   claude --model opus
   ```
   Paste the K0 prompt; answer its questions; approve the kit plan; it builds and commits the kit.
6. **K1** in a new chat (`claude --agent neptune-abap-converter`): backend assets, offline.
7. **Sessions S0 → S6** from `docs/claude-code-session-prompts.md` (K0 creates it from
   `playbook/03-session-prompts-template.md`). One chat per session; commit after each; never push without review.

## Rules that save the most rework (details: `playbook/01-method.md`, `playbook/02-lessons-learned.md`)

- Build the UI **from the XML export**, never from specs. Parse it with `parse_export.py`; never read it by hand.
- Same names everywhere; behaviour that looks wrong stays and becomes `P-xx` in the parity log.
- Nothing new may contain `NEPTUNE` (code, comments, texts, descriptions); every case is logged in `docs/replacements/`.
- SAP writes only in a main session started **as** the agent, DEV only, after your "yes"; `system` + `client` on every call.
- Decide all object names **before** SEGW: SEGW truncates the project name in the generated class names and can collide with existing classes.
- Dates: the Gateway date trap (HTTP 500 `'0000-00-00'`) is fixed in MPC_EXT with `set_internal_type( typekind_char )` for D/T.
- Large ABAP classes hit HTTP 413 through the MCP: create the shell via MCP, paste the source in SE24, verify by counts.

---
Created using Anthropic Claude — internal working document; keep it on internal versions until a human has reviewed and
verified the content. Share only with people authorized to see the source material.
